/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon;

import cn.axeon.IPlayer;
import cn.axeon.Nukkit;
import cn.axeon.OfflinePlayer;
import cn.axeon.Player;
import cn.axeon.block.Block;
import cn.axeon.blockentity.BlockEntity;
import cn.axeon.blockentity.BlockEntityBrewingStand;
import cn.axeon.blockentity.BlockEntityChest;
import cn.axeon.blockentity.BlockEntityEnchantTable;
import cn.axeon.blockentity.BlockEntityFlowerPot;
import cn.axeon.blockentity.BlockEntityFurnace;
import cn.axeon.blockentity.BlockEntitySign;
import cn.axeon.blockentity.BlockEntitySkull;
import cn.axeon.command.Command;
import cn.axeon.command.CommandReader;
import cn.axeon.command.CommandSender;
import cn.axeon.command.ConsoleCommandSender;
import cn.axeon.command.PluginIdentifiableCommand;
import cn.axeon.command.SimpleCommandMap;
import cn.axeon.entity.Attribute;
import cn.axeon.entity.Entity;
import cn.axeon.entity.EntityHuman;
import cn.axeon.entity.data.Skin;
import cn.axeon.entity.item.EntityBoat;
import cn.axeon.entity.item.EntityExpBottle;
import cn.axeon.entity.item.EntityFallingBlock;
import cn.axeon.entity.item.EntityItem;
import cn.axeon.entity.item.EntityMinecartEmpty;
import cn.axeon.entity.item.EntityPainting;
import cn.axeon.entity.item.EntityPotion;
import cn.axeon.entity.item.EntityPrimedTNT;
import cn.axeon.entity.item.EntityXPOrb;
import cn.axeon.entity.mob.EntityCreeper;
import cn.axeon.entity.passive.EntityChicken;
import cn.axeon.entity.passive.EntityCow;
import cn.axeon.entity.passive.EntityOcelot;
import cn.axeon.entity.passive.EntityPig;
import cn.axeon.entity.passive.EntityRabbit;
import cn.axeon.entity.passive.EntitySheep;
import cn.axeon.entity.passive.EntityWolf;
import cn.axeon.entity.projectile.EntityArrow;
import cn.axeon.entity.projectile.EntitySnowball;
import cn.axeon.entity.weather.EntityLightning;
import cn.axeon.event.HandlerList;
import cn.axeon.event.TextContainer;
import cn.axeon.event.TranslationContainer;
import cn.axeon.event.level.LevelInitEvent;
import cn.axeon.event.level.LevelLoadEvent;
import cn.axeon.event.server.QueryRegenerateEvent;
import cn.axeon.inventory.CraftingManager;
import cn.axeon.inventory.FurnaceRecipe;
import cn.axeon.inventory.InventoryType;
import cn.axeon.inventory.Recipe;
import cn.axeon.inventory.ShapedRecipe;
import cn.axeon.inventory.ShapelessRecipe;
import cn.axeon.item.Item;
import cn.axeon.item.enchantment.Enchantment;
import cn.axeon.lang.BaseLang;
import cn.axeon.level.Level;
import cn.axeon.level.Position;
import cn.axeon.level.format.LevelProvider;
import cn.axeon.level.format.LevelProviderManager;
import cn.axeon.level.format.anvil.Anvil;
import cn.axeon.level.format.leveldb.LevelDB;
import cn.axeon.level.format.mcregion.McRegion;
import cn.axeon.level.generator.Flat;
import cn.axeon.level.generator.Generator;
import cn.axeon.level.generator.Normal;
import cn.axeon.level.generator.biome.Biome;
import cn.axeon.math.NukkitMath;
import cn.axeon.metadata.EntityMetadataStore;
import cn.axeon.metadata.LevelMetadataStore;
import cn.axeon.metadata.PlayerMetadataStore;
import cn.axeon.nbt.NBTIO;
import cn.axeon.nbt.tag.CompoundTag;
import cn.axeon.nbt.tag.DoubleTag;
import cn.axeon.nbt.tag.FloatTag;
import cn.axeon.nbt.tag.ListTag;
import cn.axeon.network.CompressBatchedTask;
import cn.axeon.network.Network;
import cn.axeon.network.RakNetInterface;
import cn.axeon.network.SourceInterface;
import cn.axeon.network.protocol.BatchPacket;
import cn.axeon.network.protocol.CraftingDataPacket;
import cn.axeon.network.protocol.DataPacket;
import cn.axeon.network.protocol.PlayerListPacket;
import cn.axeon.network.query.QueryHandler;
import cn.axeon.permission.BanEntry;
import cn.axeon.permission.BanList;
import cn.axeon.permission.DefaultPermissions;
import cn.axeon.permission.Permissible;
import cn.axeon.plugin.JavaPluginLoader;
import cn.axeon.plugin.Plugin;
import cn.axeon.plugin.PluginLoadOrder;
import cn.axeon.plugin.PluginManager;
import cn.axeon.potion.Effect;
import cn.axeon.potion.Potion;
import cn.axeon.scheduler.FileWriteTask;
import cn.axeon.scheduler.ServerScheduler;
import cn.axeon.utils.Binary;
import cn.axeon.utils.Config;
import cn.axeon.utils.ConfigSection;
import cn.axeon.utils.LevelException;
import cn.axeon.utils.MainLogger;
import cn.axeon.utils.ServerException;
import cn.axeon.utils.ServerKiller;
import cn.axeon.utils.Utils;
import cn.axeon.utils.Zlib;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Random;
import java.util.Set;
import java.util.UUID;

public class Server {
    public static final String BROADCAST_CHANNEL_ADMINISTRATIVE = "nukkit.broadcast.admin";
    public static final String BROADCAST_CHANNEL_USERS = "nukkit.broadcast.user";
    private static Server instance = null;
    private BanList banByName = null;
    private BanList banByIP = null;
    private Config operators = null;
    private Config whitelist = null;
    private boolean isRunning = true;
    private boolean hasStopped = false;
    private PluginManager pluginManager = null;
    private int profilingTickrate = 20;
    private ServerScheduler scheduler = null;
    private int tickCounter;
    private long nextTick;
    private float[] tickAverage = new float[]{20.0f, 20.0f, 20.0f, 20.0f, 20.0f, 20.0f, 20.0f, 20.0f, 20.0f, 20.0f, 20.0f, 20.0f, 20.0f, 20.0f, 20.0f, 20.0f, 20.0f, 20.0f, 20.0f, 20.0f};
    private float[] useAverage = new float[]{0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f};
    private float maxTick = 20.0f;
    private float maxUse = 0.0f;
    private int sendUsageTicker = 0;
    private boolean dispatchSignals = false;
    private MainLogger logger;
    private CommandReader console;
    private SimpleCommandMap commandMap;
    private CraftingManager craftingManager;
    private ConsoleCommandSender consoleSender;
    private int maxPlayers;
    private boolean autoSave;
    private EntityMetadataStore entityMetadata;
    private PlayerMetadataStore playerMetadata;
    private LevelMetadataStore levelMetadata;
    private Network network;
    private boolean networkCompressionAsync = true;
    public int networkCompressionLevel = 7;
    private boolean autoTickRate = true;
    private int autoTickRateLimit = 20;
    private boolean alwaysTickPlayers = false;
    private int baseTickRate = 1;
    private int autoSaveTicker = 0;
    private int autoSaveTicks = 6000;
    private BaseLang baseLang;
    private boolean forceLanguage = false;
    private UUID serverID;
    private String filePath;
    private String dataPath;
    private String pluginPath;
    private Set<UUID> uniquePlayers = new HashSet<UUID>();
    private QueryHandler queryHandler;
    private QueryRegenerateEvent queryRegenerateEvent;
    private Config properties;
    private Config config;
    private Map<String, Player> players = new HashMap<String, Player>();
    private Map<UUID, Player> playerList = new HashMap<UUID, Player>();
    private Map<Integer, String> identifier = new HashMap<Integer, String>();
    private Map<Integer, Level> levels = new HashMap<Integer, Level>();
    private Level defaultLevel = null;

    public Server(MainLogger logger, String filePath, String dataPath, String pluginPath) {
        int threshold;
        instance = this;
        this.logger = logger;
        this.filePath = filePath;
        if (!new File(dataPath + "worlds/").exists()) {
            new File(dataPath + "worlds/").mkdirs();
        }
        if (!new File(dataPath + "players/").exists()) {
            new File(dataPath + "players/").mkdirs();
        }
        if (!new File(pluginPath).exists()) {
            new File(pluginPath).mkdirs();
        }
        this.dataPath = new File(dataPath).getAbsolutePath() + "/";
        this.pluginPath = new File(pluginPath).getAbsolutePath() + "/";
        this.console = new CommandReader();
        if (!new File(this.dataPath + "axeon.yml").exists()) {
            this.getLogger().info("\u00a7aWelcome! Please choose a language first!");
            try {
                String[] lines;
                for (String line : lines = Utils.readFile(this.getClass().getClassLoader().getResourceAsStream("lang/language.list")).split("\n")) {
                    this.getLogger().info(line);
                }
            }
            catch (IOException e) {
                throw new RuntimeException(e);
            }
            String fallback = "eng";
            String language = null;
            while (language == null) {
                String lang = this.console.readLine();
                InputStream conf = this.getClass().getClassLoader().getResourceAsStream("lang/" + lang + "/lang.ini");
                if (conf == null) continue;
                language = lang;
            }
            InputStream advacedConf = this.getClass().getClassLoader().getResourceAsStream("lang/" + language + "/axeon.yml");
            if (advacedConf == null) {
                advacedConf = this.getClass().getClassLoader().getResourceAsStream("lang/" + fallback + "/axeon.yml");
            }
            try {
                Utils.writeFile(this.dataPath + "axeon.yml", advacedConf);
            }
            catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
        this.console.start();
        this.logger.info("Loading \u00a7aaxeon.yml\u00a7f...");
        this.config = new Config(this.dataPath + "axeon.yml", 2);
        this.logger.info("Loading \u00a7aserver properties\u00a7f...");
        this.properties = new Config(this.dataPath + "server.properties", 0, new ConfigSection(){
            {
                this.put("motd", "Nukkit Server For Minecraft: PE");
                this.put("server-port", 19132);
                this.put("server-ip", "0.0.0.0");
                this.put("view-distance", 10);
                this.put("white-list", false);
                this.put("announce-player-achievements", true);
                this.put("spawn-protection", 16);
                this.put("max-players", 20);
                this.put("allow-flight", false);
                this.put("spawn-animals", true);
                this.put("spawn-mobs", true);
                this.put("gamemode", 0);
                this.put("force-gamemode", false);
                this.put("hardcore", false);
                this.put("pvp", true);
                this.put("difficulty", 1);
                this.put("generator-settings", "");
                this.put("level-name", "world");
                this.put("level-seed", "");
                this.put("level-type", "DEFAULT");
                this.put("enable-query", true);
                this.put("enable-rcon", false);
                this.put("rcon.password", Base64.getEncoder().encodeToString(UUID.randomUUID().toString().replace("-", "").getBytes()).substring(3, 13));
                this.put("auto-save", true);
            }
        });
        this.forceLanguage = (Boolean)this.getConfig("settings.force-language", false);
        this.baseLang = new BaseLang((String)this.getConfig("settings.language", "eng"));
        this.logger.info(this.getLanguage().translateString("language.selected", new String[]{this.getLanguage().getName(), this.getLanguage().getLang()}));
        this.logger.info(this.getLanguage().translateString("nukkit.server.start", "\u00a7b" + this.getVersion() + "\u00a7f"));
        Object poolSize = this.getConfig("settings.async-workers", "auto");
        if (!(poolSize instanceof Integer)) {
            try {
                poolSize = Integer.valueOf((String)poolSize);
            }
            catch (Exception e) {
                poolSize = Math.max(Runtime.getRuntime().availableProcessors() + 1, 4);
            }
        }
        ServerScheduler.WORKERS = (Integer)poolSize;
        try {
            threshold = Integer.valueOf(String.valueOf(this.getConfig("network.batch-threshold", 256)));
        }
        catch (Exception e) {
            threshold = 256;
        }
        if (threshold < 0) {
            threshold = -1;
        }
        Network.BATCH_THRESHOLD = threshold;
        this.networkCompressionLevel = (Integer)this.getConfig("network.compression-level", 7);
        this.networkCompressionAsync = (Boolean)this.getConfig("network.async-compression", true);
        this.networkCompressionLevel = (Integer)this.getConfig("network.compression-level", 7);
        this.networkCompressionAsync = (Boolean)this.getConfig("network.async-compression", true);
        this.autoTickRate = (Boolean)this.getConfig("level-settings.auto-tick-rate", true);
        this.autoTickRateLimit = (Integer)this.getConfig("level-settings.auto-tick-rate-limit", 20);
        this.alwaysTickPlayers = (Boolean)this.getConfig("level-settings.always-tick-players", false);
        this.baseTickRate = (Integer)this.getConfig("level-settings.base-tick-rate", 1);
        this.scheduler = new ServerScheduler();
        this.entityMetadata = new EntityMetadataStore();
        this.playerMetadata = new PlayerMetadataStore();
        this.levelMetadata = new LevelMetadataStore();
        this.operators = new Config(this.dataPath + "ops.txt", 5);
        this.whitelist = new Config(this.dataPath + "white-list.txt", 5);
        this.banByName = new BanList(this.dataPath + "banned-players.json");
        this.banByName.load();
        this.banByIP = new BanList(this.dataPath + "banned-ips.json");
        this.banByIP.load();
        this.maxPlayers = this.getPropertyInt("max-players", 20);
        this.setAutoSave(this.getPropertyBoolean("auto-save", true));
        if (this.getPropertyBoolean("hardcore", false) && this.getDifficulty() < 3) {
            this.setPropertyInt("difficulty", 3);
        }
        Nukkit.DEBUG = (Integer)this.getConfig("debug.level", 1);
        if (this.logger instanceof MainLogger) {
            this.logger.setLogDebug(Nukkit.DEBUG > 1);
        }
        this.logger.info(this.getLanguage().translateString("nukkit.server.networkStart", new String[]{this.getIp().equals("") ? "*" : this.getIp(), String.valueOf(this.getPort())}));
        this.serverID = UUID.randomUUID();
        this.network = new Network(this);
        this.network.setName(this.getMotd());
        this.logger.info(this.getLanguage().translateString("nukkit.server.info", new String[]{this.getName(), "\u00a7e" + this.getNukkitVersion() + "\u00a7f", "\u00a7b" + this.getCodename() + "\u00a7f", this.getApiVersion()}));
        this.logger.info(this.getLanguage().translateString("nukkit.server.license", this.getName()));
        this.consoleSender = new ConsoleCommandSender();
        this.commandMap = new SimpleCommandMap(this);
        this.registerEntities();
        this.registerBlockEntities();
        InventoryType.init();
        Block.init();
        Item.init();
        Biome.init();
        Effect.init();
        Potion.init();
        Enchantment.init();
        Attribute.init();
        this.craftingManager = new CraftingManager();
        this.pluginManager = new PluginManager(this, this.commandMap);
        this.pluginManager.subscribeToPermission(BROADCAST_CHANNEL_ADMINISTRATIVE, this.consoleSender);
        this.pluginManager.registerInterface(JavaPluginLoader.class);
        this.queryRegenerateEvent = new QueryRegenerateEvent(this, 5);
        this.network.registerInterface(new RakNetInterface(this));
        this.pluginManager.loadPlugins(this.pluginPath);
        this.enablePlugins(PluginLoadOrder.STARTUP);
        LevelProviderManager.addProvider(this, Anvil.class);
        LevelProviderManager.addProvider(this, McRegion.class);
        LevelProviderManager.addProvider(this, LevelDB.class);
        Generator.addGenerator(Flat.class, "flat", 2);
        Generator.addGenerator(Normal.class, "normal", 1);
        Generator.addGenerator(Normal.class, "default", 1);
        for (Object nameObj : ((Map)this.getConfig("worlds", new HashMap())).keySet()) {
            String name = (String)nameObj;
            long seed;
            if (this.loadLevel(name)) continue;
            try {
                seed = ((Integer)this.getConfig("worlds." + name + ".seed")).longValue();
            }
            catch (Exception e) {
                seed = System.currentTimeMillis();
            }
            HashMap<String, Object> options = new HashMap<String, Object>();
            String[] opts = ((String)this.getConfig("worlds." + name + ".generator", Generator.getGenerator("default").getSimpleName())).split(":");
            Class<? extends Generator> generator = Generator.getGenerator(opts[0]);
            if (opts.length > 1) {
                String preset = "";
                for (int i = 1; i < opts.length; ++i) {
                    preset = preset + opts[i] + ":";
                }
                preset = preset.substring(0, preset.length() - 1);
                options.put("preset", preset);
            }
            this.generateLevel(name, seed, generator, options);
        }
        if (this.getDefaultLevel() == null) {
            String defaultName = this.getPropertyString("level-name", "world");
            if (defaultName == null || "".equals(defaultName.trim())) {
                this.getLogger().warning("level-name cannot be null, using default");
                defaultName = "world";
                this.setPropertyString("level-name", defaultName);
            }
            if (!this.loadLevel(defaultName)) {
                long seed;
                String seedString = String.valueOf(this.getProperty("level-seed", System.currentTimeMillis()));
                try {
                    seed = Long.valueOf(seedString);
                }
                catch (NumberFormatException e) {
                    seed = seedString.hashCode();
                }
                this.generateLevel(defaultName, seed == 0L ? System.currentTimeMillis() : seed);
            }
            this.setDefaultLevel(this.getLevelByName(defaultName));
        }
        this.properties.save(true);
        if (this.getDefaultLevel() == null) {
            this.getLogger().emergency(this.getLanguage().translateString("nukkit.level.defaultError"));
            this.forceShutdown();
            return;
        }
        this.enablePlugins(PluginLoadOrder.POSTWORLD);
        this.queryRegenerateEvent = new QueryRegenerateEvent(this, 5);
        this.start();
    }

    public int broadcastMessage(String message) {
        return this.broadcast(message, BROADCAST_CHANNEL_USERS);
    }

    public int broadcastMessage(TextContainer message) {
        return this.broadcast(message, BROADCAST_CHANNEL_USERS);
    }

    public int broadcastMessage(String message, CommandSender[] recipients) {
        for (CommandSender recipient : recipients) {
            recipient.sendMessage(message);
        }
        return recipients.length;
    }

    public int broadcastMessage(String message, Collection<CommandSender> recipients) {
        for (CommandSender recipient : recipients) {
            recipient.sendMessage(message);
        }
        return recipients.size();
    }

    public int broadcastMessage(TextContainer message, Collection<CommandSender> recipients) {
        for (CommandSender recipient : recipients) {
            recipient.sendMessage(message);
        }
        return recipients.size();
    }

    public int broadcast(String message, String permissions) {
        HashSet<CommandSender> recipients = new HashSet<CommandSender>();
        for (String permission : permissions.split(";")) {
            for (Permissible permissible : this.pluginManager.getPermissionSubscriptions(permission)) {
                if (!(permissible instanceof CommandSender) || !permissible.hasPermission(permission)) continue;
                recipients.add((CommandSender)permissible);
            }
        }
        for (CommandSender recipient : recipients) {
            recipient.sendMessage(message);
        }
        return recipients.size();
    }

    public int broadcast(TextContainer message, String permissions) {
        HashSet<CommandSender> recipients = new HashSet<CommandSender>();
        for (String permission : permissions.split(";")) {
            for (Permissible permissible : this.pluginManager.getPermissionSubscriptions(permission)) {
                if (!(permissible instanceof CommandSender) || !permissible.hasPermission(permission)) continue;
                recipients.add((CommandSender)permissible);
            }
        }
        for (CommandSender recipient : recipients) {
            recipient.sendMessage(message);
        }
        return recipients.size();
    }

    public static void broadcastPacket(Collection<Player> players, DataPacket packet) {
        Server.broadcastPacket((Player[])players.stream().toArray(Player[]::new), packet);
    }

    public static void broadcastPacket(Player[] players, DataPacket packet) {
        packet.encode();
        packet.isEncoded = true;
        if (Network.BATCH_THRESHOLD >= 0 && packet.getBuffer().length >= Network.BATCH_THRESHOLD) {
            Server.getInstance().batchPackets(players, new DataPacket[]{packet}, false);
            return;
        }
        for (Player player : players) {
            player.dataPacket(packet);
        }
        if (packet.encapsulatedPacket != null) {
            packet.encapsulatedPacket = null;
        }
    }

    public void batchPackets(Player[] players, DataPacket[] packets) {
        this.batchPackets(players, packets, false);
    }

    public void batchPackets(Player[] players, DataPacket[] packets, boolean forceSync) {
        if (players == null || packets == null || players.length == 0 || packets.length == 0) {
            return;
        }
        byte[][] payload = new byte[packets.length * 2][];
        for (int i = 0; i < packets.length; ++i) {
            DataPacket p = packets[i];
            if (!p.isEncoded) {
                p.encode();
            }
            byte[] byArray = p.getBuffer();
            payload[i * 2] = Binary.writeInt(byArray.length);
            payload[i * 2 + 1] = byArray;
        }
        byte[] data = Binary.appendBytes(payload);
        ArrayList<String> targets = new ArrayList<String>();
        for (Player p : players) {
            if (!p.isConnected()) continue;
            targets.add(this.identifier.get(p.rawHashCode()));
        }
        if (!forceSync && this.networkCompressionAsync) {
            this.getScheduler().scheduleAsyncTask(new CompressBatchedTask(data, targets, this.networkCompressionLevel));
        } else {
            try {
                this.broadcastPacketsCallback(Zlib.deflate(data, this.networkCompressionLevel), targets);
            }
            catch (Exception exception) {
                throw new RuntimeException(exception);
            }
        }
    }

    public void broadcastPacketsCallback(byte[] data, List<String> identifiers) {
        BatchPacket pk = new BatchPacket();
        pk.payload = data;
        pk.encode();
        pk.isEncoded = true;
        for (String i : identifiers) {
            if (!this.players.containsKey(i)) continue;
            this.players.get(i).dataPacket(pk);
        }
    }

    public void enablePlugins(PluginLoadOrder type) {
        for (Plugin plugin : this.pluginManager.getPlugins().values()) {
            if (plugin.isEnabled() || type != plugin.getDescription().getOrder()) continue;
            this.enablePlugin(plugin);
        }
        if (type == PluginLoadOrder.POSTWORLD) {
            this.commandMap.registerServerAliases();
            DefaultPermissions.registerCorePermissions();
        }
    }

    public void enablePlugin(Plugin plugin) {
        this.pluginManager.enablePlugin(plugin);
    }

    public void disablePlugins() {
        this.pluginManager.disablePlugins();
    }

    public boolean dispatchCommand(CommandSender sender, String commandLine) throws ServerException {
        if (sender == null) {
            throw new ServerException("CommandSender is not valid");
        }
        if (this.commandMap.dispatch(sender, commandLine)) {
            return true;
        }
        sender.sendMessage(new TranslationContainer("\u00a7c%commands.generic.notFound"));
        return false;
    }

    public ConsoleCommandSender getConsoleSender() {
        return this.consoleSender;
    }

    public void reload() {
        this.logger.info("Reloading...");
        this.logger.info("Saving levels...");
        for (Level level : this.levels.values()) {
            level.save();
        }
        this.pluginManager.disablePlugins();
        this.pluginManager.clearPlugins();
        this.commandMap.clearCommands();
        this.logger.info("Reloading properties...");
        this.properties.reload();
        this.maxPlayers = this.getPropertyInt("max-players", 20);
        if (this.getPropertyBoolean("hardcore", false) && this.getDifficulty() < 3) {
            this.setPropertyInt("difficulty", 3);
        }
        this.banByIP.load();
        this.banByName.load();
        this.reloadWhitelist();
        this.operators.reload();
        for (BanEntry entry : this.getIPBans().getEntires().values()) {
            this.getNetwork().blockAddress(entry.getName(), -1);
        }
        this.pluginManager.registerInterface(JavaPluginLoader.class);
        this.pluginManager.loadPlugins(this.pluginPath);
        this.enablePlugins(PluginLoadOrder.STARTUP);
        this.enablePlugins(PluginLoadOrder.POSTWORLD);
    }

    public void shutdown() {
        if (this.isRunning) {
            ServerKiller killer = new ServerKiller(90);
            killer.start();
        }
        this.isRunning = false;
    }

    public void forceShutdown() {
        if (this.hasStopped) {
            return;
        }
        try {
            if (!this.isRunning) {
                // empty if block
            }
            this.console.shutdown();
            this.hasStopped = true;
            this.shutdown();
            this.getLogger().debug("Disabling all plugins");
            this.pluginManager.disablePlugins();
            for (Player player : new ArrayList<Player>(this.players.values())) {
                player.close(player.getLeaveMessage(), (String)this.getConfig("settings.shutdown-message", "Server closed"));
            }
            this.getLogger().debug("Unloading all levels");
            for (Level level : new ArrayList<Level>(this.getLevels().values())) {
                this.unloadLevel(level, true);
            }
            this.getLogger().debug("Removing event handlers");
            HandlerList.unregisterAll();
            this.getLogger().debug("Stopping all tasks");
            this.scheduler.cancelAllTasks();
            this.scheduler.mainThreadHeartbeat(Integer.MAX_VALUE);
            this.getLogger().debug("Saving properties");
            this.properties.save();
            this.getLogger().debug("Closing console");
            this.console.interrupt();
            this.getLogger().debug("Stopping network interfaces");
            for (SourceInterface interfaz : this.network.getInterfaces()) {
                interfaz.shutdown();
                this.network.unregisterInterface(interfaz);
            }
        }
        catch (Exception e) {
            this.logger.logException(e);
            this.logger.emergency("Exception happened while shutting down, exit the process");
            System.exit(1);
        }
    }

    public void start() {
        if (this.getPropertyBoolean("enable-query", true)) {
            this.queryHandler = new QueryHandler();
        }
        for (BanEntry entry : this.getIPBans().getEntires().values()) {
            this.network.blockAddress(entry.getName(), -1);
        }
        this.tickCounter = 0;
        this.logger.info(this.getLanguage().translateString("nukkit.server.defaultGameMode", Server.getGamemodeString(this.getGamemode())));
        this.logger.info(this.getLanguage().translateString("nukkit.server.startFinished", String.valueOf((double)(System.currentTimeMillis() - Nukkit.START_TIME) / 1000.0)));
        this.tickProcessor();
        this.forceShutdown();
    }

    public void handlePacket(String address, int port, byte[] payload) {
        try {
            if (payload.length > 2 && Arrays.equals(Binary.subBytes(payload, 0, 2), new byte[]{-2, -3}) && this.queryHandler != null) {
                this.queryHandler.handle(address, port, payload);
            }
        }
        catch (Exception e) {
            this.logger.logException(e);
            this.getNetwork().blockAddress(address, 600);
        }
    }

    public void tickProcessor() {
        this.nextTick = System.currentTimeMillis();
        while (this.isRunning) {
            try {
                this.tick();
            }
            catch (RuntimeException e) {
                this.getLogger().logException(e);
            }
            try {
                Thread.sleep(1L);
            }
            catch (InterruptedException e) {
                Server.getInstance().getLogger().logException(e);
            }
        }
    }

    public void onPlayerLogin(Player player) {
        if (this.sendUsageTicker > 0) {
            this.uniquePlayers.add(player.getUniqueId());
        }
    }

    public void addPlayer(String identifier, Player player) {
        this.players.put(identifier, player);
        this.identifier.put(player.rawHashCode(), identifier);
    }

    public void addOnlinePlayer(Player player) {
        this.addOnlinePlayer(player, true);
    }

    public void addOnlinePlayer(Player player, boolean update) {
        this.playerList.put(player.getUniqueId(), player);
        if (update) {
            this.updatePlayerListData(player.getUniqueId(), player.getId(), player.getDisplayName(), player.getSkin());
        }
    }

    public void removeOnlinePlayer(Player player) {
        if (this.playerList.containsKey(player.getUniqueId())) {
            this.playerList.remove(player.getUniqueId());
            PlayerListPacket pk = new PlayerListPacket();
            pk.type = 1;
            pk.entries = new PlayerListPacket.Entry[]{new PlayerListPacket.Entry(player.getUniqueId())};
            Server.broadcastPacket(this.playerList.values(), (DataPacket)pk);
        }
    }

    public void updatePlayerListData(UUID uuid, long entityId, String name, Skin skin) {
        this.updatePlayerListData(uuid, entityId, name, skin, this.playerList.values());
    }

    public void updatePlayerListData(UUID uuid, long entityId, String name, Skin skin, Player[] players) {
        PlayerListPacket pk = new PlayerListPacket();
        pk.type = 0;
        pk.entries = new PlayerListPacket.Entry[]{new PlayerListPacket.Entry(uuid, entityId, name, skin)};
        Server.broadcastPacket(players, (DataPacket)pk);
    }

    public void updatePlayerListData(UUID uuid, long entityId, String name, Skin skin, Collection<Player> players) {
        this.updatePlayerListData(uuid, entityId, name, skin, (Player[])players.stream().toArray(Player[]::new));
    }

    public void removePlayerListData(UUID uuid) {
        this.removePlayerListData(uuid, this.playerList.values());
    }

    public void removePlayerListData(UUID uuid, Player[] players) {
        PlayerListPacket pk = new PlayerListPacket();
        pk.type = 1;
        pk.entries = new PlayerListPacket.Entry[]{new PlayerListPacket.Entry(uuid)};
        Server.broadcastPacket(players, (DataPacket)pk);
    }

    public void removePlayerListData(UUID uuid, Collection<Player> players) {
        this.removePlayerListData(uuid, (Player[])players.stream().toArray(Player[]::new));
    }

    public void sendFullPlayerListData(Player player) {
        this.sendFullPlayerListData(player, false);
    }

    public void sendFullPlayerListData(Player player, boolean self) {
        PlayerListPacket pk = new PlayerListPacket();
        pk.type = 0;
        ArrayList<PlayerListPacket.Entry> entries = new ArrayList<PlayerListPacket.Entry>();
        for (Player p : this.playerList.values()) {
            if (!self && p == player) continue;
            entries.add(new PlayerListPacket.Entry(p.getUniqueId(), p.getId(), p.getDisplayName(), p.getSkin()));
        }
        pk.entries = (PlayerListPacket.Entry[])entries.stream().toArray(PlayerListPacket.Entry[]::new);
        player.dataPacket(pk);
    }

    public void sendRecipeList(Player player) {
        CraftingDataPacket pk = new CraftingDataPacket();
        pk.cleanRecipes = true;
        for (Recipe recipe : this.getCraftingManager().getRecipes().values()) {
            if (recipe instanceof ShapedRecipe) {
                pk.addShapedRecipe((ShapedRecipe)recipe);
                continue;
            }
            if (!(recipe instanceof ShapelessRecipe)) continue;
            pk.addShapelessRecipe((ShapelessRecipe)recipe);
        }
        for (FurnaceRecipe furnaceRecipe : this.getCraftingManager().getFurnaceRecipes().values()) {
            pk.addFurnaceRecipe(furnaceRecipe);
        }
        player.dataPacket(pk);
    }

    private void checkTickUpdates(int currentTick, long tickTime) {
        for (Player p : new ArrayList<Player>(this.players.values())) {
            if (!p.loggedIn && tickTime - p.creationTime >= 10000L) {
                p.close("", "Login timeout");
                continue;
            }
            if (!this.alwaysTickPlayers) continue;
            p.onUpdate(currentTick);
        }
        for (Level level : this.getLevels().values()) {
            if (level.getTickRate() > this.baseTickRate && --level.tickRateCounter > 0) continue;
            try {
                int tickMs;
                long levelTime = System.currentTimeMillis();
                level.doTick(currentTick);
                level.tickRateTime = tickMs = (int)(System.currentTimeMillis() - levelTime);
                if (!this.autoTickRate) continue;
                if (tickMs < 50 && level.getTickRate() > this.baseTickRate) {
                    int r = level.getTickRate() - 1;
                    level.setTickRate(r);
                    if (r > this.baseTickRate) {
                        level.tickRateCounter = level.getTickRate();
                    }
                    this.getLogger().debug("Raising level \"" + level.getName() + "\" tick rate to " + level.getTickRate() + " ticks");
                    continue;
                }
                if (tickMs < 50) continue;
                if (level.getTickRate() == this.baseTickRate) {
                    level.setTickRate((int)Math.max((double)(this.baseTickRate + 1), Math.min((double)this.autoTickRateLimit, Math.floor(tickMs / 50))));
                    this.getLogger().debug("Level \"" + level.getName() + "\" took " + NukkitMath.round(tickMs, 2) + "ms, setting tick rate to " + level.getTickRate() + " ticks");
                } else if (tickMs / level.getTickRate() >= 50 && level.getTickRate() < this.autoTickRateLimit) {
                    level.setTickRate(level.getTickRate() + 1);
                    this.getLogger().debug("Level \"" + level.getName() + "\" took " + NukkitMath.round(tickMs, 2) + "ms, setting tick rate to " + level.getTickRate() + " ticks");
                }
                level.tickRateCounter = level.getTickRate();
            }
            catch (Exception e) {
                if (Nukkit.DEBUG > 1 && this.logger != null) {
                    this.logger.logException(e);
                }
                this.logger.critical(this.getLanguage().translateString("nukkit.level.tickError", new String[]{level.getName(), e.toString()}));
            }
        }
    }

    public void doAutoSave() {
        if (this.getAutoSave()) {
            for (Player player : new ArrayList<Player>(this.players.values())) {
                if (player.isOnline()) {
                    player.save(true);
                    continue;
                }
                if (player.isConnected()) continue;
                this.removePlayer(player);
            }
            for (Level level : this.getLevels().values()) {
                level.save();
            }
        }
    }

    private boolean tick() {
        long tickTime = System.currentTimeMillis();
        long tickTimeNano = System.nanoTime();
        if (tickTime - this.nextTick < -25L) {
            return false;
        }
        ++this.tickCounter;
        this.network.processInterfaces();
        this.scheduler.mainThreadHeartbeat(this.tickCounter);
        this.checkTickUpdates(this.tickCounter, tickTime);
        for (Player player : new ArrayList<Player>(this.players.values())) {
            player.checkNetwork();
        }
        if ((this.tickCounter & 0xF) == 0) {
            this.titleTick();
            this.maxTick = 20.0f;
            this.maxUse = 0.0f;
            if ((this.tickCounter & 0x1FF) == 0) {
                try {
                    this.queryRegenerateEvent = new QueryRegenerateEvent(this, 5);
                    this.getPluginManager().callEvent(this.queryRegenerateEvent);
                    if (this.queryHandler != null) {
                        this.queryHandler.regenerateInfo();
                    }
                }
                catch (Exception e) {
                    this.logger.logException(e);
                }
            }
            this.getNetwork().updateName();
        }
        if (this.autoSave && ++this.autoSaveTicker >= this.autoSaveTicks) {
            this.autoSaveTicker = 0;
            this.doAutoSave();
        }
        if (this.sendUsageTicker > 0 && --this.sendUsageTicker == 0) {
            this.sendUsageTicker = 6000;
        }
        if (this.tickCounter % 100 == 0) {
            for (Level level : this.levels.values()) {
                level.clearCache();
            }
            if (this.getTicksPerSecondAverage() < 12.0f) {
                this.logger.warning(this.getLanguage().translateString("nukkit.server.tickOverload"));
            }
        }
        long nowNano = System.nanoTime();
        float tick = (float)Math.min(20.0, 1.0E9 / Math.max(1000000.0, (double)nowNano - (double)tickTimeNano));
        float use = (float)Math.min(1.0, (double)(nowNano - tickTimeNano) / 5.0E7);
        if (this.maxTick > tick) {
            this.maxTick = tick;
        }
        if (this.maxUse < use) {
            this.maxUse = use;
        }
        System.arraycopy(this.tickAverage, 1, this.tickAverage, 0, this.tickAverage.length - 1);
        this.tickAverage[this.tickAverage.length - 1] = tick;
        System.arraycopy(this.useAverage, 1, this.useAverage, 0, this.useAverage.length - 1);
        this.useAverage[this.useAverage.length - 1] = use;
        this.nextTick = this.nextTick - tickTime < -1000L ? tickTime : (this.nextTick += 50L);
        return true;
    }

    public void titleTick() {
        if (!Nukkit.ANSI) {
            return;
        }
        Runtime runtime = Runtime.getRuntime();
        double used = NukkitMath.round((double)(runtime.totalMemory() - runtime.freeMemory()) / 1024.0 / 1024.0, 2);
        double max = NukkitMath.round((double)runtime.maxMemory() / 1024.0 / 1024.0, 2);
        String usage = Math.round(used / max * 100.0) + "%";
        String title = "\u001b]0;" + this.getName() + " " + this.getNukkitVersion() + " | Online " + this.players.size() + "/" + this.getMaxPlayers() + " | Memory " + usage;
        if (!Nukkit.shortTitle) {
            title = title + " | U " + NukkitMath.round(this.network.getUpload() / 1024.0 * 1000.0, 2) + " D " + NukkitMath.round(this.network.getDownload() / 1024.0 * 1000.0, 2) + " kB/s";
        }
        title = title + " | TPS " + this.getTicksPerSecond() + " | Load " + this.getTickUsage() + "%" + '\u0007';
        System.out.print(title);
        this.network.resetStatistics();
    }

    public QueryRegenerateEvent getQueryInformation() {
        return this.queryRegenerateEvent;
    }

    public String getName() {
        return "AxeonAPI";
    }

    /**
     * Returns the fork name — this is a Nukkit Fork.
     */
    public String getForkName() {
        return "Nukkit Fork";
    }

    public boolean isRunning() {
        return this.isRunning;
    }

    public String getNukkitVersion() {
        return "1.0dev";
    }

    public String getCodename() {
        return "Axeon";
    }

    public String getVersion() {
        return "v0.14.3 alpha";
    }

    public String getApiVersion() {
        return "1.0.0";
    }

    public String getFilePath() {
        return this.filePath;
    }

    public String getDataPath() {
        return this.dataPath;
    }

    public String getPluginPath() {
        return this.pluginPath;
    }

    public int getMaxPlayers() {
        return this.maxPlayers;
    }

    public int getPort() {
        return this.getPropertyInt("server-port", 19132);
    }

    public int getViewDistance() {
        return this.getPropertyInt("view-distance", 10);
    }

    public String getIp() {
        return this.getPropertyString("server-ip", "0.0.0.0");
    }

    public UUID getServerUniqueId() {
        return this.serverID;
    }

    public boolean getAutoSave() {
        return this.autoSave;
    }

    public void setAutoSave(boolean autoSave) {
        this.autoSave = autoSave;
        for (Level level : this.getLevels().values()) {
            level.setAutoSave(this.autoSave);
        }
    }

    public String getLevelType() {
        return this.getPropertyString("level-type", "DEFAULT");
    }

    public boolean getGenerateStructures() {
        return this.getPropertyBoolean("generate-structures", true);
    }

    public int getGamemode() {
        return this.getPropertyInt("gamemode", 0) & 3;
    }

    public boolean getForceGamemode() {
        return this.getPropertyBoolean("force-gamemode", false);
    }

    public static String getGamemodeString(int mode) {
        switch (mode) {
            case 0: {
                return "%gameMode.survival";
            }
            case 1: {
                return "%gameMode.creative";
            }
            case 2: {
                return "%gameMode.adventure";
            }
            case 3: {
                return "%gameMode.spectator";
            }
        }
        return "UNKNOWN";
    }

    public static int getGamemodeFromString(String str) {
        switch (str.trim().toLowerCase()) {
            case "0": 
            case "survival": 
            case "s": {
                return 0;
            }
            case "1": 
            case "creative": 
            case "c": {
                return 1;
            }
            case "2": 
            case "adventure": 
            case "a": {
                return 2;
            }
            case "3": 
            case "spectator": 
            case "view": 
            case "v": {
                return 3;
            }
        }
        return -1;
    }

    public static int getDifficultyFromString(String str) {
        switch (str.trim().toLowerCase()) {
            case "0": 
            case "peaceful": 
            case "p": {
                return 0;
            }
            case "1": 
            case "easy": 
            case "e": {
                return 1;
            }
            case "2": 
            case "normal": 
            case "n": {
                return 2;
            }
            case "3": 
            case "hard": 
            case "h": {
                return 3;
            }
        }
        return -1;
    }

    public int getDifficulty() {
        return this.getPropertyInt("difficulty", 1);
    }

    public boolean hasWhitelist() {
        return this.getPropertyBoolean("white-list", false);
    }

    public int getSpawnRadius() {
        return this.getPropertyInt("spawn-protection", 16);
    }

    public boolean getAllowFlight() {
        return this.getPropertyBoolean("allow-flight", false);
    }

    public boolean isHardcore() {
        return this.getPropertyBoolean("hardcore", false);
    }

    public int getDefaultGamemode() {
        return this.getPropertyInt("gamemode", 0);
    }

    public String getMotd() {
        return this.getPropertyString("motd", "Nukkit Server For Minecraft: PE");
    }

    public MainLogger getLogger() {
        return this.logger;
    }

    public EntityMetadataStore getEntityMetadata() {
        return this.entityMetadata;
    }

    public PlayerMetadataStore getPlayerMetadata() {
        return this.playerMetadata;
    }

    public LevelMetadataStore getLevelMetadata() {
        return this.levelMetadata;
    }

    public PluginManager getPluginManager() {
        return this.pluginManager;
    }

    public CraftingManager getCraftingManager() {
        return this.craftingManager;
    }

    public ServerScheduler getScheduler() {
        return this.scheduler;
    }

    public int getTick() {
        return this.tickCounter;
    }

    public float getTicksPerSecond() {
        return (float)Math.round(this.maxTick * 100.0f) / 100.0f;
    }

    public float getTicksPerSecondAverage() {
        float sum = 0.0f;
        int count = this.tickAverage.length;
        for (float aTickAverage : this.tickAverage) {
            sum += aTickAverage;
        }
        return (float)NukkitMath.round(sum / (float)count, 2);
    }

    public float getTickUsage() {
        return (float)NukkitMath.round(this.maxUse * 100.0f, 2);
    }

    public float getTickUsageAverage() {
        float sum = 0.0f;
        int count = this.useAverage.length;
        for (float aUseAverage : this.useAverage) {
            sum += aUseAverage;
        }
        return (float)Math.round(sum / (float)count * 100.0f) / 100.0f;
    }

    public SimpleCommandMap getCommandMap() {
        return this.commandMap;
    }

    public Map<UUID, Player> getOnlinePlayers() {
        return new HashMap<UUID, Player>(this.playerList);
    }

    public void addRecipe(Recipe recipe) {
        this.craftingManager.registerRecipe(recipe);
    }

    public IPlayer getOfflinePlayer(String name) {
        Player result = this.getPlayerExact(name.toLowerCase());
        if (result == null) {
            return new OfflinePlayer(this, name);
        }
        return result;
    }

    public CompoundTag getOfflinePlayerData(String name) {
        name = name.toLowerCase();
        String path = this.getDataPath() + "players/";
        File file = new File(path + name + ".dat");
        if (file.exists()) {
            try {
                return NBTIO.readCompressed(new FileInputStream(file));
            }
            catch (Exception e) {
                file.renameTo(new File(path + name + ".dat.bak"));
                this.logger.notice(this.getLanguage().translateString("nukkit.data.playerCorrupted", name));
            }
        } else {
            this.logger.notice(this.getLanguage().translateString("nukkit.data.playerNotFound", name));
        }
        Position spawn = this.getDefaultLevel().getSafeSpawn();
        CompoundTag nbt = new CompoundTag().putLong("firstPlayed", System.currentTimeMillis() / 1000L).putLong("lastPlayed", System.currentTimeMillis() / 1000L).putList(new ListTag<DoubleTag>("Pos").add(new DoubleTag("0", spawn.x)).add(new DoubleTag("1", spawn.y)).add(new DoubleTag("2", spawn.z))).putString("Level", this.getDefaultLevel().getName()).putList(new ListTag("Inventory")).putCompound("Achievements", new CompoundTag()).putInt("playerGameType", this.getGamemode()).putList(new ListTag<DoubleTag>("Motion").add(new DoubleTag("0", 0.0)).add(new DoubleTag("1", 0.0)).add(new DoubleTag("2", 0.0))).putList(new ListTag<FloatTag>("Rotation").add(new FloatTag("0", 0.0f)).add(new FloatTag("1", 0.0f))).putFloat("FallDistance", 0.0f).putShort("Fire", 0).putShort("Air", 300).putBoolean("OnGround", true).putBoolean("Invulnerable", false).putString("NameTag", name);
        this.saveOfflinePlayerData(name, nbt);
        return nbt;
    }

    public void saveOfflinePlayerData(String name, CompoundTag tag) {
        this.saveOfflinePlayerData(name, tag, false);
    }

    public void saveOfflinePlayerData(String name, CompoundTag tag, boolean async) {
        block4: {
            try {
                if (async) {
                    this.getScheduler().scheduleAsyncTask(new FileWriteTask(this.getDataPath() + "players/" + name.toLowerCase() + ".dat", NBTIO.writeGZIPCompressed(tag, ByteOrder.BIG_ENDIAN)));
                } else {
                    Utils.writeFile(this.getDataPath() + "players/" + name.toLowerCase() + ".dat", (InputStream)new ByteArrayInputStream(NBTIO.writeGZIPCompressed(tag, ByteOrder.BIG_ENDIAN)));
                }
            }
            catch (Exception e) {
                this.logger.critical(this.getLanguage().translateString("nukkit.data.saveError", new String[]{name, e.getMessage()}));
                if (Nukkit.DEBUG <= 1) break block4;
                this.logger.logException(e);
            }
        }
    }

    public Player getPlayer(String name) {
        Player found = null;
        name = name.toLowerCase();
        int delta = Integer.MAX_VALUE;
        for (Player player : this.getOnlinePlayers().values()) {
            if (!player.getName().toLowerCase().startsWith(name)) continue;
            int curDelta = player.getName().length() - name.length();
            if (curDelta < delta) {
                found = player;
                delta = curDelta;
            }
            if (curDelta != 0) continue;
            break;
        }
        return found;
    }

    public Player getPlayerExact(String name) {
        name = name.toLowerCase();
        for (Player player : this.getOnlinePlayers().values()) {
            if (!player.getName().toLowerCase().equals(name)) continue;
            return player;
        }
        return null;
    }

    public Player[] matchPlayer(String partialName) {
        partialName = partialName.toLowerCase();
        ArrayList<Player> matchedPlayer = new ArrayList<Player>();
        for (Player player : this.getOnlinePlayers().values()) {
            if (player.getName().toLowerCase().equals(partialName)) {
                return new Player[]{player};
            }
            if (!player.getName().toLowerCase().contains(partialName)) continue;
            matchedPlayer.add(player);
        }
        return matchedPlayer.toArray(new Player[matchedPlayer.size()]);
    }

    public void removePlayer(Player player) {
        if (this.identifier.containsKey(player.rawHashCode())) {
            String identifier = this.identifier.get(player.rawHashCode());
            this.players.remove(identifier);
            this.identifier.remove(player.rawHashCode());
            return;
        }
        for (String identifier : new ArrayList<String>(this.players.keySet())) {
            Player p = this.players.get(identifier);
            if (player != p) continue;
            this.players.remove(identifier);
            this.identifier.remove(player.rawHashCode());
            break;
        }
    }

    public Map<Integer, Level> getLevels() {
        return this.levels;
    }

    public Level getDefaultLevel() {
        return this.defaultLevel;
    }

    public void setDefaultLevel(Level defaultLevel) {
        if (defaultLevel == null || this.isLevelLoaded(defaultLevel.getFolderName()) && defaultLevel != this.defaultLevel) {
            this.defaultLevel = defaultLevel;
        }
    }

    public boolean isLevelLoaded(String name) {
        return this.getLevelByName(name) != null;
    }

    public Level getLevel(int levelId) {
        if (this.levels.containsKey(levelId)) {
            return this.levels.get(levelId);
        }
        return null;
    }

    public Level getLevelByName(String name) {
        for (Level level : this.getLevels().values()) {
            if (!level.getFolderName().equals(name)) continue;
            return level;
        }
        return null;
    }

    public boolean unloadLevel(Level level) {
        return this.unloadLevel(level, false);
    }

    public boolean unloadLevel(Level level, boolean forceUnload) {
        if (level == this.getDefaultLevel() && !forceUnload) {
            throw new IllegalStateException("The default level cannot be unloaded while running, please switch levels.");
        }
        return level.unload(forceUnload);
    }

    public boolean loadLevel(String name) {
        Level level;
        if (Objects.equals(name.trim(), "")) {
            throw new LevelException("Invalid empty level name");
        }
        if (this.isLevelLoaded(name)) {
            return true;
        }
        if (!this.isLevelGenerated(name)) {
            this.logger.notice(this.getLanguage().translateString("nukkit.level.notFound", name));
            return false;
        }
        String path = this.getDataPath() + "worlds/" + name + "/";
        Class<? extends LevelProvider> provider = LevelProviderManager.getProvider(path);
        if (provider == null) {
            this.logger.error(this.getLanguage().translateString("nukkit.level.loadError", new String[]{name, "Unknown provider"}));
            return false;
        }
        try {
            level = new Level(this, name, path, provider);
        }
        catch (Exception e) {
            this.logger.error(this.getLanguage().translateString("nukkit.level.loadError", new String[]{name, e.getMessage()}));
            this.logger.logException(e);
            return false;
        }
        this.levels.put(level.getId(), level);
        level.initLevel();
        this.getPluginManager().callEvent(new LevelLoadEvent(level));
        level.setTickRate(this.baseTickRate);
        return true;
    }

    public boolean generateLevel(String name) {
        return this.generateLevel(name, new Random().nextLong());
    }

    public boolean generateLevel(String name, long seed) {
        return this.generateLevel(name, seed, null);
    }

    public boolean generateLevel(String name, long seed, Class<? extends Generator> generator) {
        return this.generateLevel(name, seed, generator, new HashMap<String, Object>());
    }

    public boolean generateLevel(String name, long seed, Class<? extends Generator> generator, Map<String, Object> options) {
        Level level;
        String providerName;
        Class<? extends LevelProvider> provider;
        if (Objects.equals(name.trim(), "") || this.isLevelGenerated(name)) {
            return false;
        }
        if (!options.containsKey("preset")) {
            options.put("preset", this.getPropertyString("generator-settings", ""));
        }
        if (generator == null) {
            generator = Generator.getGenerator(this.getLevelType());
        }
        if ((provider = LevelProviderManager.getProviderByName(providerName = (String)this.getConfig("level-settings.default-format", "mcregion"))) == null) {
            providerName = "mcregion";
            provider = LevelProviderManager.getProviderByName("mcregion");
        }
        try {
            String path = this.getDataPath() + "worlds/" + name + "/";
            provider.getMethod("generate", String.class, String.class, Long.TYPE, Class.class, Map.class).invoke(null, path, name, seed, generator, options);
            level = new Level(this, name, path, provider);
            this.levels.put(level.getId(), level);
            level.initLevel();
            level.setTickRate(this.baseTickRate);
        }
        catch (Exception e) {
            this.logger.error(this.getLanguage().translateString("nukkit.level.generationError", new String[]{name, e.getMessage()}));
            this.logger.logException(e);
            return false;
        }
        this.getPluginManager().callEvent(new LevelInitEvent(level));
        this.getPluginManager().callEvent(new LevelLoadEvent(level));
        return true;
    }

    public boolean isLevelGenerated(String name) {
        if (Objects.equals(name.trim(), "")) {
            return false;
        }
        String path = this.getDataPath() + "worlds/" + name + "/";
        return this.getLevelByName(name) != null || LevelProviderManager.getProvider(path) != null;
    }

    public BaseLang getLanguage() {
        return this.baseLang;
    }

    public boolean isLanguageForced() {
        return this.forceLanguage;
    }

    public Network getNetwork() {
        return this.network;
    }

    public Object getConfig(String variable) {
        return this.getConfig(variable, null);
    }

    public Object getConfig(String variable, Object defaultValue) {
        Object value = this.config.get(variable);
        return value == null ? defaultValue : value;
    }

    public Object getProperty(String variable) {
        return this.getProperty(variable, null);
    }

    public Object getProperty(String variable, Object defaultValue) {
        return this.properties.exists(variable) ? this.properties.get(variable) : defaultValue;
    }

    public void setPropertyString(String variable, String value) {
        this.properties.set(variable, value);
    }

    public String getPropertyString(String variable) {
        return this.getPropertyString(variable, null);
    }

    public String getPropertyString(String variable, String defaultValue) {
        return this.properties.exists(variable) ? (String)this.properties.get(variable) : defaultValue;
    }

    public int getPropertyInt(String variable) {
        return this.getPropertyInt(variable, null);
    }

    public int getPropertyInt(String variable, Integer defaultValue) {
        return this.properties.exists(variable) ? (!this.properties.get(variable).equals("") ? Integer.parseInt(String.valueOf(this.properties.get(variable))) : defaultValue) : defaultValue;
    }

    public void setPropertyInt(String variable, int value) {
        this.properties.set(variable, value);
    }

    public boolean getPropertyBoolean(String variable) {
        return this.getPropertyBoolean(variable, null);
    }

    public boolean getPropertyBoolean(String variable, Object defaultValue) {
        Object value;
        Object object = value = this.properties.exists(variable) ? this.properties.get(variable) : defaultValue;
        if (value instanceof Boolean) {
            return (Boolean)value;
        }
        switch (String.valueOf(value)) {
            case "on": 
            case "true": 
            case "1": 
            case "yes": {
                return true;
            }
        }
        return false;
    }

    public void setPropertyBoolean(String variable, boolean value) {
        this.properties.set(variable, value ? "1" : "0");
    }

    public PluginIdentifiableCommand getPluginCommand(String name) {
        Command command = this.commandMap.getCommand(name);
        if (command instanceof PluginIdentifiableCommand) {
            return (PluginIdentifiableCommand)((Object)command);
        }
        return null;
    }

    public BanList getNameBans() {
        return this.banByName;
    }

    public BanList getIPBans() {
        return this.banByIP;
    }

    public void addOp(String name) {
        this.operators.set(name.toLowerCase(), true);
        Player player = this.getPlayerExact(name);
        if (player != null) {
            player.recalculatePermissions();
        }
        this.operators.save(true);
    }

    public void removeOp(String name) {
        this.operators.remove(name.toLowerCase());
        Player player = this.getPlayerExact(name);
        if (player != null) {
            player.recalculatePermissions();
        }
        this.operators.save();
    }

    public void addWhitelist(String name) {
        this.whitelist.set(name.toLowerCase(), true);
        this.whitelist.save(true);
    }

    public void removeWhitelist(String name) {
        this.whitelist.remove(name.toLowerCase());
        this.whitelist.save(true);
    }

    public boolean isWhitelisted(String name) {
        return !this.hasWhitelist() || this.operators.exists(name, true) || this.whitelist.exists(name, true);
    }

    public boolean isOp(String name) {
        return this.operators.exists(name, true);
    }

    public Config getWhitelist() {
        return this.whitelist;
    }

    public Config getOps() {
        return this.operators;
    }

    public void reloadWhitelist() {
        this.whitelist.reload();
    }

    public Map<String, List<String>> getCommandAliases() {
        Object section = this.getConfig("aliases");
        LinkedHashMap<String, List<String>> result = new LinkedHashMap<String, List<String>>();
        if (section instanceof Map) {
            for (Object entryObj : ((Map)section).entrySet()) {
                Map.Entry entry = (Map.Entry)entryObj;
                ArrayList<String> commands = new ArrayList<String>();
                String key = (String)entry.getKey();
                Object value = entry.getValue();
                if (value instanceof List) {
                    for (Object strObj : (List)value) {
                        commands.add((String)strObj);
                    }
                } else {
                    commands.add((String)value);
                }
                result.put(key, commands);
            }
        }
        return result;
    }

    private void registerEntities() {
        Entity.registerEntity("Arrow", EntityArrow.class);
        Entity.registerEntity("Item", EntityItem.class);
        Entity.registerEntity("FallingSand", EntityFallingBlock.class);
        Entity.registerEntity("PrimedTnt", EntityPrimedTNT.class);
        Entity.registerEntity("Snowball", EntitySnowball.class);
        Entity.registerEntity("Painting", EntityPainting.class);
        Entity.registerEntity("Creeper", EntityCreeper.class);
        Entity.registerEntity("Chicken", EntityChicken.class);
        Entity.registerEntity("Cow", EntityCow.class);
        Entity.registerEntity("Pig", EntityPig.class);
        Entity.registerEntity("Rabbit", EntityRabbit.class);
        Entity.registerEntity("Sheep", EntitySheep.class);
        Entity.registerEntity("Wolf", EntityWolf.class);
        Entity.registerEntity("Ocelot", EntityOcelot.class);
        Entity.registerEntity("ThrownExpBottle", EntityExpBottle.class);
        Entity.registerEntity("XpOrb", EntityXPOrb.class);
        Entity.registerEntity("ThrownPotion", EntityPotion.class);
        Entity.registerEntity("Human", EntityHuman.class, true);
        Entity.registerEntity("MinecartRideable", EntityMinecartEmpty.class);
        Entity.registerEntity("Boat", EntityBoat.class);
        Entity.registerEntity("Lightning", EntityLightning.class);
    }

    private void registerBlockEntities() {
        BlockEntity.registerBlockEntity("Furnace", BlockEntityFurnace.class);
        BlockEntity.registerBlockEntity("Chest", BlockEntityChest.class);
        BlockEntity.registerBlockEntity("Sign", BlockEntitySign.class);
        BlockEntity.registerBlockEntity("EnchantTable", BlockEntityEnchantTable.class);
        BlockEntity.registerBlockEntity("Skull", BlockEntitySkull.class);
        BlockEntity.registerBlockEntity("FlowerPot", BlockEntityFlowerPot.class);
        BlockEntity.registerBlockEntity("BrewingStand", BlockEntityBrewingStand.class);
    }

    public static Server getInstance() {
        return instance;
    }
}

