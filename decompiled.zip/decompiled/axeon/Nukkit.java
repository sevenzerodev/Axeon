/*
 * Axeon API - A Nukkit Fork
 * Axeon API is a server software for Minecraft: Pocket Edition.
 * This software is a fork of Nukkit, rebranded and maintained by CloudBurst & SevenZero.
 * Licensed under GPL-2.0.
 */
package cn.axeon;

import cn.axeon.InterruptibleThread;
import cn.axeon.Server;
import cn.axeon.command.CommandReader;
import cn.axeon.utils.MainLogger;
import cn.axeon.utils.ServerKiller;

/**
 * Axeon API — Nukkit Fork
 * A Minecraft: PE server API based on Nukkit.
 */
public class Nukkit {
    public static final String VERSION = "1.0dev";
    public static final String API_VERSION = "1.0.0";
    public static final String CODENAME = "Axeon";
    public static final String FORK_OF = "Nukkit";
    public static final String MINECRAFT_VERSION = "v0.14.3 alpha";
    public static final String MINECRAFT_VERSION_NETWORK = "0.14.3";
    public static final String PATH = System.getProperty("user.dir") + "/";
    public static final String DATA_PATH = System.getProperty("user.dir") + "/";
    public static final String PLUGIN_PATH = DATA_PATH + "plugins";
    public static final long START_TIME = System.currentTimeMillis();
    public static boolean ANSI = true;
    public static boolean shortTitle = false;
    public static int DEBUG = 1;

    public static void main(String[] args) {
        String osName = System.getProperty("os.name").toLowerCase();
        if (osName.contains("windows") && (osName.contains("windows 8") || osName.contains("2012"))) {
            shortTitle = true;
        }
        String[] stringArray = args;
        int n = stringArray.length;
        for (int i = 0; i < n; ++i) {
            String arg;
            switch (arg = stringArray[i]) {
                case "disable-ansi": {
                    ANSI = false;
                }
            }
        }
        MainLogger logger = new MainLogger(DATA_PATH + "server.log");
        try {
            if (ANSI) {
                System.out.print("\u001b]0;Starting Axeon API Server For Minecraft: PE\u0007");
            }
            Server server = new Server(logger, PATH, DATA_PATH, PLUGIN_PATH);
        }
        catch (Exception e) {
            logger.logException(e);
        }
        if (ANSI) {
            System.out.print("\u001b]0;Stopping Server...\u0007");
        }
        logger.info("Stopping other threads");
        for (Thread thread : Thread.getAllStackTraces().keySet()) {
            if (!(thread instanceof InterruptibleThread)) continue;
            logger.debug("Stopping " + thread.getClass().getSimpleName() + " thread");
            if (!thread.isAlive()) continue;
            thread.interrupt();
        }
        ServerKiller killer = new ServerKiller(8);
        killer.start();
        logger.shutdown();
        logger.interrupt();
        CommandReader.getInstance().removePromptLine();
        if (ANSI) {
            System.out.print("\u001b]0;Server Stopped\u0007");
        }
        System.exit(0);
    }
}
