/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon;

public interface InterruptibleThread {
}

