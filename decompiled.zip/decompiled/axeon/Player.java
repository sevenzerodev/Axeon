/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon;

import cn.axeon.IPlayer;
import cn.axeon.PlayerFood;
import cn.axeon.Server;
import cn.axeon.block.Block;
import cn.axeon.block.BlockAir;
import cn.axeon.blockentity.BlockEntitySign;
import cn.axeon.blockentity.BlockEntitySpawnable;
import cn.axeon.command.CommandSender;
import cn.axeon.entity.Attribute;
import cn.axeon.entity.Entity;
import cn.axeon.entity.EntityHuman;
import cn.axeon.entity.EntityLiving;
import cn.axeon.entity.data.EntityData;
import cn.axeon.entity.data.EntityMetadata;
import cn.axeon.entity.data.PositionEntityData;
import cn.axeon.entity.data.ShortEntityData;
import cn.axeon.entity.data.Skin;
import cn.axeon.entity.item.EntityBoat;
import cn.axeon.entity.item.EntityExpBottle;
import cn.axeon.entity.item.EntityItem;
import cn.axeon.entity.item.EntityPotion;
import cn.axeon.entity.item.EntityVehicle;
import cn.axeon.entity.item.EntityXPOrb;
import cn.axeon.entity.projectile.EntityArrow;
import cn.axeon.entity.projectile.EntityEgg;
import cn.axeon.entity.projectile.EntityProjectile;
import cn.axeon.entity.projectile.EntitySnowball;
import cn.axeon.event.TextContainer;
import cn.axeon.event.TranslationContainer;
import cn.axeon.event.block.SignChangeEvent;
import cn.axeon.event.entity.EntityDamageByBlockEvent;
import cn.axeon.event.entity.EntityDamageByEntityEvent;
import cn.axeon.event.entity.EntityDamageEvent;
import cn.axeon.event.entity.EntityShootBowEvent;
import cn.axeon.event.entity.ProjectileLaunchEvent;
import cn.axeon.event.inventory.CraftItemEvent;
import cn.axeon.event.inventory.InventoryCloseEvent;
import cn.axeon.event.inventory.InventoryEvent;
import cn.axeon.event.inventory.InventoryPickupArrowEvent;
import cn.axeon.event.inventory.InventoryPickupItemEvent;
import cn.axeon.event.player.PlayerAnimationEvent;
import cn.axeon.event.player.PlayerBedEnterEvent;
import cn.axeon.event.player.PlayerBedLeaveEvent;
import cn.axeon.event.player.PlayerChatEvent;
import cn.axeon.event.player.PlayerChunkRequestEvent;
import cn.axeon.event.player.PlayerCommandPreprocessEvent;
import cn.axeon.event.player.PlayerDeathEvent;
import cn.axeon.event.player.PlayerDropItemEvent;
import cn.axeon.event.player.PlayerGameModeChangeEvent;
import cn.axeon.event.player.PlayerInteractEvent;
import cn.axeon.event.player.PlayerInvalidMoveEvent;
import cn.axeon.event.player.PlayerItemConsumeEvent;
import cn.axeon.event.player.PlayerJoinEvent;
import cn.axeon.event.player.PlayerKickEvent;
import cn.axeon.event.player.PlayerLoginEvent;
import cn.axeon.event.player.PlayerMoveEvent;
import cn.axeon.event.player.PlayerPreLoginEvent;
import cn.axeon.event.player.PlayerQuitEvent;
import cn.axeon.event.player.PlayerRespawnEvent;
import cn.axeon.event.player.PlayerTeleportEvent;
import cn.axeon.event.player.PlayerToggleSneakEvent;
import cn.axeon.event.player.PlayerToggleSprintEvent;
import cn.axeon.event.server.DataPacketReceiveEvent;
import cn.axeon.event.server.DataPacketSendEvent;
import cn.axeon.inventory.BaseTransaction;
import cn.axeon.inventory.BigShapedRecipe;
import cn.axeon.inventory.BigShapelessRecipe;
import cn.axeon.inventory.EnchantInventory;
import cn.axeon.inventory.Inventory;
import cn.axeon.inventory.InventoryHolder;
import cn.axeon.inventory.PlayerInventory;
import cn.axeon.inventory.ShapedRecipe;
import cn.axeon.inventory.ShapelessRecipe;
import cn.axeon.inventory.SimpleTransactionGroup;
import cn.axeon.inventory.Transaction;
import cn.axeon.item.Item;
import cn.axeon.item.ItemArrow;
import cn.axeon.item.ItemBlock;
import cn.axeon.item.ItemGlassBottle;
import cn.axeon.item.food.Food;
import cn.axeon.level.ChunkLoader;
import cn.axeon.level.Level;
import cn.axeon.level.Location;
import cn.axeon.level.Position;
import cn.axeon.level.format.Chunk;
import cn.axeon.level.format.FullChunk;
import cn.axeon.level.format.generic.BaseFullChunk;
import cn.axeon.level.particle.CriticalParticle;
import cn.axeon.level.sound.ClickSound;
import cn.axeon.level.sound.LaunchSound;
import cn.axeon.level.sound.Sound;
import cn.axeon.math.AxisAlignedBB;
import cn.axeon.math.NukkitMath;
import cn.axeon.math.NukkitRandom;
import cn.axeon.math.Vector2;
import cn.axeon.math.Vector3;
import cn.axeon.metadata.MetadataValue;
import cn.axeon.nbt.NBTIO;
import cn.axeon.nbt.tag.CompoundTag;
import cn.axeon.nbt.tag.DoubleTag;
import cn.axeon.nbt.tag.FloatTag;
import cn.axeon.nbt.tag.ListTag;
import cn.axeon.network.SourceInterface;
import cn.axeon.network.protocol.AdventureSettingsPacket;
import cn.axeon.network.protocol.AnimatePacket;
import cn.axeon.network.protocol.BatchPacket;
import cn.axeon.network.protocol.BlockEntityDataPacket;
import cn.axeon.network.protocol.ChangeDimensionPacket;
import cn.axeon.network.protocol.ChunkRadiusUpdatePacket;
import cn.axeon.network.protocol.ContainerClosePacket;
import cn.axeon.network.protocol.ContainerSetContentPacket;
import cn.axeon.network.protocol.ContainerSetSlotPacket;
import cn.axeon.network.protocol.CraftingEventPacket;
import cn.axeon.network.protocol.DataPacket;
import cn.axeon.network.protocol.DisconnectPacket;
import cn.axeon.network.protocol.DropItemPacket;
import cn.axeon.network.protocol.EntityEventPacket;
import cn.axeon.network.protocol.FullChunkDataPacket;
import cn.axeon.network.protocol.InteractPacket;
import cn.axeon.network.protocol.LoginPacket;
import cn.axeon.network.protocol.MobEquipmentPacket;
import cn.axeon.network.protocol.MovePlayerPacket;
import cn.axeon.network.protocol.PlayStatusPacket;
import cn.axeon.network.protocol.PlayerActionPacket;
import cn.axeon.network.protocol.RemoveBlockPacket;
import cn.axeon.network.protocol.RequestChunkRadiusPacket;
import cn.axeon.network.protocol.RespawnPacket;
import cn.axeon.network.protocol.SetDifficultyPacket;
import cn.axeon.network.protocol.SetEntityLinkPacket;
import cn.axeon.network.protocol.SetEntityMotionPacket;
import cn.axeon.network.protocol.SetPlayerGameTypePacket;
import cn.axeon.network.protocol.SetSpawnPositionPacket;
import cn.axeon.network.protocol.SetTimePacket;
import cn.axeon.network.protocol.StartGamePacket;
import cn.axeon.network.protocol.TakeItemEntityPacket;
import cn.axeon.network.protocol.TextPacket;
import cn.axeon.network.protocol.UpdateAttributesPacket;
import cn.axeon.network.protocol.UseItemPacket;
import cn.axeon.permission.PermissibleBase;
import cn.axeon.permission.Permission;
import cn.axeon.permission.PermissionAttachment;
import cn.axeon.permission.PermissionAttachmentInfo;
import cn.axeon.plugin.Plugin;
import cn.axeon.potion.Potion;
import cn.axeon.utils.Binary;
import cn.axeon.utils.TextFormat;
import cn.axeon.utils.Zlib;
import java.io.IOException;
import java.lang.invoke.LambdaMetafactory;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.TreeMap;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.IntFunction;

public class Player
extends EntityHuman
implements CommandSender,
InventoryHolder,
ChunkLoader,
IPlayer {
    public static final int SURVIVAL = 0;
    public static final int CREATIVE = 1;
    public static final int ADVENTURE = 2;
    public static final int SPECTATOR = 3;
    public static final int VIEW = 3;
    public static final int SURVIVAL_SLOTS = 36;
    public static final int CREATIVE_SLOTS = 112;
    protected SourceInterface interfaz;
    public boolean playedBefore;
    public boolean spawned = false;
    public boolean loggedIn = false;
    public int gamemode;
    public long lastBreak;
    protected int windowCnt = 2;
    protected Map<Inventory, Integer> windows;
    protected Map<Integer, Inventory> windowIndex = new HashMap<Integer, Inventory>();
    protected int messageCounter = 2;
    protected int sendIndex = 0;
    private String clientSecret;
    public Vector3 speed = null;
    public boolean blocked = false;
    protected SimpleTransactionGroup currentTransaction = null;
    public int craftingType = 0;
    protected boolean isCrafting = false;
    public long creationTime = 0L;
    protected long randomClientId;
    protected double lastMovement = 0.0;
    protected Vector3 forceMovement = null;
    protected Vector3 teleportPosition = null;
    protected boolean connected = true;
    protected String ip;
    protected boolean removeFormat = true;
    protected int port;
    protected String username;
    protected String iusername;
    protected String displayName;
    protected int startAction = -1;
    protected Vector3 sleeping = null;
    protected Long clientID = null;
    private Integer loaderId = null;
    protected float stepHeight = 0.6f;
    public Map<String, Boolean> usedChunks = new HashMap<String, Boolean>();
    protected int chunkLoadCount = 0;
    protected Map<String, Integer> loadQueue = new HashMap<String, Integer>();
    protected int nextChunkOrderRun = 5;
    protected Map<UUID, Player> hiddenPlayers = new HashMap<UUID, Player>();
    protected Vector3 newPosition = null;
    protected int viewDistance;
    protected int chunksPerTick;
    protected int spawnThreshold;
    private Position spawnPosition = null;
    protected int inAirTicks = 0;
    protected int startAirTicks = 5;
    protected boolean autoJump = true;
    protected boolean allowFlight = false;
    private Map<Integer, Boolean> needACK = new HashMap<Integer, Boolean>();
    private Map<Integer, List<DataPacket>> batchedPackets = new TreeMap<Integer, List<DataPacket>>();
    private PermissibleBase perm = null;
    private int exp = 0;
    private int expLevel = 0;
    private PlayerFood foodData = null;
    private Entity killer = null;
    private final AtomicReference<Locale> locale = new AtomicReference<Object>(null);
    private int hash;
    private boolean foodEnabled = true;

    public TranslationContainer getLeaveMessage() {
        return new TranslationContainer("\u00a7e%multiplayer.player.left", this.getDisplayName());
    }

    public String getClientSecret() {
        return this.clientSecret;
    }

    public Long getClientId() {
        return this.clientID;
    }

    @Override
    public boolean isBanned() {
        return this.server.getNameBans().isBanned(this.getName().toLowerCase());
    }

    @Override
    public void setBanned(boolean value) {
        if (value) {
            this.server.getNameBans().addBan(this.getName(), null, null, null);
            this.kick("You have been banned");
        } else {
            this.server.getNameBans().remove(this.getName());
        }
    }

    @Override
    public boolean isWhitelisted() {
        return this.server.isWhitelisted(this.getName().toLowerCase());
    }

    @Override
    public void setWhitelisted(boolean value) {
        if (value) {
            this.server.addWhitelist(this.getName().toLowerCase());
        } else {
            this.server.removeWhitelist(this.getName().toLowerCase());
        }
    }

    @Override
    public Player getPlayer() {
        return this;
    }

    @Override
    public Long getFirstPlayed() {
        return this.namedTag != null ? Long.valueOf(this.namedTag.getLong("firstPlayed")) : null;
    }

    @Override
    public Long getLastPlayed() {
        return this.namedTag != null ? Long.valueOf(this.namedTag.getLong("lastPlayed")) : null;
    }

    @Override
    public boolean hasPlayedBefore() {
        return this.playedBefore;
    }

    public void setAllowFlight(boolean value) {
        this.allowFlight = value;
        this.inAirTicks = 0;
        this.sendSettings();
    }

    public boolean getAllowFlight() {
        return this.allowFlight;
    }

    public void setAutoJump(boolean value) {
        this.autoJump = value;
        this.sendSettings();
    }

    public boolean hasAutoJump() {
        return this.autoJump;
    }

    @Override
    public void spawnTo(Player player) {
        if (this.spawned && player.spawned && this.isAlive() && player.isAlive() && player.getLevel() == this.level && player.canSee(this) && !this.isSpectator()) {
            super.spawnTo(player);
        }
    }

    @Override
    public Server getServer() {
        return this.server;
    }

    public boolean getRemoveFormat() {
        return this.removeFormat;
    }

    public void setRemoveFormat() {
        this.setRemoveFormat(true);
    }

    public void setRemoveFormat(boolean remove) {
        this.removeFormat = remove;
    }

    public boolean canSee(Player player) {
        return !this.hiddenPlayers.containsKey(player.getUniqueId());
    }

    public void hidePlayer(Player player) {
        if (this == player) {
            return;
        }
        this.hiddenPlayers.put(player.getUniqueId(), player);
        player.despawnFrom(this);
    }

    public void showPlayer(Player player) {
        if (this == player) {
            return;
        }
        this.hiddenPlayers.remove(player.getUniqueId());
        if (player.isOnline()) {
            player.spawnTo(this);
        }
    }

    @Override
    public boolean canCollideWith(Entity entity) {
        return false;
    }

    @Override
    public void resetFallDistance() {
        super.resetFallDistance();
        if (this.inAirTicks != 0) {
            this.startAirTicks = 5;
        }
        this.inAirTicks = 0;
        this.highestPosition = this.y;
    }

    @Override
    public boolean isOnline() {
        return this.connected && this.loggedIn;
    }

    @Override
    public boolean isOp() {
        return this.server.isOp(this.getName());
    }

    @Override
    public void setOp(boolean value) {
        if (value == this.isOp()) {
            return;
        }
        if (value) {
            this.server.addOp(this.getName());
        } else {
            this.server.removeOp(this.getName());
        }
        this.recalculatePermissions();
    }

    @Override
    public boolean isPermissionSet(String name) {
        return this.perm.isPermissionSet(name);
    }

    @Override
    public boolean isPermissionSet(Permission permission) {
        return this.perm.isPermissionSet(permission);
    }

    @Override
    public boolean hasPermission(String name) {
        return this.perm != null && this.perm.hasPermission(name);
    }

    @Override
    public boolean hasPermission(Permission permission) {
        return this.perm.hasPermission(permission);
    }

    @Override
    public PermissionAttachment addAttachment(Plugin plugin) {
        return this.addAttachment(plugin, null);
    }

    @Override
    public PermissionAttachment addAttachment(Plugin plugin, String name) {
        return this.addAttachment(plugin, name, null);
    }

    @Override
    public PermissionAttachment addAttachment(Plugin plugin, String name, Boolean value) {
        return this.perm.addAttachment(plugin, name, value);
    }

    @Override
    public void removeAttachment(PermissionAttachment attachment) {
        this.perm.removeAttachment(attachment);
    }

    @Override
    public void recalculatePermissions() {
        this.server.getPluginManager().unsubscribeFromPermission("nukkit.broadcast.user", this);
        this.server.getPluginManager().unsubscribeFromPermission("nukkit.broadcast.admin", this);
        if (this.perm == null) {
            return;
        }
        this.perm.recalculatePermissions();
        if (this.hasPermission("nukkit.broadcast.user")) {
            this.server.getPluginManager().subscribeToPermission("nukkit.broadcast.user", this);
        }
        if (this.hasPermission("nukkit.broadcast.admin")) {
            this.server.getPluginManager().subscribeToPermission("nukkit.broadcast.admin", this);
        }
    }

    @Override
    public Map<String, PermissionAttachmentInfo> getEffectivePermissions() {
        return this.perm.getEffectivePermissions();
    }

    public Player(SourceInterface interfaz, Long clientID, String ip, int port) {
        super(null, new CompoundTag());
        this.interfaz = interfaz;
        this.windows = new HashMap<Inventory, Integer>();
        this.perm = new PermissibleBase(this);
        this.server = Server.getInstance();
        this.lastBreak = Long.MAX_VALUE;
        this.ip = ip;
        this.port = port;
        this.clientID = clientID;
        this.loaderId = Level.generateChunkLoaderId(this);
        this.chunksPerTick = (Integer)this.server.getConfig("chunk-sending.per-tick", 4);
        this.spawnThreshold = (Integer)this.server.getConfig("chunk-sending.spawn-threshold", 56);
        this.spawnPosition = null;
        this.gamemode = this.server.getGamemode();
        this.setLevel(this.server.getDefaultLevel());
        this.viewDistance = this.server.getViewDistance();
        this.boundingBox = new AxisAlignedBB(0.0, 0.0, 0.0, 0.0, 0.0, 0.0);
        this.uuid = null;
        this.rawUUID = null;
        this.creationTime = System.currentTimeMillis();
    }

    @Override
    public boolean isPlayer() {
        return true;
    }

    public boolean isConnected() {
        return this.connected;
    }

    public String getDisplayName() {
        return this.displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
        if (this.spawned) {
            this.server.updatePlayerListData(this.getUniqueId(), this.getId(), this.getDisplayName(), this.getSkin());
        }
    }

    @Override
    public void setSkin(Skin skin) {
        super.setSkin(skin);
        if (this.spawned) {
            this.server.updatePlayerListData(this.getUniqueId(), this.getId(), this.getDisplayName(), skin);
        }
    }

    public String getAddress() {
        return this.ip;
    }

    public int getPort() {
        return this.port;
    }

    public Position getNextPosition() {
        return this.newPosition != null ? new Position(this.newPosition.x, this.newPosition.y, this.newPosition.z, this.level) : this.getPosition();
    }

    public boolean isSleeping() {
        return this.sleeping != null;
    }

    public int getInAirTicks() {
        return this.inAirTicks;
    }

    @Override
    protected boolean switchLevel(Level targetLevel) {
        Level oldLevel = this.level;
        if (super.switchLevel(targetLevel)) {
            for (String index : new ArrayList<String>(this.usedChunks.keySet())) {
                Chunk.Entry chunkEntry = Level.getChunkXZ(index);
                int chunkX = chunkEntry.chunkX;
                int chunkZ = chunkEntry.chunkZ;
                this.unloadChunk(chunkX, chunkZ, oldLevel);
            }
            this.usedChunks = new HashMap<String, Boolean>();
            SetTimePacket pk = new SetTimePacket();
            pk.time = this.level.getTime();
            pk.started = !this.level.stopTime;
            this.dataPacket(pk);
            return true;
        }
        return false;
    }

    public void unloadChunk(int x, int z) {
        this.unloadChunk(x, z, null);
    }

    public void unloadChunk(int x, int z, Level level) {
        level = level == null ? this.level : level;
        String index = Level.chunkHash(x, z);
        if (this.usedChunks.containsKey(index)) {
            for (Entity entity : level.getChunkEntities(x, z).values()) {
                if (entity == this) continue;
                entity.despawnFrom(this);
            }
            this.usedChunks.remove(index);
        }
        level.unregisterChunkLoader(this, x, z);
        this.loadQueue.remove(index);
    }

    public Position getSpawn() {
        if (this.spawnPosition != null && this.spawnPosition.getLevel() != null) {
            return this.spawnPosition;
        }
        return this.server.getDefaultLevel().getSafeSpawn();
    }

    public void sendChunk(int x, int z, DataPacket packet) {
        if (!this.connected) {
            return;
        }
        this.usedChunks.put(Level.chunkHash(x, z), true);
        ++this.chunkLoadCount;
        this.dataPacket(packet);
        if (this.spawned) {
            for (Entity entity : this.level.getChunkEntities(x, z).values()) {
                if (this == entity || entity.closed || !entity.isAlive()) continue;
                entity.spawnTo(this);
            }
        }
    }

    public void sendChunk(int x, int z, byte[] payload) {
        this.sendChunk(x, z, payload, (byte)0);
    }

    public void sendChunk(int x, int z, byte[] payload, byte ordering) {
        if (!this.connected) {
            return;
        }
        this.usedChunks.put(Level.chunkHash(x, z), true);
        ++this.chunkLoadCount;
        FullChunkDataPacket pk = new FullChunkDataPacket();
        pk.chunkX = x;
        pk.chunkZ = z;
        pk.order = ordering;
        pk.data = payload;
        this.batchDataPacket(pk);
        if (this.spawned) {
            for (Entity entity : this.level.getChunkEntities(x, z).values()) {
                if (this == entity || entity.closed || !entity.isAlive()) continue;
                entity.spawnTo(this);
            }
        }
    }

    protected void sendNextChunk() {
        if (!this.connected) {
            return;
        }
        int count = 0;
        ArrayList<Map.Entry<String, Integer>> entryList = new ArrayList<Map.Entry<String, Integer>>(this.loadQueue.entrySet());
        entryList.sort(new Comparator<Map.Entry<String, Integer>>(){

            @Override
            public int compare(Map.Entry<String, Integer> o1, Map.Entry<String, Integer> o2) {
                return o1.getValue() - o2.getValue();
            }
        });
        for (Map.Entry entry : entryList) {
            String index = (String)entry.getKey();
            if (count >= this.chunksPerTick) break;
            Chunk.Entry chunkEntry = Level.getChunkXZ(index);
            int chunkX = chunkEntry.chunkX;
            int chunkZ = chunkEntry.chunkZ;
            ++count;
            this.usedChunks.put(index, false);
            this.level.registerChunkLoader(this, chunkX, chunkZ, false);
            if (!this.level.populateChunk(chunkX, chunkZ)) {
                if (!this.spawned || this.teleportPosition != null) break;
                continue;
            }
            this.loadQueue.remove(index);
            PlayerChunkRequestEvent ev = new PlayerChunkRequestEvent(this, chunkX, chunkZ);
            this.server.getPluginManager().callEvent(ev);
            if (ev.isCancelled()) continue;
            this.level.requestChunk(chunkX, chunkZ, this);
        }
        if (this.chunkLoadCount >= this.spawnThreshold && !this.spawned && this.teleportPosition == null) {
            this.doFirstSpawn();
        }
    }

    protected void doFirstSpawn() {
        this.spawned = true;
        this.server.sendRecipeList(this);
        this.sendSettings();
        this.server.updatePlayerListData(this.getUniqueId(), this.getId(), this.getDisplayName(), this.getSkin());
        this.server.sendFullPlayerListData(this, false);
        this.sendPotionEffects(this);
        this.sendData(this);
        this.inventory.sendContents(this);
        this.inventory.sendArmorContents(this);
        SetTimePacket setTimePacket = new SetTimePacket();
        setTimePacket.time = this.level.getTime();
        setTimePacket.started = !this.level.stopTime;
        this.dataPacket(setTimePacket);
        Position pos = this.level.getSafeSpawn(this);
        PlayerRespawnEvent respawnEvent = new PlayerRespawnEvent(this, pos);
        this.server.getPluginManager().callEvent(respawnEvent);
        pos = respawnEvent.getRespawnPosition();
        RespawnPacket respawnPacket = new RespawnPacket();
        respawnPacket.x = (float)pos.x;
        respawnPacket.y = (float)pos.y;
        respawnPacket.z = (float)pos.z;
        this.dataPacket(respawnPacket);
        PlayStatusPacket playStatusPacket = new PlayStatusPacket();
        playStatusPacket.status = 3;
        this.dataPacket(playStatusPacket);
        PlayerJoinEvent playerJoinEvent = new PlayerJoinEvent(this, new TranslationContainer("\u00a7e%multiplayer.player.joined", new String[]{this.getDisplayName()}));
        this.server.getPluginManager().callEvent(playerJoinEvent);
        if (playerJoinEvent.getJoinMessage().toString().trim().length() > 0) {
            this.server.broadcastMessage(playerJoinEvent.getJoinMessage());
        }
        this.noDamageTicks = 60;
        for (String index : this.usedChunks.keySet()) {
            Chunk.Entry chunkEntry = Level.getChunkXZ(index);
            int chunkX = chunkEntry.chunkX;
            int chunkZ = chunkEntry.chunkZ;
            for (Entity entity : this.level.getChunkEntities(chunkX, chunkZ).values()) {
                if (this == entity || entity.closed || !entity.isAlive()) continue;
                entity.spawnTo(this);
            }
        }
        this.sendExperience(this.getExperience());
        this.sendExperienceLevel(this.getExperienceLevel());
        this.teleport(pos, null);
        if (!this.isSpectator()) {
            this.spawnToAll();
        }
        if (this.getHealth() <= 0) {
            respawnPacket = new RespawnPacket();
            pos = this.getSpawn();
            respawnPacket.x = (float)pos.x;
            respawnPacket.y = (float)pos.y;
            respawnPacket.z = (float)pos.z;
            this.dataPacket(respawnPacket);
        }
        this.getLevel().sendWeather(this);
        this.getFoodData().sendFoodLevel();
    }

    protected boolean orderChunks() {
        if (!this.connected) {
            return false;
        }
        this.nextChunkOrderRun = 200;
        HashMap<String, Integer> newOrder = new HashMap<String, Integer>();
        HashMap<String, Boolean> lastChunk = new HashMap<String, Boolean>(this.usedChunks);
        int centerX = (int)this.x >> 4;
        int centerZ = (int)this.z >> 4;
        int count = 0;
        for (int x = -this.viewDistance; x <= this.viewDistance; ++x) {
            for (int z = -this.viewDistance; z <= this.viewDistance; ++z) {
                int chunkX = x + centerX;
                int chunkZ = z + centerZ;
                int distance = (int)Math.sqrt((double)x * (double)x + (double)z * (double)z);
                if (distance > this.viewDistance) continue;
                String index = Level.chunkHash(chunkX, chunkZ);
                if (!this.usedChunks.containsKey(index) || !this.usedChunks.get(index).booleanValue()) {
                    newOrder.put(index, distance);
                    ++count;
                }
                lastChunk.remove(index);
            }
        }
        for (String index : new ArrayList(lastChunk.keySet())) {
            Chunk.Entry entry = Level.getChunkXZ(index);
            this.unloadChunk(entry.chunkX, entry.chunkZ);
        }
        this.loadQueue = newOrder;
        return true;
    }

    public boolean batchDataPacket(DataPacket packet) {
        if (!this.connected) {
            return false;
        }
        DataPacketSendEvent event = new DataPacketSendEvent(this, packet);
        this.server.getPluginManager().callEvent(event);
        if (event.isCancelled()) {
            return false;
        }
        if (!this.batchedPackets.containsKey(packet.getChannel())) {
            this.batchedPackets.put(packet.getChannel(), new ArrayList());
        }
        this.batchedPackets.get(packet.getChannel()).add(packet.clone());
        return true;
    }

    public boolean dataPacket(DataPacket packet) {
        return this.dataPacket(packet, false) != -1;
    }

    public int dataPacket(DataPacket packet, boolean needACK) {
        if (!this.connected) {
            return -1;
        }
        DataPacketSendEvent ev = new DataPacketSendEvent(this, packet);
        this.server.getPluginManager().callEvent(ev);
        if (ev.isCancelled()) {
            return -1;
        }
        Integer identifier = this.interfaz.putPacket(this, packet, needACK, false);
        if (needACK && identifier != null) {
            this.needACK.put(identifier, false);
            return identifier;
        }
        return 0;
    }

    public boolean directDataPacket(DataPacket packet) {
        return this.directDataPacket(packet, false) != -1;
    }

    public int directDataPacket(DataPacket packet, boolean needACK) {
        if (!this.connected) {
            return -1;
        }
        DataPacketSendEvent ev = new DataPacketSendEvent(this, packet);
        this.server.getPluginManager().callEvent(ev);
        if (ev.isCancelled()) {
            return -1;
        }
        Integer identifier = this.interfaz.putPacket(this, packet, needACK, true);
        if (needACK && identifier != null) {
            this.needACK.put(identifier, false);
            return identifier;
        }
        return 0;
    }

    public boolean sleepOn(Vector3 pos) {
        if (!this.isOnline()) {
            return false;
        }
        for (Entity p : this.level.getNearbyEntities(this.boundingBox.grow(2.0, 1.0, 2.0), this)) {
            if (!(p instanceof Player) || ((Player)p).sleeping == null || !(pos.distance(((Player)p).sleeping) <= 0.1)) continue;
            return false;
        }
        PlayerBedEnterEvent ev = new PlayerBedEnterEvent(this, this.level.getBlock(pos));
        this.server.getPluginManager().callEvent(ev);
        if (ev.isCancelled()) {
            return false;
        }
        this.sleeping = pos.clone();
        this.teleport(new Location(pos.x + 0.5, pos.y - 0.5, pos.z + 0.5, this.yaw, this.pitch, this.level), null);
        this.setDataProperty(new PositionEntityData(17, (int)pos.x, (int)pos.y, (int)pos.z));
        this.setDataFlag(16, 1, true);
        this.setSpawn(pos);
        this.level.sleepTicks = 60;
        return true;
    }

    public void setSpawn(Vector3 pos) {
        Level level = !(pos instanceof Position) ? this.level : ((Position)pos).getLevel();
        this.spawnPosition = new Position(pos.x, pos.y, pos.z, level);
        SetSpawnPositionPacket pk = new SetSpawnPositionPacket();
        pk.x = (int)this.spawnPosition.x;
        pk.y = (int)this.spawnPosition.y;
        pk.z = (int)this.spawnPosition.z;
        this.dataPacket(pk);
    }

    public void stopSleep() {
        if (this.sleeping != null) {
            this.server.getPluginManager().callEvent(new PlayerBedLeaveEvent(this, this.level.getBlock(this.sleeping)));
            this.sleeping = null;
            this.setDataProperty(new PositionEntityData(17, 0, 0, 0));
            this.setDataFlag(16, 1, false);
            this.level.sleepTicks = 0;
            AnimatePacket pk = new AnimatePacket();
            pk.eid = 0L;
            pk.action = 3;
            this.dataPacket(pk);
        }
    }

    public int getGamemode() {
        return this.gamemode;
    }

    public boolean setGamemode(int gamemode) {
        if (gamemode < 0 || gamemode > 3 || this.gamemode == gamemode) {
            return false;
        }
        PlayerGameModeChangeEvent ev = new PlayerGameModeChangeEvent(this, gamemode);
        this.server.getPluginManager().callEvent(ev);
        if (ev.isCancelled()) {
            return false;
        }
        this.gamemode = gamemode;
        this.allowFlight = this.isCreative();
        this.inAirTicks = 0;
        if (this.isSpectator()) {
            this.keepMovement = true;
            this.despawnFromAll();
        } else {
            this.keepMovement = false;
            this.spawnToAll();
        }
        this.namedTag.putInt("playerGameType", this.gamemode);
        SetPlayerGameTypePacket pk = new SetPlayerGameTypePacket();
        pk.gamemode = this.gamemode & 1;
        this.dataPacket(pk);
        this.sendSettings();
        if (this.gamemode == 3) {
            ContainerSetContentPacket containerSetContentPacket = new ContainerSetContentPacket();
            containerSetContentPacket.windowid = 121;
            this.dataPacket(containerSetContentPacket);
        } else {
            ContainerSetContentPacket containerSetContentPacket = new ContainerSetContentPacket();
            containerSetContentPacket.windowid = 121;
            containerSetContentPacket.slots = (Item[])Item.getCreativeItems().stream().toArray(Item[]::new);
            this.dataPacket(containerSetContentPacket);
        }
        this.inventory.sendContents(this);
        this.inventory.sendContents(this.getViewers().values());
        this.inventory.sendHeldItem(this.hasSpawned.values());
        return true;
    }

    public void sendSettings() {
        int flags = 0;
        if (this.isAdventure()) {
            flags |= 1;
        }
        if (this.autoJump) {
            flags |= 0x40;
        }
        if (this.allowFlight) {
            flags |= 0x80;
        }
        if (this.isSpectator()) {
            flags |= 0x100;
        }
        AdventureSettingsPacket pk = new AdventureSettingsPacket();
        pk.flags = flags;
        pk.userPermission = 2;
        pk.globalPermission = 2;
        this.dataPacket(pk);
    }

    public boolean isSurvival() {
        return (this.gamemode & 1) == 0;
    }

    public boolean isCreative() {
        return (this.gamemode & 1) > 0;
    }

    public boolean isSpectator() {
        return this.gamemode == 3;
    }

    public boolean isAdventure() {
        return (this.gamemode & 2) > 0;
    }

    @Override
    public Item[] getDrops() {
        if (!this.isCreative()) {
            return super.getDrops();
        }
        return new Item[0];
    }

    @Override
    public boolean setDataProperty(EntityData data) {
        if (super.setDataProperty(data)) {
            this.sendData(this, new EntityMetadata().put(this.getDataProperty(data.getId())));
            return true;
        }
        return false;
    }

    @Override
    protected void checkGroundState(double movX, double movY, double movZ, double dx, double dy, double dz) {
        if (!this.onGround || movX != 0.0 || movY != 0.0 || movZ != 0.0) {
            boolean onGround = false;
            AxisAlignedBB bb = this.boundingBox.clone();
            bb.maxY = bb.minY + 0.5;
            bb.minY -= 1.0;
            AxisAlignedBB realBB = this.boundingBox.clone();
            realBB.maxY = realBB.minY + 0.1;
            realBB.minY -= 0.2;
            int minX = NukkitMath.floorDouble(bb.minX);
            int minY = NukkitMath.floorDouble(bb.minY);
            int minZ = NukkitMath.floorDouble(bb.minZ);
            int maxX = NukkitMath.ceilDouble(bb.maxX);
            int maxY = NukkitMath.ceilDouble(bb.maxY);
            int maxZ = NukkitMath.ceilDouble(bb.maxZ);
            for (int z = minZ; z <= maxZ; ++z) {
                block1: for (int x = minX; x <= maxX; ++x) {
                    for (int y = minY; y <= maxY; ++y) {
                        Block block = this.level.getBlock(this.temporalVector.setComponents(x, y, z));
                        if (block.canPassThrough() || !block.collidesWithBB(realBB)) continue;
                        onGround = true;
                        continue block1;
                    }
                }
            }
            this.onGround = onGround;
        }
        this.isCollided = this.onGround;
    }

    @Override
    protected void checkBlockCollision() {
        for (Block block : this.getBlocksAround()) {
            block.onEntityCollide(this);
        }
    }

    protected void checkNearEntities() {
        for (Entity entity : this.level.getNearbyEntities(this.boundingBox.grow(1.0, 0.5, 1.0), this)) {
            TakeItemEntityPacket pk;
            InventoryEvent ev;
            Item item;
            entity.scheduleUpdate();
            if (!entity.isAlive() || !this.isAlive()) continue;
            if (entity instanceof EntityArrow && ((EntityArrow)entity).hadCollision) {
                item = new ItemArrow();
                if (this.isSurvival() && !this.inventory.canAddItem(item)) continue;
                ev = new InventoryPickupArrowEvent(this.inventory, (EntityArrow)entity);
                this.server.getPluginManager().callEvent(ev);
                if (ev.isCancelled()) continue;
                pk = new TakeItemEntityPacket();
                pk.entityId = this.getId();
                pk.target = entity.getId();
                Server.broadcastPacket(entity.getViewers().values(), (DataPacket)pk);
                pk = new TakeItemEntityPacket();
                pk.entityId = 0L;
                pk.target = entity.getId();
                this.dataPacket(pk);
                this.inventory.addItem(item.clone());
                entity.kill();
                continue;
            }
            if (!(entity instanceof EntityItem) || ((EntityItem)entity).getPickupDelay() > 0 || (item = ((EntityItem)entity).getItem()) == null || this.isSurvival() && !this.inventory.canAddItem(item)) continue;
            ev = new InventoryPickupItemEvent(this.inventory, (EntityItem)entity);
            this.server.getPluginManager().callEvent(ev);
            if (ev.isCancelled()) continue;
            pk = new TakeItemEntityPacket();
            pk.entityId = this.getId();
            pk.target = entity.getId();
            Server.broadcastPacket(entity.getViewers().values(), (DataPacket)pk);
            pk = new TakeItemEntityPacket();
            pk.entityId = 0L;
            pk.target = entity.getId();
            this.dataPacket(pk);
            this.inventory.addItem(item.clone());
            entity.kill();
        }
        for (Entity entity : this.level.getNearbyEntities(this.boundingBox.grow(3.5, 2.0, 3.5), this)) {
            EntityXPOrb xpOrb;
            entity.scheduleUpdate();
            if (!entity.isAlive() || !this.isAlive() || !(entity instanceof EntityXPOrb) || (xpOrb = (EntityXPOrb)entity).getPickupDelay() > 0) continue;
            int exp = xpOrb.getExp();
            this.addExperience(exp);
            entity.kill();
            ClickSound sound = new ClickSound((Vector3)this, (float)new NukkitRandom().nextRange(260, 360) / 100.0f);
            this.getLevel().addSound(sound);
            break;
        }
    }

    protected void processMovement(int tickDiff) {
        if (!this.isAlive() || !this.spawned || this.newPosition == null || this.teleportPosition != null) {
            return;
        }
        Vector3 newPos = this.newPosition;
        double distanceSquared = newPos.distanceSquared(this);
        boolean revert = false;
        if (distanceSquared / (double)(tickDiff * tickDiff) > 100.0 && newPos.y - this.y > -5.0) {
            revert = true;
        } else if (this.chunk == null || !this.chunk.isGenerated()) {
            BaseFullChunk chunk = this.level.getChunk((int)newPos.x >> 4, (int)newPos.z >> 4, false);
            if (chunk == null || !chunk.isGenerated()) {
                revert = true;
                this.nextChunkOrderRun = 0;
            } else {
                if (this.chunk != null) {
                    this.chunk.removeEntity(this);
                }
                this.chunk = chunk;
            }
        }
        Vector2 newPosV2 = new Vector2(newPos.x, newPos.z);
        double distance = newPosV2.distance(this.x, this.z);
        if (!revert && distanceSquared != 0.0) {
            double dx = newPos.x - this.x;
            double dy = newPos.y - this.y;
            double dz = newPos.z - this.z;
            this.move(dx, dy, dz);
            double diffX = this.x - newPos.x;
            double diffY = this.y - newPos.y;
            double diffZ = this.z - newPos.z;
            double yS = 0.5 + (double)this.ySize;
            if (diffY >= -yS || diffY <= yS) {
                diffY = 0.0;
            }
            double diff = (diffX * diffX + diffY * diffY + diffZ * diffZ) / (double)(tickDiff * tickDiff);
            if (this.isSurvival() && !this.isSleeping() && diff > 0.0625) {
                PlayerInvalidMoveEvent ev = new PlayerInvalidMoveEvent(this, true);
                this.getServer().getPluginManager().callEvent(ev);
                if (!ev.isCancelled() && (revert = ev.isRevert())) {
                    this.server.getLogger().warning(this.getServer().getLanguage().translateString("nukkit.player.invalidMove", this.getName()));
                }
            }
            if (diff > 0.0) {
                this.x = newPos.x;
                this.y = newPos.y;
                this.z = newPos.z;
                double radius = this.getWidth() / 2.0f;
                this.boundingBox.setBounds(this.x - radius, this.y, this.z - radius, this.x + radius, this.y + (double)this.getHeight(), this.z + radius);
            }
        }
        Location from = new Location(this.lastX, this.lastY, this.lastZ, this.lastYaw, this.lastPitch, this.level);
        Location to = this.getLocation();
        double delta = Math.pow(this.lastX - to.x, 2.0) + Math.pow(this.lastY - to.y, 2.0) + Math.pow(this.lastZ - to.z, 2.0);
        double deltaAngle = Math.abs(this.lastYaw - to.yaw) + Math.abs(this.lastPitch - to.pitch);
        if (!revert && (delta > 0.0 || deltaAngle > 10.0)) {
            boolean isFirst = this.firstMove;
            this.firstMove = false;
            this.lastX = to.x;
            this.lastY = to.y;
            this.lastZ = to.z;
            this.lastYaw = to.yaw;
            this.lastPitch = to.pitch;
            if (!isFirst) {
                PlayerMoveEvent ev = new PlayerMoveEvent(this, from, to);
                this.server.getPluginManager().callEvent(ev);
                revert = ev.isCancelled();
                if (!revert) {
                    if (to.distanceSquared(ev.getTo()) > 0.01) {
                        this.teleport(ev.getTo(), null);
                    } else {
                        this.level.addEntityMovement((int)this.x >> 4, (int)this.z >> 4, this.getId(), this.x, this.y + (double)this.getEyeHeight(), this.z, this.yaw, this.pitch, this.yaw);
                    }
                }
            }
            if (!this.isSpectator()) {
                this.checkNearEntities();
            }
            this.speed = from.subtract(to);
        } else if (distanceSquared == 0.0) {
            this.speed = new Vector3(0.0, 0.0, 0.0);
        }
        if (!revert && (this.isFoodEnabled() || this.getServer().getDifficulty() == 0) && (this.isSurvival() || this.isAdventure()) && distance >= 0.05) {
            double swimming;
            double jump = 0.0;
            double d = swimming = this.isInsideOfWater() ? 0.015 * distance : 0.0;
            if (swimming != 0.0) {
                distance = 0.0;
            }
            if (this.isSprinting()) {
                if (this.inAirTicks == 3 && swimming == 0.0) {
                    jump = 0.7;
                }
                this.getFoodData().updateFoodExpLevel(0.1 * distance + jump + swimming);
            } else {
                if (this.inAirTicks == 3 && swimming == 0.0) {
                    jump = 0.2;
                }
                this.getFoodData().updateFoodExpLevel(0.01 * distance + jump + swimming);
            }
        }
        if (revert) {
            this.lastX = from.x;
            this.lastY = from.y;
            this.lastZ = from.z;
            this.lastYaw = from.yaw;
            this.lastPitch = from.pitch;
            this.sendPosition(from, from.yaw, from.pitch, (byte)1);
            this.forceMovement = new Vector3(from.x, from.y, from.z);
        } else {
            this.forceMovement = null;
            if (distanceSquared != 0.0 && this.nextChunkOrderRun > 20) {
                this.nextChunkOrderRun = 20;
            }
        }
        this.newPosition = null;
    }

    @Override
    public boolean setMotion(Vector3 motion) {
        if (super.setMotion(motion)) {
            if (this.chunk != null) {
                this.level.addEntityMotion(this.chunk.getX(), this.chunk.getZ(), this.getId(), this.motionX, this.motionY, this.motionZ);
                SetEntityMotionPacket pk = new SetEntityMotionPacket();
                pk.entities = new SetEntityMotionPacket.Entry[]{new SetEntityMotionPacket.Entry(0L, (float)motion.x, (float)motion.y, (float)motion.z)};
                this.dataPacket(pk);
            }
            if (this.motionY > 0.0) {
                this.startAirTicks = (int)(-Math.log((double)this.getGravity() / ((double)this.getGravity() + (double)this.getDrag() * this.motionY)) / (double)this.getDrag() * 2.0 + 5.0);
            }
            return true;
        }
        return false;
    }

    @Override
    public void addMovement(double x, double y, double z, double yaw, double pitch, double headYaw) {
        this.level.addPlayerMovement(this.chunk.getX(), this.chunk.getZ(), this.id, x, y, z, yaw, pitch, this.isOnGround());
    }

    @Override
    public boolean onUpdate(int currentTick) {
        if (!this.loggedIn) {
            return false;
        }
        int tickDiff = currentTick - this.lastUpdate;
        if (tickDiff <= 0) {
            return true;
        }
        this.messageCounter = 2;
        this.lastUpdate = currentTick;
        if (!this.isAlive() && this.spawned) {
            ++this.deadTicks;
            if (this.deadTicks >= 10) {
                this.despawnFromAll();
            }
            return true;
        }
        if (this.spawned) {
            this.processMovement(tickDiff);
            this.entityBaseTick(tickDiff);
            if (this.isOnFire() && this.lastUpdate % 10 == 0) {
                if (this.isCreative() && !this.isInsideOfFire()) {
                    this.extinguish();
                } else if (this.getLevel().isRaining() && this.getLevel().canBlockSeeSky(this)) {
                    this.extinguish();
                }
            }
            if (!this.isSpectator() && this.speed != null) {
                if (this.onGround) {
                    if (this.inAirTicks != 0) {
                        this.startAirTicks = 5;
                    }
                    this.inAirTicks = 0;
                    this.highestPosition = this.y;
                } else {
                    if (!(this.allowFlight || this.inAirTicks <= 10 || this.isSleeping() || this.getDataPropertyBoolean(15))) {
                        double expectedVelocity = (double)(-this.getGravity()) / (double)this.getDrag() - (double)(-this.getGravity()) / (double)this.getDrag() * Math.exp(-((double)this.getDrag()) * (double)(this.inAirTicks - this.startAirTicks));
                        double diff = (this.speed.y - expectedVelocity) * (this.speed.y - expectedVelocity);
                        if (!this.hasEffect(8) && diff > 0.6 && expectedVelocity < this.speed.y && !this.server.getAllowFlight()) {
                            if (this.inAirTicks < 100) {
                                this.setMotion(new Vector3(0.0, expectedVelocity, 0.0));
                            } else if (this.kick("Flying is not enabled on this server")) {
                                return false;
                            }
                        }
                    }
                    if (this.y > this.highestPosition) {
                        this.highestPosition = this.y;
                    }
                    ++this.inAirTicks;
                }
                if ((this.isSurvival() || this.isAdventure()) && this.getFoodData() != null) {
                    this.getFoodData().update(tickDiff);
                }
            }
        }
        this.checkTeleportPosition();
        return true;
    }

    public void checkNetwork() {
        if (!this.isOnline()) {
            return;
        }
        if (this.nextChunkOrderRun-- <= 0 || this.chunk == null) {
            this.orderChunks();
        }
        if (!this.loadQueue.isEmpty() || !this.spawned) {
            this.sendNextChunk();
        }
        if (!this.batchedPackets.isEmpty()) {
            for (int channel : this.batchedPackets.keySet()) {
                this.server.batchPackets(new Player[]{this}, (DataPacket[])this.batchedPackets.get(channel).stream().toArray(DataPacket[]::new), false);
            }
            this.batchedPackets = new TreeMap<Integer, List<DataPacket>>();
        }
    }

    public boolean canInteract(Vector3 pos, double maxDistance) {
        return this.canInteract(pos, maxDistance, 0.5);
    }

    public boolean canInteract(Vector3 pos, double maxDistance, double maxDiff) {
        if (this.distanceSquared(pos) > maxDistance * maxDistance) {
            return false;
        }
        Vector2 dV = this.getDirectionPlane();
        double dot = dV.dot(new Vector2(this.x, this.z));
        double dot1 = dV.dot(new Vector2(pos.x, pos.z));
        return dot1 - dot >= -maxDiff;
    }

    public void onPlayerPreLogin() {
        this.tryAuthenticate();
    }

    public void tryAuthenticate() {
        this.authenticateCallback(true);
    }

    public void authenticateCallback(boolean valid) {
        if (!valid) {
            this.close("", "disconnectionScreen.invalidSession");
            return;
        }
        this.processLogin();
    }

    protected void processLogin() {
        if (!this.server.isWhitelisted(this.getName().toLowerCase())) {
            this.close(this.getLeaveMessage(), "Server is white-listed");
            return;
        }
        if (this.server.getNameBans().isBanned(this.getName().toLowerCase()) || this.server.getIPBans().isBanned(this.getAddress())) {
            this.close(this.getLeaveMessage(), "You are banned");
            return;
        }
        if (this.hasPermission("nukkit.broadcast.user")) {
            this.server.getPluginManager().subscribeToPermission("nukkit.broadcast.user", this);
        }
        if (this.hasPermission("nukkit.broadcast.admin")) {
            this.server.getPluginManager().subscribeToPermission("nukkit.broadcast.admin", this);
        }
        for (Player p : new ArrayList<Player>(this.server.getOnlinePlayers().values())) {
            if (p != this && p.getName() != null && this.getName() != null && Objects.equals(p.getName().toLowerCase(), this.getName().toLowerCase())) {
                if (p.kick("logged in from another location")) continue;
                this.close(this.getLeaveMessage(), "Logged in from another location");
                return;
            }
            if (!p.loggedIn || !this.getUniqueId().equals(p.getUniqueId()) || p.kick("logged in from another location")) continue;
            this.close(this.getLeaveMessage(), "Logged in from another location");
            return;
        }
        CompoundTag nbt = this.server.getOfflinePlayerData(this.username);
        if (nbt == null) {
            this.close(this.getLeaveMessage(), "Invalid data");
            return;
        }
        this.playedBefore = nbt.getLong("lastPlayed") - nbt.getLong("firstPlayed") > 1L;
        nbt.putString("NameTag", this.username);
        int exp = nbt.getInt("EXP");
        int expLevel = nbt.getInt("expLevel");
        this.setExperience(exp, expLevel);
        this.gamemode = nbt.getInt("playerGameType") & 3;
        if (this.server.getForceGamemode()) {
            this.gamemode = this.server.getGamemode();
            nbt.putInt("playerGameType", this.gamemode);
        }
        this.allowFlight = this.isCreative();
        Level level = this.server.getLevelByName(nbt.getString("Level"));
        if (level == null) {
            this.setLevel(this.server.getDefaultLevel());
            nbt.putString("Level", this.level.getName());
            nbt.getList("Pos", DoubleTag.class).add(new DoubleTag("0", this.level.getSpawnLocation().x)).add(new DoubleTag("1", this.level.getSpawnLocation().y)).add(new DoubleTag("2", this.level.getSpawnLocation().z));
        } else {
            this.setLevel(level);
        }
        nbt.putLong("lastPlayed", System.currentTimeMillis() / 1000L);
        if (this.server.getAutoSave()) {
            this.server.saveOfflinePlayerData(this.username, nbt, true);
        }
        ListTag<DoubleTag> posList = nbt.getList("Pos", DoubleTag.class);
        super.init(this.level.getChunk((int)posList.get((int)0).data >> 4, (int)posList.get((int)2).data >> 4, true), nbt);
        if (!this.namedTag.contains("foodLevel")) {
            this.namedTag.putInt("foodLevel", 20);
        }
        int foodLevel = this.namedTag.getInt("foodLevel");
        if (!this.namedTag.contains("FoodSaturationLevel")) {
            this.namedTag.putFloat("FoodSaturationLevel", 20.0f);
        }
        float foodSaturationLevel = this.namedTag.getFloat("foodSaturationLevel");
        this.foodData = new PlayerFood(this, foodLevel, foodSaturationLevel);
        this.server.addOnlinePlayer(this, false);
        PlayerLoginEvent ev = new PlayerLoginEvent(this, "Plugin reason");
        this.server.getPluginManager().callEvent(ev);
        if (ev.isCancelled()) {
            this.close(this.getLeaveMessage(), ev.getKickMessage());
            return;
        }
        this.loggedIn = true;
        if (this.isCreative()) {
            this.inventory.setHeldItemSlot(0);
        } else {
            this.inventory.setHeldItemSlot(this.inventory.getHotbarSlotIndex(0));
        }
        if (this.isSpectator()) {
            this.keepMovement = true;
        }
        PlayStatusPacket statusPacket = new PlayStatusPacket();
        statusPacket.status = 0;
        this.dataPacket(statusPacket);
        if (this.spawnPosition == null && this.namedTag.contains("SpawnLevel") && (level = this.server.getLevelByName(this.namedTag.getString("SpawnLevel"))) != null) {
            this.spawnPosition = new Position(this.namedTag.getInt("SpawnX"), this.namedTag.getInt("SpawnY"), this.namedTag.getInt("SpawnZ"), level);
        }
        Position spawnPosition = this.getSpawn();
        StartGamePacket startGamePacket = new StartGamePacket();
        startGamePacket.seed = -1;
        startGamePacket.dimension = (byte)(this.getLevel().getDimension() & 0xFF);
        startGamePacket.x = (float)this.x;
        startGamePacket.y = (float)this.y;
        startGamePacket.z = (float)this.z;
        startGamePacket.spawnX = (int)spawnPosition.x;
        startGamePacket.spawnY = (int)spawnPosition.y;
        startGamePacket.spawnZ = (int)spawnPosition.z;
        startGamePacket.generator = 1;
        startGamePacket.gamemode = this.gamemode & 1;
        startGamePacket.eid = 0L;
        startGamePacket.b1 = true;
        startGamePacket.b2 = true;
        startGamePacket.b3 = false;
        startGamePacket.unknownstr = "";
        this.dataPacket(startGamePacket);
        SetTimePacket setTimePacket = new SetTimePacket();
        setTimePacket.time = this.level.getTime();
        setTimePacket.started = !this.level.stopTime;
        this.dataPacket(setTimePacket);
        SetSpawnPositionPacket setSpawnPositionPacket = new SetSpawnPositionPacket();
        setSpawnPositionPacket.x = (int)spawnPosition.x;
        setSpawnPositionPacket.y = (int)spawnPosition.y;
        setSpawnPositionPacket.z = (int)spawnPosition.z;
        this.dataPacket(setSpawnPositionPacket);
        UpdateAttributesPacket updateAttributesPacket = new UpdateAttributesPacket();
        updateAttributesPacket.entityId = 0L;
        updateAttributesPacket.entries = new Attribute[]{Attribute.getAttribute(0).setMaxValue(this.getMaxHealth()).setValue(this.getHealth()), Attribute.getAttribute(4).setValue(this.getMovementSpeed())};
        this.dataPacket(updateAttributesPacket);
        SetDifficultyPacket setDifficultyPacket = new SetDifficultyPacket();
        setDifficultyPacket.difficulty = this.server.getDifficulty();
        this.dataPacket(setDifficultyPacket);
        this.server.getLogger().info(this.getServer().getLanguage().translateString("nukkit.player.logIn", new String[]{"\u00a7b" + this.username + "\u00a7f", this.ip, String.valueOf(this.port), String.valueOf(this.id), this.level.getName(), String.valueOf(NukkitMath.round(this.x, 4)), String.valueOf(NukkitMath.round(this.y, 4)), String.valueOf(NukkitMath.round(this.z, 4))}));
        if (this.isOp()) {
            this.setRemoveFormat(false);
        }
        if (this.gamemode == 3) {
            ContainerSetContentPacket containerSetContentPacket = new ContainerSetContentPacket();
            containerSetContentPacket.windowid = 121;
            this.dataPacket(containerSetContentPacket);
        } else {
            ContainerSetContentPacket containerSetContentPacket = new ContainerSetContentPacket();
            containerSetContentPacket.windowid = 121;
            containerSetContentPacket.slots = (Item[])Item.getCreativeItems().stream().toArray(Item[]::new);
            this.dataPacket(containerSetContentPacket);
        }
        this.forceMovement = this.teleportPosition = this.getPosition();
        this.server.onPlayerLogin(this);
    }

    /*
     * Unable to fully structure code
     */
    public void handleDataPacket(DataPacket packet) {
        if (!this.connected) {
            return;
        }
        if (packet.pid() == -110) {
            this.server.getNetwork().processBatch((BatchPacket)packet, this);
            return;
        }
        ev = new DataPacketReceiveEvent(this, packet);
        this.server.getPluginManager().callEvent(ev);
        if (ev.isCancelled()) {
            return;
        }
        block1 : switch (packet.pid()) {
            case -113: {
                if (this.loggedIn) break;
                loginPacket = (LoginPacket)packet;
                this.displayName = this.username = TextFormat.clean(loginPacket.username);
                this.setNameTag(this.username);
                this.iusername = this.username.toLowerCase();
                if (this.server.getOnlinePlayers().size() >= this.server.getMaxPlayers() && this.kick("disconnectionScreen.serverFull", false)) break;
                if (loginPacket.protocol1 != 70) {
                    if (loginPacket.protocol1 < 70) {
                        message = "disconnectionScreen.outdatedClient";
                        pk = new PlayStatusPacket();
                        pk.status = 1;
                        this.directDataPacket(pk);
                    } else {
                        message = "disconnectionScreen.outdatedServer";
                        pk = new PlayStatusPacket();
                        pk.status = 2;
                        this.directDataPacket(pk);
                    }
                    this.close("", message, false);
                    break;
                }
                this.randomClientId = loginPacket.clientId;
                this.uuid = loginPacket.clientUUID;
                this.rawUUID = Binary.writeUUID(this.uuid);
                this.clientSecret = loginPacket.clientSecret;
                valid = true;
                len = loginPacket.username.length();
                if (len > 16 || len < 3) {
                    valid = false;
                }
                for (i = 0; i < len && valid; ++i) {
                    c = loginPacket.username.charAt(i);
                    if (c >= 'a' && c <= 'z' || c >= 'A' && c <= 'Z' || c >= '0' && c <= '9' || c == '_') continue;
                    valid = false;
                    break;
                }
                if (!valid || Objects.equals(this.iusername, "rcon") || Objects.equals(this.iusername, "console")) {
                    this.close("", "disconnectionScreen.invalidName");
                    break;
                }
                if (!loginPacket.skin.isValid()) {
                    this.close("", "disconnectionScreen.invalidSkin");
                    break;
                }
                this.setSkin(loginPacket.skin);
                playerPreLoginEvent = new PlayerPreLoginEvent(this, "Plugin reason");
                this.server.getPluginManager().callEvent(playerPreLoginEvent);
                if (playerPreLoginEvent.isCancelled()) {
                    this.close("", playerPreLoginEvent.getKickMessage());
                    break;
                }
                this.onPlayerPreLogin();
                break;
            }
            case -99: {
                movePlayerPacket = (MovePlayerPacket)packet;
                newPos = new Vector3(movePlayerPacket.x, movePlayerPacket.y - this.getEyeHeight(), movePlayerPacket.z);
                revert = false;
                if (!this.isAlive() || !this.spawned) {
                    revert = true;
                    this.forceMovement = new Vector3(this.x, this.y, this.z);
                }
                if (this.teleportPosition != null || this.forceMovement != null && (newPos.distanceSquared(this.forceMovement) > 0.1 || revert)) {
                    this.sendPosition(this.teleportPosition == null ? this.forceMovement : this.teleportPosition, movePlayerPacket.yaw, movePlayerPacket.pitch);
                } else {
                    movePlayerPacket.yaw %= 360.0f;
                    movePlayerPacket.pitch %= 360.0f;
                    if (movePlayerPacket.yaw < 0.0f) {
                        movePlayerPacket.yaw += 360.0f;
                    }
                    this.setRotation(movePlayerPacket.yaw, movePlayerPacket.pitch);
                    this.newPosition = newPos;
                    this.forceMovement = null;
                }
                if (this.riding == null || !(this.riding instanceof EntityBoat)) break;
                this.riding.setPositionAndRotation(this.temporalVector.setComponents(movePlayerPacket.x, movePlayerPacket.y - 1.0f, movePlayerPacket.z), (movePlayerPacket.headYaw + 90.0f) % 360.0f, 0.0);
                break;
            }
            case -89: {
                if (!this.spawned || !this.isAlive()) break;
                mobEquipmentPacket = (MobEquipmentPacket)packet;
                mobEquipmentPacket.slot = mobEquipmentPacket.slot == 40 || mobEquipmentPacket.slot == 0 || mobEquipmentPacket.slot == 255 ? -1 : (mobEquipmentPacket.slot -= 9);
                if (this.isCreative()) {
                    item = mobEquipmentPacket.item;
                    slot = Item.getCreativeItemIndex(item);
                } else {
                    item = this.inventory.getItem(mobEquipmentPacket.slot);
                    slot = mobEquipmentPacket.slot;
                }
                if (mobEquipmentPacket.slot != -1) {
                    if (item == null || slot == -1 || !item.deepEquals(mobEquipmentPacket.item)) {
                        this.inventory.sendContents(this);
                        break;
                    }
                    if (this.isCreative()) {
                        this.inventory.setHeldItemIndex(mobEquipmentPacket.selectedSlot);
                        this.inventory.setItem(mobEquipmentPacket.selectedSlot, item);
                        this.inventory.setHeldItemSlot(mobEquipmentPacket.selectedSlot);
                    } else if (mobEquipmentPacket.selectedSlot >= 0 && mobEquipmentPacket.selectedSlot < this.inventory.getHotbarSize()) {
                        this.inventory.setHeldItemIndex(mobEquipmentPacket.selectedSlot);
                        this.inventory.setHeldItemSlot(slot);
                    } else {
                        this.inventory.sendContents(this);
                        break;
                    }
                } else {
                    if (this.isCreative()) {
                        found = false;
                        for (i = 0; i < this.inventory.getHotbarSize(); ++i) {
                            if (this.inventory.getHotbarSlotIndex(i) != -1) continue;
                            this.inventory.setHeldItemIndex(i);
                            found = true;
                            break;
                        }
                        if (!found) {
                            this.inventory.sendContents(this);
                            break;
                        }
                    } else if (mobEquipmentPacket.selectedSlot >= 0 && mobEquipmentPacket.selectedSlot < 9) {
                        this.inventory.setHeldItemIndex(mobEquipmentPacket.selectedSlot);
                        this.inventory.setHeldItemSlot(mobEquipmentPacket.slot);
                    } else {
                        this.inventory.sendContents(this);
                        break;
                    }
                }
                this.inventory.sendHeldItem(this.hasSpawned.values());
                this.setDataFlag(0, 4, false);
                break;
            }
            case -86: {
                if (!this.spawned || !this.isAlive() || this.blocked) break;
                useItemPacket = (UseItemPacket)packet;
                blockVector = new Vector3(useItemPacket.x, useItemPacket.y, useItemPacket.z);
                this.craftingType = 0;
                if (useItemPacket.face >= 0 && useItemPacket.face <= 5) {
                    this.setDataFlag(0, 4, false);
                    if (this.canInteract(blockVector.add(0.5, 0.5, 0.5), 13.0)) {
                        if (this.isCreative()) {
                            i = this.inventory.getItemInHand();
                            if (this.level.useItemOn(blockVector, i, useItemPacket.face, useItemPacket.fx, useItemPacket.fy, useItemPacket.fz, this) != null) {
                                break;
                            }
                        } else if (!this.inventory.getItemInHand().deepEquals(useItemPacket.item)) {
                            this.inventory.sendHeldItem(this);
                        } else {
                            item = this.inventory.getItemInHand();
                            oldItem = item.clone();
                            if ((item = this.level.useItemOn(blockVector, item, useItemPacket.face, useItemPacket.fx, useItemPacket.fy, useItemPacket.fz, this)) != null) {
                                if (item.deepEquals(oldItem) && item.getCount() == oldItem.getCount()) break;
                                this.inventory.setItemInHand(item);
                                this.inventory.sendHeldItem(this.hasSpawned.values());
                                break;
                            }
                        }
                    }
                    this.inventory.sendHeldItem(this);
                    if (blockVector.distanceSquared(this) > 10000.0) break;
                    target = this.level.getBlock(blockVector);
                    block = target.getSide(useItemPacket.face);
                    this.level.sendBlocks(new Player[]{this}, new Block[]{target, block}, 11);
                    break;
                }
                if (useItemPacket.face != 255) break;
                aimPos = new Vector3(useItemPacket.x / 32768, useItemPacket.y / 32768, useItemPacket.z / 32768).normalize();
                if (this.isCreative()) {
                    item = this.inventory.getItemInHand();
                } else {
                    if (!this.inventory.getItemInHand().deepEquals(useItemPacket.item)) {
                        this.inventory.sendHeldItem(this);
                        break;
                    }
                    item = this.inventory.getItemInHand();
                }
                playerInteractEvent = new PlayerInteractEvent(this, item, aimPos, useItemPacket.face, 3);
                this.server.getPluginManager().callEvent(playerInteractEvent);
                if (playerInteractEvent.isCancelled()) {
                    this.inventory.sendHeldItem(this);
                    break;
                }
                if (item.getId() == 332) {
                    nbt = new CompoundTag().putList(new ListTag<DoubleTag>("Pos").add(new DoubleTag("", this.x)).add(new DoubleTag("", this.y + (double)this.getEyeHeight())).add(new DoubleTag("", this.z))).putList(new ListTag<DoubleTag>("Motion").add(new DoubleTag("", -Math.sin(this.yaw / 180.0 * 3.141592653589793) * Math.cos(this.pitch / 180.0 * 3.141592653589793))).add(new DoubleTag("", -Math.sin(this.pitch / 180.0 * 3.141592653589793))).add(new DoubleTag("", Math.cos(this.yaw / 180.0 * 3.141592653589793) * Math.cos(this.pitch / 180.0 * 3.141592653589793)))).putList(new ListTag<FloatTag>("Rotation").add(new FloatTag("", (float)this.yaw)).add(new FloatTag("", (float)this.pitch)));
                    f = 1.5f;
                    snowball = new EntitySnowball(this.chunk, nbt, this);
                    snowball.setMotion(snowball.getMotion().multiply(f));
                    if (this.isSurvival()) {
                        item.setCount(item.getCount() - 1);
                        this.inventory.setItemInHand(item.getCount() > 0 ? item : Item.get(0));
                    }
                    if (snowball instanceof EntityProjectile) {
                        projectileLaunchEvent = new ProjectileLaunchEvent(snowball);
                        this.server.getPluginManager().callEvent(projectileLaunchEvent);
                        if (projectileLaunchEvent.isCancelled()) {
                            snowball.kill();
                        } else {
                            snowball.spawnToAll();
                            this.level.addSound((Sound)new LaunchSound(this), this.getViewers().values());
                        }
                    } else {
                        snowball.spawnToAll();
                    }
                } else if (item.getId() == 344) {
                    nbt = new CompoundTag().putList(new ListTag<DoubleTag>("Pos").add(new DoubleTag("", this.x)).add(new DoubleTag("", this.y + (double)this.getEyeHeight())).add(new DoubleTag("", this.z))).putList(new ListTag<DoubleTag>("Motion").add(new DoubleTag("", -Math.sin(this.yaw / 180.0 * 3.141592653589793) * Math.cos(this.pitch / 180.0 * 3.141592653589793))).add(new DoubleTag("", -Math.sin(this.pitch / 180.0 * 3.141592653589793))).add(new DoubleTag("", Math.cos(this.yaw / 180.0 * 3.141592653589793) * Math.cos(this.pitch / 180.0 * 3.141592653589793)))).putList(new ListTag<FloatTag>("Rotation").add(new FloatTag("", (float)this.yaw)).add(new FloatTag("", (float)this.pitch)));
                    f = 1.5f;
                    egg = new EntityEgg(this.chunk, nbt, this);
                    egg.setMotion(egg.getMotion().multiply(f));
                    if (this.isSurvival()) {
                        item.setCount(item.getCount() - 1);
                        this.inventory.setItemInHand(item.getCount() > 0 ? item : Item.get(0));
                    }
                    if (egg instanceof EntityProjectile) {
                        projectileLaunchEvent = new ProjectileLaunchEvent(egg);
                        this.server.getPluginManager().callEvent(projectileLaunchEvent);
                        if (projectileLaunchEvent.isCancelled()) {
                            egg.kill();
                        } else {
                            egg.spawnToAll();
                            this.level.addSound((Sound)new LaunchSound(this), this.getViewers().values());
                        }
                    } else {
                        egg.spawnToAll();
                    }
                } else if (item.getId() == 384) {
                    nbt = new CompoundTag().putList(new ListTag<DoubleTag>("Pos").add(new DoubleTag("", this.x)).add(new DoubleTag("", this.y + (double)this.getEyeHeight())).add(new DoubleTag("", this.z))).putList(new ListTag<DoubleTag>("Motion").add(new DoubleTag("", -Math.sin(this.yaw / 180.0 * 3.141592653589793) * Math.cos(this.pitch / 180.0 * 3.141592653589793))).add(new DoubleTag("", -Math.sin(this.pitch / 180.0 * 3.141592653589793))).add(new DoubleTag("", Math.cos(this.yaw / 180.0 * 3.141592653589793) * Math.cos(this.pitch / 180.0 * 3.141592653589793)))).putList(new ListTag<FloatTag>("Rotation").add(new FloatTag("", (float)this.yaw)).add(new FloatTag("", (float)this.pitch))).putInt("Potion", item.getDamage());
                    f = 1.5;
                    bottle = new EntityExpBottle(this.chunk, nbt, this);
                    bottle.setMotion(bottle.getMotion().multiply(f));
                    if (this.isSurvival()) {
                        item.setCount(item.getCount() - 1);
                        this.inventory.setItemInHand(item.getCount() > 0 ? item : Item.get(0));
                    }
                    if (bottle instanceof EntityProjectile) {
                        bottleEntity = bottle;
                        projectileEv = new ProjectileLaunchEvent(bottleEntity);
                        this.server.getPluginManager().callEvent(projectileEv);
                        if (projectileEv.isCancelled()) {
                            bottle.kill();
                        } else {
                            bottle.spawnToAll();
                            this.level.addSound((Sound)new LaunchSound(this), this.getViewers().values());
                        }
                    } else {
                        bottle.spawnToAll();
                    }
                } else if (item.getId() == 438) {
                    nbt = new CompoundTag().putList(new ListTag<DoubleTag>("Pos").add(new DoubleTag("", this.x)).add(new DoubleTag("", this.y + (double)this.getEyeHeight())).add(new DoubleTag("", this.z))).putList(new ListTag<DoubleTag>("Motion").add(new DoubleTag("", -Math.sin(this.yaw / 180.0 * 3.141592653589793) * Math.cos(this.pitch / 180.0 * 3.141592653589793))).add(new DoubleTag("", -Math.sin(this.pitch / 180.0 * 3.141592653589793))).add(new DoubleTag("", Math.cos(this.yaw / 180.0 * 3.141592653589793) * Math.cos(this.pitch / 180.0 * 3.141592653589793)))).putList(new ListTag<FloatTag>("Rotation").add(new FloatTag("", (float)this.yaw)).add(new FloatTag("", (float)this.pitch))).putShort("PotionId", item.getDamage());
                    f = 1.5;
                    bottle = new EntityPotion(this.chunk, nbt, this);
                    bottle.setMotion(bottle.getMotion().multiply(f));
                    if (this.isSurvival()) {
                        item.setCount(item.getCount() - 1);
                        this.inventory.setItemInHand(item.getCount() > 0 ? item : Item.get(0));
                    }
                    if (bottle instanceof EntityPotion) {
                        bottleEntity = bottle;
                        projectileEv = new ProjectileLaunchEvent(bottleEntity);
                        this.server.getPluginManager().callEvent(projectileEv);
                        if (projectileEv.isCancelled()) {
                            bottle.kill();
                        } else {
                            bottle.spawnToAll();
                            this.level.addSound((Sound)new LaunchSound(this), this.getViewers().values());
                        }
                    } else {
                        bottle.spawnToAll();
                    }
                }
                this.setDataFlag(0, 4, true);
                this.startAction = this.server.getTick();
                break;
            }
            case -85: {
                if (!this.spawned || this.blocked || !this.isAlive() && ((PlayerActionPacket)packet).action != 7 && ((PlayerActionPacket)packet).action != 13) break;
                ((PlayerActionPacket)packet).entityId = this.id;
                pos = new Vector3(((PlayerActionPacket)packet).x, ((PlayerActionPacket)packet).y, ((PlayerActionPacket)packet).z);
                switch (((PlayerActionPacket)packet).action) {
                    case 0: {
                        if (this.lastBreak != 0x7FFFFFFFFFFFFFFFL || pos.distanceSquared(this) > 10000.0) break;
                        target = this.level.getBlock(pos);
                        playerInteractEvent = new PlayerInteractEvent(this, this.inventory.getItemInHand(), target, ((PlayerActionPacket)packet).face, target.getId() == 0 ? 2 : 0);
                        this.getServer().getPluginManager().callEvent(playerInteractEvent);
                        if (playerInteractEvent.isCancelled()) {
                            this.inventory.sendHeldItem(this);
                            break;
                        }
                        block = target.getSide(((PlayerActionPacket)packet).face);
                        if (block.getId() == 51) {
                            this.level.setBlock(block, new BlockAir(), true);
                        }
                        this.lastBreak = System.currentTimeMillis();
                        break;
                    }
                    case 1: {
                        this.lastBreak = 0x7FFFFFFFFFFFFFFFL;
                        break;
                    }
                    case 5: {
                        if (this.startAction <= -1 || !this.getDataFlag(0, 4) || this.inventory.getItemInHand().getId() != 261) break;
                        bow = this.inventory.getItemInHand();
                        itemArrow = new ItemArrow();
                        if (this.isSurvival() && !this.inventory.contains(itemArrow)) {
                            this.inventory.sendContents(this);
                            break;
                        }
                        nbt = new CompoundTag().putList(new ListTag<DoubleTag>("Pos").add(new DoubleTag("", this.x)).add(new DoubleTag("", this.y + (double)this.getEyeHeight())).add(new DoubleTag("", this.z))).putList(new ListTag<DoubleTag>("Motion").add(new DoubleTag("", -Math.sin(this.yaw / 180.0 * 3.141592653589793) * Math.cos(this.pitch / 180.0 * 3.141592653589793))).add(new DoubleTag("", -Math.sin(this.pitch / 180.0 * 3.141592653589793))).add(new DoubleTag("", Math.cos(this.yaw / 180.0 * 3.141592653589793) * Math.cos(this.pitch / 180.0 * 3.141592653589793)))).putList(new ListTag<FloatTag>("Rotation").add(new FloatTag("", (float)this.yaw)).add(new FloatTag("", (float)this.pitch))).putShort("Fire", this.isOnFire() != false ? 2700 : 0);
                        diff = this.server.getTick() - this.startAction;
                        p = (double)diff / 20.0;
                        f = Math.min((p * p + p * 2.0) / 3.0, 1.0) * 2.0;
                        entityShootBowEvent = new EntityShootBowEvent(this, bow, new EntityArrow(this.chunk, nbt, this, f == 2.0), f);
                        if (f < 0.1 || diff < 5) {
                            entityShootBowEvent.setCancelled();
                        }
                        this.server.getPluginManager().callEvent(entityShootBowEvent);
                        if (!entityShootBowEvent.isCancelled()) {
                        entityShootBowEvent.getProjectile().setMotion(entityShootBowEvent.getProjectile().getMotion().multiply(entityShootBowEvent.getForce()));
                        if (this.isSurvival()) {
                            this.inventory.removeItem(new Item[]{itemArrow});
                            bow.setDamage(bow.getDamage() + 1);
                            if (bow.getDamage() >= 385) {
                                this.inventory.setItemInHand(new ItemBlock(new BlockAir(), (Integer)0, 0));
                            } else {
                                this.inventory.setItemInHand(bow);
                            }
                        }
                        if (entityShootBowEvent.getProjectile() instanceof EntityProjectile) {
                            projectev = new ProjectileLaunchEvent(entityShootBowEvent.getProjectile());
                            this.server.getPluginManager().callEvent(projectev);
                            if (projectev.isCancelled()) {
                                entityShootBowEvent.getProjectile().kill();
                            } else {
                                entityShootBowEvent.getProjectile().spawnToAll();
                                this.level.addSound((Sound)new LaunchSound(this), this.getViewers().values());
                            }
                        } else {
                            entityShootBowEvent.getProjectile().spawnToAll();
                        }
                        } else {
                            entityShootBowEvent.getProjectile().kill();
                            this.inventory.sendContents(this);
                        }
                        break;
                    }
                    case 6: {
                        this.stopSleep();
                        break;
                    }
                    case 7: {
                        if (!this.spawned || this.isAlive() || !this.isOnline()) break;
                        if (this.server.isHardcore()) {
                            this.setBanned(true);
                            break;
                        }
                        this.craftingType = 0;
                        playerRespawnEvent = new PlayerRespawnEvent(this, this.getSpawn());
                        this.server.getPluginManager().callEvent(playerRespawnEvent);
                        this.teleport(playerRespawnEvent.getRespawnPosition(), null);
                        this.setSprinting(false);
                        this.setSneaking(false);
                        this.extinguish();
                        this.setDataProperty(new ShortEntityData(1, 300));
                        this.deadTicks = 0;
                        this.noDamageTicks = 60;
                        this.setHealth(this.getMaxHealth());
                        this.getFoodData().setLevel(20, 20.0f);
                        this.removeAllEffects();
                        this.sendData(this);
                        this.setMovementSpeed(0.1f);
                        this.sendSettings();
                        this.inventory.sendContents(this);
                        this.inventory.sendArmorContents(this);
                        this.blocked = false;
                        this.spawnToAll();
                        this.scheduleUpdate();
                        break;
                    }
                    case 9: {
                        playerToggleSprintEvent = new PlayerToggleSprintEvent(this, true);
                        this.server.getPluginManager().callEvent(playerToggleSprintEvent);
                        if (playerToggleSprintEvent.isCancelled()) {
                            this.sendData(this);
                            break;
                        }
                        this.setSprinting(true);
                        break;
                    }
                    case 10: {
                        playerToggleSprintEvent = new PlayerToggleSprintEvent(this, false);
                        this.server.getPluginManager().callEvent(playerToggleSprintEvent);
                        if (playerToggleSprintEvent.isCancelled()) {
                            this.sendData(this);
                            break;
                        }
                        this.setSprinting(false);
                        break;
                    }
                    case 11: {
                        playerToggleSneakEvent = new PlayerToggleSneakEvent(this, true);
                        this.server.getPluginManager().callEvent(playerToggleSneakEvent);
                        if (playerToggleSneakEvent.isCancelled()) {
                            this.sendData(this);
                            break;
                        }
                        this.setSneaking(true);
                        break;
                    }
                    case 12: {
                        playerToggleSneakEvent = new PlayerToggleSneakEvent(this, false);
                        this.server.getPluginManager().callEvent(playerToggleSneakEvent);
                        if (playerToggleSneakEvent.isCancelled()) {
                            this.sendData(this);
                            break;
                        }
                        this.setSneaking(false);
                    }
                }
                this.startAction = -1;
                this.setDataFlag(0, 4, false);
                break;
            }
            case -98: {
                if (!this.spawned || this.blocked || !this.isAlive()) break;
                this.craftingType = 0;
                vector = new Vector3(((RemoveBlockPacket)packet).x, ((RemoveBlockPacket)packet).y, ((RemoveBlockPacket)packet).z);
                item = this.isCreative() != false ? this.inventory.getItemInHand() : this.inventory.getItemInHand();
                oldItem = item.clone();
                if (this.canInteract(vector.add(0.5, 0.5, 0.5), this.isCreative() != false ? 13.0 : 6.0) && (item = this.level.useBreakOn(vector, item, this, true)) != null) {
                    if (!this.isSurvival()) break;
                    this.getFoodData().updateFoodExpLevel(0.025);
                    if (item.deepEquals(oldItem) && item.getCount() == oldItem.getCount()) break;
                    this.inventory.setItemInHand(item);
                    this.inventory.sendHeldItem(this.hasSpawned.values());
                    break;
                }
                this.inventory.sendContents(this);
                target = this.level.getBlock(vector);
                blockEntity = this.level.getBlockEntity(vector);
                this.level.sendBlocks(new Player[]{this}, new Block[]{target}, 11);
                this.inventory.sendHeldItem(this);
                if (!(blockEntity instanceof BlockEntitySpawnable)) break;
                ((BlockEntitySpawnable)blockEntity).spawnTo(this);
                break;
            }
            case -88: {
                break;
            }
            case -87: {
                if (!this.spawned || !this.isAlive() || this.blocked) break;
                this.craftingType = 0;
                targetEntity = this.level.getEntity(((InteractPacket)packet).target);
                cancelled = false;
                if (targetEntity instanceof Player && !((Boolean)this.server.getConfig("pvp", true)).booleanValue()) {
                    cancelled = true;
                }
                if (targetEntity == null || !this.isAlive() || !targetEntity.isAlive()) break;
                if (this.getGamemode() == 3) {
                    cancelled = true;
                }
                if (targetEntity instanceof EntityItem || targetEntity instanceof EntityArrow) {
                    this.kick("Attempting to attack an invalid entity");
                    this.server.getLogger().warning(this.getServer().getLanguage().translateString("nukkit.player.invalidEntity", this.getName()));
                    break;
                }
                item = this.inventory.getItemInHand();
                damageTable = new HashMap<Integer, Float>(){
                    {
                        this.put(268, Float.valueOf(4.0f));
                        this.put(283, Float.valueOf(4.0f));
                        this.put(272, Float.valueOf(5.0f));
                        this.put(267, Float.valueOf(6.0f));
                        this.put(276, Float.valueOf(7.0f));
                        this.put(271, Float.valueOf(3.0f));
                        this.put(286, Float.valueOf(3.0f));
                        this.put(275, Float.valueOf(3.0f));
                        this.put(258, Float.valueOf(5.0f));
                        this.put(279, Float.valueOf(6.0f));
                        this.put(270, Float.valueOf(2.0f));
                        this.put(285, Float.valueOf(2.0f));
                        this.put(274, Float.valueOf(3.0f));
                        this.put(257, Float.valueOf(4.0f));
                        this.put(278, Float.valueOf(5.0f));
                        this.put(269, Float.valueOf(1.0f));
                        this.put(284, Float.valueOf(1.0f));
                        this.put(273, Float.valueOf(2.0f));
                        this.put(256, Float.valueOf(3.0f));
                        this.put(277, Float.valueOf(4.0f));
                    }
                };
                damage = new HashMap<Integer, Float>();
                damage.put(0, damageTable.getOrDefault(item.getId(), Float.valueOf(1.0f)));
                if (!this.canInteract(targetEntity, 8.0)) {
                    cancelled = true;
                } else if (targetEntity instanceof Player) {
                    if ((((Player)targetEntity).getGamemode() & 1) > 0) break;
                    if (!this.server.getPropertyBoolean("pvp") || this.server.getDifficulty() == 0) {
                        cancelled = true;
                    }
                    armorValues = new HashMap<Integer, Float>(){
                        {
                            this.put(298, Float.valueOf(1.0f));
                            this.put(299, Float.valueOf(3.0f));
                            this.put(300, Float.valueOf(2.0f));
                            this.put(301, Float.valueOf(1.0f));
                            this.put(302, Float.valueOf(1.0f));
                            this.put(303, Float.valueOf(5.0f));
                            this.put(304, Float.valueOf(4.0f));
                            this.put(305, Float.valueOf(1.0f));
                            this.put(314, Float.valueOf(1.0f));
                            this.put(315, Float.valueOf(5.0f));
                            this.put(316, Float.valueOf(3.0f));
                            this.put(317, Float.valueOf(1.0f));
                            this.put(306, Float.valueOf(2.0f));
                            this.put(307, Float.valueOf(6.0f));
                            this.put(308, Float.valueOf(5.0f));
                            this.put(309, Float.valueOf(2.0f));
                            this.put(310, Float.valueOf(3.0f));
                            this.put(311, Float.valueOf(8.0f));
                            this.put(312, Float.valueOf(6.0f));
                            this.put(313, Float.valueOf(3.0f));
                        }
                    };
                    points = 0.0f;
                    for (Item i : ((Player)targetEntity).getInventory().getArmorContents()) {
                        points += armorValues.getOrDefault(i.getId(), Float.valueOf(0.0f)).floatValue();
                    }
                    damage.put(1, Float.valueOf((float)((double)damage.getOrDefault(1, Float.valueOf(0.0f)).floatValue() - Math.floor((double)(damage.getOrDefault(0, Float.valueOf(1.0f)).floatValue() * points) * 0.04))));
                } else if (targetEntity instanceof EntityVehicle) {
                    switch (((InteractPacket)packet).action) {
                        case 1: {
                            cancelled = true;
                            if (((EntityVehicle)targetEntity).linkedEntity != null) break;
                            pk = new SetEntityLinkPacket();
                            pk.rider = targetEntity.getId();
                            pk.riding = this.id;
                            pk.type = (byte)2;
                            Server.broadcastPacket(this.hasSpawned.values(), (DataPacket)pk);
                            pk = new SetEntityLinkPacket();
                            pk.rider = targetEntity.getId();
                            pk.riding = 0L;
                            pk.type = (byte)2;
                            this.dataPacket(pk);
                            this.riding = targetEntity;
                            ((EntityVehicle)targetEntity).linkedEntity = this;
                            this.setDataFlag(0, 2, true);
                            break;
                        }
                        case 3: {
                            pk = new SetEntityLinkPacket();
                            pk.rider = targetEntity.getId();
                            pk.riding = this.id;
                            pk.type = (byte)3;
                            Server.broadcastPacket(this.hasSpawned.values(), (DataPacket)pk);
                            pk = new SetEntityLinkPacket();
                            pk.rider = targetEntity.getId();
                            pk.riding = 0L;
                            pk.type = (byte)3;
                            this.dataPacket(pk);
                            cancelled = true;
                            this.riding = null;
                            ((EntityVehicle)targetEntity).linkedEntity = null;
                            this.setDataFlag(0, 2, false);
                        }
                    }
                }
                entityDamageByEntityEvent = new EntityDamageByEntityEvent((Entity)this, targetEntity, 1, damage);
                if (cancelled) {
                    entityDamageByEntityEvent.setCancelled();
                }
                targetEntity.attack(entityDamageByEntityEvent);
                if (entityDamageByEntityEvent.isCancelled()) {
                    if (!item.isTool() || !this.isSurvival()) break;
                    this.inventory.sendContents(this);
                    break;
                }
                if (!item.isTool() || !this.isSurvival()) break;
                if (item.useOn(targetEntity) && item.getDamage() >= item.getMaxDurability()) {
                    this.inventory.setItemInHand(new ItemBlock(new BlockAir()));
                    break;
                }
                this.inventory.setItemInHand(item);
                break;
            }
            case -78: {
                if (!this.spawned || !this.isAlive()) break;
                animationEvent = new PlayerAnimationEvent(this, ((AnimatePacket)packet).action);
                this.server.getPluginManager().callEvent(animationEvent);
                if (animationEvent.isCancelled()) break;
                animatePacket = new AnimatePacket();
                animatePacket.eid = this.getId();
                animatePacket.action = animationEvent.getAnimationType();
                Server.broadcastPacket(this.getViewers().values(), (DataPacket)animatePacket);
                break;
            }
            case -80: {
                break;
            }
            case -92: {
                if (!this.spawned || this.blocked || !this.isAlive()) break;
                this.craftingType = 0;
                this.setDataFlag(0, 4, false);
                entityEventPacket = (EntityEventPacket)packet;
                switch (entityEventPacket.event) {
                    case 9: {
                        itemInHand = this.inventory.getItemInHand();
                        consumeEvent = new PlayerItemConsumeEvent(this, itemInHand);
                        this.server.getPluginManager().callEvent(consumeEvent);
                        if (consumeEvent.isCancelled()) {
                            this.inventory.sendContents(this);
                            break;
                        }
                        if (itemInHand.getId() == 373) {
                            potion = Potion.getPotion(itemInHand.getDamage()).setSplash(false);
                            if (this.getGamemode() == 0) {
                                if (itemInHand.getCount() > 1) {
                                    bottle = new ItemGlassBottle();
                                    if (this.inventory.canAddItem(bottle)) {
                                        this.inventory.addItem(new Item[]{bottle});
                                    }
                                    --itemInHand.count;
                                } else {
                                    itemInHand = new ItemGlassBottle();
                                }
                            }
                            if (potion != null) {
                                potion.applyPotion(this);
                            }
                        } else {
                            pk = new EntityEventPacket();
                            pk.eid = this.getId();
                            pk.event = (byte)9;
                            this.dataPacket(pk);
                            Server.broadcastPacket(this.getViewers().values(), (DataPacket)pk);
                            food = Food.getByRelative(itemInHand);
                            if (food != null && food.eatenBy(this)) {
                                --itemInHand.count;
                            }
                        }
                        this.inventory.setItemInHand(itemInHand);
                        this.inventory.sendHeldItem(this);
                    }
                }
                break;
            }
            case -76: {
                if (!this.spawned || this.blocked || !this.isAlive()) break;
                dropItem = (DropItemPacket)packet;
                if (dropItem.item.getId() <= 0) break;
                item = this.inventory.contains(dropItem.item) != false ? dropItem.item : this.inventory.getItemInHand();
                dropItemEvent = new PlayerDropItemEvent(this, item);
                this.server.getPluginManager().callEvent(dropItemEvent);
                if (dropItemEvent.isCancelled()) {
                    this.inventory.sendContents(this);
                    break;
                }
                this.inventory.removeItem(new Item[]{item});
                motion = this.getDirectionVector().multiply(0.4);
                this.level.dropItem(this.add(0.0, 1.3, 0.0), item, motion, 40);
                this.setDataFlag(0, 4, false);
                break;
            }
            case -109: {
                if (!this.spawned || !this.isAlive()) break;
                this.craftingType = 0;
                textPacket = (TextPacket)packet;
                if (textPacket.type != 1) break;
                textPacket.message = this.removeFormat != false ? TextFormat.clean(textPacket.message) : textPacket.message;
                for (String msg : textPacket.message.split("\n")) {
                    if ("".equals(msg.trim()) || msg.length() > 255 || this.messageCounter-- <= 0) continue;
                    if (msg.startsWith("/")) {
                        commandPreprocessEvent = new PlayerCommandPreprocessEvent(this, msg);
                        if (commandPreprocessEvent.getMessage().length() > 320) {
                            commandPreprocessEvent.setCancelled();
                        }
                        this.server.getPluginManager().callEvent(commandPreprocessEvent);
                        if (commandPreprocessEvent.isCancelled()) break block1;
                        this.server.dispatchCommand(commandPreprocessEvent.getPlayer(), commandPreprocessEvent.getMessage().substring(1));
                        continue;
                    }
                    chatEvent = new PlayerChatEvent(this, msg);
                    this.server.getPluginManager().callEvent(chatEvent);
                    if (chatEvent.isCancelled()) continue;
                    this.server.broadcastMessage(this.getServer().getLanguage().translateString(chatEvent.getFormat(), new String[]{chatEvent.getPlayer().getDisplayName(), chatEvent.getMessage()}), chatEvent.getRecipients());
                }
                break;
            }
            case -74: {
                containerClosePacket = (ContainerClosePacket)packet;
                if (!this.spawned || containerClosePacket.windowid == 0) break;
                this.craftingType = 0;
                this.currentTransaction = null;
                if (this.windowIndex.containsKey(containerClosePacket.windowid)) {
                    this.server.getPluginManager().callEvent(new InventoryCloseEvent(this.windowIndex.get(containerClosePacket.windowid), this));
                    this.removeWindow(this.windowIndex.get(containerClosePacket.windowid));
                    break;
                }
                this.windowIndex.remove(containerClosePacket.windowid);
                break;
            }
            case -69: {
                craftingEventPacket = (CraftingEventPacket)packet;
                if (!this.spawned || !this.isAlive()) break;
                if (!this.windowIndex.containsKey(craftingEventPacket.windowId)) {
                    this.inventory.sendContents(this);
                    containerClosePacket = new ContainerClosePacket();
                    containerClosePacket.windowid = craftingEventPacket.windowId;
                    this.dataPacket(containerClosePacket);
                    break;
                }
                recipe = this.server.getCraftingManager().getRecipe(craftingEventPacket.id);
                if (recipe == null || (recipe instanceof BigShapelessRecipe || recipe instanceof BigShapedRecipe) && this.craftingType == 0) {
                    this.inventory.sendContents(this);
                    break;
                }
                for (i = 0; i < craftingEventPacket.input.length; ++i) {
                    inputItem = craftingEventPacket.input[i];
                    if (inputItem.getDamage() == -1 || inputItem.getDamage() == 65535) {
                        inputItem.setDamage(null);
                    }
                    if (i >= 9 || inputItem.getId() <= 0) continue;
                    inputItem.setCount(1);
                }
                canCraft = true;
                if (recipe instanceof ShapedRecipe) {
                    offsetX = 0;
                    offsetY = 0;
                    if (this.craftingType == 1) {
                        minX = -1;
                        minY = -1;
                        maxX = 0;
                        maxY = 0;
                        for (x = 0; x < 3 && canCraft; ++x) {
                            for (y = 0; y < 3; ++y) {
                                readItem = craftingEventPacket.input[y * 3 + x];
                                if (readItem.getId() == 0) continue;
                                if (minY == -1 || minY > y) {
                                    minY = y;
                                }
                                if (maxY < y) {
                                    maxY = y;
                                }
                                if (minX == -1) {
                                    minX = x;
                                }
                                if (maxX >= x) continue;
                                maxX = x;
                            }
                        }
                        if (maxX == minX) {
                            offsetX = minX;
                        }
                        if (maxY == minY) {
                            offsetY = minY;
                        }
                    }
                    block47: for (x = 0; x < 3 - offsetX && canCraft; ++x) {
                        for (y = 0; y < 3 - offsetY; ++y) {
                            item = craftingEventPacket.input[(y + offsetY) * 3 + (x + offsetX)];
                            ingredient = ((ShapedRecipe)recipe).getIngredient(x, y);
                            if (item.getCount() <= 0 || ingredient != null && ingredient.deepEquals(item, ingredient.hasMeta(), ingredient.getCompoundTag() != null)) continue;
                            canCraft = false;
                            continue block47;
                        }
                    }
                    if (!canCraft) {
                        canCraft = true;
                        block49: for (x = 0; x < 3 && canCraft; ++x) {
                            for (y = 0; y < 3; ++y) {
                                item = craftingEventPacket.input[y * 3 + x];
                                ingredient = ((ShapedRecipe)recipe).getIngredient(x, y);
                                if (item.getCount() <= 0 || ingredient != null && ingredient.deepEquals(item, ingredient.hasMeta(), ingredient.getCompoundTag() != null)) continue;
                                canCraft = false;
                                continue block49;
                            }
                        }
                    }
                } else if (recipe instanceof ShapelessRecipe) {
                    needed = ((ShapelessRecipe)recipe).getIngredientList();
                    block51: for (x = 0; x < 3 && canCraft; ++x) {
                        for (y = 0; y < 3; ++y) {
                            item = craftingEventPacket.input[y * 3 + x].clone();
                            for (Item n : new ArrayList<Item>(needed)) {
                                if (!n.deepEquals(item, n.hasMeta(), n.getCompoundTag() != null)) continue;
                                remove = Math.min(n.getCount(), item.getCount());
                                n.setCount(n.getCount() - remove);
                                item.setCount(item.getCount() - remove);
                                if (n.getCount() != 0) continue;
                                needed.remove(n);
                            }
                            if (item.getCount() <= 0) continue;
                            canCraft = false;
                            continue block51;
                        }
                    }
                    if (!needed.isEmpty()) {
                        canCraft = false;
                    }
                } else {
                    canCraft = false;
                }
                ingredientsList = new ArrayList<Item>();
                if (recipe instanceof ShapedRecipe) {
                    for (x = 0; x < 3; ++x) {
                        for (y = 0; y < 3; ++y) {
                            need = ((ShapedRecipe)recipe).getIngredient(x, y);
                            if (need.getId() == 0) continue;
                            for (count = need.getCount(); count > 0; --count) {
                                needAdd = need.clone();
                                needAdd.setCount(1);
                                ingredientsList.add(needAdd);
                            }
                        }
                    }
                }
                if (recipe instanceof ShapelessRecipe) {
                    recipeItem = ((ShapelessRecipe)recipe).getIngredientList();
                    for (Item need : recipeItem) {
                        if (need.getId() == 0) continue;
                        needAdd = need.clone();
                        needAdd.setCount(1);
                        ingredientsList.add(needAdd);
                    }
                }
                ingredients = ingredientsList.toArray(new Item[0]);
                result = craftingEventPacket.output[0];
                if (!canCraft || !recipe.getResult().deepEquals(result)) {
                    this.server.getLogger().debug("Unmatched recipe " + recipe.getId() + " from player " + this.getName() + ": expected " + recipe.getResult() + ", got " + result + ", using: " + Arrays.asList(ingredients).toString());
                    this.inventory.sendContents(this);
                    break;
                }
                used = new int[this.inventory.getSize()];
                for (Item ingredient : ingredients) {
                    slot = -1;
                    readItem = this.inventory.getContents().keySet().iterator();
                    while (readItem.hasNext()) {
                        index = (Integer)readItem.next();
                        i = this.inventory.getContents().get(index);
                        if (ingredient.getId() == 0 || !ingredient.deepEquals(i, ingredient.hasMeta()) || i.getCount() - used[index] < 1) continue;
                        slot = index;
                        v0 = index;
                        used[v0] = used[v0] + 1;
                        break;
                    }
                    if (ingredient.getId() == 0 || slot != -1) continue;
                    canCraft = false;
                    break;
                }
                if (!canCraft) {
                    this.server.getLogger().debug("Unmatched recipe " + recipe.getId() + " from player " + this.getName() + ": client does not have enough items, using: " + Arrays.asList(ingredients).toString());
                    this.inventory.sendContents(this);
                    break;
                }
                craftItemEvent = new CraftItemEvent(this, ingredients, recipe);
                this.server.getPluginManager().callEvent(craftItemEvent);
                if (craftItemEvent.isCancelled()) {
                    this.inventory.sendContents(this);
                    break;
                }
                for (i = 0; i < used.length; ++i) {
                    count = used[i];
                    if (count == 0) continue;
                    item = this.inventory.getItem(i);
                    if (item.getCount() > count) {
                        newItem = item.clone();
                        newItem.setCount(item.getCount() - count);
                    } else {
                        newItem = new ItemBlock(new BlockAir(), (Integer)0, 0);
                    }
                    this.inventory.setItem(i, newItem);
                }
                extraItem = this.inventory.addItem(new Item[]{recipe.getResult()});
                if (extraItem.length <= 0) break;
                for (Item i : extraItem) {
                    this.level.dropItem(this, i);
                }
                break;
            }
            case -73: {
                if (!this.spawned || this.blocked || !this.isAlive()) break;
                containerSetSlotPacket = (ContainerSetSlotPacket)packet;
                if (containerSetSlotPacket.slot < 0) break;
                if (containerSetSlotPacket.windowid == 0) {
                    if (containerSetSlotPacket.slot >= this.inventory.getSize()) break;
                    if (this.isCreative() && Item.getCreativeItemIndex(containerSetSlotPacket.item) != -1) {
                        this.inventory.setItem(containerSetSlotPacket.slot, containerSetSlotPacket.item);
                        this.inventory.setHotbarSlotIndex(containerSetSlotPacket.slot, containerSetSlotPacket.slot);
                    }
                    transaction = new BaseTransaction(this.inventory, containerSetSlotPacket.slot, this.inventory.getItem(containerSetSlotPacket.slot), containerSetSlotPacket.item);
                } else if (containerSetSlotPacket.windowid == 120) {
                    if (containerSetSlotPacket.slot >= 4) break;
                    transaction = new BaseTransaction(this.inventory, containerSetSlotPacket.slot + this.inventory.getSize(), this.inventory.getArmorItem(containerSetSlotPacket.slot), containerSetSlotPacket.item);
                } else {
                    if (!this.windowIndex.containsKey(containerSetSlotPacket.windowid)) break;
                    this.craftingType = 0;
                    inv = this.windowIndex.get(containerSetSlotPacket.windowid);
                    if (inv instanceof EnchantInventory && containerSetSlotPacket.item.hasEnchantments()) {
                        ((EnchantInventory)inv).onEnchant(this, inv.getItem(containerSetSlotPacket.slot), containerSetSlotPacket.item);
                    }
                    transaction = new BaseTransaction(inv, containerSetSlotPacket.slot, inv.getItem(containerSetSlotPacket.slot), containerSetSlotPacket.item);
                }
                if (var41_138.getSourceItem().deepEquals(var41_138.getTargetItem()) && var41_138.getTargetItem().getCount() == var41_138.getSourceItem().getCount()) break;
                if (this.currentTransaction == null || this.currentTransaction.getCreationTime() < System.currentTimeMillis() - 8000L) {
                    if (this.currentTransaction != null) {
                        for (Inventory inventory : this.currentTransaction.getInventories()) {
                            if (inventory instanceof PlayerInventory) {
                                ((PlayerInventory)inventory).sendArmorContents(this);
                            }
                            inventory.sendContents(this);
                        }
                    }
                    this.currentTransaction = new SimpleTransactionGroup(this);
                }
                this.currentTransaction.addTransaction((Transaction)var41_138);
                if (!this.currentTransaction.canExecute()) break;
                this.currentTransaction.execute();
                this.currentTransaction = null;
                break;
            }
            case -67: {
                if (!this.spawned || this.blocked || !this.isAlive()) break;
                blockEntityDataPacket = (BlockEntityDataPacket)packet;
                this.craftingType = 0;
                pos = new Vector3(blockEntityDataPacket.x, blockEntityDataPacket.y, blockEntityDataPacket.z);
                if (pos.distanceSquared(this) > 10.0 || !((t = this.level.getBlockEntity(pos)) instanceof BlockEntitySign)) break;
                try {
                    nbt = NBTIO.read(blockEntityDataPacket.namedTag, ByteOrder.LITTLE_ENDIAN);
                }
                catch (IOException e) {
                    throw new RuntimeException(e);
                }
                if (!"Sign".equals(nbt.getString("id"))) {
                    ((BlockEntitySign)t).spawnTo(this);
                    break;
                }
                signChangeEvent = new SignChangeEvent(t.getBlock(), this, new String[]{TextFormat.clean(nbt.getString("Text1"), this.removeFormat), TextFormat.clean(nbt.getString("Text2"), this.removeFormat), TextFormat.clean(nbt.getString("Text3"), this.removeFormat), TextFormat.clean(nbt.getString("Text4"), this.removeFormat)});
                if (!t.namedTag.contains("Creator") || !Objects.equals(this.getUniqueId().toString(), t.namedTag.getString("Creator"))) {
                    signChangeEvent.setCancelled();
                } else {
                    for (String line : signChangeEvent.getLines()) {
                        if (line.length() <= 16) continue;
                        signChangeEvent.setCancelled();
                    }
                }
                this.server.getPluginManager().callEvent(signChangeEvent);
                if (!signChangeEvent.isCancelled()) {
                    ((BlockEntitySign)t).setText(signChangeEvent.getLine(0), signChangeEvent.getLine(1), signChangeEvent.getLine(2), signChangeEvent.getLine(3));
                    break;
                }
                ((BlockEntitySign)t).spawnTo(this);
                break;
            }
            case -56: {
                requestChunkRadiusPacket = (RequestChunkRadiusPacket)packet;
                chunkRadiusUpdatePacket = new ChunkRadiusUpdatePacket();
                chunkRadiusUpdatePacket.radius = this.viewDistance;
                this.dataPacket(chunkRadiusUpdatePacket);
                break;
            }
        }
    }

    public boolean kick() {
        return this.kick("");
    }

    public boolean kick(String reason) {
        return this.kick(reason, true);
    }

    public boolean kick(String reason, boolean isAdmin) {
        PlayerKickEvent ev = new PlayerKickEvent(this, reason, this.getLeaveMessage());
        this.server.getPluginManager().callEvent(ev);
        if (!ev.isCancelled()) {
            String message = isAdmin ? (!this.isBanned() ? "Kicked by admin." + (!"".equals(reason) ? " Reason: " + reason : "") : reason) : ("".equals(reason) ? "disconnectionScreen.noReason" : reason);
            this.close(ev.getQuitMessage(), message);
            return true;
        }
        return false;
    }

    @Override
    public void sendMessage(String message) {
        String[] mes;
        for (String m : mes = this.server.getLanguage().translateString(message).split("\\n")) {
            if ("".equals(m)) continue;
            TextPacket pk = new TextPacket();
            pk.type = 0;
            pk.message = m;
            this.dataPacket(pk);
        }
    }

    @Override
    public void sendMessage(TextContainer message) {
        if (message instanceof TranslationContainer) {
            this.sendTranslation(message.getText(), ((TranslationContainer)message).getParameters());
            return;
        }
        this.sendMessage(message.getText());
    }

    public void sendTranslation(String message) {
        this.sendTranslation(message, new String[0]);
    }

    public void sendTranslation(String message, String[] parameters) {
        TextPacket pk = new TextPacket();
        if (!this.server.isLanguageForced()) {
            pk.type = (byte)2;
            pk.message = this.server.getLanguage().translateString(message, parameters, "nukkit.");
            for (int i = 0; i < parameters.length; ++i) {
                parameters[i] = this.server.getLanguage().translateString(parameters[i], parameters, "nukkit.");
            }
            pk.parameters = parameters;
        } else {
            pk.type = 0;
            pk.message = this.server.getLanguage().translateString(message, parameters);
        }
        this.dataPacket(pk);
    }

    public void sendPopup(String message) {
        this.sendPopup(message, "");
    }

    public void sendPopup(String message, String subtitle) {
        TextPacket pk = new TextPacket();
        pk.type = (byte)3;
        pk.source = message;
        pk.message = subtitle;
        this.dataPacket(pk);
    }

    @Deprecated
    public void sendTip(String message) {
        TextPacket pk = new TextPacket();
        pk.type = (byte)4;
        pk.message = message;
        this.dataPacket(pk);
    }

    @Override
    public void close() {
        this.close("");
    }

    public void close(String message) {
        this.close(message, "generic");
    }

    public void close(String message, String reason) {
        this.close(message, reason, true);
    }

    public void close(String message, String reason, boolean notify) {
        this.close(new TextContainer(message), reason, notify);
    }

    public void close(TextContainer message) {
        this.close(message, "generic");
    }

    public void close(TextContainer message, String reason) {
        this.close(message, reason, true);
    }

    public void close(TextContainer message, String reason, boolean notify) {
        if (this.connected && !this.closed) {
            if (notify && reason.length() > 0) {
                DisconnectPacket pk = new DisconnectPacket();
                pk.message = reason;
                this.directDataPacket(pk);
            }
            this.connected = false;
            PlayerQuitEvent ev = null;
            if (this.getName() != null && this.getName().length() > 0) {
                ev = new PlayerQuitEvent(this, message, true);
                this.server.getPluginManager().callEvent(ev);
                if (this.loggedIn && ev.getAutoSave()) {
                    this.save();
                }
            }
            for (Player player : new ArrayList<Player>(this.server.getOnlinePlayers().values())) {
                if (player.canSee(this)) continue;
                player.showPlayer(this);
            }
            this.hiddenPlayers = new HashMap<UUID, Player>();
            for (Inventory window : new ArrayList<Inventory>(this.windowIndex.values())) {
                this.removeWindow(window);
            }
            for (String index : new ArrayList<String>(this.usedChunks.keySet())) {
                Chunk.Entry entry = Level.getChunkXZ(index);
                this.level.unregisterChunkLoader(this, entry.chunkX, entry.chunkZ);
                this.usedChunks.remove(index);
            }
            super.close();
            this.interfaz.close(this, notify ? reason : "");
            if (this.loggedIn) {
                this.server.removeOnlinePlayer(this);
            }
            this.loggedIn = false;
            if (ev != null && !Objects.equals(this.username, "") && this.spawned && !Objects.equals(ev.getQuitMessage().toString(), "")) {
                this.server.broadcastMessage(ev.getQuitMessage());
            }
            this.server.getPluginManager().unsubscribeFromPermission("nukkit.broadcast.user", this);
            this.spawned = false;
            this.server.getLogger().info(this.getServer().getLanguage().translateString("nukkit.player.logOut", new String[]{"\u00a7b" + (this.getName() == null ? "" : this.getName()) + "\u00a7f", this.ip, String.valueOf(this.port), this.getServer().getLanguage().translateString(reason)}));
            this.windows = new HashMap<Inventory, Integer>();
            this.windowIndex = new HashMap<Integer, Inventory>();
            this.usedChunks = new HashMap<String, Boolean>();
            this.loadQueue = new HashMap<String, Integer>();
            this.hasSpawned = new HashMap();
            this.spawnPosition = null;
            if (this.riding instanceof EntityVehicle) {
                ((EntityVehicle)this.riding).linkedEntity = null;
            }
            this.riding = null;
        }
        if (this.perm != null) {
            this.perm.clearPermissions();
            this.perm = null;
        }
        if (this.inventory != null) {
            this.inventory = null;
            this.currentTransaction = null;
        }
        this.chunk = null;
        this.server.removePlayer(this);
    }

    public void save() {
        this.save(false);
    }

    public void save(boolean async) {
        if (this.closed) {
            throw new IllegalStateException("Tried to save closed player");
        }
        super.saveNBT();
        if (this.level != null) {
            this.namedTag.putString("Level", this.level.getFolderName());
            if (this.spawnPosition != null && this.spawnPosition.getLevel() != null) {
                this.namedTag.putString("SpawnLevel", this.spawnPosition.getLevel().getFolderName());
                this.namedTag.putInt("SpawnX", (int)this.spawnPosition.x);
                this.namedTag.putInt("SpawnY", (int)this.spawnPosition.y);
                this.namedTag.putInt("SpawnZ", (int)this.spawnPosition.z);
            }
            this.namedTag.putInt("playerGameType", this.gamemode);
            this.namedTag.putLong("lastPlayed", System.currentTimeMillis() / 1000L);
            this.namedTag.putString("lastIP", this.getAddress());
            this.namedTag.putInt("EXP", this.getExperience());
            this.namedTag.putInt("expLevel", this.getExperienceLevel());
            this.namedTag.putInt("foodLevel", this.getFoodData().getLevel());
            this.namedTag.putFloat("foodSaturationLevel", this.getFoodData().getFoodSaturationLevel());
            if (!"".equals(this.username) && this.namedTag != null) {
                this.server.saveOfflinePlayerData(this.username, this.namedTag, async);
            }
        }
    }

    @Override
    public String getName() {
        return this.username;
    }

    @Override
    public void kill() {
        if (!this.spawned) {
            return;
        }
        String message = "death.attack.generic";
        ArrayList<String> params = new ArrayList<String>();
        params.add(this.getDisplayName());
        EntityDamageEvent cause = this.getLastDamageCause();
        switch (cause == null ? 14 : cause.getCause()) {
            case 1: {
                Entity e;
                if (!(cause instanceof EntityDamageByEntityEvent)) break;
                this.killer = e = ((EntityDamageByEntityEvent)cause).getDamager();
                if (e instanceof Player) {
                    message = "death.attack.player";
                    params.add(((Player)e).getDisplayName());
                    break;
                }
                if (e instanceof EntityLiving) {
                    message = "death.attack.mob";
                    params.add(!Objects.equals(e.getNameTag(), "") ? e.getNameTag() : e.getName());
                    break;
                }
                params.add("Unknown");
                break;
            }
            case 2: {
                Entity e;
                if (!(cause instanceof EntityDamageByEntityEvent)) break;
                this.killer = e = ((EntityDamageByEntityEvent)cause).getDamager();
                if (e instanceof Player) {
                    message = "death.attack.arrow";
                    params.add(((Player)e).getDisplayName());
                    break;
                }
                if (e instanceof EntityLiving) {
                    message = "death.attack.arrow";
                    params.add(!Objects.equals(e.getNameTag(), "") ? e.getNameTag() : e.getName());
                    break;
                }
                params.add("Unknown");
                break;
            }
            case 12: {
                message = "death.attack.generic";
                break;
            }
            case 11: {
                message = "death.attack.outOfWorld";
                break;
            }
            case 4: {
                if (cause != null && cause.getFinalDamage() > 2.0f) {
                    message = "death.fell.accident.generic";
                    break;
                }
                message = "death.attack.fall";
                break;
            }
            case 3: {
                message = "death.attack.inWall";
                break;
            }
            case 7: {
                message = "death.attack.lava";
                break;
            }
            case 5: {
                message = "death.attack.onFire";
                break;
            }
            case 6: {
                message = "death.attack.inFire";
                break;
            }
            case 8: {
                message = "death.attack.drown";
                break;
            }
            case 0: {
                if (!(cause instanceof EntityDamageByBlockEvent) || ((EntityDamageByBlockEvent)cause).getDamager().getId() != 81) break;
                message = "death.attack.cactus";
                break;
            }
            case 9: 
            case 10: {
                Entity e;
                if (cause instanceof EntityDamageByEntityEvent) {
                    this.killer = e = ((EntityDamageByEntityEvent)cause).getDamager();
                    if (e instanceof Player) {
                        message = "death.attack.explosion.player";
                        params.add(((Player)e).getDisplayName());
                        break;
                    }
                    if (!(e instanceof EntityLiving)) break;
                    message = "death.attack.explosion.player";
                    params.add(!Objects.equals(e.getNameTag(), "") ? e.getNameTag() : ((EntityLiving)e).getName());
                    break;
                }
                message = "death.attack.explosion";
                break;
            }
            case 13: {
                message = "death.attack.magic";
                break;
            }
            case 14: {
                break;
            }
        }
        this.health = 0;
        this.scheduleUpdate();
        PlayerDeathEvent ev = new PlayerDeathEvent(this, this.getDrops(), new TranslationContainer(message, (String[])params.stream().toArray(String[]::new)), this.getExperienceLevel());
        this.server.getPluginManager().callEvent(ev);
        if (!ev.getKeepInventory()) {
            for (Item item : ev.getDrops()) {
                this.level.dropItem(this, item);
            }
            if (this.inventory != null) {
                this.inventory.clearAll();
            }
        }
        if (!ev.getKeepExperience()) {
            if (this.isSurvival() || this.isAdventure()) {
                int exp = ev.getExperience() * 7;
                if (exp > 100) {
                    exp = 100;
                }
                int add = 1;
                for (int ii = 1; ii < exp; ii += add) {
                    this.getLevel().dropExpOrb(this, add);
                    add = new NukkitRandom().nextRange(1, 3);
                }
            }
            this.setExperience(0, 0);
        }
        if (!Objects.equals(ev.getDeathMessage().toString(), "")) {
            this.server.broadcast(ev.getDeathMessage(), "nukkit.broadcast.user");
        }
        RespawnPacket pk = new RespawnPacket();
        Position pos = this.getSpawn();
        pk.x = (float)pos.x;
        pk.y = (float)pos.y;
        pk.z = (float)pos.z;
        this.dataPacket(pk);
    }

    @Override
    public void setHealth(float health) {
        super.setHealth(health);
        Attribute attr = Attribute.getAttribute(0).setMaxValue(this.getMaxHealth()).setValue(health > 0.0f ? (health < (float)this.getMaxHealth() ? health : (float)this.getMaxHealth()) : 0.0f);
        if (this.spawned) {
            UpdateAttributesPacket pk = new UpdateAttributesPacket();
            pk.entries = new Attribute[]{attr};
            pk.entityId = 0L;
            this.dataPacket(pk);
        }
    }

    public int getExperience() {
        return this.exp;
    }

    public int getExperienceLevel() {
        return this.expLevel;
    }

    public void addExperience(int add) {
        int added;
        if (add == 0) {
            return;
        }
        int now = this.getExperience();
        int level = this.getExperienceLevel();
        int most = Player.calculateRequireExperience(level);
        for (added = now + add; added >= most; added -= most) {
            most = Player.calculateRequireExperience(++level);
        }
        this.setExperience(added, level);
    }

    public static int calculateRequireExperience(int level) {
        if (level < 16) {
            return 2 * level + 7;
        }
        if (level >= 17 && level <= 31) {
            return 5 * level - 38;
        }
        return 9 * level - 158;
    }

    public void setExperience(int exp) {
        this.setExperience(exp, this.getExperienceLevel());
    }

    public void setExperience(int exp, int level) {
        this.exp = exp;
        this.expLevel = level;
        this.sendExperienceLevel(level);
        this.sendExperience(exp);
    }

    public void sendExperience() {
        this.sendExperience(this.getExperience());
    }

    public void sendExperience(int exp) {
        float percent = (float)exp / (float)Player.calculateRequireExperience(this.getExperienceLevel());
        this.setAttribute(Attribute.addAttribute(1, "player.experience", 0.0f, 1.0f, percent, true).setValue(percent));
    }

    public void sendExperienceLevel() {
        this.sendExperienceLevel(this.getExperienceLevel());
    }

    public void sendExperienceLevel(int level) {
        this.setAttribute(Attribute.getAttribute(2).setValue(level));
    }

    public void setAttribute(Attribute attribute) {
        UpdateAttributesPacket pk = new UpdateAttributesPacket();
        pk.entries = new Attribute[]{attribute};
        pk.entityId = 0L;
        this.dataPacket(pk);
    }

    @Override
    public void setMovementSpeed(float speed) {
        super.setMovementSpeed(speed);
        if (this.spawned) {
            Attribute attribute = Attribute.getAttribute(4).setValue(speed);
            this.setAttribute(attribute);
        }
    }

    public Entity getKiller() {
        return this.killer;
    }

    @Override
    public void attack(EntityDamageEvent source) {
        if (!this.isAlive()) {
            return;
        }
        if (this.isCreative() && source.getCause() != 13 && source.getCause() != 12 && source.getCause() != 11) {
            source.setCancelled();
        } else if (this.allowFlight && source.getCause() == 4) {
            source.setCancelled();
        } else if (source.getCause() == 4 && this.getLevel().getBlock(this.getPosition().floor().add(0.5, -1.0, 0.5)).getId() == 165 && !this.isSneaking()) {
            source.setCancelled();
            this.resetFallDistance();
        }
        if (source instanceof EntityDamageByEntityEvent) {
            Entity damager = ((EntityDamageByEntityEvent)source).getDamager();
            if (damager instanceof Player) {
                ((Player)damager).getFoodData().updateFoodExpLevel(0.3);
            }
            boolean add = false;
            if (!damager.onGround) {
                NukkitRandom random = new NukkitRandom();
                for (int i = 0; i < 5; ++i) {
                    CriticalParticle par = new CriticalParticle(new Vector3(this.x + (double)(random.nextRange(-15, 15) / 10), this.y + (double)(random.nextRange(0, 20) / 10), this.z + (double)(random.nextRange(-15, 15) / 10)));
                    this.getLevel().addParticle(par);
                }
                add = true;
            }
            if (add) {
                source.setDamage((float)((double)source.getDamage() * 1.5));
            }
        }
        super.attack(source);
        if (!source.isCancelled() && this.getLastDamageCause() == source && this.spawned) {
            this.getFoodData().updateFoodExpLevel(0.3);
            EntityEventPacket pk = new EntityEventPacket();
            pk.eid = 0L;
            pk.event = (byte)2;
            this.dataPacket(pk);
        }
    }

    public void sendPosition(Vector3 pos) {
        this.sendPosition(pos, this.yaw);
    }

    public void sendPosition(Vector3 pos, double yaw) {
        this.sendPosition(pos, yaw, this.pitch);
    }

    public void sendPosition(Vector3 pos, double yaw, double pitch) {
        this.sendPosition(pos, yaw, pitch, (byte)0);
    }

    public void sendPosition(Vector3 pos, double yaw, double pitch, byte mode) {
        this.sendPosition(pos, yaw, pitch, mode, null);
    }

    public void sendPosition(Vector3 pos, double yaw, double pitch, byte mode, Player[] targets) {
        MovePlayerPacket pk = new MovePlayerPacket();
        pk.eid = this.getId();
        pk.x = (float)pos.x;
        pk.y = (float)(pos.y + (double)this.getEyeHeight());
        pk.z = (float)pos.z;
        pk.headYaw = (float)yaw;
        pk.pitch = (float)pitch;
        pk.yaw = (float)yaw;
        pk.mode = mode;
        if (targets != null) {
            Server.broadcastPacket(targets, (DataPacket)pk);
        } else {
            pk.eid = 0L;
            this.dataPacket(pk);
        }
    }

    @Override
    protected void checkChunks() {
        if (this.chunk == null || this.chunk.getX() != (int)this.x >> 4 || this.chunk.getZ() != (int)this.z >> 4) {
            if (this.chunk != null) {
                this.chunk.removeEntity(this);
            }
            this.chunk = this.level.getChunk((int)this.x >> 4, (int)this.z >> 4, true);
            if (!this.justCreated) {
                Map<Integer, Player> newChunk = this.level.getChunkPlayers((int)this.x >> 4, (int)this.z >> 4);
                newChunk.remove(this.getLoaderId());
                for (Player player : new ArrayList(this.hasSpawned.values())) {
                    if (!newChunk.containsKey(player.getLoaderId())) {
                        this.despawnFrom(player);
                        continue;
                    }
                    newChunk.remove(player.getLoaderId());
                }
                for (Player player : newChunk.values()) {
                    this.spawnTo(player);
                }
            }
            if (this.chunk == null) {
                return;
            }
            this.chunk.addEntity(this);
        }
    }

    protected boolean checkTeleportPosition() {
        if (this.teleportPosition != null) {
            int chunkX = (int)this.teleportPosition.x >> 4;
            int chunkZ = (int)this.teleportPosition.z >> 4;
            for (int X = -1; X <= 1; ++X) {
                for (int Z = -1; Z <= 1; ++Z) {
                    String index = Level.chunkHash(chunkX + X, chunkZ + Z);
                    if (this.usedChunks.containsKey(index) && this.usedChunks.get(index).booleanValue()) continue;
                    return false;
                }
            }
            this.sendPosition(this, this.yaw, this.pitch, (byte)1);
            this.spawnToAll();
            this.forceMovement = this.teleportPosition;
            this.teleportPosition = null;
            return true;
        }
        return false;
    }

    @Override
    public boolean teleport(Location location, PlayerTeleportEvent.TeleportCause cause) {
        if (!this.isOnline()) {
            return false;
        }
        Location from = this.getLocation();
        Location to = location;
        if (cause != null) {
            PlayerTeleportEvent event = new PlayerTeleportEvent(this, from, to, cause);
            this.server.getPluginManager().callEvent(event);
            if (event.isCancelled()) {
                return false;
            }
            to = event.getTo();
        }
        Position oldPos = this.getPosition();
        if (super.teleport(to, null)) {
            for (Inventory window : new ArrayList<Inventory>(this.windowIndex.values())) {
                if (window == this.inventory) continue;
                this.removeWindow(window);
            }
            this.teleportPosition = new Vector3(this.x, this.y, this.z);
            if (!this.checkTeleportPosition()) {
                this.forceMovement = oldPos;
            } else {
                this.spawnToAll();
            }
            this.resetFallDistance();
            this.nextChunkOrderRun = 0;
            this.newPosition = null;
            this.getLevel().sendWeather(this);
            this.getLevel().sendTime(this);
            return true;
        }
        return false;
    }

    public void teleportImmediate(Location location) {
        this.teleportImmediate(location, PlayerTeleportEvent.TeleportCause.PLUGIN);
    }

    public void teleportImmediate(Location location, PlayerTeleportEvent.TeleportCause cause) {
        if (super.teleport(location, cause)) {
            for (Inventory window : new ArrayList<Inventory>(this.windowIndex.values())) {
                if (window == this.inventory) continue;
                this.removeWindow(window);
            }
            this.forceMovement = new Vector3(this.x, this.y, this.z);
            this.sendPosition(this, this.yaw, this.pitch, (byte)1);
            this.resetFallDistance();
            this.orderChunks();
            this.nextChunkOrderRun = 0;
            this.newPosition = null;
            this.getLevel().sendWeather(this);
            this.getLevel().sendTime(this);
        }
    }

    public int getWindowId(Inventory inventory) {
        if (this.windows.containsKey(inventory)) {
            return this.windows.get(inventory);
        }
        return -1;
    }

    public int addWindow(Inventory inventory) {
        return this.addWindow(inventory, null);
    }

    public int addWindow(Inventory inventory, Integer forceId) {
        int cnt;
        if (this.windows.containsKey(inventory)) {
            return this.windows.get(inventory);
        }
        if (forceId == null) {
            this.windowCnt = cnt = Math.max(2, ++this.windowCnt % 99);
        } else {
            cnt = forceId;
        }
        this.windowIndex.put(cnt, inventory);
        this.windows.put(inventory, cnt);
        if (inventory.open(this)) {
            return cnt;
        }
        this.removeWindow(inventory);
        return -1;
    }

    public void removeWindow(Inventory inventory) {
        inventory.close(this);
        if (this.windows.containsKey(inventory)) {
            int id = this.windows.get(inventory);
            this.windows.remove(this.windowIndex.get(id));
            this.windowIndex.remove(id);
        }
    }

    @Override
    public void setMetadata(String metadataKey, MetadataValue newMetadataValue) {
        this.server.getPlayerMetadata().setMetadata(this, metadataKey, newMetadataValue);
    }

    @Override
    public List<MetadataValue> getMetadata(String metadataKey) {
        return this.server.getPlayerMetadata().getMetadata(this, metadataKey);
    }

    @Override
    public boolean hasMetadata(String metadataKey) {
        return this.server.getPlayerMetadata().hasMetadata(this, metadataKey);
    }

    @Override
    public void removeMetadata(String metadataKey, Plugin owningPlugin) {
        this.server.getPlayerMetadata().removeMetadata(this, metadataKey, owningPlugin);
    }

    @Override
    public void onChunkChanged(FullChunk chunk) {
        this.loadQueue.put(Level.chunkHash(chunk.getX(), chunk.getZ()), Math.abs(((int)this.x >> 4) - chunk.getX()) + Math.abs(((int)this.z >> 4) - chunk.getZ()));
    }

    @Override
    public void onChunkLoaded(FullChunk chunk) {
    }

    @Override
    public void onChunkPopulated(FullChunk chunk) {
    }

    @Override
    public void onChunkUnloaded(FullChunk chunk) {
    }

    @Override
    public void onBlockChanged(Vector3 block) {
    }

    @Override
    public Integer getLoaderId() {
        return this.loaderId;
    }

    @Override
    public boolean isLoaderActive() {
        return this.isConnected();
    }

    public static BatchPacket getChunkCacheFromData(int chunkX, int chunkZ, byte[] payload) {
        return Player.getChunkCacheFromData(chunkX, chunkZ, payload, (byte)0);
    }

    public static BatchPacket getChunkCacheFromData(int chunkX, int chunkZ, byte[] payload, byte ordering) {
        FullChunkDataPacket pk = new FullChunkDataPacket();
        pk.chunkX = chunkX;
        pk.chunkZ = chunkZ;
        pk.order = ordering;
        pk.data = payload;
        pk.encode();
        BatchPacket batch = new BatchPacket();
        byte[][] batchPayload = new byte[2][];
        byte[] buf = pk.getBuffer();
        batchPayload[0] = Binary.writeInt(buf.length);
        batchPayload[1] = buf;
        byte[] data = Binary.appendBytes(batchPayload);
        try {
            batch.payload = Zlib.deflate(data, Server.getInstance().networkCompressionLevel);
        }
        catch (Exception e) {
            throw new RuntimeException(e);
        }
        batch.encode();
        batch.isEncoded = true;
        return batch;
    }

    public boolean isFoodEnabled() {
        return !this.isCreative() && !this.isSpectator() && this.foodEnabled;
    }

    public void setFoodEnabled(boolean foodEnabled) {
        this.foodEnabled = foodEnabled;
    }

    public PlayerFood getFoodData() {
        return this.foodData;
    }

    public void setDimension() {
        ChangeDimensionPacket pk = new ChangeDimensionPacket();
        pk.dimension = (byte)(this.getLevel().getDimension() & 0xFF);
        this.dataPacket(pk);
    }

    public synchronized void setLocale(Locale locale) {
        this.locale.set(locale);
    }

    public synchronized Locale getLocale() {
        return this.locale.get();
    }

    @Override
    public int hashCode() {
        if (this.hash == 0 || this.hash == 485) {
            this.hash = 485 + (this.getUniqueId() != null ? this.getUniqueId().hashCode() : 0);
        }
        return this.hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof Player)) {
            return false;
        }
        Player other = (Player)obj;
        return Objects.equals(this.getUniqueId(), other.getUniqueId()) && this.getId() == other.getId();
    }

    private static /* synthetic */ Item[] lambda$handleDataPacket$9(int x$0) {
        return new Item[x$0];
    }
}

