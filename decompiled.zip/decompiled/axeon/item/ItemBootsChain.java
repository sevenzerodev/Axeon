/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.item;

import cn.axeon.item.ItemArmor;

public class ItemBootsChain
extends ItemArmor {
    public ItemBootsChain() {
        this((Integer)0, 1);
    }

    public ItemBootsChain(Integer meta) {
        this(meta, 1);
    }

    public ItemBootsChain(Integer meta, int count) {
        super(305, (int)meta, count, "Chainmail Boots");
    }

    @Override
    public int getTier() {
        return 3;
    }

    @Override
    public boolean isBoots() {
        return true;
    }
}

