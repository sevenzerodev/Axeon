/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.item;

import cn.axeon.item.ItemColorArmor;

public class ItemChestplateLeather
extends ItemColorArmor {
    public ItemChestplateLeather() {
        this((Integer)0, 1);
    }

    public ItemChestplateLeather(Integer meta) {
        this(meta, 1);
    }

    public ItemChestplateLeather(Integer meta, int count) {
        super(299, meta, count, "Leather Tunic");
    }

    @Override
    public int getTier() {
        return 1;
    }

    @Override
    public boolean isChestplate() {
        return true;
    }
}

