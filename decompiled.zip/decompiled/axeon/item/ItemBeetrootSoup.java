/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.item;

import cn.axeon.item.ItemEdible;

public class ItemBeetrootSoup
extends ItemEdible {
    public ItemBeetrootSoup() {
        this((Integer)0, 1);
    }

    public ItemBeetrootSoup(Integer meta) {
        this(meta, 1);
    }

    public ItemBeetrootSoup(Integer meta, int count) {
        super(459, 0, count, "Beetroot Soup");
    }
}

