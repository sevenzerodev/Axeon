/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.item;

import cn.axeon.item.ItemArmor;

public class ItemChestplateIron
extends ItemArmor {
    public ItemChestplateIron() {
        this((Integer)0, 1);
    }

    public ItemChestplateIron(Integer meta) {
        this(meta, 1);
    }

    public ItemChestplateIron(Integer meta, int count) {
        super(307, (int)meta, count, "Iron Chestplate");
    }

    @Override
    public int getTier() {
        return 2;
    }

    @Override
    public boolean isChestplate() {
        return true;
    }
}

