/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.item;

import cn.axeon.block.BlockDoorBirch;
import cn.axeon.item.Item;

public class ItemDoorBirch
extends Item {
    public ItemDoorBirch() {
        this((Integer)0, 1);
    }

    public ItemDoorBirch(Integer meta) {
        this(meta, 1);
    }

    public ItemDoorBirch(Integer meta, int count) {
        super(428, 0, count, "Birch Door");
        this.block = new BlockDoorBirch();
    }
}

