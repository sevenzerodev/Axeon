/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.item;

import cn.axeon.item.ItemArmor;

public class ItemChestplateDiamond
extends ItemArmor {
    public ItemChestplateDiamond() {
        this((Integer)0, 1);
    }

    public ItemChestplateDiamond(Integer meta) {
        this(meta, 1);
    }

    public ItemChestplateDiamond(Integer meta, int count) {
        super(311, (int)meta, count, "Diamond Chestplate");
    }

    @Override
    public int getTier() {
        return 5;
    }

    @Override
    public boolean isChestplate() {
        return true;
    }
}

