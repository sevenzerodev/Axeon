/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.item;

import cn.axeon.block.BlockDoorAcacia;
import cn.axeon.item.Item;

public class ItemDoorAcacia
extends Item {
    public ItemDoorAcacia() {
        this((Integer)0, 1);
    }

    public ItemDoorAcacia(Integer meta) {
        this(meta, 1);
    }

    public ItemDoorAcacia(Integer meta, int count) {
        super(430, 0, count, "Acacia Door");
        this.block = new BlockDoorAcacia();
    }
}

