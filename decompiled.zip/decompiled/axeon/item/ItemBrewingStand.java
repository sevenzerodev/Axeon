/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.item;

import cn.axeon.block.BlockBrewingStand;
import cn.axeon.item.Item;

public class ItemBrewingStand
extends Item {
    public ItemBrewingStand(int meta) {
        this(meta, 1);
    }

    public ItemBrewingStand(int meta, int count) {
        super(379, 0, count, "Brewing Stand");
        this.block = new BlockBrewingStand();
    }
}

