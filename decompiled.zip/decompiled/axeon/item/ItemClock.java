/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.item;

import cn.axeon.item.Item;

public class ItemClock
extends Item {
    public ItemClock() {
        this((Integer)0, 1);
    }

    public ItemClock(Integer meta) {
        this(meta, 1);
    }

    public ItemClock(Integer meta, int count) {
        super(347, meta, count, "Clock");
    }
}

