/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.item;

import cn.axeon.item.ItemTool;

public class ItemAxeGold
extends ItemTool {
    public ItemAxeGold() {
        this((Integer)0, 1);
    }

    public ItemAxeGold(Integer meta) {
        this(meta, 1);
    }

    public ItemAxeGold(Integer meta, int count) {
        super(286, (int)meta, count, "Gold Axe");
    }

    @Override
    public int getMaxDurability() {
        return 33;
    }

    @Override
    public boolean isAxe() {
        return true;
    }

    @Override
    public int getTier() {
        return 2;
    }
}

