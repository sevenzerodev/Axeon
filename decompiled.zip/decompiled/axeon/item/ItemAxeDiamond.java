/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.item;

import cn.axeon.item.ItemTool;

public class ItemAxeDiamond
extends ItemTool {
    public ItemAxeDiamond() {
        this((Integer)0, 1);
    }

    public ItemAxeDiamond(Integer meta) {
        this(meta, 1);
    }

    public ItemAxeDiamond(Integer meta, int count) {
        super(279, (int)meta, count, "Diamond Axe");
    }

    @Override
    public int getMaxDurability() {
        return 1562;
    }

    @Override
    public boolean isAxe() {
        return true;
    }

    @Override
    public int getTier() {
        return 5;
    }
}

