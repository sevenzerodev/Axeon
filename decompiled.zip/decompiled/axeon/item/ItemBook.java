/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.item;

import cn.axeon.item.Item;

public class ItemBook
extends Item {
    public ItemBook() {
        this((Integer)0, 1);
    }

    public ItemBook(Integer meta) {
        this(meta, 1);
    }

    public ItemBook(Integer meta, int count) {
        super(340, meta, count, "Book");
    }

    @Override
    public int getEnchantAbility() {
        return 1;
    }
}

