/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.item;

import cn.axeon.item.Item;
import cn.axeon.utils.BlockColor;

public class ItemDye
extends Item {
    public static final int WHITE = 0;
    public static final int ORANGE = 1;
    public static final int MAGENTA = 2;
    public static final int LIGHT_BLUE = 3;
    public static final int YELLOW = 4;
    public static final int LIME = 5;
    public static final int PINK = 6;
    public static final int GRAY = 7;
    public static final int LIGHT_GRAY = 8;
    public static final int CYAN = 9;
    public static final int PURPLE = 10;
    public static final int BLUE = 11;
    public static final int BROWN = 12;
    public static final int GREEN = 13;
    public static final int RED = 14;
    public static final int BLACK = 15;

    public ItemDye() {
        this((Integer)0, 1);
    }

    public ItemDye(Integer meta) {
        this(meta, 1);
    }

    public ItemDye(Integer meta, int count) {
        super(351, meta, count, "Dye");
    }

    public static BlockColor getColor(int meta) {
        switch (meta & 0xF) {
            case 0: {
                return BlockColor.WHITE_BLOCK_COLOR;
            }
            case 1: {
                return BlockColor.ORANGE_BLOCK_COLOR;
            }
            case 2: {
                return BlockColor.MAGENTA_BLOCK_COLOR;
            }
            case 3: {
                return BlockColor.LIGHT_BLUE_BLOCK_COLOR;
            }
            case 4: {
                return BlockColor.YELLOW_BLOCK_COLOR;
            }
            case 5: {
                return BlockColor.LIME_BLOCK_COLOR;
            }
            case 6: {
                return BlockColor.PINK_BLOCK_COLOR;
            }
            case 7: {
                return BlockColor.GRAY_BLOCK_COLOR;
            }
            case 8: {
                return BlockColor.LIGHT_GRAY_BLOCK_COLOR;
            }
            case 9: {
                return BlockColor.CYAN_BLOCK_COLOR;
            }
            case 10: {
                return BlockColor.PURPLE_BLOCK_COLOR;
            }
            case 11: {
                return BlockColor.BLUE_BLOCK_COLOR;
            }
            case 12: {
                return BlockColor.BROWN_BLOCK_COLOR;
            }
            case 13: {
                return BlockColor.GREEN_BLOCK_COLOR;
            }
            case 14: {
                return BlockColor.RED_BLOCK_COLOR;
            }
            case 15: {
                return BlockColor.BLACK_BLOCK_COLOR;
            }
        }
        return BlockColor.WHITE_BLOCK_COLOR;
    }

    public static String getColorName(int meta) {
        String[] names = new String[]{"White", "Orange", "Magenta", "Light Blue", "Yellow", "Lime", "Pink", "Gray", "Light Gray", "Cyan", "Purple", "Blue", "Brown", "Green", "Red", "Black"};
        return names[meta & 0xF];
    }
}

