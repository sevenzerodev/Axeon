/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.item;

import cn.axeon.item.Item;

public class ItemBone
extends Item {
    public ItemBone() {
        this((Integer)0, 1);
    }

    public ItemBone(Integer meta) {
        this(meta, 1);
    }

    public ItemBone(Integer meta, int count) {
        super(352, meta, count, "Bone");
    }
}

