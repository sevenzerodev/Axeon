/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.item;

import cn.axeon.block.BlockDoorWood;
import cn.axeon.item.Item;

public class ItemDoorWood
extends Item {
    public ItemDoorWood() {
        this((Integer)0, 1);
    }

    public ItemDoorWood(Integer meta) {
        this(meta, 1);
    }

    public ItemDoorWood(Integer meta, int count) {
        super(324, 0, count, "Oak Door");
        this.block = new BlockDoorWood();
    }
}

