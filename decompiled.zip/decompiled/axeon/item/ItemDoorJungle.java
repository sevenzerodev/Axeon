/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.item;

import cn.axeon.block.BlockDoorJungle;
import cn.axeon.item.Item;

public class ItemDoorJungle
extends Item {
    public ItemDoorJungle() {
        this((Integer)0, 1);
    }

    public ItemDoorJungle(Integer meta) {
        this(meta, 1);
    }

    public ItemDoorJungle(Integer meta, int count) {
        super(429, 0, count, "Jungle Door");
        this.block = new BlockDoorJungle();
    }
}

