/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.item;

import cn.axeon.item.ItemTool;

public class ItemAxeStone
extends ItemTool {
    public ItemAxeStone() {
        this((Integer)0, 1);
    }

    public ItemAxeStone(Integer meta) {
        this(meta, 1);
    }

    public ItemAxeStone(Integer meta, int count) {
        super(275, (int)meta, count, "Stone Axe");
    }

    @Override
    public int getMaxDurability() {
        return 132;
    }

    @Override
    public boolean isAxe() {
        return true;
    }

    @Override
    public int getTier() {
        return 3;
    }
}

