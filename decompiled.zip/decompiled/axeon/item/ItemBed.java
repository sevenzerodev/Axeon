/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.item;

import cn.axeon.block.BlockBed;
import cn.axeon.item.Item;

public class ItemBed
extends Item {
    public ItemBed() {
        this((Integer)0, 1);
    }

    public ItemBed(Integer meta) {
        this(meta, 1);
    }

    public ItemBed(Integer meta, int count) {
        super(355, 0, count, "BlockBed");
        this.block = new BlockBed();
    }

    @Override
    public int getMaxStackSize() {
        return 1;
    }
}

