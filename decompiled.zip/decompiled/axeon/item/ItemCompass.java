/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.item;

import cn.axeon.item.Item;

public class ItemCompass
extends Item {
    public ItemCompass() {
        this((Integer)0, 1);
    }

    public ItemCompass(Integer meta) {
        this(meta, 1);
    }

    public ItemCompass(Integer meta, int count) {
        super(345, meta, count, "Compass");
    }
}

