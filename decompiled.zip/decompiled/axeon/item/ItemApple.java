/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.item;

import cn.axeon.item.ItemEdible;

public class ItemApple
extends ItemEdible {
    public ItemApple() {
        this((Integer)0, 1);
    }

    public ItemApple(Integer meta) {
        this(meta, 1);
    }

    public ItemApple(Integer meta, int count) {
        super(260, 0, count, "Apple");
    }
}

