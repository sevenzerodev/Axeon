/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.item;

import cn.axeon.item.ItemEdible;

public class ItemBread
extends ItemEdible {
    public ItemBread() {
        this((Integer)0, 1);
    }

    public ItemBread(Integer meta) {
        this(meta, 1);
    }

    public ItemBread(Integer meta, int count) {
        super(297, meta, count, "Bread");
    }
}

