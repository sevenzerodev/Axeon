/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.item;

import cn.axeon.Player;
import cn.axeon.block.Block;
import cn.axeon.entity.item.EntityBoat;
import cn.axeon.item.Item;
import cn.axeon.level.Level;
import cn.axeon.nbt.tag.CompoundTag;
import cn.axeon.nbt.tag.DoubleTag;
import cn.axeon.nbt.tag.FloatTag;
import cn.axeon.nbt.tag.ListTag;

public class ItemBoat
extends Item {
    public ItemBoat() {
        this((Integer)0, 1);
    }

    public ItemBoat(Integer meta) {
        this(meta, 1);
    }

    public ItemBoat(Integer meta, int count) {
        super(333, meta, count, "Boat");
    }

    @Override
    public boolean canBeActivated() {
        return true;
    }

    @Override
    public boolean onActivate(Level level, Player player, Block block, Block target, int face, double fx, double fy, double fz) {
        if (face != 1) {
            return false;
        }
        EntityBoat boat = new EntityBoat(level.getChunk(block.getFloorX() >> 4, block.getFloorZ() >> 4), new CompoundTag("").putList(new ListTag<DoubleTag>("Pos").add(new DoubleTag("", block.getX() + 0.5)).add(new DoubleTag("", block.getY() - 0.0625)).add(new DoubleTag("", block.getZ() + 0.5))).putList(new ListTag<DoubleTag>("Motion").add(new DoubleTag("", 0.0)).add(new DoubleTag("", 0.0)).add(new DoubleTag("", 0.0))).putList(new ListTag<FloatTag>("Rotation").add(new FloatTag("", (float)((player.yaw + 90.0) % 360.0))).add(new FloatTag("", 0.0f))).putByte("woodID", this.getDamage()));
        if (player.isSurvival()) {
            Item item = player.getInventory().getItemInHand();
            item.setCount(item.getCount() - 1);
            player.getInventory().setItemInHand(item);
        }
        boat.spawnToAll();
        return true;
    }
}

