/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.item;

import cn.axeon.item.Item;

public class ItemAppleGold
extends Item {
    public ItemAppleGold() {
        this((Integer)0, 1);
    }

    public ItemAppleGold(Integer meta) {
        this(meta, 1);
    }

    public ItemAppleGold(Integer meta, int count) {
        super(322, meta, count, "Golden Apple");
    }
}

