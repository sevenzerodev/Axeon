/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.item;

import cn.axeon.Player;
import cn.axeon.block.Block;
import cn.axeon.block.BlockAir;
import cn.axeon.block.BlockLiquid;
import cn.axeon.event.player.PlayerBucketFillEvent;
import cn.axeon.item.Item;
import cn.axeon.level.Level;

public class ItemBucket
extends Item {
    public ItemBucket() {
        this((Integer)0, 1);
    }

    public ItemBucket(Integer meta) {
        this(meta, 1);
    }

    public ItemBucket(Integer meta, int count) {
        super(325, meta, count, ItemBucket.getName(meta));
    }

    protected static String getName(int meta) {
        switch (meta) {
            case 1: {
                return "Milk";
            }
            case 8: {
                return "Water Bucket";
            }
            case 10: {
                return "Lava Bucket";
            }
        }
        return "Bucket";
    }

    @Override
    public int getMaxStackSize() {
        return 1;
    }

    @Override
    public boolean canBeActivated() {
        return true;
    }

    @Override
    public boolean onActivate(Level level, Player player, Block block, Block target, int face, double fx, double fy, double fz) {
        Block targetBlock = Block.get(this.meta);
        if (targetBlock instanceof BlockAir) {
            if (target instanceof BlockLiquid && target.getDamage() == 0) {
                Item result = this.clone();
                result.setDamage(target.getId());
                PlayerBucketFillEvent ev = new PlayerBucketFillEvent(player, block, face, (Item)this, result);
                player.getServer().getPluginManager().callEvent(ev);
                if (!ev.isCancelled()) {
                    player.getLevel().setBlock(target, new BlockAir(), true, true);
                    if (player.isSurvival()) {
                        player.getInventory().setItemInHand(ev.getItem());
                    }
                    return true;
                }
                player.getInventory().sendContents(player);
            }
        } else if (targetBlock instanceof BlockLiquid) {
            Item result = this.clone();
            result.setDamage(0);
            PlayerBucketFillEvent ev = new PlayerBucketFillEvent(player, block, face, (Item)this, result);
            player.getServer().getPluginManager().callEvent(ev);
            if (!ev.isCancelled()) {
                player.getLevel().setBlock(block, targetBlock, true, true);
                if (player.isSurvival()) {
                    player.getInventory().setItemInHand(ev.getItem());
                }
                return true;
            }
            player.getInventory().sendContents(player);
        }
        return false;
    }
}

