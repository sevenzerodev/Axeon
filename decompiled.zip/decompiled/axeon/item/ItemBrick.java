/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.item;

import cn.axeon.item.Item;

public class ItemBrick
extends Item {
    public ItemBrick() {
        this((Integer)0, 1);
    }

    public ItemBrick(Integer meta) {
        this(meta, 1);
    }

    public ItemBrick(Integer meta, int count) {
        super(336, 0, count, "Brick");
    }
}

