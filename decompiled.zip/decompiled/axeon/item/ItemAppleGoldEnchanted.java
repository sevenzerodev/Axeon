/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.item;

import cn.axeon.item.ItemEdible;

public class ItemAppleGoldEnchanted
extends ItemEdible {
    public ItemAppleGoldEnchanted() {
        this((Integer)0, 1);
    }

    public ItemAppleGoldEnchanted(Integer meta) {
        this(meta, 1);
    }

    public ItemAppleGoldEnchanted(Integer meta, int count) {
        super(466, meta, count, "Enchanted Golden Apple");
    }
}

