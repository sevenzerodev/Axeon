/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.item;

import cn.axeon.block.BlockDoorSpruce;
import cn.axeon.item.Item;

public class ItemDoorSpruce
extends Item {
    public ItemDoorSpruce() {
        this((Integer)0, 1);
    }

    public ItemDoorSpruce(Integer meta) {
        this(meta, 1);
    }

    public ItemDoorSpruce(Integer meta, int count) {
        super(427, 0, count, "Spruce Door");
        this.block = new BlockDoorSpruce();
    }
}

