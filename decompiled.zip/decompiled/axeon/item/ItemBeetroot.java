/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.item;

import cn.axeon.item.ItemEdible;

public class ItemBeetroot
extends ItemEdible {
    public ItemBeetroot() {
        this((Integer)0, 1);
    }

    public ItemBeetroot(Integer meta) {
        this(meta, 1);
    }

    public ItemBeetroot(Integer meta, int count) {
        super(457, meta, count, "Beetroot");
    }
}

