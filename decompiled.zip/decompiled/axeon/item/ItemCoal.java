/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.item;

import cn.axeon.item.Item;

public class ItemCoal
extends Item {
    public ItemCoal() {
        this((Integer)0, 1);
    }

    public ItemCoal(Integer meta) {
        this(meta, 1);
    }

    public ItemCoal(Integer meta, int count) {
        super(263, meta, count, "Coal");
        if (this.meta == 1) {
            this.name = "Charcoal";
        }
    }
}

