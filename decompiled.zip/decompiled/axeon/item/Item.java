/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.item;

import cn.axeon.Player;
import cn.axeon.block.Block;
import cn.axeon.block.BlockAir;
import cn.axeon.block.BlockRedstoneTorch;
import cn.axeon.entity.Entity;
import cn.axeon.inventory.Fuel;
import cn.axeon.item.ItemApple;
import cn.axeon.item.ItemAppleGold;
import cn.axeon.item.ItemAppleGoldEnchanted;
import cn.axeon.item.ItemArrow;
import cn.axeon.item.ItemAxeDiamond;
import cn.axeon.item.ItemAxeGold;
import cn.axeon.item.ItemAxeIron;
import cn.axeon.item.ItemAxeStone;
import cn.axeon.item.ItemAxeWood;
import cn.axeon.item.ItemBed;
import cn.axeon.item.ItemBeefRaw;
import cn.axeon.item.ItemBeetroot;
import cn.axeon.item.ItemBeetrootSoup;
import cn.axeon.item.ItemBlock;
import cn.axeon.item.ItemBoat;
import cn.axeon.item.ItemBone;
import cn.axeon.item.ItemBook;
import cn.axeon.item.ItemBootsChain;
import cn.axeon.item.ItemBootsDiamond;
import cn.axeon.item.ItemBootsGold;
import cn.axeon.item.ItemBootsIron;
import cn.axeon.item.ItemBootsLeather;
import cn.axeon.item.ItemBow;
import cn.axeon.item.ItemBowl;
import cn.axeon.item.ItemBread;
import cn.axeon.item.ItemBrewingStand;
import cn.axeon.item.ItemBrick;
import cn.axeon.item.ItemBucket;
import cn.axeon.item.ItemCake;
import cn.axeon.item.ItemCarrot;
import cn.axeon.item.ItemChestplateChain;
import cn.axeon.item.ItemChestplateDiamond;
import cn.axeon.item.ItemChestplateGold;
import cn.axeon.item.ItemChestplateIron;
import cn.axeon.item.ItemChestplateLeather;
import cn.axeon.item.ItemChickenCooked;
import cn.axeon.item.ItemChickenRaw;
import cn.axeon.item.ItemClay;
import cn.axeon.item.ItemClock;
import cn.axeon.item.ItemClownfish;
import cn.axeon.item.ItemCoal;
import cn.axeon.item.ItemCompass;
import cn.axeon.item.ItemCookie;
import cn.axeon.item.ItemDiamond;
import cn.axeon.item.ItemDoorAcacia;
import cn.axeon.item.ItemDoorBirch;
import cn.axeon.item.ItemDoorDarkOak;
import cn.axeon.item.ItemDoorIron;
import cn.axeon.item.ItemDoorJungle;
import cn.axeon.item.ItemDoorSpruce;
import cn.axeon.item.ItemDoorWood;
import cn.axeon.item.ItemDye;
import cn.axeon.item.ItemEgg;
import cn.axeon.item.ItemEmerald;
import cn.axeon.item.ItemExpBottle;
import cn.axeon.item.ItemFeather;
import cn.axeon.item.ItemFish;
import cn.axeon.item.ItemFishCooked;
import cn.axeon.item.ItemFishingRod;
import cn.axeon.item.ItemFlint;
import cn.axeon.item.ItemFlintSteel;
import cn.axeon.item.ItemFlowerPot;
import cn.axeon.item.ItemGlassBottle;
import cn.axeon.item.ItemGlowstoneDust;
import cn.axeon.item.ItemGunpowder;
import cn.axeon.item.ItemHelmetChain;
import cn.axeon.item.ItemHelmetDiamond;
import cn.axeon.item.ItemHelmetGold;
import cn.axeon.item.ItemHelmetIron;
import cn.axeon.item.ItemHelmetLeather;
import cn.axeon.item.ItemHoeDiamond;
import cn.axeon.item.ItemHoeGold;
import cn.axeon.item.ItemHoeIron;
import cn.axeon.item.ItemHoeStone;
import cn.axeon.item.ItemHoeWood;
import cn.axeon.item.ItemIngotGold;
import cn.axeon.item.ItemIngotIron;
import cn.axeon.item.ItemLeather;
import cn.axeon.item.ItemLeggingsChain;
import cn.axeon.item.ItemLeggingsDiamond;
import cn.axeon.item.ItemLeggingsGold;
import cn.axeon.item.ItemLeggingsIron;
import cn.axeon.item.ItemLeggingsLeather;
import cn.axeon.item.ItemMelon;
import cn.axeon.item.ItemMinecart;
import cn.axeon.item.ItemMushroomStew;
import cn.axeon.item.ItemNetherBrick;
import cn.axeon.item.ItemNuggetGold;
import cn.axeon.item.ItemPainting;
import cn.axeon.item.ItemPaper;
import cn.axeon.item.ItemPickaxeDiamond;
import cn.axeon.item.ItemPickaxeGold;
import cn.axeon.item.ItemPickaxeIron;
import cn.axeon.item.ItemPickaxeStone;
import cn.axeon.item.ItemPickaxeWood;
import cn.axeon.item.ItemPorkchopCooked;
import cn.axeon.item.ItemPorkchopRaw;
import cn.axeon.item.ItemPotato;
import cn.axeon.item.ItemPotatoBaked;
import cn.axeon.item.ItemPotatoPoisonous;
import cn.axeon.item.ItemPotion;
import cn.axeon.item.ItemPotionSplash;
import cn.axeon.item.ItemPufferfish;
import cn.axeon.item.ItemPumpkinPie;
import cn.axeon.item.ItemQuartz;
import cn.axeon.item.ItemRabbitCooked;
import cn.axeon.item.ItemRabbitFoot;
import cn.axeon.item.ItemRabbitRaw;
import cn.axeon.item.ItemRabbitStew;
import cn.axeon.item.ItemRedstone;
import cn.axeon.item.ItemRottenFlesh;
import cn.axeon.item.ItemSalmon;
import cn.axeon.item.ItemSalmonCooked;
import cn.axeon.item.ItemSeedsBeetroot;
import cn.axeon.item.ItemSeedsMelon;
import cn.axeon.item.ItemSeedsPumpkin;
import cn.axeon.item.ItemSeedsWheat;
import cn.axeon.item.ItemShears;
import cn.axeon.item.ItemShovelDiamond;
import cn.axeon.item.ItemShovelGold;
import cn.axeon.item.ItemShovelIron;
import cn.axeon.item.ItemShovelStone;
import cn.axeon.item.ItemShovelWood;
import cn.axeon.item.ItemSign;
import cn.axeon.item.ItemSkull;
import cn.axeon.item.ItemSlimeball;
import cn.axeon.item.ItemSnowball;
import cn.axeon.item.ItemSpawnEgg;
import cn.axeon.item.ItemSpiderEye;
import cn.axeon.item.ItemSteak;
import cn.axeon.item.ItemStick;
import cn.axeon.item.ItemString;
import cn.axeon.item.ItemSugar;
import cn.axeon.item.ItemSugarcane;
import cn.axeon.item.ItemSwordDiamond;
import cn.axeon.item.ItemSwordGold;
import cn.axeon.item.ItemSwordIron;
import cn.axeon.item.ItemSwordStone;
import cn.axeon.item.ItemSwordWood;
import cn.axeon.item.ItemWheat;
import cn.axeon.item.enchantment.Enchantment;
import cn.axeon.level.Level;
import cn.axeon.nbt.NBTIO;
import cn.axeon.nbt.tag.CompoundTag;
import cn.axeon.nbt.tag.ListTag;
import cn.axeon.nbt.tag.StringTag;
import cn.axeon.nbt.tag.Tag;
import cn.axeon.utils.Binary;
import java.io.IOException;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.regex.Pattern;

public class Item
implements Cloneable {
    public static final int AIR = 0;
    public static final int STONE = 1;
    public static final int GRASS = 2;
    public static final int DIRT = 3;
    public static final int COBBLESTONE = 4;
    public static final int COBBLE = 4;
    public static final int PLANK = 5;
    public static final int PLANKS = 5;
    public static final int WOODEN_PLANK = 5;
    public static final int WOODEN_PLANKS = 5;
    public static final int SAPLING = 6;
    public static final int SAPLINGS = 6;
    public static final int BEDROCK = 7;
    public static final int WATER = 8;
    public static final int STILL_WATER = 9;
    public static final int LAVA = 10;
    public static final int STILL_LAVA = 11;
    public static final int SAND = 12;
    public static final int GRAVEL = 13;
    public static final int GOLD_ORE = 14;
    public static final int IRON_ORE = 15;
    public static final int COAL_ORE = 16;
    public static final int LOG = 17;
    public static final int WOOD = 17;
    public static final int TRUNK = 17;
    public static final int LEAVES = 18;
    public static final int LEAVE = 18;
    public static final int SPONGE = 19;
    public static final int GLASS = 20;
    public static final int LAPIS_ORE = 21;
    public static final int LAPIS_BLOCK = 22;
    public static final int DISPENSER = 23;
    public static final int SANDSTONE = 24;
    public static final int NOTEBLOCK = 25;
    public static final int BED_BLOCK = 26;
    public static final int POWERED_RAIL = 27;
    public static final int DETECTOR_RAIL = 28;
    public static final int COBWEB = 30;
    public static final int TALL_GRASS = 31;
    public static final int BUSH = 32;
    public static final int DEAD_BUSH = 32;
    public static final int WOOL = 35;
    public static final int DANDELION = 37;
    public static final int POPPY = 38;
    public static final int ROSE = 38;
    public static final int FLOWER = 38;
    public static final int RED_FLOWER = 38;
    public static final int BROWN_MUSHROOM = 39;
    public static final int RED_MUSHROOM = 40;
    public static final int GOLD_BLOCK = 41;
    public static final int IRON_BLOCK = 42;
    public static final int DOUBLE_SLAB = 43;
    public static final int DOUBLE_SLABS = 43;
    public static final int SLAB = 44;
    public static final int SLABS = 44;
    public static final int BRICKS = 45;
    public static final int BRICKS_BLOCK = 45;
    public static final int TNT = 46;
    public static final int BOOKSHELF = 47;
    public static final int MOSS_STONE = 48;
    public static final int MOSSY_STONE = 48;
    public static final int OBSIDIAN = 49;
    public static final int TORCH = 50;
    public static final int FIRE = 51;
    public static final int MONSTER_SPAWNER = 52;
    public static final int WOOD_STAIRS = 53;
    public static final int WOODEN_STAIRS = 53;
    public static final int OAK_WOOD_STAIRS = 53;
    public static final int OAK_WOODEN_STAIRS = 53;
    public static final int CHEST = 54;
    public static final int REDSTONE_WIRE = 55;
    public static final int DIAMOND_ORE = 56;
    public static final int DIAMOND_BLOCK = 57;
    public static final int CRAFTING_TABLE = 58;
    public static final int WORKBENCH = 58;
    public static final int WHEAT_BLOCK = 59;
    public static final int FARMLAND = 60;
    public static final int FURNACE = 61;
    public static final int BURNING_FURNACE = 62;
    public static final int LIT_FURNACE = 62;
    public static final int SIGN_POST = 63;
    public static final int DOOR_BLOCK = 64;
    public static final int WOODEN_DOOR_BLOCK = 64;
    public static final int WOOD_DOOR_BLOCK = 64;
    public static final int LADDER = 65;
    public static final int RAIL = 66;
    public static final int COBBLE_STAIRS = 67;
    public static final int COBBLESTONE_STAIRS = 67;
    public static final int WALL_SIGN = 68;
    public static final int LEVER = 69;
    public static final int STONE_PRESSURE_PLATE = 70;
    public static final int IRON_DOOR_BLOCK = 71;
    public static final int WOODEN_PRESSURE_PLATE = 72;
    public static final int REDSTONE_ORE = 73;
    public static final int GLOWING_REDSTONE_ORE = 74;
    public static final int LIT_REDSTONE_ORE = 74;
    public static final int REDSTONE_TORCH = 76;
    public static final int STONE_BUTTON = 77;
    public static final int SNOW = 78;
    public static final int SNOW_LAYER = 78;
    public static final int ICE = 79;
    public static final int SNOW_BLOCK = 80;
    public static final int CACTUS = 81;
    public static final int CLAY_BLOCK = 82;
    public static final int REEDS = 83;
    public static final int SUGARCANE_BLOCK = 83;
    public static final int FENCE = 85;
    public static final int PUMPKIN = 86;
    public static final int NETHERRACK = 87;
    public static final int SOUL_SAND = 88;
    public static final int GLOWSTONE = 89;
    public static final int GLOWSTONE_BLOCK = 89;
    public static final int NETHER_PORTAL = 90;
    public static final int LIT_PUMPKIN = 91;
    public static final int JACK_O_LANTERN = 91;
    public static final int CAKE_BLOCK = 92;
    public static final int INVISIBLE_BEDROCK = 95;
    public static final int TRAPDOOR = 96;
    public static final int STONE_BRICKS = 98;
    public static final int STONE_BRICK = 98;
    public static final int BROWN_MUSHROOM_BLOCK = 99;
    public static final int RED_MUSHROOM_BLOCK = 100;
    public static final int IRON_BAR = 101;
    public static final int IRON_BARS = 101;
    public static final int GLASS_PANE = 102;
    public static final int GLASS_PANEL = 102;
    public static final int MELON_BLOCK = 103;
    public static final int PUMPKIN_STEM = 104;
    public static final int MELON_STEM = 105;
    public static final int VINE = 106;
    public static final int VINES = 106;
    public static final int FENCE_GATE = 107;
    public static final int BRICK_STAIRS = 108;
    public static final int STONE_BRICK_STAIRS = 109;
    public static final int MYCELIUM = 110;
    public static final int WATER_LILY = 111;
    public static final int LILY_PAD = 111;
    public static final int NETHER_BRICKS = 112;
    public static final int NETHER_BRICK_BLOCK = 112;
    public static final int NETHER_BRICK_FENCE = 113;
    public static final int NETHER_BRICKS_STAIRS = 114;
    public static final int ENCHANTING_TABLE = 116;
    public static final int ENCHANT_TABLE = 116;
    public static final int ENCHANTMENT_TABLE = 116;
    public static final int BREWING_STAND_BLOCK = 117;
    public static final int BREWING_BLOCK = 117;
    public static final int CAULDRON_BLOCK = 118;
    public static final int END_PORTAL = 119;
    public static final int END_PORTAL_FRAME = 120;
    public static final int END_STONE = 121;
    public static final int REDSTONE_LAMP = 123;
    public static final int LIT_REDSTONE_LAMP = 124;
    public static final int ACTIVATOR_RAIL = 126;
    public static final int SANDSTONE_STAIRS = 128;
    public static final int EMERALD_ORE = 129;
    public static final int TRIPWIRE_HOOK = 131;
    public static final int EMERALD_BLOCK = 133;
    public static final int SPRUCE_WOOD_STAIRS = 134;
    public static final int SPRUCE_WOODEN_STAIRS = 134;
    public static final int BIRCH_WOOD_STAIRS = 135;
    public static final int BIRCH_WOODEN_STAIRS = 135;
    public static final int JUNGLE_WOOD_STAIRS = 136;
    public static final int JUNGLE_WOODEN_STAIRS = 136;
    public static final int COBBLE_WALL = 139;
    public static final int STONE_WALL = 139;
    public static final int COBBLESTONE_WALL = 139;
    public static final int FLOWER_POT_BLOCK = 140;
    public static final int CARROT_BLOCK = 141;
    public static final int POTATO_BLOCK = 142;
    public static final int WOODEN_BUTTON = 143;
    public static final int SKULL_BLOCK = 144;
    public static final int ANVIL = 145;
    public static final int TRAPPED_CHEST = 146;
    public static final int LIGHT_WEIGHTED_PRESSURE_PLATE = 147;
    public static final int HEAVY_WEIGHTED_PRESSURE_PLATE = 148;
    public static final int UNPOWERED_COMPARATOR = 149;
    public static final int POWERED_COMPARATOR = 150;
    public static final int DAYLIGHT_DETECTOR = 151;
    public static final int REDSTONE_BLOCK = 152;
    public static final int QUARTZ_ORE = 153;
    public static final int HOPPER_BLOCK = 154;
    public static final int QUARTZ_BLOCK = 155;
    public static final int QUARTZ_STAIRS = 156;
    public static final int DOUBLE_WOOD_SLAB = 157;
    public static final int DOUBLE_WOODEN_SLAB = 157;
    public static final int DOUBLE_WOOD_SLABS = 157;
    public static final int DOUBLE_WOODEN_SLABS = 157;
    public static final int WOOD_SLAB = 158;
    public static final int WOODEN_SLAB = 158;
    public static final int WOOD_SLABS = 158;
    public static final int WOODEN_SLABS = 158;
    public static final int STAINED_CLAY = 159;
    public static final int STAINED_HARDENED_CLAY = 159;
    public static final int LEAVES2 = 161;
    public static final int LEAVE2 = 161;
    public static final int WOOD2 = 162;
    public static final int TRUNK2 = 162;
    public static final int LOG2 = 162;
    public static final int ACACIA_WOOD_STAIRS = 163;
    public static final int ACACIA_WOODEN_STAIRS = 163;
    public static final int DARK_OAK_WOOD_STAIRS = 164;
    public static final int DARK_OAK_WOODEN_STAIRS = 164;
    public static final int SLIME_BLOCK = 165;
    public static final int IRON_TRAPDOOR = 167;
    public static final int HAY_BALE = 170;
    public static final int CARPET = 171;
    public static final int HARDENED_CLAY = 172;
    public static final int COAL_BLOCK = 173;
    public static final int PACKED_ICE = 174;
    public static final int DOUBLE_PLANT = 175;
    public static final int DAYLIGHT_DETECTOR_INVERTED = 178;
    public static final int FENCE_GATE_SPRUCE = 183;
    public static final int FENCE_GATE_BIRCH = 184;
    public static final int FENCE_GATE_JUNGLE = 185;
    public static final int FENCE_GATE_DARK_OAK = 186;
    public static final int FENCE_GATE_ACACIA = 187;
    public static final int SPRUCE_DOOR_BLOCK = 193;
    public static final int BIRCH_DOOR_BLOCK = 194;
    public static final int JUNGLE_DOOR_BLOCK = 195;
    public static final int ACACIA_DOOR_BLOCK = 196;
    public static final int DARK_OAK_DOOR_BLOCK = 197;
    public static final int GRASS_PATH = 198;
    public static final int PODZOL = 243;
    public static final int BEETROOT_BLOCK = 244;
    public static final int STONECUTTER = 245;
    public static final int GLOWING_OBSIDIAN = 246;
    public static final int IRON_SHOVEL = 256;
    public static final int IRON_PICKAXE = 257;
    public static final int IRON_AXE = 258;
    public static final int FLINT_STEEL = 259;
    public static final int FLINT_AND_STEEL = 259;
    public static final int APPLE = 260;
    public static final int BOW = 261;
    public static final int ARROW = 262;
    public static final int COAL = 263;
    public static final int DIAMOND = 264;
    public static final int IRON_INGOT = 265;
    public static final int GOLD_INGOT = 266;
    public static final int IRON_SWORD = 267;
    public static final int WOODEN_SWORD = 268;
    public static final int WOODEN_SHOVEL = 269;
    public static final int WOODEN_PICKAXE = 270;
    public static final int WOODEN_AXE = 271;
    public static final int STONE_SWORD = 272;
    public static final int STONE_SHOVEL = 273;
    public static final int STONE_PICKAXE = 274;
    public static final int STONE_AXE = 275;
    public static final int DIAMOND_SWORD = 276;
    public static final int DIAMOND_SHOVEL = 277;
    public static final int DIAMOND_PICKAXE = 278;
    public static final int DIAMOND_AXE = 279;
    public static final int STICK = 280;
    public static final int STICKS = 280;
    public static final int BOWL = 281;
    public static final int MUSHROOM_STEW = 282;
    public static final int GOLD_SWORD = 283;
    public static final int GOLD_SHOVEL = 284;
    public static final int GOLD_PICKAXE = 285;
    public static final int GOLD_AXE = 286;
    public static final int GOLDEN_SWORD = 283;
    public static final int GOLDEN_SHOVEL = 284;
    public static final int GOLDEN_PICKAXE = 285;
    public static final int GOLDEN_AXE = 286;
    public static final int STRING = 287;
    public static final int FEATHER = 288;
    public static final int GUNPOWDER = 289;
    public static final int WOODEN_HOE = 290;
    public static final int STONE_HOE = 291;
    public static final int IRON_HOE = 292;
    public static final int DIAMOND_HOE = 293;
    public static final int GOLD_HOE = 294;
    public static final int GOLDEN_HOE = 294;
    public static final int SEEDS = 295;
    public static final int WHEAT_SEEDS = 295;
    public static final int WHEAT = 296;
    public static final int BREAD = 297;
    public static final int LEATHER_CAP = 298;
    public static final int LEATHER_TUNIC = 299;
    public static final int LEATHER_PANTS = 300;
    public static final int LEATHER_BOOTS = 301;
    public static final int CHAIN_HELMET = 302;
    public static final int CHAIN_CHESTPLATE = 303;
    public static final int CHAIN_LEGGINGS = 304;
    public static final int CHAIN_BOOTS = 305;
    public static final int IRON_HELMET = 306;
    public static final int IRON_CHESTPLATE = 307;
    public static final int IRON_LEGGINGS = 308;
    public static final int IRON_BOOTS = 309;
    public static final int DIAMOND_HELMET = 310;
    public static final int DIAMOND_CHESTPLATE = 311;
    public static final int DIAMOND_LEGGINGS = 312;
    public static final int DIAMOND_BOOTS = 313;
    public static final int GOLD_HELMET = 314;
    public static final int GOLD_CHESTPLATE = 315;
    public static final int GOLD_LEGGINGS = 316;
    public static final int GOLD_BOOTS = 317;
    public static final int FLINT = 318;
    public static final int RAW_PORKCHOP = 319;
    public static final int COOKED_PORKCHOP = 320;
    public static final int PAINTING = 321;
    public static final int GOLDEN_APPLE = 322;
    public static final int SIGN = 323;
    public static final int WOODEN_DOOR = 324;
    public static final int BUCKET = 325;
    public static final int MINECART = 328;
    public static final int IRON_DOOR = 330;
    public static final int REDSTONE = 331;
    public static final int REDSTONE_DUST = 331;
    public static final int SNOWBALL = 332;
    public static final int BOAT = 333;
    public static final int LEATHER = 334;
    public static final int BRICK = 336;
    public static final int CLAY = 337;
    public static final int SUGARCANE = 338;
    public static final int SUGAR_CANE = 338;
    public static final int SUGAR_CANES = 338;
    public static final int PAPER = 339;
    public static final int BOOK = 340;
    public static final int SLIMEBALL = 341;
    public static final int MINECART_WITH_CHEST = 342;
    public static final int EGG = 344;
    public static final int COMPASS = 345;
    public static final int FISHING_ROD = 346;
    public static final int CLOCK = 347;
    public static final int GLOWSTONE_DUST = 348;
    public static final int RAW_FISH = 349;
    public static final int COOKED_FISH = 350;
    public static final int DYE = 351;
    public static final int BONE = 352;
    public static final int SUGAR = 353;
    public static final int CAKE = 354;
    public static final int BED = 355;
    public static final int REPEATER = 356;
    public static final int COOKIE = 357;
    public static final int MAP = 358;
    public static final int SHEARS = 359;
    public static final int MELON = 360;
    public static final int MELON_SLICE = 360;
    public static final int PUMPKIN_SEEDS = 361;
    public static final int MELON_SEEDS = 362;
    public static final int RAW_BEEF = 363;
    public static final int STEAK = 364;
    public static final int COOKED_BEEF = 364;
    public static final int RAW_CHICKEN = 365;
    public static final int COOKED_CHICKEN = 366;
    public static final int ROTTEN_FLESH = 367;
    public static final int BLAZE_ROD = 369;
    public static final int GHAST_TEAR = 370;
    public static final int GOLD_NUGGET = 371;
    public static final int GOLDEN_NUGGET = 371;
    public static final int NETHER_WART = 372;
    public static final int POTION = 373;
    public static final int GLASS_BOTTLE = 374;
    public static final int BOTTLE = 374;
    public static final int SPIDER_EYE = 375;
    public static final int FERMENTED_SPIDER_EYE = 376;
    public static final int BLAZE_POWDER = 377;
    public static final int MAGMA_CREAM = 378;
    public static final int BREWING_STAND = 379;
    public static final int BREWING = 379;
    public static final int CAULDRON = 380;
    public static final int GLISTERING_MELON = 382;
    public static final int SPAWN_EGG = 383;
    public static final int EXPERIENCE_BOTTLE = 384;
    public static final int EMERALD = 388;
    public static final int ITEM_FRAME = 389;
    public static final int FLOWER_POT = 390;
    public static final int CARROT = 391;
    public static final int CARROTS = 391;
    public static final int POTATO = 392;
    public static final int POTATOES = 392;
    public static final int BAKED_POTATO = 393;
    public static final int BAKED_POTATOES = 393;
    public static final int POISONOUS_POTATO = 394;
    public static final int EMPTY_MAP = 395;
    public static final int GOLDEN_CARROT = 396;
    public static final int SKULL = 397;
    public static final int PUMPKIN_PIE = 400;
    public static final int ENCHANTED_BOOK = 403;
    public static final int ENCHANT_BOOK = 403;
    public static final int COMPARATOR = 404;
    public static final int NETHER_BRICK = 405;
    public static final int QUARTZ = 406;
    public static final int NETHER_QUARTZ = 406;
    public static final int MINECART_WITH_TNT = 407;
    public static final int MINECART_WITH_HOPPER = 408;
    public static final int HOPPER = 410;
    public static final int RAW_RABBIT = 411;
    public static final int COOKED_RABBIT = 412;
    public static final int RABBIT_STEW = 413;
    public static final int RABBIT_FOOT = 414;
    public static final int RABBIT_HIDE = 415;
    public static final int SPRUCE_DOOR = 427;
    public static final int BIRCH_DOOR = 428;
    public static final int JUNGLE_DOOR = 429;
    public static final int ACACIA_DOOR = 430;
    public static final int DARK_OAK_DOOR = 431;
    public static final int SPLASH_POTION = 438;
    public static final int SPRUCE_BOAT = 444;
    public static final int BIRCH_BOAT = 445;
    public static final int JUNGLE_BOAT = 446;
    public static final int ACACIA_BOAT = 447;
    public static final int DARK_OAK_BOAT = 448;
    public static final int CAMERA = 456;
    public static final int BEETROOT = 457;
    public static final int BEETROOT_SEEDS = 458;
    public static final int BEETROOT_SEED = 458;
    public static final int BEETROOT_SOUP = 459;
    public static final int RAW_SALMON = 460;
    public static final int CLOWNFISH = 461;
    public static final int PUFFERFISH = 462;
    public static final int COOKED_SALMON = 463;
    public static final int GOLDEN_APPLE_ENCHANTED = 466;
    public static Class[] list = null;
    protected Block block = null;
    protected int id;
    protected int meta;
    protected boolean hasMeta = true;
    private byte[] tags = new byte[0];
    private CompoundTag cachedNBT = null;
    public int count;
    protected int durability = 0;
    protected String name;
    private static ArrayList<Item> creative = new ArrayList();

    private static CompoundTag parseCompoundTag(byte[] tag) {
        try {
            return NBTIO.read(tag, ByteOrder.LITTLE_ENDIAN);
        }
        catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    private byte[] writeCompoundTag(CompoundTag tag) {
        try {
            return NBTIO.write(tag, ByteOrder.LITTLE_ENDIAN);
        }
        catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public Item(int id) {
        this(id, 0, 1, "Unknown");
    }

    public Item(int id, Integer meta) {
        this(id, meta, 1, "Unknown");
    }

    public Item(int id, Integer meta, int count) {
        this(id, meta, count, "Unknown");
    }

    public Item(int id, Integer meta, int count, String name) {
        this.id = id & 0xFFFF;
        if (meta != null) {
            this.meta = meta & 0xFFFF;
        } else {
            this.hasMeta = false;
        }
        this.count = count;
        this.name = name;
        if (this.block != null && this.id <= 255 && Block.list[id] != null) {
            this.block = Block.get(this.id, this.meta);
            this.name = this.block.getName();
        }
    }

    public boolean hasMeta() {
        return this.hasMeta;
    }

    public boolean canBeActivated() {
        return false;
    }

    public static void init() {
        if (list == null) {
            list = new Class[65535];
            Item.list[256] = ItemShovelIron.class;
            Item.list[257] = ItemPickaxeIron.class;
            Item.list[258] = ItemAxeIron.class;
            Item.list[259] = ItemFlintSteel.class;
            Item.list[260] = ItemApple.class;
            Item.list[261] = ItemBow.class;
            Item.list[262] = ItemArrow.class;
            Item.list[263] = ItemCoal.class;
            Item.list[264] = ItemDiamond.class;
            Item.list[265] = ItemIngotIron.class;
            Item.list[266] = ItemIngotGold.class;
            Item.list[267] = ItemSwordIron.class;
            Item.list[268] = ItemSwordWood.class;
            Item.list[269] = ItemShovelWood.class;
            Item.list[270] = ItemPickaxeWood.class;
            Item.list[271] = ItemAxeWood.class;
            Item.list[272] = ItemSwordStone.class;
            Item.list[273] = ItemShovelStone.class;
            Item.list[274] = ItemPickaxeStone.class;
            Item.list[275] = ItemAxeStone.class;
            Item.list[276] = ItemSwordDiamond.class;
            Item.list[277] = ItemShovelDiamond.class;
            Item.list[278] = ItemPickaxeDiamond.class;
            Item.list[279] = ItemAxeDiamond.class;
            Item.list[280] = ItemStick.class;
            Item.list[281] = ItemBowl.class;
            Item.list[282] = ItemMushroomStew.class;
            Item.list[283] = ItemSwordGold.class;
            Item.list[284] = ItemShovelGold.class;
            Item.list[285] = ItemPickaxeGold.class;
            Item.list[286] = ItemAxeGold.class;
            Item.list[287] = ItemString.class;
            Item.list[288] = ItemFeather.class;
            Item.list[289] = ItemGunpowder.class;
            Item.list[290] = ItemHoeWood.class;
            Item.list[291] = ItemHoeStone.class;
            Item.list[292] = ItemHoeIron.class;
            Item.list[293] = ItemHoeDiamond.class;
            Item.list[294] = ItemHoeGold.class;
            Item.list[295] = ItemSeedsWheat.class;
            Item.list[296] = ItemWheat.class;
            Item.list[297] = ItemBread.class;
            Item.list[298] = ItemHelmetLeather.class;
            Item.list[299] = ItemChestplateLeather.class;
            Item.list[300] = ItemLeggingsLeather.class;
            Item.list[301] = ItemBootsLeather.class;
            Item.list[302] = ItemHelmetChain.class;
            Item.list[303] = ItemChestplateChain.class;
            Item.list[304] = ItemLeggingsChain.class;
            Item.list[305] = ItemBootsChain.class;
            Item.list[306] = ItemHelmetIron.class;
            Item.list[307] = ItemChestplateIron.class;
            Item.list[308] = ItemLeggingsIron.class;
            Item.list[309] = ItemBootsIron.class;
            Item.list[310] = ItemHelmetDiamond.class;
            Item.list[311] = ItemChestplateDiamond.class;
            Item.list[312] = ItemLeggingsDiamond.class;
            Item.list[313] = ItemBootsDiamond.class;
            Item.list[314] = ItemHelmetGold.class;
            Item.list[315] = ItemChestplateGold.class;
            Item.list[316] = ItemLeggingsGold.class;
            Item.list[317] = ItemBootsGold.class;
            Item.list[318] = ItemFlint.class;
            Item.list[319] = ItemPorkchopRaw.class;
            Item.list[320] = ItemPorkchopCooked.class;
            Item.list[321] = ItemPainting.class;
            Item.list[322] = ItemAppleGold.class;
            Item.list[323] = ItemSign.class;
            Item.list[324] = ItemDoorWood.class;
            Item.list[325] = ItemBucket.class;
            Item.list[328] = ItemMinecart.class;
            Item.list[333] = ItemBoat.class;
            Item.list[330] = ItemDoorIron.class;
            Item.list[331] = ItemRedstone.class;
            Item.list[332] = ItemSnowball.class;
            Item.list[334] = ItemLeather.class;
            Item.list[336] = ItemBrick.class;
            Item.list[337] = ItemClay.class;
            Item.list[338] = ItemSugarcane.class;
            Item.list[339] = ItemPaper.class;
            Item.list[340] = ItemBook.class;
            Item.list[341] = ItemSlimeball.class;
            Item.list[344] = ItemEgg.class;
            Item.list[345] = ItemCompass.class;
            Item.list[346] = ItemFishingRod.class;
            Item.list[347] = ItemClock.class;
            Item.list[348] = ItemGlowstoneDust.class;
            Item.list[349] = ItemFish.class;
            Item.list[350] = ItemFishCooked.class;
            Item.list[351] = ItemDye.class;
            Item.list[352] = ItemBone.class;
            Item.list[353] = ItemSugar.class;
            Item.list[354] = ItemCake.class;
            Item.list[355] = ItemBed.class;
            Item.list[357] = ItemCookie.class;
            Item.list[359] = ItemShears.class;
            Item.list[360] = ItemMelon.class;
            Item.list[361] = ItemSeedsPumpkin.class;
            Item.list[362] = ItemSeedsMelon.class;
            Item.list[363] = ItemBeefRaw.class;
            Item.list[364] = ItemSteak.class;
            Item.list[365] = ItemChickenRaw.class;
            Item.list[366] = ItemChickenCooked.class;
            Item.list[371] = ItemNuggetGold.class;
            Item.list[383] = ItemSpawnEgg.class;
            Item.list[388] = ItemEmerald.class;
            Item.list[391] = ItemCarrot.class;
            Item.list[392] = ItemPotato.class;
            Item.list[393] = ItemPotatoBaked.class;
            Item.list[397] = ItemSkull.class;
            Item.list[400] = ItemPumpkinPie.class;
            Item.list[405] = ItemNetherBrick.class;
            Item.list[406] = ItemQuartz.class;
            Item.list[457] = ItemBeetroot.class;
            Item.list[458] = ItemSeedsBeetroot.class;
            Item.list[459] = ItemBeetrootSoup.class;
            Item.list[76] = BlockRedstoneTorch.class;
            Item.list[379] = ItemBrewingStand.class;
            Item.list[374] = ItemGlassBottle.class;
            Item.list[373] = ItemPotion.class;
            Item.list[438] = ItemPotionSplash.class;
            Item.list[384] = ItemExpBottle.class;
            Item.list[427] = ItemDoorSpruce.class;
            Item.list[428] = ItemDoorBirch.class;
            Item.list[429] = ItemDoorJungle.class;
            Item.list[430] = ItemDoorAcacia.class;
            Item.list[431] = ItemDoorDarkOak.class;
            Item.list[460] = ItemSalmon.class;
            Item.list[461] = ItemClownfish.class;
            Item.list[462] = ItemPufferfish.class;
            Item.list[463] = ItemSalmonCooked.class;
            Item.list[375] = ItemSpiderEye.class;
            Item.list[411] = ItemRabbitRaw.class;
            Item.list[412] = ItemRabbitCooked.class;
            Item.list[414] = ItemRabbitFoot.class;
            Item.list[466] = ItemAppleGoldEnchanted.class;
            Item.list[413] = ItemRabbitStew.class;
            Item.list[394] = ItemPotatoPoisonous.class;
            Item.list[367] = ItemRottenFlesh.class;
            Item.list[390] = ItemFlowerPot.class;
            for (int i = 0; i < 256; ++i) {
                if (Block.list[i] == null) continue;
                Item.list[i] = Block.list[i];
            }
        }
        Item.initCreativeItems();
    }

    private static void initCreativeItems() {
        Item.clearCreativeItems();
        Item.addCreativeItem(Item.get(4, 0));
        Item.addCreativeItem(Item.get(98, 0));
        Item.addCreativeItem(Item.get(98, 1));
        Item.addCreativeItem(Item.get(98, 2));
        Item.addCreativeItem(Item.get(98, 3));
        Item.addCreativeItem(Item.get(48, 0));
        Item.addCreativeItem(Item.get(5, 0));
        Item.addCreativeItem(Item.get(5, 1));
        Item.addCreativeItem(Item.get(5, 2));
        Item.addCreativeItem(Item.get(5, 3));
        Item.addCreativeItem(Item.get(5, 4));
        Item.addCreativeItem(Item.get(5, 5));
        Item.addCreativeItem(Item.get(45, 0));
        Item.addCreativeItem(Item.get(1, 0));
        Item.addCreativeItem(Item.get(1, 1));
        Item.addCreativeItem(Item.get(1, 2));
        Item.addCreativeItem(Item.get(1, 3));
        Item.addCreativeItem(Item.get(1, 4));
        Item.addCreativeItem(Item.get(1, 5));
        Item.addCreativeItem(Item.get(1, 6));
        Item.addCreativeItem(Item.get(3, 0));
        Item.addCreativeItem(Item.get(243, 0));
        Item.addCreativeItem(Item.get(2, 0));
        Item.addCreativeItem(Item.get(110, 0));
        Item.addCreativeItem(Item.get(82, 0));
        Item.addCreativeItem(Item.get(172, 0));
        Item.addCreativeItem(Item.get(159, 0));
        Item.addCreativeItem(Item.get(159, 1));
        Item.addCreativeItem(Item.get(159, 2));
        Item.addCreativeItem(Item.get(159, 3));
        Item.addCreativeItem(Item.get(159, 4));
        Item.addCreativeItem(Item.get(159, 5));
        Item.addCreativeItem(Item.get(159, 6));
        Item.addCreativeItem(Item.get(159, 7));
        Item.addCreativeItem(Item.get(159, 8));
        Item.addCreativeItem(Item.get(159, 9));
        Item.addCreativeItem(Item.get(159, 10));
        Item.addCreativeItem(Item.get(159, 11));
        Item.addCreativeItem(Item.get(159, 12));
        Item.addCreativeItem(Item.get(159, 13));
        Item.addCreativeItem(Item.get(159, 14));
        Item.addCreativeItem(Item.get(159, 15));
        Item.addCreativeItem(Item.get(24, 0));
        Item.addCreativeItem(Item.get(24, 1));
        Item.addCreativeItem(Item.get(24, 2));
        Item.addCreativeItem(Item.get(12, 0));
        Item.addCreativeItem(Item.get(12, 1));
        Item.addCreativeItem(Item.get(13, 0));
        Item.addCreativeItem(Item.get(17, 0));
        Item.addCreativeItem(Item.get(17, 1));
        Item.addCreativeItem(Item.get(17, 2));
        Item.addCreativeItem(Item.get(17, 3));
        Item.addCreativeItem(Item.get(162, 0));
        Item.addCreativeItem(Item.get(162, 1));
        Item.addCreativeItem(Item.get(112, 0));
        Item.addCreativeItem(Item.get(87, 0));
        Item.addCreativeItem(Item.get(88, 0));
        Item.addCreativeItem(Item.get(7, 0));
        Item.addCreativeItem(Item.get(67, 0));
        Item.addCreativeItem(Item.get(53, 0));
        Item.addCreativeItem(Item.get(134, 0));
        Item.addCreativeItem(Item.get(135, 0));
        Item.addCreativeItem(Item.get(136, 0));
        Item.addCreativeItem(Item.get(163, 0));
        Item.addCreativeItem(Item.get(164, 0));
        Item.addCreativeItem(Item.get(108, 0));
        Item.addCreativeItem(Item.get(128, 0));
        Item.addCreativeItem(Item.get(109, 0));
        Item.addCreativeItem(Item.get(114, 0));
        Item.addCreativeItem(Item.get(156, 0));
        Item.addCreativeItem(Item.get(44, 0));
        Item.addCreativeItem(Item.get(44, 3));
        Item.addCreativeItem(Item.get(158, 0));
        Item.addCreativeItem(Item.get(158, 1));
        Item.addCreativeItem(Item.get(158, 2));
        Item.addCreativeItem(Item.get(158, 3));
        Item.addCreativeItem(Item.get(158, 4));
        Item.addCreativeItem(Item.get(158, 5));
        Item.addCreativeItem(Item.get(44, 4));
        Item.addCreativeItem(Item.get(44, 1));
        Item.addCreativeItem(Item.get(44, 5));
        Item.addCreativeItem(Item.get(44, 6));
        Item.addCreativeItem(Item.get(44, 7));
        Item.addCreativeItem(Item.get(155, 0));
        Item.addCreativeItem(Item.get(155, 2));
        Item.addCreativeItem(Item.get(155, 1));
        Item.addCreativeItem(Item.get(16, 0));
        Item.addCreativeItem(Item.get(15, 0));
        Item.addCreativeItem(Item.get(14, 0));
        Item.addCreativeItem(Item.get(56, 0));
        Item.addCreativeItem(Item.get(21, 0));
        Item.addCreativeItem(Item.get(73, 0));
        Item.addCreativeItem(Item.get(129, 0));
        Item.addCreativeItem(Item.get(153, 0));
        Item.addCreativeItem(Item.get(49, 0));
        Item.addCreativeItem(Item.get(79, 0));
        Item.addCreativeItem(Item.get(174, 0));
        Item.addCreativeItem(Item.get(80, 0));
        Item.addCreativeItem(Item.get(121, 0));
        Item.addCreativeItem(Item.get(139, 0));
        Item.addCreativeItem(Item.get(139, 1));
        Item.addCreativeItem(Item.get(111, 0));
        Item.addCreativeItem(Item.get(41, 0));
        Item.addCreativeItem(Item.get(42, 0));
        Item.addCreativeItem(Item.get(57, 0));
        Item.addCreativeItem(Item.get(22, 0));
        Item.addCreativeItem(Item.get(173, 0));
        Item.addCreativeItem(Item.get(133, 0));
        Item.addCreativeItem(Item.get(152, 0));
        Item.addCreativeItem(Item.get(78, 0));
        Item.addCreativeItem(Item.get(20, 0));
        Item.addCreativeItem(Item.get(89, 0));
        Item.addCreativeItem(Item.get(106, 0));
        Item.addCreativeItem(Item.get(65, 0));
        Item.addCreativeItem(Item.get(19, 0));
        Item.addCreativeItem(Item.get(102, 0));
        Item.addCreativeItem(Item.get(324, 0));
        Item.addCreativeItem(Item.get(427, 0));
        Item.addCreativeItem(Item.get(428, 0));
        Item.addCreativeItem(Item.get(429, 0));
        Item.addCreativeItem(Item.get(430, 0));
        Item.addCreativeItem(Item.get(431, 0));
        Item.addCreativeItem(Item.get(330, 0));
        Item.addCreativeItem(Item.get(96, 0));
        Item.addCreativeItem(Item.get(167, 0));
        Item.addCreativeItem(Item.get(85, 0));
        Item.addCreativeItem(Item.get(85, 1));
        Item.addCreativeItem(Item.get(85, 2));
        Item.addCreativeItem(Item.get(85, 3));
        Item.addCreativeItem(Item.get(85, 4));
        Item.addCreativeItem(Item.get(85, 5));
        Item.addCreativeItem(Item.get(113, 0));
        Item.addCreativeItem(Item.get(107, 0));
        Item.addCreativeItem(Item.get(183, 0));
        Item.addCreativeItem(Item.get(184, 0));
        Item.addCreativeItem(Item.get(185, 0));
        Item.addCreativeItem(Item.get(187, 0));
        Item.addCreativeItem(Item.get(186, 0));
        Item.addCreativeItem(Item.get(101, 0));
        Item.addCreativeItem(Item.get(355, 0));
        Item.addCreativeItem(Item.get(47, 0));
        Item.addCreativeItem(Item.get(323, 0));
        Item.addCreativeItem(Item.get(321, 0));
        Item.addCreativeItem(Item.get(389, 0));
        Item.addCreativeItem(Item.get(58, 0));
        Item.addCreativeItem(Item.get(245, 0));
        Item.addCreativeItem(Item.get(54, 0));
        Item.addCreativeItem(Item.get(146, 0));
        Item.addCreativeItem(Item.get(61, 0));
        Item.addCreativeItem(Item.get(379, 0));
        Item.addCreativeItem(Item.get(380, 0));
        Item.addCreativeItem(Item.get(25, 0));
        Item.addCreativeItem(Item.get(120, 0));
        Item.addCreativeItem(Item.get(145, 0));
        Item.addCreativeItem(Item.get(145, 4));
        Item.addCreativeItem(Item.get(145, 8));
        Item.addCreativeItem(Item.get(37, 0));
        Item.addCreativeItem(Item.get(38, 0));
        Item.addCreativeItem(Item.get(38, 1));
        Item.addCreativeItem(Item.get(38, 2));
        Item.addCreativeItem(Item.get(38, 3));
        Item.addCreativeItem(Item.get(38, 4));
        Item.addCreativeItem(Item.get(38, 5));
        Item.addCreativeItem(Item.get(38, 6));
        Item.addCreativeItem(Item.get(38, 7));
        Item.addCreativeItem(Item.get(38, 8));
        Item.addCreativeItem(Item.get(175, 0));
        Item.addCreativeItem(Item.get(175, 1));
        Item.addCreativeItem(Item.get(175, 2));
        Item.addCreativeItem(Item.get(175, 3));
        Item.addCreativeItem(Item.get(175, 4));
        Item.addCreativeItem(Item.get(175, 5));
        Item.addCreativeItem(Item.get(39, 0));
        Item.addCreativeItem(Item.get(40, 0));
        Item.addCreativeItem(Item.get(99, 14));
        Item.addCreativeItem(Item.get(100, 14));
        Item.addCreativeItem(Item.get(99, 0));
        Item.addCreativeItem(Item.get(100, 15));
        Item.addCreativeItem(Item.get(81, 0));
        Item.addCreativeItem(Item.get(103, 0));
        Item.addCreativeItem(Item.get(86, 0));
        Item.addCreativeItem(Item.get(91, 0));
        Item.addCreativeItem(Item.get(30, 0));
        Item.addCreativeItem(Item.get(170, 0));
        Item.addCreativeItem(Item.get(31, 1));
        Item.addCreativeItem(Item.get(31, 2));
        Item.addCreativeItem(Item.get(32, 0));
        Item.addCreativeItem(Item.get(6, 0));
        Item.addCreativeItem(Item.get(6, 1));
        Item.addCreativeItem(Item.get(6, 2));
        Item.addCreativeItem(Item.get(6, 3));
        Item.addCreativeItem(Item.get(6, 4));
        Item.addCreativeItem(Item.get(6, 5));
        Item.addCreativeItem(Item.get(18, 0));
        Item.addCreativeItem(Item.get(18, 1));
        Item.addCreativeItem(Item.get(18, 2));
        Item.addCreativeItem(Item.get(18, 3));
        Item.addCreativeItem(Item.get(161, 0));
        Item.addCreativeItem(Item.get(161, 1));
        Item.addCreativeItem(Item.get(354, 0));
        Item.addCreativeItem(Item.get(397, 0));
        Item.addCreativeItem(Item.get(397, 1));
        Item.addCreativeItem(Item.get(397, 2));
        Item.addCreativeItem(Item.get(397, 3));
        Item.addCreativeItem(Item.get(397, 4));
        Item.addCreativeItem(Item.get(52, 0));
        Item.addCreativeItem(Item.get(390, 0));
        Item.addCreativeItem(Item.get(116, 0));
        Item.addCreativeItem(Item.get(165, 0));
        Item.addCreativeItem(Item.get(35, 0));
        Item.addCreativeItem(Item.get(35, 8));
        Item.addCreativeItem(Item.get(35, 7));
        Item.addCreativeItem(Item.get(35, 15));
        Item.addCreativeItem(Item.get(35, 12));
        Item.addCreativeItem(Item.get(35, 14));
        Item.addCreativeItem(Item.get(35, 1));
        Item.addCreativeItem(Item.get(35, 4));
        Item.addCreativeItem(Item.get(35, 5));
        Item.addCreativeItem(Item.get(35, 13));
        Item.addCreativeItem(Item.get(35, 9));
        Item.addCreativeItem(Item.get(35, 3));
        Item.addCreativeItem(Item.get(35, 11));
        Item.addCreativeItem(Item.get(35, 10));
        Item.addCreativeItem(Item.get(35, 2));
        Item.addCreativeItem(Item.get(35, 6));
        Item.addCreativeItem(Item.get(171, 0));
        Item.addCreativeItem(Item.get(171, 8));
        Item.addCreativeItem(Item.get(171, 7));
        Item.addCreativeItem(Item.get(171, 15));
        Item.addCreativeItem(Item.get(171, 12));
        Item.addCreativeItem(Item.get(171, 14));
        Item.addCreativeItem(Item.get(171, 1));
        Item.addCreativeItem(Item.get(171, 4));
        Item.addCreativeItem(Item.get(171, 5));
        Item.addCreativeItem(Item.get(171, 13));
        Item.addCreativeItem(Item.get(171, 9));
        Item.addCreativeItem(Item.get(171, 3));
        Item.addCreativeItem(Item.get(171, 11));
        Item.addCreativeItem(Item.get(171, 10));
        Item.addCreativeItem(Item.get(171, 2));
        Item.addCreativeItem(Item.get(171, 6));
        Item.addCreativeItem(Item.get(66, 0));
        Item.addCreativeItem(Item.get(27, 0));
        Item.addCreativeItem(Item.get(28, 0));
        Item.addCreativeItem(Item.get(126, 0));
        Item.addCreativeItem(Item.get(50, 0));
        Item.addCreativeItem(Item.get(325, 0));
        Item.addCreativeItem(Item.get(325, 1));
        Item.addCreativeItem(Item.get(325, 8));
        Item.addCreativeItem(Item.get(325, 10));
        Item.addCreativeItem(Item.get(46, 0));
        Item.addCreativeItem(Item.get(331, 0));
        Item.addCreativeItem(Item.get(261, 0));
        Item.addCreativeItem(Item.get(346, 0));
        Item.addCreativeItem(Item.get(259, 0));
        Item.addCreativeItem(Item.get(359, 0));
        Item.addCreativeItem(Item.get(347, 0));
        Item.addCreativeItem(Item.get(345, 0));
        Item.addCreativeItem(Item.get(328, 0));
        Item.addCreativeItem(Item.get(342, 0));
        Item.addCreativeItem(Item.get(408, 0));
        Item.addCreativeItem(Item.get(407, 0));
        Item.addCreativeItem(Item.get(333, 0));
        Item.addCreativeItem(Item.get(333, 1));
        Item.addCreativeItem(Item.get(333, 2));
        Item.addCreativeItem(Item.get(333, 3));
        Item.addCreativeItem(Item.get(333, 4));
        Item.addCreativeItem(Item.get(333, 5));
        Item.addCreativeItem(Item.get(383, 10));
        Item.addCreativeItem(Item.get(383, 11));
        Item.addCreativeItem(Item.get(383, 12));
        Item.addCreativeItem(Item.get(383, 13));
        Item.addCreativeItem(Item.get(383, 14));
        Item.addCreativeItem(Item.get(383, 18));
        Item.addCreativeItem(Item.get(383, 22));
        Item.addCreativeItem(Item.get(383, 33));
        Item.addCreativeItem(Item.get(268));
        Item.addCreativeItem(Item.get(290));
        Item.addCreativeItem(Item.get(269));
        Item.addCreativeItem(Item.get(270));
        Item.addCreativeItem(Item.get(271));
        Item.addCreativeItem(Item.get(272));
        Item.addCreativeItem(Item.get(291));
        Item.addCreativeItem(Item.get(273));
        Item.addCreativeItem(Item.get(274));
        Item.addCreativeItem(Item.get(275));
        Item.addCreativeItem(Item.get(267));
        Item.addCreativeItem(Item.get(292));
        Item.addCreativeItem(Item.get(256));
        Item.addCreativeItem(Item.get(257));
        Item.addCreativeItem(Item.get(258));
        Item.addCreativeItem(Item.get(276));
        Item.addCreativeItem(Item.get(293));
        Item.addCreativeItem(Item.get(277));
        Item.addCreativeItem(Item.get(278));
        Item.addCreativeItem(Item.get(279));
        Item.addCreativeItem(Item.get(283));
        Item.addCreativeItem(Item.get(294));
        Item.addCreativeItem(Item.get(284));
        Item.addCreativeItem(Item.get(285));
        Item.addCreativeItem(Item.get(286));
        Item.addCreativeItem(Item.get(298));
        Item.addCreativeItem(Item.get(299));
        Item.addCreativeItem(Item.get(300));
        Item.addCreativeItem(Item.get(301));
        Item.addCreativeItem(Item.get(302));
        Item.addCreativeItem(Item.get(303));
        Item.addCreativeItem(Item.get(304));
        Item.addCreativeItem(Item.get(305));
        Item.addCreativeItem(Item.get(306));
        Item.addCreativeItem(Item.get(307));
        Item.addCreativeItem(Item.get(308));
        Item.addCreativeItem(Item.get(309));
        Item.addCreativeItem(Item.get(310));
        Item.addCreativeItem(Item.get(311));
        Item.addCreativeItem(Item.get(312));
        Item.addCreativeItem(Item.get(313));
        Item.addCreativeItem(Item.get(314));
        Item.addCreativeItem(Item.get(315));
        Item.addCreativeItem(Item.get(316));
        Item.addCreativeItem(Item.get(317));
        Item.addCreativeItem(Item.get(69));
        Item.addCreativeItem(Item.get(123));
        Item.addCreativeItem(Item.get(76));
        Item.addCreativeItem(Item.get(72));
        Item.addCreativeItem(Item.get(70));
        Item.addCreativeItem(Item.get(147));
        Item.addCreativeItem(Item.get(148));
        Item.addCreativeItem(Item.get(143, 5));
        Item.addCreativeItem(Item.get(77, 5));
        Item.addCreativeItem(Item.get(151));
        Item.addCreativeItem(Item.get(131));
        Item.addCreativeItem(Item.get(356));
        Item.addCreativeItem(Item.get(404));
        Item.addCreativeItem(Item.get(23, 3));
        Item.addCreativeItem(Item.get(410));
        Item.addCreativeItem(Item.get(332));
        Item.addCreativeItem(Item.get(263, 0));
        Item.addCreativeItem(Item.get(263, 1));
        Item.addCreativeItem(Item.get(264, 0));
        Item.addCreativeItem(Item.get(265, 0));
        Item.addCreativeItem(Item.get(266, 0));
        Item.addCreativeItem(Item.get(388, 0));
        Item.addCreativeItem(Item.get(280, 0));
        Item.addCreativeItem(Item.get(281, 0));
        Item.addCreativeItem(Item.get(287, 0));
        Item.addCreativeItem(Item.get(288, 0));
        Item.addCreativeItem(Item.get(318, 0));
        Item.addCreativeItem(Item.get(334, 0));
        Item.addCreativeItem(Item.get(415, 0));
        Item.addCreativeItem(Item.get(337, 0));
        Item.addCreativeItem(Item.get(353, 0));
        Item.addCreativeItem(Item.get(406, 0));
        Item.addCreativeItem(Item.get(339, 0));
        Item.addCreativeItem(Item.get(340, 0));
        Item.addCreativeItem(Item.get(262, 0));
        Item.addCreativeItem(Item.get(352, 0));
        Item.addCreativeItem(Item.get(395, 0));
        Item.addCreativeItem(Item.get(338, 0));
        Item.addCreativeItem(Item.get(296, 0));
        Item.addCreativeItem(Item.get(295, 0));
        Item.addCreativeItem(Item.get(361, 0));
        Item.addCreativeItem(Item.get(362, 0));
        Item.addCreativeItem(Item.get(458, 0));
        Item.addCreativeItem(Item.get(344, 0));
        Item.addCreativeItem(Item.get(260, 0));
        Item.addCreativeItem(Item.get(322, 0));
        Item.addCreativeItem(Item.get(466, 0));
        Item.addCreativeItem(Item.get(349, 0));
        Item.addCreativeItem(Item.get(460, 0));
        Item.addCreativeItem(Item.get(461, 0));
        Item.addCreativeItem(Item.get(462, 0));
        Item.addCreativeItem(Item.get(350, 0));
        Item.addCreativeItem(Item.get(463, 0));
        Item.addCreativeItem(Item.get(367, 0));
        Item.addCreativeItem(Item.get(282, 0));
        Item.addCreativeItem(Item.get(297, 0));
        Item.addCreativeItem(Item.get(319, 0));
        Item.addCreativeItem(Item.get(320, 0));
        Item.addCreativeItem(Item.get(365, 0));
        Item.addCreativeItem(Item.get(366, 0));
        Item.addCreativeItem(Item.get(363, 0));
        Item.addCreativeItem(Item.get(364, 0));
        Item.addCreativeItem(Item.get(360, 0));
        Item.addCreativeItem(Item.get(391, 0));
        Item.addCreativeItem(Item.get(392, 0));
        Item.addCreativeItem(Item.get(393, 0));
        Item.addCreativeItem(Item.get(394, 0));
        Item.addCreativeItem(Item.get(457, 0));
        Item.addCreativeItem(Item.get(357, 0));
        Item.addCreativeItem(Item.get(400, 0));
        Item.addCreativeItem(Item.get(411, 0));
        Item.addCreativeItem(Item.get(412, 0));
        Item.addCreativeItem(Item.get(413, 0));
        Item.addCreativeItem(Item.get(378, 0));
        Item.addCreativeItem(Item.get(369, 0));
        Item.addCreativeItem(Item.get(371, 0));
        Item.addCreativeItem(Item.get(396, 0));
        Item.addCreativeItem(Item.get(382, 0));
        Item.addCreativeItem(Item.get(414, 0));
        Item.addCreativeItem(Item.get(370, 0));
        Item.addCreativeItem(Item.get(341, 0));
        Item.addCreativeItem(Item.get(377, 0));
        Item.addCreativeItem(Item.get(372, 0));
        Item.addCreativeItem(Item.get(289, 0));
        Item.addCreativeItem(Item.get(348, 0));
        Item.addCreativeItem(Item.get(375, 0));
        Item.addCreativeItem(Item.get(376, 0));
        Item.addCreativeItem(Item.get(384));
        Item.addCreativeItem(Item.get(351, 0));
        Item.addCreativeItem(Item.get(351, 8));
        Item.addCreativeItem(Item.get(351, 7));
        Item.addCreativeItem(Item.get(351, 15));
        Item.addCreativeItem(Item.get(351, 12));
        Item.addCreativeItem(Item.get(351, 14));
        Item.addCreativeItem(Item.get(351, 1));
        Item.addCreativeItem(Item.get(351, 4));
        Item.addCreativeItem(Item.get(351, 5));
        Item.addCreativeItem(Item.get(351, 13));
        Item.addCreativeItem(Item.get(351, 9));
        Item.addCreativeItem(Item.get(351, 3));
        Item.addCreativeItem(Item.get(351, 11));
        Item.addCreativeItem(Item.get(351, 10));
        Item.addCreativeItem(Item.get(351, 2));
        Item.addCreativeItem(Item.get(351, 6));
        Item.addCreativeItem(Item.get(374, 0));
        Item.addCreativeItem(Item.get(373, 0));
        Item.addCreativeItem(Item.get(373, 1));
        Item.addCreativeItem(Item.get(373, 2));
        Item.addCreativeItem(Item.get(373, 3));
        Item.addCreativeItem(Item.get(373, 4));
        Item.addCreativeItem(Item.get(373, 5));
        Item.addCreativeItem(Item.get(373, 6));
        Item.addCreativeItem(Item.get(373, 7));
        Item.addCreativeItem(Item.get(373, 8));
        Item.addCreativeItem(Item.get(373, 9));
        Item.addCreativeItem(Item.get(373, 10));
        Item.addCreativeItem(Item.get(373, 11));
        Item.addCreativeItem(Item.get(373, 12));
        Item.addCreativeItem(Item.get(373, 13));
        Item.addCreativeItem(Item.get(373, 14));
        Item.addCreativeItem(Item.get(373, 15));
        Item.addCreativeItem(Item.get(373, 16));
        Item.addCreativeItem(Item.get(373, 17));
        Item.addCreativeItem(Item.get(373, 18));
        Item.addCreativeItem(Item.get(373, 19));
        Item.addCreativeItem(Item.get(373, 20));
        Item.addCreativeItem(Item.get(373, 21));
        Item.addCreativeItem(Item.get(373, 22));
        Item.addCreativeItem(Item.get(373, 23));
        Item.addCreativeItem(Item.get(373, 24));
        Item.addCreativeItem(Item.get(373, 25));
        Item.addCreativeItem(Item.get(373, 26));
        Item.addCreativeItem(Item.get(373, 27));
        Item.addCreativeItem(Item.get(373, 28));
        Item.addCreativeItem(Item.get(373, 29));
        Item.addCreativeItem(Item.get(373, 30));
        Item.addCreativeItem(Item.get(373, 31));
        Item.addCreativeItem(Item.get(373, 32));
        Item.addCreativeItem(Item.get(373, 33));
        Item.addCreativeItem(Item.get(373, 34));
        Item.addCreativeItem(Item.get(373, 35));
        Item.addCreativeItem(Item.get(438, 0));
        Item.addCreativeItem(Item.get(438, 1));
        Item.addCreativeItem(Item.get(438, 2));
        Item.addCreativeItem(Item.get(438, 3));
        Item.addCreativeItem(Item.get(438, 4));
        Item.addCreativeItem(Item.get(438, 5));
        Item.addCreativeItem(Item.get(438, 6));
        Item.addCreativeItem(Item.get(438, 7));
        Item.addCreativeItem(Item.get(438, 8));
        Item.addCreativeItem(Item.get(438, 9));
        Item.addCreativeItem(Item.get(438, 10));
        Item.addCreativeItem(Item.get(438, 11));
        Item.addCreativeItem(Item.get(438, 12));
        Item.addCreativeItem(Item.get(438, 13));
        Item.addCreativeItem(Item.get(438, 14));
        Item.addCreativeItem(Item.get(438, 15));
        Item.addCreativeItem(Item.get(438, 16));
        Item.addCreativeItem(Item.get(438, 17));
        Item.addCreativeItem(Item.get(438, 18));
        Item.addCreativeItem(Item.get(438, 19));
        Item.addCreativeItem(Item.get(438, 20));
        Item.addCreativeItem(Item.get(438, 21));
        Item.addCreativeItem(Item.get(438, 22));
        Item.addCreativeItem(Item.get(438, 23));
        Item.addCreativeItem(Item.get(438, 24));
        Item.addCreativeItem(Item.get(438, 25));
        Item.addCreativeItem(Item.get(438, 26));
        Item.addCreativeItem(Item.get(438, 27));
        Item.addCreativeItem(Item.get(438, 28));
        Item.addCreativeItem(Item.get(438, 29));
        Item.addCreativeItem(Item.get(438, 30));
        Item.addCreativeItem(Item.get(438, 31));
        Item.addCreativeItem(Item.get(438, 32));
        Item.addCreativeItem(Item.get(438, 33));
        Item.addCreativeItem(Item.get(438, 34));
        Item.addCreativeItem(Item.get(438, 35));
    }

    public static void clearCreativeItems() {
        creative.clear();
    }

    public static ArrayList<Item> getCreativeItems() {
        return new ArrayList<Item>(creative);
    }

    public static void addCreativeItem(Item item) {
        creative.add(Item.get(item.getId(), item.hasMeta ? Integer.valueOf(item.getDamage()) : null));
    }

    public static void removeCreativeItem(Item item) {
        int index = Item.getCreativeItemIndex(item);
        if (index != -1) {
            creative.remove(index);
        }
    }

    public static boolean isCreativeItem(Item item) {
        for (Item aCreative : creative) {
            if (!item.equals(aCreative, !item.isTool())) continue;
            return true;
        }
        return false;
    }

    public static Item getCreativeItem(int index) {
        return index >= 0 && index < creative.size() ? creative.get(index) : null;
    }

    public static int getCreativeItemIndex(Item item) {
        for (int i = 0; i < creative.size(); ++i) {
            if (!item.equals(creative.get(i), !item.isTool())) continue;
            return i;
        }
        return -1;
    }

    public static Item get(int id) {
        return Item.get(id, 0);
    }

    public static Item get(int id, Integer meta) {
        return Item.get(id, meta, 1);
    }

    public static Item get(int id, Integer meta, int count) {
        return Item.get(id, meta, count, new byte[0]);
    }

    public static Item get(int id, Integer meta, int count, byte[] tags) {
        try {
            Class c = list[id];
            if (c == null) {
                return new Item(id, meta, count).setCompoundTag(tags);
            }
            if (id < 256) {
                return new ItemBlock((Block)c.getConstructor(Integer.TYPE).newInstance(meta), meta, count).setCompoundTag(tags);
            }
            return ((Item)c.getConstructor(Integer.class, Integer.TYPE).newInstance(meta, count)).setCompoundTag(tags);
        }
        catch (Exception e) {
            return new Item(id, meta, count).setCompoundTag(tags);
        }
    }

    public static Item fromString(String str) {
        String[] b = str.trim().replace(' ', '_').replace("minecraft:", "").split(":");
        int id = 0;
        int meta = 0;
        Pattern integerPattern = Pattern.compile("^[1-9]\\d*$");
        if (integerPattern.matcher(b[0]).matches()) {
            id = Integer.valueOf(b[0]);
        } else {
            try {
                id = Item.class.getField(b[0].toUpperCase()).getInt(null);
            }
            catch (Exception exception) {
                // empty catch block
            }
        }
        id &= 0xFFFF;
        if (b.length != 1) {
            meta = Integer.valueOf(b[1]) & 0xFFFF;
        }
        return Item.get(id, meta);
    }

    public static Item[] fromStringMultiple(String str) {
        String[] b = str.split(",");
        Item[] items = new Item[b.length - 1];
        for (int i = 0; i < b.length; ++i) {
            items[i] = Item.fromString(b[i]);
        }
        return items;
    }

    public Item setCompoundTag(CompoundTag tag) {
        this.setNamedTag(tag);
        return this;
    }

    public Item setCompoundTag(byte[] tags) {
        this.tags = tags;
        this.cachedNBT = null;
        return this;
    }

    public byte[] getCompoundTag() {
        return this.tags;
    }

    public boolean hasCompoundTag() {
        return this.tags != null && this.tags.length > 0;
    }

    public boolean hasCustomBlockData() {
        if (!this.hasCompoundTag()) {
            return false;
        }
        CompoundTag tag = this.getNamedTag();
        return tag.contains("BlockEntityTag") && tag.get("BlockEntityTag") instanceof CompoundTag;
    }

    public Item clearCustomBlockData() {
        if (!this.hasCompoundTag()) {
            return this;
        }
        CompoundTag tag = this.getNamedTag();
        if (tag.contains("BlockEntityTag") && tag.get("BlockEntityTag") instanceof CompoundTag) {
            tag.remove("BlockEntityTag");
            this.setNamedTag(tag);
        }
        return this;
    }

    public Item setCustomBlockData(CompoundTag compoundTag) {
        CompoundTag tags = compoundTag.copy();
        tags.setName("BlockEntityTag");
        CompoundTag tag = !this.hasCompoundTag() ? new CompoundTag() : this.getNamedTag();
        tag.putCompound("BlockEntityTag", tags);
        this.setNamedTag(tag);
        return this;
    }

    public CompoundTag getCustomBlockData() {
        Tag bet;
        if (!this.hasCompoundTag()) {
            return null;
        }
        CompoundTag tag = this.getNamedTag();
        if (tag.contains("BlockEntityTag") && (bet = tag.get("BlockEntityTag")) instanceof CompoundTag) {
            return (CompoundTag)bet;
        }
        return null;
    }

    public boolean hasEnchantments() {
        Tag enchTag;
        if (!this.hasCompoundTag()) {
            return false;
        }
        CompoundTag tag = this.getNamedTag();
        return tag.contains("ench") && (enchTag = tag.get("ench")) instanceof ListTag;
    }

    public Enchantment getEnchantment(int id) {
        return this.getEnchantment((short)(id & 0xFFFF));
    }

    public Enchantment getEnchantment(short id) {
        if (!this.hasEnchantments()) {
            return null;
        }
        for (CompoundTag entry : this.getNamedTag().getList("ench", CompoundTag.class).getAll()) {
            if (entry.getShort("id") != id) continue;
            Enchantment e = Enchantment.getEnchantment(entry.getShort("id"));
            e.setLevel(entry.getShort("lvl"));
            return e;
        }
        return null;
    }

    public void addEnchantment(Enchantment ... enchantments) {
        ListTag<Object> ench;
        CompoundTag tag = !this.hasCompoundTag() ? new CompoundTag() : this.getNamedTag();
        if (!tag.contains("ench")) {
            ench = new ListTag("ench");
            tag.putList(ench);
        }
        for (Enchantment enchantment : enchantments) {
            boolean found = false;
            ench = tag.getList("ench", CompoundTag.class);
            for (int k = 0; k < ench.size(); ++k) {
                CompoundTag entry = (CompoundTag)ench.get(k);
                if (entry.getShort("id") != enchantment.getId()) continue;
                ench.add(k, new CompoundTag().putShort("id", enchantment.getId()).putShort("lvl", enchantment.getLevel()));
                found = true;
                break;
            }
            if (found) continue;
            ench.add(new CompoundTag().putShort("id", enchantment.getId()).putShort("lvl", enchantment.getLevel()));
        }
        this.setNamedTag(tag);
    }

    public Enchantment[] getEnchantments() {
        if (!this.hasEnchantments()) {
            return new Enchantment[0];
        }
        ArrayList<Enchantment> enchantments = new ArrayList<Enchantment>();
        ListTag<CompoundTag> ench = this.getNamedTag().getList("ench", CompoundTag.class);
        for (CompoundTag entry : ench.getAll()) {
            Enchantment e = Enchantment.getEnchantment(entry.getShort("id"));
            e.setLevel(entry.getShort("lvl"));
            enchantments.add(e);
        }
        return (Enchantment[])enchantments.stream().toArray(Enchantment[]::new);
    }

    public boolean hasCustomName() {
        Tag tag1;
        if (!this.hasCompoundTag()) {
            return false;
        }
        CompoundTag tag = this.getNamedTag();
        return tag.contains("display") && (tag1 = tag.get("display")) instanceof CompoundTag && ((CompoundTag)tag1).contains("Name") && ((CompoundTag)tag1).get("Name") instanceof StringTag;
    }

    public String getCustomName() {
        Tag tag1;
        if (!this.hasCompoundTag()) {
            return "";
        }
        CompoundTag tag = this.getNamedTag();
        if (tag.contains("display") && (tag1 = tag.get("display")) instanceof CompoundTag && ((CompoundTag)tag1).contains("Name") && ((CompoundTag)tag1).get("Name") instanceof StringTag) {
            return ((CompoundTag)tag1).getString("Name");
        }
        return "";
    }

    public Item setCustomName(String name) {
        CompoundTag tag;
        if (name == null || name.equals("")) {
            this.clearCustomName();
        }
        if ((tag = !this.hasCompoundTag() ? new CompoundTag() : this.getNamedTag()).contains("display") && tag.get("display") instanceof CompoundTag) {
            tag.getCompound("display").putString("Name", name);
        } else {
            tag.putCompound("display", new CompoundTag("display").putString("Name", name));
        }
        this.setNamedTag(tag);
        return this;
    }

    public Item clearCustomName() {
        if (!this.hasCompoundTag()) {
            return this;
        }
        CompoundTag tag = this.getNamedTag();
        if (tag.contains("display") && tag.get("display") instanceof CompoundTag) {
            tag.getCompound("display").remove("Name");
            if (tag.getCompound("display").isEmpty()) {
                tag.remove("display");
            }
            this.setNamedTag(tag);
        }
        return this;
    }

    public Tag getNamedTagEntry(String name) {
        CompoundTag tag = this.getNamedTag();
        if (tag != null) {
            return tag.contains(name) ? tag.get(name) : null;
        }
        return null;
    }

    public CompoundTag getNamedTag() {
        if (!this.hasCompoundTag()) {
            return null;
        }
        if (this.cachedNBT != null) {
            return this.cachedNBT;
        }
        this.cachedNBT = Item.parseCompoundTag(this.tags);
        return this.cachedNBT;
    }

    public Item setNamedTag(CompoundTag tag) {
        if (tag.isEmpty()) {
            return this.clearNamedTag();
        }
        this.cachedNBT = tag;
        this.tags = this.writeCompoundTag(tag);
        return this;
    }

    public Item clearNamedTag() {
        return this.setCompoundTag(new byte[0]);
    }

    public int getCount() {
        return this.count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public final String getName() {
        return this.hasCustomName() ? this.getCustomName() : this.name;
    }

    public final boolean canBePlaced() {
        return this.block != null && this.block.canBePlaced();
    }

    public Block getBlock() {
        if (this.block != null) {
            return this.block.clone();
        }
        return new BlockAir();
    }

    public int getId() {
        return this.id;
    }

    public int getDamage() {
        return this.meta;
    }

    public void setDamage(Integer meta) {
        if (meta != null) {
            this.meta = meta & 0xFFFF;
        } else {
            this.hasMeta = false;
        }
    }

    public int getMaxStackSize() {
        return 64;
    }

    public final Short getFuelTime() {
        if (!Fuel.duration.containsKey(this.id)) {
            return null;
        }
        if (this.id != 325 || this.meta == 10) {
            return Fuel.duration.get(this.id);
        }
        return null;
    }

    public boolean useOn(Entity entity) {
        return false;
    }

    public boolean useOn(Block block) {
        return false;
    }

    public boolean isTool() {
        return false;
    }

    public int getMaxDurability() {
        return -1;
    }

    public int getTier() {
        return 0;
    }

    public boolean isPickaxe() {
        return false;
    }

    public boolean isAxe() {
        return false;
    }

    public boolean isSword() {
        return false;
    }

    public boolean isShovel() {
        return false;
    }

    public boolean isHoe() {
        return false;
    }

    public boolean isShears() {
        return false;
    }

    public boolean isArmor() {
        return false;
    }

    public boolean isHelmet() {
        return false;
    }

    public boolean isChestplate() {
        return false;
    }

    public boolean isLeggings() {
        return false;
    }

    public boolean isBoots() {
        return false;
    }

    public int getEnchantAbility() {
        return 0;
    }

    public final String toString() {
        return "Item " + this.name + " (" + this.id + ":" + (!this.hasMeta ? "?" : Integer.valueOf(this.meta)) + ")x" + this.count + (this.hasCompoundTag() ? " tags:0x" + Binary.bytesToHexString(this.getCompoundTag()) : "");
    }

    public int getDestroySpeed(Block block, Player player) {
        return 1;
    }

    public boolean onActivate(Level level, Player player, Block block, Block target, int face, double fx, double fy, double fz) {
        return false;
    }

    public final boolean equals(Object item) {
        return item instanceof Item && this.equals((Item)item, true);
    }

    public final boolean equals(Item item, boolean checkDamage) {
        return this.equals(item, checkDamage, true);
    }

    public final boolean equals(Item item, boolean checkDamage, boolean checkCompound) {
        return !(this.getId() != item.getId() || checkDamage && this.getDamage() != item.getDamage() || checkCompound && !Arrays.equals(this.getCompoundTag(), item.getCompoundTag()));
    }

    public final boolean deepEquals(Item item) {
        return this.deepEquals(item, true);
    }

    public final boolean deepEquals(Item item, boolean checkDamage) {
        return this.deepEquals(item, checkDamage, true);
    }

    public final boolean deepEquals(Item item, boolean checkDamage, boolean checkCompound) {
        if (this.equals(item, checkDamage, checkCompound)) {
            return true;
        }
        if (item.hasCompoundTag()) {
            return item.getNamedTag().equals(this.getNamedTag());
        }
        if (this.hasCompoundTag()) {
            return this.getNamedTag().equals(item.getNamedTag());
        }
        return false;
    }

    public Item clone() {
        try {
            Item item = (Item)super.clone();
            item.tags = (byte[])this.tags.clone();
            return item;
        }
        catch (CloneNotSupportedException e) {
            return null;
        }
    }
}

