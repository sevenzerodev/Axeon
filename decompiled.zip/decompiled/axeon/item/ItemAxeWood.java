/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.item;

import cn.axeon.item.ItemTool;

public class ItemAxeWood
extends ItemTool {
    public ItemAxeWood() {
        this((Integer)0, 1);
    }

    public ItemAxeWood(Integer meta) {
        this(meta, 1);
    }

    public ItemAxeWood(Integer meta, int count) {
        super(271, (int)meta, count, "Wooden Axe");
    }

    @Override
    public int getMaxDurability() {
        return 60;
    }

    @Override
    public boolean isAxe() {
        return true;
    }

    @Override
    public int getTier() {
        return 1;
    }
}

