/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.item;

import cn.axeon.item.ItemTool;

public class ItemAxeIron
extends ItemTool {
    public ItemAxeIron() {
        this((Integer)0, 1);
    }

    public ItemAxeIron(Integer meta) {
        this(meta, 1);
    }

    public ItemAxeIron(Integer meta, int count) {
        super(258, (int)meta, count, "Iron Axe");
    }

    @Override
    public int getMaxDurability() {
        return 251;
    }

    @Override
    public boolean isAxe() {
        return true;
    }

    @Override
    public int getTier() {
        return 4;
    }
}

