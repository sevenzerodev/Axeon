/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.item;

import cn.axeon.block.BlockDoorDarkOak;
import cn.axeon.item.Item;

public class ItemDoorDarkOak
extends Item {
    public ItemDoorDarkOak() {
        this((Integer)0, 1);
    }

    public ItemDoorDarkOak(Integer meta) {
        this(meta, 1);
    }

    public ItemDoorDarkOak(Integer meta, int count) {
        super(431, 0, count, "Dark Oak Door");
        this.block = new BlockDoorDarkOak();
    }
}

