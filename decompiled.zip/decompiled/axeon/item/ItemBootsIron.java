/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.item;

import cn.axeon.item.ItemArmor;

public class ItemBootsIron
extends ItemArmor {
    public ItemBootsIron() {
        this((Integer)0, 1);
    }

    public ItemBootsIron(Integer meta) {
        this(meta, 1);
    }

    public ItemBootsIron(Integer meta, int count) {
        super(309, (int)meta, count, "Iron Boots");
    }

    @Override
    public int getTier() {
        return 2;
    }

    @Override
    public boolean isBoots() {
        return true;
    }
}

