/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.item;

import cn.axeon.block.BlockCake;
import cn.axeon.item.Item;

public class ItemCake
extends Item {
    public ItemCake() {
        this((Integer)0, 1);
    }

    public ItemCake(Integer meta) {
        this(meta, 1);
    }

    public ItemCake(Integer meta, int count) {
        super(354, 0, count, "Cake");
        this.block = new BlockCake();
    }

    @Override
    public int getMaxStackSize() {
        return 1;
    }
}

