/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.item;

import cn.axeon.block.BlockCarrot;
import cn.axeon.item.ItemEdible;

public class ItemCarrot
extends ItemEdible {
    public ItemCarrot() {
        this((Integer)0, 1);
    }

    public ItemCarrot(Integer meta) {
        this(meta, 1);
    }

    public ItemCarrot(Integer meta, int count) {
        super(391, 0, count, "Carrot");
        this.block = new BlockCarrot();
    }
}

