/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.item;

import cn.axeon.item.ItemFish;

public class ItemClownfish
extends ItemFish {
    public ItemClownfish() {
        this((Integer)0, 1);
    }

    public ItemClownfish(Integer meta) {
        this(meta, 1);
    }

    public ItemClownfish(Integer meta, int count) {
        super(461, meta, count, "Clownfish");
    }
}

