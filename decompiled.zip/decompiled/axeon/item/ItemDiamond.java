/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.item;

import cn.axeon.item.Item;

public class ItemDiamond
extends Item {
    public ItemDiamond() {
        this((Integer)0, 1);
    }

    public ItemDiamond(Integer meta) {
        this(meta, 1);
    }

    public ItemDiamond(Integer meta, int count) {
        super(264, 0, count, "Diamond");
    }
}

