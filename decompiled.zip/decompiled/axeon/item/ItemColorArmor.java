/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.item;

import cn.axeon.item.ItemArmor;
import cn.axeon.nbt.tag.CompoundTag;
import cn.axeon.utils.BlockColor;

public abstract class ItemColorArmor
extends ItemArmor {
    public ItemColorArmor(int id) {
        super(id);
    }

    public ItemColorArmor(int id, Integer meta) {
        super(id, (int)meta);
    }

    public ItemColorArmor(int id, Integer meta, int count) {
        super(id, (int)meta, count);
    }

    public ItemColorArmor(int id, Integer meta, int count, String name) {
        super(id, (int)meta, count, name);
    }

    public ItemColorArmor setColor(int dyeColor) {
        BlockColor blockColor = BlockColor.getDyeColor(dyeColor);
        return this.setColor(blockColor.getRed(), blockColor.getGreen(), blockColor.getBlue());
    }

    public ItemColorArmor setColor(int r, int g, int b) {
        int rgb = r << 16 | g << 8 | b << 0;
        CompoundTag tag = this.hasCompoundTag() ? this.getNamedTag() : new CompoundTag();
        tag.putInt("customColor", rgb);
        this.setNamedTag(tag);
        return this;
    }

    public BlockColor getColor() {
        if (!this.hasCompoundTag()) {
            return null;
        }
        CompoundTag tag = this.getNamedTag();
        if (!tag.exist("customColor")) {
            return null;
        }
        int rgb = tag.getInt("customColor");
        return new BlockColor(rgb);
    }
}

