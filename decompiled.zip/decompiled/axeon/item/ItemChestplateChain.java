/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.item;

import cn.axeon.item.ItemArmor;

public class ItemChestplateChain
extends ItemArmor {
    public ItemChestplateChain() {
        this((Integer)0, 1);
    }

    public ItemChestplateChain(Integer meta) {
        this(meta, 1);
    }

    public ItemChestplateChain(Integer meta, int count) {
        super(303, (int)meta, count, "Chain Chestplate");
    }

    @Override
    public int getTier() {
        return 3;
    }

    @Override
    public boolean isChestplate() {
        return true;
    }
}

