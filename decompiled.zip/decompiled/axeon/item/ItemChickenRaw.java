/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.item;

import cn.axeon.item.ItemEdible;

public class ItemChickenRaw
extends ItemEdible {
    public ItemChickenRaw() {
        this((Integer)0, 1);
    }

    public ItemChickenRaw(Integer meta) {
        this(meta, 1);
    }

    public ItemChickenRaw(Integer meta, int count) {
        super(365, meta, count, "Raw Chicken");
    }
}

