/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.item;

import cn.axeon.item.Item;

public abstract class ItemArmor
extends Item {
    public static final int TIER_LEATHER = 1;
    public static final int TIER_IRON = 2;
    public static final int TIER_CHAIN = 3;
    public static final int TIER_GOLD = 4;
    public static final int TIER_DIAMOND = 5;

    public ItemArmor(int id) {
        super(id);
    }

    public ItemArmor(int id, int meta) {
        super(id, meta);
    }

    public ItemArmor(int id, int meta, int count) {
        super(id, meta, count);
    }

    public ItemArmor(int id, int meta, int count, String name) {
        super(id, meta, count, name);
    }

    @Override
    public int getMaxStackSize() {
        return 1;
    }

    @Override
    public boolean isArmor() {
        return true;
    }

    @Override
    public int getEnchantAbility() {
        switch (this.getTier()) {
            case 3: {
                return 12;
            }
            case 1: {
                return 15;
            }
            case 5: {
                return 10;
            }
            case 4: {
                return 25;
            }
            case 2: {
                return 9;
            }
        }
        return 0;
    }
}

