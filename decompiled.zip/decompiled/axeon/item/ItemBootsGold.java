/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.item;

import cn.axeon.item.ItemArmor;

public class ItemBootsGold
extends ItemArmor {
    public ItemBootsGold() {
        this((Integer)0, 1);
    }

    public ItemBootsGold(Integer meta) {
        this(meta, 1);
    }

    public ItemBootsGold(Integer meta, int count) {
        super(317, (int)meta, count, "Gold Boots");
    }

    @Override
    public int getTier() {
        return 4;
    }

    @Override
    public boolean isBoots() {
        return true;
    }
}

