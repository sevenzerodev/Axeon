/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.item;

import cn.axeon.item.ItemEdible;

public class ItemChickenCooked
extends ItemEdible {
    public ItemChickenCooked() {
        this((Integer)0, 1);
    }

    public ItemChickenCooked(Integer meta) {
        this(meta, 1);
    }

    public ItemChickenCooked(Integer meta, int count) {
        super(366, meta, count, "Cooked Chicken");
    }
}

