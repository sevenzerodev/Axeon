/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.item;

import cn.axeon.item.ItemArmor;

public class ItemChestplateGold
extends ItemArmor {
    public ItemChestplateGold() {
        this((Integer)0, 1);
    }

    public ItemChestplateGold(Integer meta) {
        this(meta, 1);
    }

    public ItemChestplateGold(Integer meta, int count) {
        super(315, (int)meta, count, "Gold Chestplate");
    }

    @Override
    public int getTier() {
        return 4;
    }

    @Override
    public boolean isChestplate() {
        return true;
    }
}

