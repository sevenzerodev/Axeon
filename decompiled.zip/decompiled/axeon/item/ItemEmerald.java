/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.item;

import cn.axeon.item.Item;

public class ItemEmerald
extends Item {
    public ItemEmerald() {
        this((Integer)0, 1);
    }

    public ItemEmerald(Integer meta) {
        this(meta, 1);
    }

    public ItemEmerald(Integer meta, int count) {
        super(388, meta, count, "Emerald");
    }
}

