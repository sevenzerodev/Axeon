/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.item;

import cn.axeon.item.ItemColorArmor;

public class ItemBootsLeather
extends ItemColorArmor {
    public ItemBootsLeather() {
        this((Integer)0, 1);
    }

    public ItemBootsLeather(Integer meta) {
        this(meta, 1);
    }

    public ItemBootsLeather(Integer meta, int count) {
        super(301, meta, count, "Leather Boots");
    }

    @Override
    public int getTier() {
        return 1;
    }

    @Override
    public boolean isBoots() {
        return true;
    }
}

