/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.item;

import cn.axeon.item.Item;

public class ItemBookEnchanted
extends Item {
    public ItemBookEnchanted() {
        this((Integer)0, 1);
    }

    public ItemBookEnchanted(Integer meta) {
        this(meta, 1);
    }

    public ItemBookEnchanted(Integer meta, int count) {
        super(403, meta, count, "Enchanted Book");
    }
}

