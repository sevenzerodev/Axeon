/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.item;

import cn.axeon.item.Item;

public class ItemBowl
extends Item {
    public ItemBowl() {
        this((Integer)0, 1);
    }

    public ItemBowl(Integer meta) {
        this(meta, 1);
    }

    public ItemBowl(Integer meta, int count) {
        super(281, 0, count, "Bowl");
    }
}

