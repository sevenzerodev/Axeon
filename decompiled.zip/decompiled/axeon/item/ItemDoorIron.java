/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.item;

import cn.axeon.block.BlockDoorIron;
import cn.axeon.item.Item;

public class ItemDoorIron
extends Item {
    public ItemDoorIron() {
        this((Integer)0, 1);
    }

    public ItemDoorIron(Integer meta) {
        this(meta, 1);
    }

    public ItemDoorIron(Integer meta, int count) {
        super(330, 0, count, "Iron Door");
        this.block = new BlockDoorIron();
    }
}

