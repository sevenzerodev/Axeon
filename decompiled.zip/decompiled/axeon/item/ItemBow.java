/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.item;

import cn.axeon.item.ItemTool;

public class ItemBow
extends ItemTool {
    public ItemBow() {
        this((Integer)0, 1);
    }

    public ItemBow(Integer meta) {
        this(meta, 1);
    }

    public ItemBow(Integer meta, int count) {
        super(261, (int)meta, count, "Bow");
    }

    @Override
    public int getMaxDurability() {
        return 385;
    }

    @Override
    public int getEnchantAbility() {
        return 1;
    }
}

