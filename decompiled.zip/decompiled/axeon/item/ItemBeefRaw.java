/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.item;

import cn.axeon.item.ItemEdible;

public class ItemBeefRaw
extends ItemEdible {
    public ItemBeefRaw() {
        this((Integer)0, 1);
    }

    public ItemBeefRaw(Integer meta) {
        this(meta, 1);
    }

    public ItemBeefRaw(Integer meta, int count) {
        super(363, meta, count, "Raw Beef");
    }
}

