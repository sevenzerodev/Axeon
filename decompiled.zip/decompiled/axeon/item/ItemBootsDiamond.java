/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.item;

import cn.axeon.item.ItemArmor;

public class ItemBootsDiamond
extends ItemArmor {
    public ItemBootsDiamond() {
        this((Integer)0, 1);
    }

    public ItemBootsDiamond(Integer meta) {
        this(meta, 1);
    }

    public ItemBootsDiamond(Integer meta, int count) {
        super(313, (int)meta, count, "Diamond Boots");
    }

    @Override
    public int getTier() {
        return 5;
    }

    @Override
    public boolean isBoots() {
        return true;
    }
}

