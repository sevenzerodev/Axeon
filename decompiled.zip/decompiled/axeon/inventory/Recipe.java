/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.inventory;

import cn.axeon.item.Item;
import java.util.UUID;

public interface Recipe {
    public Item getResult();

    public void registerToCraftingManager();

    public UUID getId();

    public void setId(UUID var1);
}

