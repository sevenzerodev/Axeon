/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.inventory;

import cn.axeon.Player;
import cn.axeon.Server;
import cn.axeon.inventory.ContainerInventory;
import cn.axeon.inventory.FakeBlockMenu;
import cn.axeon.inventory.InventoryType;
import cn.axeon.item.Item;
import cn.axeon.item.ItemBookEnchanted;
import cn.axeon.item.enchantment.Enchantment;
import cn.axeon.item.enchantment.EnchantmentEntry;
import cn.axeon.item.enchantment.EnchantmentList;
import cn.axeon.level.Position;
import cn.axeon.math.NukkitRandom;
import cn.axeon.network.protocol.CraftingDataPacket;
import cn.axeon.network.protocol.DataPacket;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

public class EnchantInventory
extends ContainerInventory {
    private final Random random = new Random();
    private int bookshelfAmount = 0;
    private int[] levels = null;
    private EnchantmentEntry[] entries = null;

    public EnchantInventory(Position position) {
        super(null, InventoryType.get(9));
        this.holder = new FakeBlockMenu(this, position);
    }

    @Override
    public FakeBlockMenu getHolder() {
        return (FakeBlockMenu)this.holder;
    }

    @Override
    public void onOpen(Player who) {
        super.onOpen(who);
        if (this.levels == null) {
            this.levels = new int[3];
            this.bookshelfAmount = this.countBookshelf();
            if (this.bookshelfAmount < 0) {
                this.bookshelfAmount = 0;
            }
            if (this.bookshelfAmount > 15) {
                this.bookshelfAmount = 15;
            }
            NukkitRandom random = new NukkitRandom();
            double base = (double)random.nextRange(1, 8) + (double)this.bookshelfAmount / 2.0 + (double)random.nextRange(0, this.bookshelfAmount);
            this.levels[0] = (int)Math.max(base / 3.0, 1.0);
            this.levels[1] = (int)(base * 2.0 / 3.0 + 1.0);
            this.levels[2] = (int)Math.max(base, (double)(this.bookshelfAmount * 2));
        }
    }

    @Override
    public void onSlotChange(int index, Item before) {
        super.onSlotChange(index, before);
        if (index == 0) {
            Item item = this.getItem(0);
            if (item.getId() == 0) {
                this.entries = null;
            } else if (before.getId() == 0 && !item.hasEnchantments()) {
                if (this.entries == null) {
                    int enchantAbility = item.getEnchantAbility();
                    this.entries = new EnchantmentEntry[3];
                    for (int i = 0; i < 3; ++i) {
                        int key;
                        int level;
                        ArrayList<Enchantment> result = new ArrayList<Enchantment>();
                        int k = level = this.levels[i];
                        k += ThreadLocalRandom.current().nextInt(0, Math.round((float)enchantAbility / 2.0f));
                        k += ThreadLocalRandom.current().nextInt(0, Math.round((float)enchantAbility / 2.0f));
                        float bonus = (ThreadLocalRandom.current().nextFloat() + ThreadLocalRandom.current().nextFloat() - 1.0f) * 0.15f + 1.0f;
                        int modifiedLevel = (int)((float)(++k) * (1.0f + bonus) + 0.5f);
                        ArrayList<Enchantment> possible = new ArrayList<Enchantment>();
                        for (Enchantment enchantment : Enchantment.getEnchantments()) {
                            if (!enchantment.canEnchant(item)) continue;
                            for (int enchLevel = enchantment.getMinLevel(); enchLevel < enchantment.getMaxLevel(); ++enchLevel) {
                                if (modifiedLevel < enchantment.getMinEnchantAbility(enchLevel) || modifiedLevel > enchantment.getMaxEnchantAbility(enchLevel)) continue;
                                enchantment.setLevel(enchLevel);
                                possible.add(enchantment);
                            }
                        }
                        int[] weights = new int[possible.size()];
                        int total = 0;
                        for (int j = 0; j < weights.length; ++j) {
                            int weight;
                            weights[j] = weight = ((Enchantment)possible.get(j)).getWeight();
                            total += weight;
                        }
                        int v = ThreadLocalRandom.current().nextInt(total + 1);
                        int sum = 0;
                        for (key = 0; key < weights.length; ++key) {
                            if ((sum += weights[key]) < v) continue;
                            ++key;
                            break;
                        }
                        Enchantment enchantment = (Enchantment)possible.get(--key);
                        result.add(enchantment);
                        possible.remove(key);
                        while (!possible.isEmpty()) {
                            modifiedLevel = Math.round((float)modifiedLevel / 2.0f);
                            v = ThreadLocalRandom.current().nextInt(0, 51);
                            if (v > modifiedLevel + 1) break;
                            for (Enchantment e : new ArrayList(possible)) {
                                if (e.isCompatibleWith(enchantment)) continue;
                                possible.remove(e);
                            }
                            weights = new int[possible.size()];
                            total = 0;
                            for (int j = 0; j < weights.length; ++j) {
                                int weight;
                                weights[j] = weight = ((Enchantment)possible.get(j)).getWeight();
                                total += weight;
                            }
                            v = ThreadLocalRandom.current().nextInt(total + 1);
                            sum = 0;
                            for (key = 0; key < weights.length; ++key) {
                                if ((sum += weights[key]) < v) continue;
                                ++key;
                                break;
                            }
                            enchantment = (Enchantment)possible.get(--key);
                            result.add(enchantment);
                            possible.remove(key);
                        }
                        this.entries[i] = new EnchantmentEntry((Enchantment[])result.stream().toArray(Enchantment[]::new), level, Enchantment.getRandomName());
                    }
                }
                this.sendEnchantmentList();
            }
        }
    }

    @Override
    public void onClose(Player who) {
        super.onClose(who);
        for (int i = 0; i < 2; ++i) {
            this.getHolder().getLevel().dropItem(this.getHolder().add(0.5, 0.5, 0.5), this.getItem(i));
            this.clear(i);
        }
        if (this.getViewers().size() == 0) {
            this.levels = null;
            this.entries = null;
            this.bookshelfAmount = 0;
        }
    }

    public void onEnchant(Player who, Item before, Item after) {
        Item result;
        Item item = result = before.getId() == 340 ? new ItemBookEnchanted() : before;
        if (!before.hasEnchantments() && after.hasEnchantments() && after.getId() == result.getId() && this.levels != null && this.entries != null) {
            Object[] enchantments = after.getEnchantments();
            for (int i = 0; i < 3; ++i) {
                if (!Arrays.equals(enchantments, this.entries[i].getEnchantments())) continue;
                Item lapis = this.getItem(1);
                int level = who.getExperienceLevel();
                int exp = who.getExperience();
                int cost = this.entries[i].getCost();
                if (lapis.getId() != 351 || lapis.getDamage() != 11 || lapis.getCount() <= i || level < cost) continue;
                result.addEnchantment((Enchantment[])enchantments);
                this.setItem(0, result);
                lapis.setCount(lapis.getCount() - i - 1);
                this.setItem(1, lapis);
                who.setExperience(exp, level - cost);
                break;
            }
        }
    }

    public int countBookshelf() {
        return 15;
    }

    public void sendEnchantmentList() {
        CraftingDataPacket pk = new CraftingDataPacket();
        if (this.entries != null && this.levels != null) {
            EnchantmentList list = new EnchantmentList(this.entries.length);
            for (int i = 0; i < list.getSize(); ++i) {
                list.setSlot(i, this.entries[i]);
            }
            pk.addEnchantList(list);
        }
        Server.broadcastPacket(this.getViewers(), (DataPacket)pk);
    }
}

