/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.inventory;

import cn.axeon.blockentity.BlockEntityBrewingStand;
import cn.axeon.inventory.BigShapedRecipe;
import cn.axeon.inventory.BrewingRecipe;
import cn.axeon.inventory.FurnaceRecipe;
import cn.axeon.inventory.Recipe;
import cn.axeon.inventory.ShapedRecipe;
import cn.axeon.inventory.ShapelessRecipe;
import cn.axeon.item.Item;
import cn.axeon.utils.Utils;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class CraftingManager {
    public Map<UUID, Recipe> recipes = new HashMap<UUID, Recipe>();
    protected Map<String, Map<String, Recipe>> recipeLookup = new HashMap<String, Map<String, Recipe>>();
    public Map<String, FurnaceRecipe> furnaceRecipes = new HashMap<String, FurnaceRecipe>();
    public Map<String, BrewingRecipe> brewingRecipes = new HashMap<String, BrewingRecipe>();
    private static int RECIPE_COUNT = 0;
    public final Comparator<Item> comparator = new Comparator<Item>(){

        @Override
        public int compare(Item i1, Item i2) {
            if (i1.getId() > i2.getId()) {
                return 1;
            }
            if (i1.getId() < i2.getId()) {
                return -1;
            }
            if (i1.getDamage() > i2.getDamage()) {
                return 1;
            }
            if (i1.getDamage() < i2.getDamage()) {
                return -1;
            }
            if (i1.getCount() > i2.getCount()) {
                return 1;
            }
            if (i1.getCount() < i2.getCount()) {
                return -1;
            }
            return 0;
        }
    };

    public CraftingManager() {
        this.registerFurnace();
        this.registerBrewing();
        this.registerDyes();
        this.registerIngots();
        this.registerTools();
        this.registerWeapons();
        this.registerArmor();
        this.registerFood();
        this.registerWoodenDoors();
        this.registerRecipe(new ShapedRecipe(Item.get(82, 0, 1), "XX ", "XX ", "   ").setIngredient("X", Item.get(337, 0, 4)));
        this.registerRecipe(new ShapedRecipe(Item.get(58, 0, 1), "XX", "XX").setIngredient("X", Item.get(5, null)));
        this.registerRecipe(new ShapedRecipe(Item.get(89, 0, 1), "XX", "XX").setIngredient("X", Item.get(348, 0, 1)));
        this.registerRecipe(new ShapedRecipe(Item.get(91, 0, 1), "X ", "Y ").setIngredient("X", Item.get(86, 0, 1)).setIngredient("Y", Item.get(50, 0, 1)));
        this.registerRecipe(new ShapedRecipe(Item.get(80, 0, 1), "   ", "XX ", "XX ").setIngredient("X", Item.get(332, 0, 1)));
        this.registerRecipe(new ShapedRecipe(Item.get(78, 0, 6), "   ", "XXX", "   ").setIngredient("X", Item.get(80, 0, 1)));
        this.registerRecipe(new ShapedRecipe(Item.get(280, 0, 4), "X ", "X ").setIngredient("X", Item.get(5, null)));
        this.registerRecipe(new ShapedRecipe(Item.get(5, 0, 4), "X").setIngredient("X", Item.get(17, 0, 1)));
        this.registerRecipe(new ShapedRecipe(Item.get(5, 1, 4), "X").setIngredient("X", Item.get(17, 1, 1)));
        this.registerRecipe(new ShapedRecipe(Item.get(5, 2, 4), "X").setIngredient("X", Item.get(17, 2, 1)));
        this.registerRecipe(new ShapedRecipe(Item.get(5, 3, 4), "X").setIngredient("X", Item.get(17, 3, 1)));
        this.registerRecipe(new ShapedRecipe(Item.get(5, 4, 4), "X").setIngredient("X", Item.get(162, 0, 1)));
        this.registerRecipe(new ShapedRecipe(Item.get(5, 5, 4), "X").setIngredient("X", Item.get(162, 1, 1)));
        this.registerRecipe(new ShapedRecipe(Item.get(35, 0, 1), "XX", "XX").setIngredient("X", Item.get(287, 0, 1)));
        this.registerRecipe(new ShapedRecipe(Item.get(50, 0, 4), "C ", "S").setIngredient("C", Item.get(263, 0, 1)).setIngredient("S", Item.get(280, 0, 1)));
        this.registerRecipe(new ShapedRecipe(Item.get(50, 0, 4), "C ", "S").setIngredient("C", Item.get(263, 1, 1)).setIngredient("S", Item.get(280, 0, 1)));
        this.registerRecipe(new ShapedRecipe(Item.get(353, 0, 1), "S").setIngredient("S", Item.get(338, 0, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(355, 0, 1), "WWW", "PPP", "   ").setIngredient("W", Item.get(35, null, 1)).setIngredient("P", Item.get(5, null, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(54, 0, 1), "PPP", "P P", "PPP").setIngredient("P", Item.get(5, null, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(116, 0, 1), " B ", "DOD", "OOO").setIngredient("D", Item.get(264, 0, 2)).setIngredient("O", Item.get(49, 0, 4)).setIngredient("B", Item.get(340, 0, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(85, 0, 3), "PSP", "PSP", "   ").setIngredient("S", Item.get(280, 0, 1)).setIngredient("P", Item.get(5, 0, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(85, 1, 3), "PSP", "PSP", "   ").setIngredient("S", Item.get(280, 0, 1)).setIngredient("P", Item.get(5, 1, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(85, 2, 3), "PSP", "PSP", "   ").setIngredient("S", Item.get(280, 0, 1)).setIngredient("P", Item.get(5, 2, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(85, 3, 3), "PSP", "PSP", "   ").setIngredient("S", Item.get(280, 0, 1)).setIngredient("P", Item.get(5, 3, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(85, 4, 3), "PSP", "PSP", "   ").setIngredient("S", Item.get(280, 0, 1)).setIngredient("P", Item.get(5, 4, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(85, 5, 3), "PSP", "PSP", "   ").setIngredient("S", Item.get(280, 0, 1)).setIngredient("P", Item.get(5, 5, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(113, 0, 3), "PPP", "PPP", "   ").setIngredient("P", Item.get(112, 0, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(107, 0, 1), "SPS", "SPS", "   ").setIngredient("S", Item.get(280, 0, 1)).setIngredient("P", Item.get(5, 0, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(183, 0, 1), "SPS", "SPS", "   ").setIngredient("S", Item.get(280, 0, 1)).setIngredient("P", Item.get(5, 1, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(184, 0, 1), "SPS", "SPS", "   ").setIngredient("S", Item.get(280, 0, 1)).setIngredient("P", Item.get(5, 2, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(185, 0, 1), "SPS", "SPS", "   ").setIngredient("S", Item.get(280, 0, 1)).setIngredient("P", Item.get(5, 3, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(186, 0, 1), "SPS", "SPS", "   ").setIngredient("S", Item.get(280, 0, 1)).setIngredient("P", Item.get(5, 5, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(187, 0, 1), "SPS", "SPS", "   ").setIngredient("S", Item.get(280, 0, 1)).setIngredient("P", Item.get(5, 4, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(139, 0, 6), "CCC", "CCC", "   ").setIngredient("C", Item.get(4, 0, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(139, 1, 6), "MMM", "MMM", "   ").setIngredient("M", Item.get(48, 0, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(61, 0, 1), "CCC", "C C", "CCC").setIngredient("C", Item.get(4, 0, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(102, 0, 16), "GGG", "GGG", "   ").setIngredient("G", Item.get(20, 0, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(65, 0, 3), "S S", "SSS", "S S").setIngredient("S", Item.get(280, 0, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(96, 0, 2), "PPP", "PPP", "   ").setIngredient("P", Item.get(5, null, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(330, 0, 1), "II ", "II ", "II ").setIngredient("I", Item.get(265, 0, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(333, 0, 1), "PSP", "PPP", "   ").setIngredient("S", Item.get(269, 0, 1)).setIngredient("P", Item.get(5, 0, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(333, 1, 1), "PSP", "PPP", "   ").setIngredient("S", Item.get(269, 0, 1)).setIngredient("P", Item.get(5, 1, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(333, 2, 1), "PSP", "PPP", "   ").setIngredient("S", Item.get(269, 0, 1)).setIngredient("P", Item.get(5, 2, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(333, 3, 1), "PSP", "PPP", "   ").setIngredient("S", Item.get(269, 0, 1)).setIngredient("P", Item.get(5, 3, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(333, 4, 1), "PSP", "PPP", "   ").setIngredient("S", Item.get(269, 0, 1)).setIngredient("P", Item.get(5, 4, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(333, 5, 1), "PSP", "PPP", "   ").setIngredient("S", Item.get(269, 0, 1)).setIngredient("P", Item.get(5, 5, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(128, 0, 4), "P  ", "PP ", "PPP").setIngredient("P", Item.get(24, null, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(53, 0, 4), "P  ", "PP ", "PPP").setIngredient("P", Item.get(5, 0, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(134, 0, 4), "P  ", "PP ", "PPP").setIngredient("P", Item.get(5, 1, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(135, 0, 4), "P  ", "PP ", "PPP").setIngredient("P", Item.get(5, 2, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(136, 0, 4), "P  ", "PP ", "PPP").setIngredient("P", Item.get(5, 3, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(163, 0, 4), "P  ", "PP ", "PPP").setIngredient("P", Item.get(5, 4, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(164, 0, 4), "P  ", "PP ", "PPP").setIngredient("P", Item.get(5, 5, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(67, 0, 4), "P  ", "PP ", "PPP").setIngredient("P", Item.get(4, 0, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(108, 0, 4), "P  ", "PP ", "PPP").setIngredient("P", Item.get(45, 0, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(109, 0, 4), "P  ", "PP ", "PPP").setIngredient("P", Item.get(98, 0, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(156, 0, 4), "P  ", "PP ", "PPP").setIngredient("P", Item.get(155, null, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(114, 0, 4), "P  ", "PP ", "PPP").setIngredient("P", Item.get(112, 0, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(44, 0, 6), "PPP", "   ", "   ").setIngredient("P", Item.get(1, 0, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(44, 1, 6), "PPP", "   ", "   ").setIngredient("P", Item.get(24, null, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(158, 0, 6), "PPP", "   ", "   ").setIngredient("P", Item.get(5, 0, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(158, 1, 6), "PPP", "   ", "   ").setIngredient("P", Item.get(5, 1, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(158, 2, 6), "PPP", "   ", "   ").setIngredient("P", Item.get(5, 2, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(158, 3, 6), "PPP", "   ", "   ").setIngredient("P", Item.get(5, 3, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(158, 4, 6), "PPP", "   ", "   ").setIngredient("P", Item.get(5, 4, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(158, 5, 6), "PPP", "   ", "   ").setIngredient("P", Item.get(5, 5, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(44, 3, 6), "PPP", "   ", "   ").setIngredient("P", Item.get(4, 0, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(44, 4, 6), "PPP", "   ", "   ").setIngredient("P", Item.get(336, 0, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(44, 5, 6), "PPP", "   ", "   ").setIngredient("P", Item.get(98, 0, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(44, 6, 6), "PPP", "   ", "   ").setIngredient("P", Item.get(155, 0, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(44, 7, 6), "PPP", "   ", "   ").setIngredient("P", Item.get(112, 0, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(155, 0, 1), "NN ", "NN ", "   ").setIngredient("N", Item.get(406, 0, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(155, 2, 2), "N  ", "N  ", "   ").setIngredient("N", Item.get(155, 0, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(155, 1, 1), "   ", " N ", " N ").setIngredient("N", Item.get(44, 6, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(24, 0, 1), "SS ", "SS ", "   ").setIngredient("S", Item.get(12, 0, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(24, 2, 2), "S  ", "S  ", "   ").setIngredient("S", Item.get(24, 0, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(24, 1, 1), "   ", " N ", " N ").setIngredient("N", Item.get(44, 1, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(98, 0, 1), "   ", "SS ", "SS ").setIngredient("S", Item.get(1, 0, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(98, 1, 1), "   ", "SL ", "   ").setIngredient("S", Item.get(98, 0, 1)).setIngredient("L", Item.get(106, 0, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(98, 3, 1), "   ", " S ", " S ").setIngredient("S", Item.get(44, 5, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(48, 0, 1), "   ", "SL ", "   ").setIngredient("S", Item.get(4, 0, 1)).setIngredient("L", Item.get(106, 0, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(1, 1, 1), "   ", "DN ", "   ").setIngredient("D", Item.get(1, 3, 1)).setIngredient("N", Item.get(406, 0, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(1, 2, 4), "   ", "GG ", "GG ").setIngredient("G", Item.get(1, 1, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(1, 3, 2), "   ", "CN ", "NC ").setIngredient("C", Item.get(4, 0, 1)).setIngredient("N", Item.get(406, 0, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(1, 4, 4), "   ", "DD ", "DD ").setIngredient("D", Item.get(1, 3, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(1, 5, 2), "   ", "DC ", "   ").setIngredient("D", Item.get(1, 3, 1)).setIngredient("C", Item.get(4, 0, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(1, 6, 4), "   ", "AA ", "AA ").setIngredient("A", Item.get(1, 5, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(325, 0, 1), "I I", " I ", "   ").setIngredient("I", Item.get(265, 0, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(347, 0, 1), " G ", "GRG", " G ").setIngredient("G", Item.get(266, 0, 1)).setIngredient("R", Item.get(331, 0, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(345, 0, 1), " I ", "IRI", " I ").setIngredient("I", Item.get(265, 0, 1)).setIngredient("R", Item.get(331, 0, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(46, 0, 1), "GSG", "SGS", "GSG").setIngredient("G", Item.get(289, 0, 1)).setIngredient("S", Item.get(12, null, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(281, 0, 4), "P P", " P ", "   ").setIngredient("P", Item.get(5, null, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(328, 0, 1), "I I", "III").setIngredient("I", Item.get(265, 0, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(340, 0, 1), "P P", " P ").setIngredient("P", Item.get(339, 0, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(47, 0, 1), "PPP", "BBB", "PPP").setIngredient("P", Item.get(5, null, 1)).setIngredient("B", Item.get(340, 0, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(321, 0, 1), "SSS", "SWS", "SSS").setIngredient("S", Item.get(280, 0, 1)).setIngredient("W", Item.get(35, null, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(339, 0, 3), "   ", "SSS", "   ").setIngredient("S", Item.get(338, 0, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(323, 0, 3), "PPP", "PPP", " S ").setIngredient("S", Item.get(280, 0, 1)).setIngredient("P", Item.get(5, null, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(101, 0, 16), "   ", "III", "III").setIngredient("I", Item.get(265, 0, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(374, 0, 3), "I I", " I ", "   ").setIngredient("I", Item.get(20, 0, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(379, 0, 1), " I ", "CCC").setIngredient("C", Item.get(4, 0, 1)).setIngredient("I", Item.get(369, 0, 1)));
    }

    protected void registerFurnace() {
        this.registerRecipe(new FurnaceRecipe(Item.get(1, 0, 1), Item.get(4, 0, 1)));
        this.registerRecipe(new FurnaceRecipe(Item.get(98, 2, 1), Item.get(98, 0, 1)));
        this.registerRecipe(new FurnaceRecipe(Item.get(20, 0, 1), Item.get(12, null, 1)));
        this.registerRecipe(new FurnaceRecipe(Item.get(263, 1, 1), Item.get(17, null, 1)));
        this.registerRecipe(new FurnaceRecipe(Item.get(266, 0, 1), Item.get(14, 0, 1)));
        this.registerRecipe(new FurnaceRecipe(Item.get(265, 0, 1), Item.get(15, 0, 1)));
        this.registerRecipe(new FurnaceRecipe(Item.get(388, 0, 1), Item.get(129, 0, 1)));
        this.registerRecipe(new FurnaceRecipe(Item.get(264, 0, 1), Item.get(56, 0, 1)));
        this.registerRecipe(new FurnaceRecipe(Item.get(405, 0, 1), Item.get(87, 0, 1)));
        this.registerRecipe(new FurnaceRecipe(Item.get(320, 0, 1), Item.get(319, 0, 1)));
        this.registerRecipe(new FurnaceRecipe(Item.get(336, 0, 1), Item.get(337, 0, 1)));
        this.registerRecipe(new FurnaceRecipe(Item.get(350, 0, 1), Item.get(349, 0, 1)));
        this.registerRecipe(new FurnaceRecipe(Item.get(350, 1, 1), Item.get(349, 1, 1)));
        this.registerRecipe(new FurnaceRecipe(Item.get(351, 2, 1), Item.get(81, 0, 1)));
        this.registerRecipe(new FurnaceRecipe(Item.get(351, 1, 1), Item.get(40, 0, 1)));
        this.registerRecipe(new FurnaceRecipe(Item.get(364, 0, 1), Item.get(363, 0, 1)));
        this.registerRecipe(new FurnaceRecipe(Item.get(366, 0, 1), Item.get(365, 0, 1)));
        this.registerRecipe(new FurnaceRecipe(Item.get(393, 0, 1), Item.get(392, 0, 1)));
        this.registerRecipe(new FurnaceRecipe(Item.get(172, 0, 1), Item.get(82, 0, 1)));
    }

    protected void registerBrewing() {
        for (int ingredient : new int[]{372, 371, 370, 348, 331, 289, 378, 377, 396, 375, 376, 382, 353, 349}) {
            BlockEntityBrewingStand.ingredients.add(ingredient);
        }
        this.registerBrewingRecipe(new BrewingRecipe(Item.get(373, 4, 1), Item.get(372, 0, 1), Item.get(373, 0, 1)));
        this.registerBrewingRecipe(new BrewingRecipe(Item.get(373, 3, 1), Item.get(348, 0, 1), Item.get(373, 0, 1)));
        this.registerBrewingRecipe(new BrewingRecipe(Item.get(373, 2, 1), Item.get(331, 0, 1), Item.get(373, 0, 1)));
        this.registerBrewingRecipe(new BrewingRecipe(Item.get(373, 31, 1), Item.get(377, 0, 1), Item.get(373, 4, 1)));
        this.registerBrewingRecipe(new BrewingRecipe(Item.get(373, 32, 1), Item.get(331, 0, 1), Item.get(373, 31, 1)));
        this.registerBrewingRecipe(new BrewingRecipe(Item.get(373, 32, 1), Item.get(331, 0, 1), Item.get(373, 33, 1)));
        this.registerBrewingRecipe(new BrewingRecipe(Item.get(373, 33, 1), Item.get(348, 0, 1), Item.get(373, 31, 1)));
        this.registerBrewingRecipe(new BrewingRecipe(Item.get(373, 33, 1), Item.get(348, 0, 1), Item.get(373, 32, 1)));
        this.registerBrewingRecipe(new BrewingRecipe(Item.get(373, 34, 1), Item.get(376, 0, 1), Item.get(373, 0, 1)));
        this.registerBrewingRecipe(new BrewingRecipe(Item.get(373, 35, 1), Item.get(331, 0, 1), Item.get(373, 34, 1)));
        this.registerBrewingRecipe(new BrewingRecipe(Item.get(373, 5, 1), Item.get(396, 0, 1), Item.get(373, 4, 1)));
        this.registerBrewingRecipe(new BrewingRecipe(Item.get(373, 6, 1), Item.get(331, 0, 1), Item.get(373, 5, 1)));
        this.registerBrewingRecipe(new BrewingRecipe(Item.get(373, 7, 1), Item.get(376, 0, 1), Item.get(373, 5, 1)));
        this.registerBrewingRecipe(new BrewingRecipe(Item.get(373, 8, 1), Item.get(331, 0, 1), Item.get(373, 7, 1)));
        this.registerBrewingRecipe(new BrewingRecipe(Item.get(373, 8, 1), Item.get(376, 0, 1), Item.get(373, 6, 1)));
        this.registerBrewingRecipe(new BrewingRecipe(Item.get(373, 12, 1), Item.get(378, 0, 1), Item.get(373, 4, 1)));
        this.registerBrewingRecipe(new BrewingRecipe(Item.get(373, 13, 1), Item.get(331, 0, 1), Item.get(373, 12, 1)));
        this.registerBrewingRecipe(new BrewingRecipe(Item.get(373, 17, 1), Item.get(376, 0, 1), Item.get(373, 12, 1)));
        this.registerBrewingRecipe(new BrewingRecipe(Item.get(373, 17, 1), Item.get(376, 0, 1), Item.get(373, 14, 1)));
        this.registerBrewingRecipe(new BrewingRecipe(Item.get(373, 17, 1), Item.get(376, 0, 1), Item.get(373, 9, 1)));
        this.registerBrewingRecipe(new BrewingRecipe(Item.get(373, 18, 1), Item.get(376, 0, 1), Item.get(373, 13, 1)));
        this.registerBrewingRecipe(new BrewingRecipe(Item.get(373, 18, 1), Item.get(376, 0, 1), Item.get(373, 15, 1)));
        this.registerBrewingRecipe(new BrewingRecipe(Item.get(373, 14, 1), Item.get(353, 0, 1), Item.get(373, 4, 1)));
        this.registerBrewingRecipe(new BrewingRecipe(Item.get(373, 15, 1), Item.get(331, 0, 1), Item.get(373, 14, 1)));
        this.registerBrewingRecipe(new BrewingRecipe(Item.get(373, 16, 1), Item.get(348, 0, 1), Item.get(373, 14, 1)));
        this.registerBrewingRecipe(new BrewingRecipe(Item.get(373, 21, 1), Item.get(382, 0, 1), Item.get(373, 4, 1)));
        this.registerBrewingRecipe(new BrewingRecipe(Item.get(373, 22, 1), Item.get(348, 0, 1), Item.get(373, 21, 1)));
        this.registerBrewingRecipe(new BrewingRecipe(Item.get(373, 25, 1), Item.get(375, 0, 1), Item.get(373, 4, 1)));
        this.registerBrewingRecipe(new BrewingRecipe(Item.get(373, 26, 1), Item.get(331, 0, 1), Item.get(373, 25, 1)));
        this.registerBrewingRecipe(new BrewingRecipe(Item.get(373, 27, 1), Item.get(348, 0, 1), Item.get(373, 25, 1)));
        this.registerBrewingRecipe(new BrewingRecipe(Item.get(373, 28, 1), Item.get(370, 0, 1), Item.get(373, 4, 1)));
        this.registerBrewingRecipe(new BrewingRecipe(Item.get(373, 29, 1), Item.get(331, 0, 1), Item.get(373, 28, 1)));
        this.registerBrewingRecipe(new BrewingRecipe(Item.get(373, 30, 1), Item.get(348, 0, 1), Item.get(373, 28, 1)));
        this.registerBrewingRecipe(new BrewingRecipe(Item.get(373, 23, 1), Item.get(376, 0, 1), Item.get(373, 19, 1)));
        this.registerBrewingRecipe(new BrewingRecipe(Item.get(373, 23, 1), Item.get(376, 0, 1), Item.get(373, 21, 1)));
        this.registerBrewingRecipe(new BrewingRecipe(Item.get(373, 23, 1), Item.get(376, 0, 1), Item.get(373, 25, 1)));
        this.registerBrewingRecipe(new BrewingRecipe(Item.get(373, 24, 1), Item.get(348, 0, 1), Item.get(373, 23, 1)));
        this.registerBrewingRecipe(new BrewingRecipe(Item.get(373, 24, 1), Item.get(376, 0, 1), Item.get(373, 22, 1)));
        this.registerBrewingRecipe(new BrewingRecipe(Item.get(373, 24, 1), Item.get(376, 0, 1), Item.get(373, 26, 1)));
    }

    protected void registerFood() {
        this.registerRecipe(new BigShapedRecipe(Item.get(103, 0, 1), "XXX", "XXX", "XXX").setIngredient("X", Item.get(360, 0, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(459, 0, 1), "XXX", "XXX", " Y ").setIngredient("X", Item.get(457, 0, 1)).setIngredient("Y", Item.get(281, 0, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(297, 0, 1), "   ", "   ", "XXX").setIngredient("X", Item.get(296, 0, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(354, 0, 1), "XXX", "YZY", "AAA").setIngredient("X", Item.get(325, 1, 1)).setIngredient("Y", Item.get(353, 0, 1)).setIngredient("Z", Item.get(344, 0, 1)).setIngredient("A", Item.get(296, 0, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(357, 0, 8), "   ", "   ", "XYX").setIngredient("X", Item.get(296, 0, 1)).setIngredient("Y", Item.get(351, 3, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(322, 0, 1), "XXX", "XYX", "XXX").setIngredient("X", Item.get(371, 0, 1)).setIngredient("Y", Item.get(260, 0, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(322, 1, 1), "XXX", "XYX", "XXX").setIngredient("X", Item.get(41, 0, 1)).setIngredient("Y", Item.get(260, 0, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(282, 0, 1), " X ", " Y ", " Z ").setIngredient("X", Item.get(40, 0, 1)).setIngredient("Y", Item.get(39, 0, 1)).setIngredient("Z", Item.get(281, 0, 1)));
        this.registerRecipe(new BigShapedRecipe(Item.get(400, 0, 1), "   ", "XY ", "Z  ").setIngredient("X", Item.get(86, 0, 1)).setIngredient("Y", Item.get(344, 0, 1)).setIngredient("Z", Item.get(353, 0, 1)));
        this.registerRecipe(new ShapedRecipe(Item.get(362, 0, 1), "X ", "  ").setIngredient("X", Item.get(360, 0, 1)));
        this.registerRecipe(new ShapedRecipe(Item.get(361, 0, 4), "X ", "  ").setIngredient("X", Item.get(86, 0, 1)));
    }

    protected void registerArmor() {
        int[][] types = new int[][]{{334, 51, 265, 264, 266}, {298, 302, 306, 310, 314}, {299, 303, 307, 311, 315}, {300, 304, 308, 312, 316}, {301, 305, 309, 313, 317}};
        String[][] shapes = new String[][]{{"XXX", "X X", "   "}, {"X X", "XXX", "XXX"}, {"XXX", "X X", "X X"}, {"   ", "X X", "X X"}};
        for (int i = 1; i < 5; ++i) {
            for (int j = 0; j < types[i].length; ++j) {
                int type = types[i][j];
                this.registerRecipe(new BigShapedRecipe(Item.get(type, 0, 1), shapes[i - 1]).setIngredient("X", Item.get(types[0][j], 0, 1)));
            }
        }
    }

    protected void registerWeapons() {
        int[][] types = new int[][]{{5, 4, 265, 264, 266}, {268, 272, 267, 276, 283}};
        for (int i = 1; i < 2; ++i) {
            for (int j = 0; j < types[i].length; ++j) {
                int type = types[i][j];
                this.registerRecipe(new BigShapedRecipe(Item.get(type, 0, 1), " X ", " X ", " I ").setIngredient("X", Item.get(types[0][j], null)).setIngredient("I", Item.get(280)));
            }
        }
        this.registerRecipe(new BigShapedRecipe(Item.get(262, 0, 1), " F ", " S ", " P ").setIngredient("S", Item.get(280)).setIngredient("F", Item.get(318)).setIngredient("P", Item.get(288)));
        this.registerRecipe(new BigShapedRecipe(Item.get(261, 0, 1), " X~", "X ~", " X~").setIngredient("~", Item.get(287)).setIngredient("X", Item.get(280)));
    }

    protected void registerTools() {
        int[][] types = new int[][]{{5, 4, 265, 264, 266}, {270, 274, 257, 278, 285}, {269, 273, 256, 277, 284}, {271, 275, 258, 279, 286}, {290, 291, 292, 293, 294}};
        String[][] shapes = new String[][]{{"XXX", " I ", " I "}, {" X ", " I ", " I "}, {"XX ", "XI ", " I "}, {"XX ", " I ", " I "}};
        for (int i = 1; i < 5; ++i) {
            for (int j = 0; j < types[i].length; ++j) {
                int type = types[i][j];
                this.registerRecipe(new BigShapedRecipe(Item.get(type, 0, 1), shapes[i - 1]).setIngredient('X', Item.get(types[0][j], null)).setIngredient('I', Item.get(280)));
            }
        }
        this.registerRecipe(new ShapedRecipe(Item.get(259, 0, 1), " S", "F ").setIngredient('F', Item.get(318)).setIngredient("S", Item.get(265)));
        this.registerRecipe(new ShapedRecipe(Item.get(359, 0, 1), " X", "X ").setIngredient("X", Item.get(265)));
    }

    protected void registerWoodenDoors() {
        int[] items = new int[]{324, 427, 428, 429, 430, 431};
        for (int i = 0; i < 6; ++i) {
            this.registerRecipe(new BigShapedRecipe(Item.get(items[i], 0, 3), "XX ", "XX ", "XX ").setIngredient("X", Item.get(5, i, 1)));
        }
    }

    protected void registerDyes() {
        for (int i = 0; i < 16; ++i) {
            this.registerRecipe(new ShapelessRecipe(Item.get(35, 15 - i, 1)).addIngredient(Item.get(351, i, 1)).addIngredient(Item.get(35, 0, 1)));
            this.registerRecipe(new ShapelessRecipe(Item.get(159, 15 - i, 8)).addIngredient(Item.get(351, i, 1)).addIngredient(Item.get(172, 0, 8)));
            this.registerRecipe(new ShapelessRecipe(Item.get(35, 15 - i, 1)).addIngredient(Item.get(351, i, 1)).addIngredient(Item.get(35, 0, 1)));
            this.registerRecipe(new ShapelessRecipe(Item.get(35, 15 - i, 1)).addIngredient(Item.get(351, i, 1)).addIngredient(Item.get(35, 0, 1)));
            this.registerRecipe(new ShapelessRecipe(Item.get(35, 15 - i, 1)).addIngredient(Item.get(351, i, 1)).addIngredient(Item.get(35, 0, 1)));
            this.registerRecipe(new ShapelessRecipe(Item.get(171, i, 3)).addIngredient(Item.get(35, i, 2)));
        }
        this.registerRecipe(new ShapelessRecipe(Item.get(351, 11, 2)).addIngredient(Item.get(37, 0, 1)));
        this.registerRecipe(new ShapelessRecipe(Item.get(351, 15, 3)).addIngredient(Item.get(352, 0, 1)));
        this.registerRecipe(new ShapelessRecipe(Item.get(351, 3, 2)).addIngredient(Item.get(351, 14, 1)).addIngredient(Item.get(351, 0, 1)));
        this.registerRecipe(new ShapelessRecipe(Item.get(351, 3, 3)).addIngredient(Item.get(351, 1, 1)).addIngredient(Item.get(351, 0, 1)).addIngredient(Item.get(351, 11, 1)));
        this.registerRecipe(new ShapelessRecipe(Item.get(351, 9, 2)).addIngredient(Item.get(351, 15, 1)).addIngredient(Item.get(351, 1, 1)));
        this.registerRecipe(new ShapelessRecipe(Item.get(351, 14, 2)).addIngredient(Item.get(351, 11, 1)).addIngredient(Item.get(351, 1, 1)));
        this.registerRecipe(new ShapelessRecipe(Item.get(351, 10, 2)).addIngredient(Item.get(351, 2, 1)).addIngredient(Item.get(351, 15, 1)));
        this.registerRecipe(new ShapelessRecipe(Item.get(351, 12, 2)).addIngredient(Item.get(351, 4, 1)).addIngredient(Item.get(351, 15, 1)));
        this.registerRecipe(new ShapelessRecipe(Item.get(351, 6, 2)).addIngredient(Item.get(351, 4, 1)).addIngredient(Item.get(351, 2, 1)));
        this.registerRecipe(new ShapelessRecipe(Item.get(351, 5, 2)).addIngredient(Item.get(351, 4, 1)).addIngredient(Item.get(351, 1, 1)));
        this.registerRecipe(new ShapelessRecipe(Item.get(351, 13, 3)).addIngredient(Item.get(351, 4, 1)).addIngredient(Item.get(351, 1, 1)).addIngredient(Item.get(351, 15, 1)));
        this.registerRecipe(new ShapelessRecipe(Item.get(351, 1, 1)).addIngredient(Item.get(457, 0, 1)));
        this.registerRecipe(new ShapelessRecipe(Item.get(351, 13, 4)).addIngredient(Item.get(351, 15, 1)).addIngredient(Item.get(351, 1, 2)).addIngredient(Item.get(351, 4, 1)));
        this.registerRecipe(new ShapelessRecipe(Item.get(351, 13, 2)).addIngredient(Item.get(351, 5, 1)).addIngredient(Item.get(351, 9, 1)));
        this.registerRecipe(new ShapelessRecipe(Item.get(351, 8, 2)).addIngredient(Item.get(351, 0, 1)).addIngredient(Item.get(351, 15, 1)));
        this.registerRecipe(new ShapelessRecipe(Item.get(351, 7, 3)).addIngredient(Item.get(351, 0, 1)).addIngredient(Item.get(351, 15, 2)));
        this.registerRecipe(new ShapelessRecipe(Item.get(351, 7, 2)).addIngredient(Item.get(351, 0, 1)).addIngredient(Item.get(351, 8, 1)));
    }

    protected void registerIngots() {
        int[][] ingots;
        for (int[] e : ingots = new int[][]{{41, 266}, {266, 371}, {42, 265}, {57, 264}, {133, 388}, {152, 331}, {173, 263}, {170, 296}, {22, 351, 4}}) {
            int block = e[0];
            int ingot = e[1];
            int ingot_meta = e.length > 2 ? e[2] : 0;
            this.registerRecipe(new ShapedRecipe(Item.get(ingot, ingot_meta, 9), "X").setIngredient("X", Item.get(block, 0, 1)));
            this.registerRecipe(new BigShapedRecipe(Item.get(block, 0, 1), "XXX", "XXX", "XXX").setIngredient("X", Item.get(ingot, ingot_meta, 1)));
        }
    }

    public Recipe getRecipe(UUID id) {
        return this.recipes.containsKey(id) ? this.recipes.get(id) : null;
    }

    public Map<UUID, Recipe> getRecipes() {
        return this.recipes;
    }

    public Map<String, FurnaceRecipe> getFurnaceRecipes() {
        return this.furnaceRecipes;
    }

    public FurnaceRecipe matchFurnaceRecipe(Item input) {
        if (this.furnaceRecipes.containsKey(input.getId() + ":" + input.getDamage())) {
            return this.furnaceRecipes.get(input.getId() + ":" + input.getDamage());
        }
        if (this.furnaceRecipes.containsKey(input.getId() + ":?")) {
            return this.furnaceRecipes.get(input.getId() + ":?");
        }
        return null;
    }

    public void registerShapedRecipe(ShapedRecipe recipe) {
        Item result = recipe.getResult();
        this.recipes.put(recipe.getId(), recipe);
        Map<Integer, Map<Integer, Item>> ingredients = recipe.getIngredientMap();
        String hash = "";
        for (Map<Integer, Item> v : ingredients.values()) {
            for (Item item : v.values()) {
                if (item == null) continue;
                hash = hash + item.getId() + ":" + (!item.hasMeta() ? "?" : Integer.valueOf(item.getDamage())) + "x" + item.getCount() + ",";
            }
            hash = hash + ";";
        }
        String index = result.getId() + ":" + (result.hasMeta() ? Integer.valueOf(result.getDamage()) : "");
        if (!this.recipeLookup.containsKey(index)) {
            this.recipeLookup.put(index, new HashMap());
        }
        this.recipeLookup.get(index).put(hash, recipe);
    }

    public void registerShapelessRecipe(ShapelessRecipe recipe) {
        Item result = recipe.getResult();
        this.recipes.put(recipe.getId(), recipe);
        String hash = "";
        List<Item> ingredients = recipe.getIngredientList();
        Collections.sort(ingredients, this.comparator);
        for (Item item : ingredients) {
            hash = hash + item.getId() + ":" + (!item.hasMeta() ? "?" : Integer.valueOf(item.getDamage())) + "x" + item.getCount() + ",";
        }
        if (!this.recipeLookup.containsKey(result.getId() + ":" + result.getDamage())) {
            this.recipeLookup.put(result.getId() + ":" + result.getDamage(), new HashMap());
        }
        this.recipeLookup.get(result.getId() + ":" + result.getDamage()).put(hash, recipe);
    }

    public void registerFurnaceRecipe(FurnaceRecipe recipe) {
        Item input = recipe.getInput();
        this.furnaceRecipes.put(input.getId() + ":" + (!input.hasMeta() ? "?" : Integer.valueOf(input.getDamage())), recipe);
    }

    public void registerBrewingRecipe(BrewingRecipe recipe) {
        Item input = recipe.getInput();
        Item potion = recipe.getPotion();
        this.brewingRecipes.put(input.getId() + ":" + (!potion.hasMeta() ? 0 : potion.getDamage()), recipe);
    }

    public BrewingRecipe matchBrewingRecipe(Item input, Item potion) {
        if (this.brewingRecipes.containsKey(input.getId() + ":" + (!potion.hasMeta() ? 0 : potion.getDamage()))) {
            return this.brewingRecipes.get(input.getId() + ":" + (!potion.hasMeta() ? 0 : potion.getDamage()));
        }
        return null;
    }

    public boolean matchRecipe(ShapelessRecipe recipe) {
        String idx = recipe.getResult().getId() + ":" + recipe.getResult().getDamage();
        if (!this.recipeLookup.containsKey(idx)) {
            return false;
        }
        String hash = "";
        List<Item> ingredients = recipe.getIngredientList();
        Collections.sort(ingredients, this.comparator);
        for (Item item : ingredients) {
            hash = hash + item.getId() + ":" + (!item.hasMeta() ? "?" : Integer.valueOf(item.getDamage())) + "x" + item.getCount() + ",";
        }
        if (this.recipeLookup.get(idx).containsKey(hash)) {
            return true;
        }
        Recipe hasRecipe = null;
        for (Recipe r : this.recipeLookup.get(idx).values()) {
            if (!(r instanceof ShapelessRecipe) || ((ShapelessRecipe)r).getIngredientCount() != ingredients.size()) continue;
            List<Item> checkInput = ((ShapelessRecipe)r).getIngredientList();
            block2: for (Item item : ingredients) {
                int amount = item.getCount();
                for (Item checkItem : checkInput) {
                    if (!checkItem.equals(item, checkItem.hasMeta())) continue;
                    int remove = Math.min(checkItem.getCount(), amount);
                    checkItem.setCount(checkItem.getCount() - amount);
                    if (checkItem.getCount() == 0) {
                        checkInput.remove(checkItem);
                    }
                    if ((amount -= remove) != 0) continue;
                    continue block2;
                }
            }
            if (!checkInput.isEmpty()) continue;
            hasRecipe = r;
            break;
        }
        return hasRecipe != null;
    }

    public void registerRecipe(Recipe recipe) {
        recipe.setId(Utils.dataToUUID(String.valueOf(++RECIPE_COUNT), String.valueOf(recipe.getResult().getId()), String.valueOf(recipe.getResult().getDamage()), String.valueOf(recipe.getResult().getCount()), Arrays.toString(recipe.getResult().getCompoundTag())));
        if (recipe instanceof ShapedRecipe) {
            this.registerShapedRecipe((ShapedRecipe)recipe);
        } else if (recipe instanceof ShapelessRecipe) {
            this.registerShapelessRecipe((ShapelessRecipe)recipe);
        } else if (recipe instanceof FurnaceRecipe) {
            this.registerFurnaceRecipe((FurnaceRecipe)recipe);
        }
    }

    public static class Entry {
        int resultItemId;
        int resultMeta;
        int ingredientItemId;
        int ingredientMeta;
        String recipeShape;
        int resultAmount;

        public Entry(int resultItemId, int resultMeta, int ingredientItemId, int ingredientMeta, String recipeShape, int resultAmount) {
            this.resultItemId = resultItemId;
            this.resultMeta = resultMeta;
            this.ingredientItemId = ingredientItemId;
            this.ingredientMeta = ingredientMeta;
            this.recipeShape = recipeShape;
            this.resultAmount = resultAmount;
        }
    }
}

