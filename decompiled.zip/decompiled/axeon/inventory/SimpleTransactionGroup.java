/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.inventory;

import cn.axeon.Player;
import cn.axeon.Server;
import cn.axeon.event.inventory.InventoryTransactionEvent;
import cn.axeon.inventory.Inventory;
import cn.axeon.inventory.PlayerInventory;
import cn.axeon.inventory.Transaction;
import cn.axeon.inventory.TransactionGroup;
import cn.axeon.item.Item;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class SimpleTransactionGroup
implements TransactionGroup {
    private long creationTime;
    protected boolean hasExecuted = false;
    protected Player source = null;
    protected Set<Inventory> inventories = new HashSet<Inventory>();
    protected Set<Transaction> transactions = new HashSet<Transaction>();

    public SimpleTransactionGroup() {
        this(null);
    }

    public SimpleTransactionGroup(Player source) {
        this.creationTime = System.currentTimeMillis();
        this.source = source;
    }

    public Player getSource() {
        return this.source;
    }

    @Override
    public long getCreationTime() {
        return this.creationTime;
    }

    @Override
    public Set<Inventory> getInventories() {
        return this.inventories;
    }

    @Override
    public Set<Transaction> getTransactions() {
        return this.transactions;
    }

    @Override
    public void addTransaction(Transaction transaction) {
        if (this.transactions.contains(transaction)) {
            return;
        }
        for (Transaction tx : new HashSet<Transaction>(this.transactions)) {
            if (!tx.getInventory().equals(transaction.getInventory()) || tx.getSlot() != transaction.getSlot()) continue;
            if (transaction.getCreationTime() >= tx.getCreationTime()) {
                this.transactions.remove(tx);
                continue;
            }
            return;
        }
        this.transactions.add(transaction);
        this.inventories.add(transaction.getInventory());
    }

    protected boolean matchItems(List<Item> needItems, List<Item> haveItems) {
        for (Transaction ts : this.transactions) {
            Item sourceItem;
            Item checkSourceItem;
            if (ts.getTargetItem().getId() != 0) {
                needItems.add(ts.getTargetItem());
            }
            if (!(checkSourceItem = ts.getInventory().getItem(ts.getSlot())).deepEquals(sourceItem = ts.getSourceItem()) || sourceItem.getCount() != checkSourceItem.getCount()) {
                return false;
            }
            if (sourceItem.getId() == 0) continue;
            haveItems.add(sourceItem);
        }
        block1: for (Item needItem : new ArrayList<Item>(needItems)) {
            for (Item haveItem : new ArrayList<Item>(haveItems)) {
                if (!needItem.deepEquals(haveItem)) continue;
                int amount = Math.min(haveItem.getCount(), needItem.getCount());
                needItem.setCount(needItem.getCount() - amount);
                haveItem.setCount(haveItem.getCount() - amount);
                if (haveItem.getCount() == 0) {
                    haveItems.remove(haveItem);
                }
                if (needItem.getCount() != 0) continue;
                needItems.remove(needItem);
                continue block1;
            }
        }
        return true;
    }

    @Override
    public boolean canExecute() {
        ArrayList<Item> needItems = new ArrayList<Item>();
        ArrayList<Item> haveItems = new ArrayList<Item>();
        return this.matchItems(needItems, haveItems) && haveItems.isEmpty() && needItems.isEmpty() && !this.transactions.isEmpty();
    }

    @Override
    public boolean execute() {
        if (this.hasExecuted || !this.canExecute()) {
            return false;
        }
        InventoryTransactionEvent ev = new InventoryTransactionEvent(this);
        Server.getInstance().getPluginManager().callEvent(ev);
        if (ev.isCancelled()) {
            for (Inventory inventory : this.inventories) {
                if (inventory instanceof PlayerInventory) {
                    ((PlayerInventory)inventory).sendArmorContents(this.getSource());
                }
                inventory.sendContents(this.getSource());
            }
            return false;
        }
        for (Transaction transaction : this.transactions) {
            transaction.getInventory().setItem(transaction.getSlot(), transaction.getTargetItem());
        }
        this.hasExecuted = true;
        return true;
    }

    @Override
    public boolean hasExecuted() {
        return this.hasExecuted;
    }
}

