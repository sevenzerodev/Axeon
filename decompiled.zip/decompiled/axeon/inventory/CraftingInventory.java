/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.inventory;

import cn.axeon.inventory.BaseInventory;
import cn.axeon.inventory.Inventory;
import cn.axeon.inventory.InventoryHolder;
import cn.axeon.inventory.InventoryType;

public class CraftingInventory
extends BaseInventory {
    private Inventory resultInventory;

    public CraftingInventory(InventoryHolder holder, Inventory resultInventory, InventoryType type) {
        super(holder, type);
        if (!type.getDefaultTitle().equals("Crafting")) {
            throw new IllegalStateException("Invalid Inventory type, expected CRAFTING or WORKBENCH");
        }
        this.resultInventory = resultInventory;
    }

    public Inventory getResultInventory() {
        return this.resultInventory;
    }

    @Override
    public int getSize() {
        return this.getResultInventory().getSize() + super.getSize();
    }
}

