/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.inventory;

import cn.axeon.Server;
import cn.axeon.inventory.Recipe;
import cn.axeon.item.Item;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class ShapedRecipe
implements Recipe {
    private Item output;
    private UUID uuid = null;
    private Map<Character, String> shapes = new HashMap<Character, String>();
    private Map<Integer, Map<Integer, Item>> ingredients = new HashMap<Integer, Map<Integer, Item>>();
    private Map<Character, List<Entry>> shapeItems = new HashMap<Character, List<Entry>>();

    public ShapedRecipe(Item result, String ... shape) {
        if (shape.length == 0) {
            throw new IllegalArgumentException("Must provide a shape");
        }
        if (shape.length > 3) {
            throw new IllegalStateException("Crafting recipes should be 1, 2, 3 rows, not " + shape.length);
        }
        for (int y = 0; y < shape.length; ++y) {
            final String row = shape[y];
            if (row.length() == 0 || row.length() > 3) {
                throw new IllegalStateException("Crafting rows should be 1, 2, 3 characters, not " + row.length());
            }
            this.ingredients.put(y, (Map<Integer, Item>)new HashMap<Integer, Item>(){
                {
                    for (int i = 0; i < row.length(); ++i) {
                        this.put(i, null);
                    }
                }
            });
            int len = row.length();
            for (int i = 0; i < len; ++i) {
                this.shapes.put(Character.valueOf(row.charAt(i)), null);
                if (!this.shapeItems.containsKey(Character.valueOf(row.charAt(i)))) {
                    this.shapeItems.put(Character.valueOf(row.charAt(i)), new ArrayList<Entry>(Arrays.asList(new Entry(i, y))));
                    continue;
                }
                this.shapeItems.get(Character.valueOf(row.charAt(i))).add(new Entry(i, y));
            }
        }
        this.output = result.clone();
    }

    public int getWidth() {
        return this.ingredients.get(0).size();
    }

    public int getHeight() {
        return this.ingredients.size();
    }

    @Override
    public Item getResult() {
        return this.output;
    }

    @Override
    public UUID getId() {
        return this.uuid;
    }

    @Override
    public void setId(UUID id) {
        if (this.uuid != null) {
            throw new IllegalStateException("Id is already set");
        }
        this.uuid = id;
    }

    public ShapedRecipe setIngredient(String key, Item item) {
        return this.setIngredient(key.charAt(0), item);
    }

    public ShapedRecipe setIngredient(char key, Item item) {
        if (!this.shapes.containsKey(Character.valueOf(key))) {
            throw new RuntimeException("Symbol does not appear in the shape: " + key);
        }
        this.fixRecipe(key, item);
        return this;
    }

    protected void fixRecipe(char key, Item item) {
        for (Entry entry : this.shapeItems.get(Character.valueOf(key))) {
            this.ingredients.get(entry.y).put(entry.x, item.clone());
        }
    }

    public Map<Integer, Map<Integer, Item>> getIngredientMap() {
        HashMap<Integer, Map<Integer, Item>> ingredients = new HashMap<Integer, Map<Integer, Item>>();
        for (int y : this.ingredients.keySet()) {
            Map<Integer, Item> row = this.ingredients.get(y);
            ingredients.put(y, new HashMap());
            for (int x : row.keySet()) {
                Item ingredient = row.get(x);
                if (ingredient != null) {
                    ((Map)ingredients.get(y)).put(x, ingredient.clone());
                    continue;
                }
                ((Map)ingredients.get(y)).put(x, Item.get(0));
            }
        }
        return ingredients;
    }

    public Item getIngredient(int x, int y) {
        if (this.ingredients.containsKey(y) && this.ingredients.get(y).containsKey(x)) {
            return this.ingredients.get(y).get(x) != null ? this.ingredients.get(y).get(x) : Item.get(0);
        }
        return Item.get(0);
    }

    public Map<Character, String> getShape() {
        return this.shapes;
    }

    @Override
    public void registerToCraftingManager() {
        Server.getInstance().getCraftingManager().registerShapedRecipe(this);
    }

    public static class Entry {
        public int x;
        public int y;

        public Entry(int x, int y) {
            this.x = x;
            this.y = y;
        }
    }
}

