/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.inventory;

import cn.axeon.inventory.Inventory;

public interface InventoryHolder {
    public Inventory getInventory();
}

