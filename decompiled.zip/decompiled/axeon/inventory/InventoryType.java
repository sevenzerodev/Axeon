/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.inventory;

import java.util.HashMap;
import java.util.Map;

public class InventoryType {
    public static final int CHEST = 0;
    public static final int DOUBLE_CHEST = 1;
    public static final int PLAYER = 2;
    public static final int FURNACE = 3;
    public static final int CRAFTING = 4;
    public static final int WORKBENCH = 5;
    public static final int STONECUTTER = 6;
    public static final int BREWING_STAND = 7;
    public static final int ANVIL = 8;
    public static final int ENCHANT_TABLE = 9;
    public static final int DISPENSER = 10;
    public static final int DROPPER = 11;
    public static final int HOPPER = 12;
    private static Map<Integer, InventoryType> defaults = new HashMap<Integer, InventoryType>();
    private int size;
    private String title;
    private int typeId;

    public static InventoryType get(int index) {
        return defaults.containsKey(index) ? defaults.get(index) : null;
    }

    public static void init() {
        if (!defaults.isEmpty()) {
            return;
        }
        defaults.put(0, new InventoryType(27, "Chest", 0));
        defaults.put(1, new InventoryType(54, "Double Chest", 0));
        defaults.put(2, new InventoryType(49, "Player", 0));
        defaults.put(3, new InventoryType(3, "Furnace", 2));
        defaults.put(4, new InventoryType(5, "Crafting", 1));
        defaults.put(5, new InventoryType(10, "Crafting", 1));
        defaults.put(6, new InventoryType(10, "Crafting", 1));
        defaults.put(9, new InventoryType(2, "Enchant", 3));
        defaults.put(7, new InventoryType(4, "Brewing", 4));
        defaults.put(8, new InventoryType(3, "Anvil", 5));
        defaults.put(10, new InventoryType(9, "Dispenser", 6));
        defaults.put(11, new InventoryType(9, "Dropper", 7));
        defaults.put(12, new InventoryType(5, "Hopper", 8));
    }

    public InventoryType(int defaultSize, String defaultBlockEntity, int typeId) {
        this.size = defaultSize;
        this.title = defaultBlockEntity;
        this.typeId = typeId;
    }

    public int getDefaultSize() {
        return this.size;
    }

    public String getDefaultTitle() {
        return this.title;
    }

    public int getNetworkType() {
        return this.typeId;
    }
}

