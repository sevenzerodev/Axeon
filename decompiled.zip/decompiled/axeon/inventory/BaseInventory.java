/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.inventory;

import cn.axeon.Player;
import cn.axeon.Server;
import cn.axeon.block.BlockAir;
import cn.axeon.entity.Entity;
import cn.axeon.event.entity.EntityInventoryChangeEvent;
import cn.axeon.event.inventory.InventoryOpenEvent;
import cn.axeon.inventory.DoubleChestInventory;
import cn.axeon.inventory.Inventory;
import cn.axeon.inventory.InventoryHolder;
import cn.axeon.inventory.InventoryType;
import cn.axeon.item.Item;
import cn.axeon.item.ItemBlock;
import cn.axeon.network.protocol.ContainerSetContentPacket;
import cn.axeon.network.protocol.ContainerSetSlotPacket;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

public abstract class BaseInventory
implements Inventory {
    protected InventoryType type;
    protected int maxStackSize = 64;
    protected int size;
    protected String name;
    protected String title;
    protected Map<Integer, Item> slots = new HashMap<Integer, Item>();
    protected Set<Player> viewers = new HashSet<Player>();
    protected InventoryHolder holder;

    public BaseInventory(InventoryHolder holder, InventoryType type) {
        this(holder, type, new HashMap<Integer, Item>());
    }

    public BaseInventory(InventoryHolder holder, InventoryType type, Map<Integer, Item> items) {
        this(holder, type, items, null);
    }

    public BaseInventory(InventoryHolder holder, InventoryType type, Map<Integer, Item> items, Integer overrideSize) {
        this(holder, type, items, overrideSize, null);
    }

    public BaseInventory(InventoryHolder holder, InventoryType type, Map<Integer, Item> items, Integer overrideSize, String overrideTitle) {
        this.holder = holder;
        this.type = type;
        this.size = overrideSize != null ? overrideSize.intValue() : this.type.getDefaultSize();
        this.title = overrideTitle != null ? overrideTitle : this.type.getDefaultTitle();
        this.name = this.type.getDefaultTitle();
        if (!(this instanceof DoubleChestInventory)) {
            this.setContents(items);
        }
    }

    @Override
    public int getSize() {
        return this.size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    @Override
    public int getMaxStackSize() {
        return this.maxStackSize;
    }

    @Override
    public String getName() {
        return this.name;
    }

    @Override
    public String getTitle() {
        return this.title;
    }

    @Override
    public Item getItem(int index) {
        return this.slots.containsKey(index) ? this.slots.get(index).clone() : new ItemBlock(new BlockAir(), null, 0);
    }

    @Override
    public Map<Integer, Item> getContents() {
        return new HashMap<Integer, Item>(this.slots);
    }

    @Override
    public void setContents(Map<Integer, Item> items) {
        if (items.size() > this.size) {
            TreeMap<Integer, Item> newItems = new TreeMap<Integer, Item>();
            for (Map.Entry<Integer, Item> entry : items.entrySet()) {
                newItems.put(entry.getKey(), entry.getValue());
            }
            items = newItems;
            newItems = new TreeMap();
            int i = 0;
            for (Map.Entry<Integer, Item> entry : items.entrySet()) {
                newItems.put(entry.getKey(), entry.getValue());
                if (++i < this.size) continue;
                break;
            }
            items = newItems;
        }
        for (int i = 0; i < this.size; ++i) {
            if (!items.containsKey(i)) {
                if (!this.slots.containsKey(i)) continue;
                this.clear(i);
                continue;
            }
            if (this.setItem(i, items.get(i))) continue;
            this.clear(i);
        }
    }

    @Override
    public boolean setItem(int index, Item item) {
        item = item.clone();
        if (index < 0 || index >= this.size) {
            return false;
        }
        if (item.getId() == 0 || item.getCount() <= 0) {
            return this.clear(index);
        }
        InventoryHolder holder = this.getHolder();
        if (holder instanceof Entity) {
            EntityInventoryChangeEvent ev = new EntityInventoryChangeEvent((Entity)((Object)holder), this.getItem(index), item, index);
            Server.getInstance().getPluginManager().callEvent(ev);
            if (ev.isCancelled()) {
                this.sendSlot(index, this.getViewers());
                return false;
            }
            item = ev.getNewItem();
        }
        Item old = this.getItem(index);
        this.slots.put(index, item.clone());
        this.onSlotChange(index, old);
        return true;
    }

    @Override
    public boolean contains(Item item) {
        int count = Math.max(1, item.getCount());
        boolean checkDamage = item.hasMeta();
        boolean checkTag = item.getCompoundTag() != null;
        for (Item i : this.getContents().values()) {
            if (!item.equals(i, checkDamage, checkTag) || (count -= i.getCount()) > 0) continue;
            return true;
        }
        return false;
    }

    @Override
    public Map<Integer, Item> all(Item item) {
        HashMap<Integer, Item> slots = new HashMap<Integer, Item>();
        boolean checkDamage = item.hasMeta();
        boolean checkTag = item.getCompoundTag() != null;
        for (Map.Entry<Integer, Item> entry : this.getContents().entrySet()) {
            if (!item.equals(entry.getValue(), checkDamage, checkTag)) continue;
            slots.put(entry.getKey(), entry.getValue());
        }
        return slots;
    }

    @Override
    public void remove(Item item) {
        boolean checkDamage = item.hasMeta();
        boolean checkTag = item.getCompoundTag() != null;
        for (Map.Entry<Integer, Item> entry : this.getContents().entrySet()) {
            if (!item.equals(entry.getValue(), checkDamage, checkTag)) continue;
            this.clear(entry.getKey());
        }
    }

    @Override
    public int first(Item item) {
        int count = Math.max(1, item.getCount());
        boolean checkDamage = item.hasMeta();
        boolean checkTag = item.getCompoundTag() != null;
        for (Map.Entry<Integer, Item> entry : this.getContents().entrySet()) {
            if (!item.equals(entry.getValue(), checkDamage, checkTag) || entry.getValue().getCount() < count) continue;
            return entry.getKey();
        }
        return -1;
    }

    @Override
    public int firstEmpty(Item item) {
        for (int i = 0; i < this.size; ++i) {
            if (this.getItem(i).getId() != 0) continue;
            return i;
        }
        return -1;
    }

    @Override
    public boolean canAddItem(Item item) {
        item = item.clone();
        boolean checkDamage = item.hasMeta();
        boolean checkTag = item.getCompoundTag() != null;
        for (int i = 0; i < this.getSize(); ++i) {
            Item slot = this.getItem(i);
            if (item.equals(slot, checkDamage, checkTag)) {
                int diff = slot.getMaxStackSize() - slot.getCount();
                if (diff > 0) {
                    item.setCount(item.getCount() - diff);
                }
            } else if (slot.getId() == 0) {
                item.setCount(item.getCount() - this.getMaxStackSize());
            }
            if (item.getCount() > 0) continue;
            return true;
        }
        return false;
    }

    @Override
    public Item[] addItem(Item ... slots) {
        ArrayList<Item> itemSlots = new ArrayList<Item>();
        for (Item item : slots) {
            if (item.getId() == 0 || item.getCount() <= 0) continue;
            itemSlots.add(item.clone());
        }
        ArrayList<Integer> emptySlots = new ArrayList<Integer>();
        for (int i = 0; i < this.getSize(); ++i) {
            Item item = this.getItem(i);
            if (item.getId() == 0 || item.getCount() <= 0) {
                emptySlots.add(i);
            }
            for (Item slot : new ArrayList(itemSlots)) {
                if (!slot.equals(item) || item.getCount() >= item.getMaxStackSize()) continue;
                int amount = Math.min(item.getMaxStackSize() - item.getCount(), slot.getCount());
                if ((amount = Math.min(amount, this.getMaxStackSize())) <= 0) continue;
                slot.setCount(slot.getCount() - amount);
                item.setCount(item.getCount() + amount);
                this.setItem(i, item);
                if (slot.getCount() > 0) continue;
                itemSlots.remove(slot);
            }
            if (itemSlots.isEmpty()) break;
        }
        if (!itemSlots.isEmpty() && !emptySlots.isEmpty()) {
            Iterator iterator = emptySlots.iterator();
            while (iterator.hasNext()) {
                int slotIndex = (Integer)iterator.next();
                if (itemSlots.isEmpty()) continue;
                Item item = (Item)itemSlots.get(0);
                int amount = Math.min(item.getMaxStackSize(), item.getCount());
                amount = Math.min(amount, this.getMaxStackSize());
                item.setCount(item.getCount() - amount);
                Item item2 = item.clone();
                item2.setCount(amount);
                this.setItem(slotIndex, item2);
                if (item.getCount() > 0) continue;
                itemSlots.remove(item);
            }
        }
        return (Item[])itemSlots.stream().toArray(Item[]::new);
    }

    @Override
    public Item[] removeItem(Item ... slots) {
        ArrayList<Item> itemSlots = new ArrayList<Item>();
        for (Item slot : slots) {
            if (slot.getId() == 0 || slot.getCount() <= 0) continue;
            itemSlots.add(slot.clone());
        }
        for (int i = 0; i < this.getSize(); ++i) {
            Item item = this.getItem(i);
            if (item.getId() == 0 || item.getCount() <= 0) continue;
            for (Item slot : new ArrayList(itemSlots)) {
                if (!slot.equals(item, item.hasMeta(), item.getCompoundTag() != null)) continue;
                int amount = Math.min(item.getCount(), slot.getCount());
                slot.setCount(slot.getCount() - amount);
                item.setCount(item.getCount() - amount);
                this.setItem(i, item);
                if (slot.getCount() > 0) continue;
                itemSlots.remove(slot);
            }
            if (itemSlots.size() == 0) break;
        }
        return (Item[])itemSlots.stream().toArray(Item[]::new);
    }

    @Override
    public boolean clear(int index) {
        if (this.slots.containsKey(index)) {
            Item item = new ItemBlock(new BlockAir(), null, 0);
            Item old = this.slots.get(index);
            InventoryHolder holder = this.getHolder();
            if (holder instanceof Entity) {
                EntityInventoryChangeEvent ev = new EntityInventoryChangeEvent((Entity)((Object)holder), old, item, index);
                Server.getInstance().getPluginManager().callEvent(ev);
                if (ev.isCancelled()) {
                    this.sendSlot(index, this.getViewers());
                    return false;
                }
                item = ev.getNewItem();
            }
            if (item.getId() != 0) {
                this.slots.put(index, ((Item)item).clone());
            } else {
                this.slots.remove(index);
            }
            this.onSlotChange(index, old);
        }
        return true;
    }

    @Override
    public void clearAll() {
        for (Integer index : this.getContents().keySet()) {
            this.clear(index);
        }
    }

    @Override
    public Set<Player> getViewers() {
        return this.viewers;
    }

    @Override
    public InventoryHolder getHolder() {
        return this.holder;
    }

    @Override
    public void setMaxStackSize(int maxStackSize) {
        this.maxStackSize = maxStackSize;
    }

    @Override
    public boolean open(Player who) {
        InventoryOpenEvent ev = new InventoryOpenEvent(this, who);
        who.getServer().getPluginManager().callEvent(ev);
        if (ev.isCancelled()) {
            return false;
        }
        this.onOpen(who);
        return true;
    }

    @Override
    public void close(Player who) {
        this.onClose(who);
    }

    @Override
    public void onOpen(Player who) {
        this.viewers.add(who);
    }

    @Override
    public void onClose(Player who) {
        this.viewers.remove(who);
    }

    @Override
    public void onSlotChange(int index, Item before) {
        this.sendSlot(index, this.getViewers());
    }

    @Override
    public void sendContents(Player player) {
        this.sendContents(new Player[]{player});
    }

    @Override
    public void sendContents(Player[] players) {
        ContainerSetContentPacket pk = new ContainerSetContentPacket();
        pk.slots = new Item[this.getSize()];
        for (int i = 0; i < this.getSize(); ++i) {
            pk.slots[i] = this.getItem(i);
        }
        for (Player player : players) {
            int id = player.getWindowId(this);
            if (id == -1 || !player.spawned) {
                this.close(player);
                continue;
            }
            pk.windowid = (byte)id;
            player.dataPacket(pk);
        }
    }

    @Override
    public void sendContents(Collection<Player> players) {
        this.sendContents((Player[])players.stream().toArray(Player[]::new));
    }

    @Override
    public void sendSlot(int index, Player player) {
        this.sendSlot(index, new Player[]{player});
    }

    @Override
    public void sendSlot(int index, Player[] players) {
        ContainerSetSlotPacket pk = new ContainerSetSlotPacket();
        pk.slot = index;
        pk.item = this.getItem(index).clone();
        for (Player player : players) {
            int id = player.getWindowId(this);
            if (id == -1) {
                this.close(player);
                continue;
            }
            pk.windowid = (byte)id;
            player.dataPacket(pk);
        }
    }

    @Override
    public void sendSlot(int index, Collection<Player> players) {
        this.sendSlot(index, (Player[])players.stream().toArray(Player[]::new));
    }

    @Override
    public InventoryType getType() {
        return this.type;
    }
}

