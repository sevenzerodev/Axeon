/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.inventory;

import cn.axeon.Server;
import cn.axeon.inventory.Recipe;
import cn.axeon.item.Item;
import java.util.UUID;

public class BrewingRecipe
implements Recipe {
    private UUID id;
    private Item output;
    private Item potion;
    private Item ingredient;

    public BrewingRecipe(Item result, Item ingredient, Item potion) {
        this.output = result.clone();
        this.ingredient = ingredient.clone();
        this.potion = potion.clone();
    }

    @Override
    public UUID getId() {
        return this.id;
    }

    @Override
    public void setId(UUID uuid) {
        if (this.id != null) {
            throw new IllegalStateException("Id is already set");
        }
        this.id = uuid;
    }

    public void setInput(Item item) {
        this.ingredient = item.clone();
    }

    public Item getInput() {
        return this.ingredient.clone();
    }

    public Item getPotion() {
        return this.potion.clone();
    }

    @Override
    public Item getResult() {
        return this.output.clone();
    }

    @Override
    public void registerToCraftingManager() {
        Server.getInstance().getCraftingManager().registerBrewingRecipe(this);
    }
}

