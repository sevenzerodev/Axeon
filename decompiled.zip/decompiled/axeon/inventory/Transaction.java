/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.inventory;

import cn.axeon.inventory.Inventory;
import cn.axeon.item.Item;

public interface Transaction {
    public Inventory getInventory();

    public int getSlot();

    public Item getSourceItem();

    public Item getTargetItem();

    public long getCreationTime();
}

