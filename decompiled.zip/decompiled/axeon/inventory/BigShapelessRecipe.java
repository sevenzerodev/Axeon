/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.inventory;

import cn.axeon.inventory.ShapelessRecipe;
import cn.axeon.item.Item;

public class BigShapelessRecipe
extends ShapelessRecipe {
    public BigShapelessRecipe(Item result) {
        super(result);
    }
}

