/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.inventory;

import cn.axeon.inventory.Inventory;
import cn.axeon.inventory.Transaction;
import cn.axeon.item.Item;

public class BaseTransaction
implements Transaction {
    protected Inventory inventory;
    protected int slot;
    protected Item sourceItem;
    protected Item targetItem;
    protected long creationTime;

    public BaseTransaction(Inventory inventory, int slot, Item sourceItem, Item targetItem) {
        this.inventory = inventory;
        this.slot = slot;
        this.sourceItem = sourceItem.clone();
        this.targetItem = targetItem.clone();
        this.creationTime = System.currentTimeMillis();
    }

    @Override
    public long getCreationTime() {
        return this.creationTime;
    }

    @Override
    public Inventory getInventory() {
        return this.inventory;
    }

    @Override
    public int getSlot() {
        return this.slot;
    }

    @Override
    public Item getSourceItem() {
        return this.sourceItem.clone();
    }

    @Override
    public Item getTargetItem() {
        return this.targetItem.clone();
    }
}

