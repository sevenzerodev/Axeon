/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.inventory;

import cn.axeon.Player;
import cn.axeon.blockentity.BlockEntityChest;
import cn.axeon.inventory.ContainerInventory;
import cn.axeon.inventory.InventoryType;
import cn.axeon.level.Level;
import cn.axeon.network.protocol.BlockEventPacket;

public class ChestInventory
extends ContainerInventory {
    public ChestInventory(BlockEntityChest chest) {
        super(chest, InventoryType.get(0));
    }

    @Override
    public BlockEntityChest getHolder() {
        return (BlockEntityChest)this.holder;
    }

    @Override
    public void onOpen(Player who) {
        super.onOpen(who);
        if (this.getViewers().size() == 1) {
            BlockEventPacket pk = new BlockEventPacket();
            pk.x = (int)this.getHolder().getX();
            pk.y = (int)this.getHolder().getY();
            pk.z = (int)this.getHolder().getZ();
            pk.case1 = 1;
            pk.case2 = 2;
            Level level = this.getHolder().getLevel();
            if (level != null) {
                level.addChunkPacket((int)this.getHolder().getX() >> 4, (int)this.getHolder().getZ() >> 4, pk);
            }
        }
    }

    @Override
    public void onClose(Player who) {
        if (this.getViewers().size() == 1) {
            BlockEventPacket pk = new BlockEventPacket();
            pk.x = (int)this.getHolder().getX();
            pk.y = (int)this.getHolder().getY();
            pk.z = (int)this.getHolder().getZ();
            pk.case1 = 1;
            pk.case2 = 0;
            Level level = this.getHolder().getLevel();
            if (level != null) {
                level.addChunkPacket((int)this.getHolder().getX() >> 4, (int)this.getHolder().getZ() >> 4, pk);
            }
        }
        super.onClose(who);
    }
}

