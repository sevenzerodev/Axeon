/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.inventory;

import cn.axeon.Player;
import cn.axeon.inventory.ContainerInventory;
import cn.axeon.inventory.FakeBlockMenu;
import cn.axeon.inventory.InventoryType;
import cn.axeon.level.Position;

public class AnvilInventory
extends ContainerInventory {
    public AnvilInventory(Position position) {
        super(null, InventoryType.get(8));
        this.holder = new FakeBlockMenu(this, position);
    }

    @Override
    public FakeBlockMenu getHolder() {
        return (FakeBlockMenu)this.holder;
    }

    @Override
    public void onClose(Player who) {
        super.onClose(who);
        for (int i = 0; i < 2; ++i) {
            this.getHolder().getLevel().dropItem(this.getHolder().add(0.5, 0.5, 0.5), this.getItem(i));
            this.clear(i);
        }
    }
}

