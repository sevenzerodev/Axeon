/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.inventory;

import cn.axeon.blockentity.BlockEntityBrewingStand;
import cn.axeon.inventory.ContainerInventory;
import cn.axeon.inventory.InventoryType;
import cn.axeon.item.Item;

public class BrewingInventory
extends ContainerInventory {
    public BrewingInventory(BlockEntityBrewingStand brewingStand) {
        super(brewingStand, InventoryType.get(7));
    }

    @Override
    public BlockEntityBrewingStand getHolder() {
        return (BlockEntityBrewingStand)this.holder;
    }

    public Item getIngredient() {
        return this.getItem(0);
    }

    public void setIngredient(Item item) {
        this.setItem(0, item);
    }

    @Override
    public void onSlotChange(int index, Item before) {
        super.onSlotChange(index, before);
        this.getHolder().scheduleUpdate();
    }
}

