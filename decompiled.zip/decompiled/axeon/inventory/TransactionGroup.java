/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.inventory;

import cn.axeon.inventory.Inventory;
import cn.axeon.inventory.Transaction;
import java.util.Set;

public interface TransactionGroup {
    public long getCreationTime();

    public Set<Transaction> getTransactions();

    public Set<Inventory> getInventories();

    public void addTransaction(Transaction var1);

    public boolean canExecute();

    public boolean execute();

    public boolean hasExecuted();
}

