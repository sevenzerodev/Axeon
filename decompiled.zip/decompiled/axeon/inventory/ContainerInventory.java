/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.inventory;

import cn.axeon.Player;
import cn.axeon.inventory.BaseInventory;
import cn.axeon.inventory.InventoryHolder;
import cn.axeon.inventory.InventoryType;
import cn.axeon.item.Item;
import cn.axeon.math.Vector3;
import cn.axeon.network.protocol.ContainerClosePacket;
import cn.axeon.network.protocol.ContainerOpenPacket;
import java.util.Map;

public abstract class ContainerInventory
extends BaseInventory {
    public ContainerInventory(InventoryHolder holder, InventoryType type) {
        super(holder, type);
    }

    public ContainerInventory(InventoryHolder holder, InventoryType type, Map<Integer, Item> items) {
        super(holder, type, items);
    }

    public ContainerInventory(InventoryHolder holder, InventoryType type, Map<Integer, Item> items, Integer overrideSize) {
        super(holder, type, items, overrideSize);
    }

    public ContainerInventory(InventoryHolder holder, InventoryType type, Map<Integer, Item> items, Integer overrideSize, String overrideTitle) {
        super(holder, type, items, overrideSize, overrideTitle);
    }

    @Override
    public void onOpen(Player who) {
        super.onOpen(who);
        ContainerOpenPacket pk = new ContainerOpenPacket();
        pk.windowid = (byte)who.getWindowId(this);
        pk.type = (byte)this.getType().getNetworkType();
        pk.slots = this.getSize();
        InventoryHolder holder = this.getHolder();
        if (holder instanceof Vector3) {
            pk.x = (int)((Vector3)((Object)holder)).getX();
            pk.y = (int)((Vector3)((Object)holder)).getY();
            pk.z = (int)((Vector3)((Object)holder)).getZ();
        } else {
            pk.z = 0;
            pk.y = 0;
            pk.x = 0;
        }
        who.dataPacket(pk);
        this.sendContents(who);
    }

    @Override
    public void onClose(Player who) {
        ContainerClosePacket pk = new ContainerClosePacket();
        pk.windowid = (byte)who.getWindowId(this);
        who.dataPacket(pk);
        super.onClose(who);
    }
}

