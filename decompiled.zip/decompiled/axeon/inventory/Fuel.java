/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.inventory;

import java.util.Map;
import java.util.TreeMap;

public abstract class Fuel {
    public static Map<Integer, Short> duration = new TreeMap<Integer, Short>();

    static {
        duration.put(263, (short)1600);
        duration.put(173, (short)16000);
        duration.put(17, (short)300);
        duration.put(5, (short)300);
        duration.put(6, (short)100);
        duration.put(271, (short)200);
        duration.put(270, (short)200);
        duration.put(268, (short)200);
        duration.put(269, (short)200);
        duration.put(290, (short)200);
        duration.put(280, (short)100);
        duration.put(85, (short)300);
        duration.put(107, (short)300);
        duration.put(183, (short)300);
        duration.put(184, (short)300);
        duration.put(185, (short)300);
        duration.put(187, (short)300);
        duration.put(186, (short)300);
        duration.put(53, (short)300);
        duration.put(134, (short)300);
        duration.put(135, (short)300);
        duration.put(136, (short)300);
        duration.put(96, (short)300);
        duration.put(58, (short)300);
        duration.put(47, (short)300);
        duration.put(54, (short)300);
        duration.put(325, (short)20000);
    }
}

