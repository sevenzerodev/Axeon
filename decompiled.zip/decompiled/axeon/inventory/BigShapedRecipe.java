/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.inventory;

import cn.axeon.inventory.ShapedRecipe;
import cn.axeon.item.Item;

public class BigShapedRecipe
extends ShapedRecipe {
    public BigShapedRecipe(Item result, String ... shape) {
        super(result, shape);
    }
}

