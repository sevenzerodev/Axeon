/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.inventory;

import cn.axeon.inventory.Inventory;
import cn.axeon.inventory.InventoryHolder;
import cn.axeon.level.Position;

public class FakeBlockMenu
extends Position
implements InventoryHolder {
    private Inventory inventory;

    public FakeBlockMenu(Inventory inventory, Position pos) {
        super(pos.x, pos.y, pos.z, pos.level);
        this.inventory = inventory;
    }

    @Override
    public Inventory getInventory() {
        return this.inventory;
    }
}

