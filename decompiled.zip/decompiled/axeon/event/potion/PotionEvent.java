/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.event.potion;

import cn.axeon.event.Event;
import cn.axeon.potion.Potion;

public abstract class PotionEvent
extends Event {
    private Potion potion;

    public PotionEvent(Potion potion) {
        this.potion = potion;
    }

    public Potion getPotion() {
        return this.potion;
    }

    public void setPotion(Potion potion) {
        this.potion = potion;
    }
}

