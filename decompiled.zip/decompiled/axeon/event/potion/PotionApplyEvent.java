/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.event.potion;

import cn.axeon.entity.Entity;
import cn.axeon.event.Cancellable;
import cn.axeon.event.HandlerList;
import cn.axeon.event.potion.PotionEvent;
import cn.axeon.potion.Potion;

public class PotionApplyEvent
extends PotionEvent
implements Cancellable {
    private static final HandlerList handlers = new HandlerList();
    private Entity entity;

    public static HandlerList getHandlers() {
        return handlers;
    }

    public PotionApplyEvent(Potion potion, Entity entity) {
        super(potion);
        this.entity = entity;
    }

    public Entity getEntity() {
        return this.entity;
    }
}

