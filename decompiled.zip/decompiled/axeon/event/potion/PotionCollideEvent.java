/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.event.potion;

import cn.axeon.entity.item.EntityPotion;
import cn.axeon.event.Cancellable;
import cn.axeon.event.HandlerList;
import cn.axeon.event.potion.PotionEvent;
import cn.axeon.potion.Potion;

public class PotionCollideEvent
extends PotionEvent
implements Cancellable {
    private static final HandlerList handlers = new HandlerList();
    private EntityPotion thrownPotion;

    public static HandlerList getHandlers() {
        return handlers;
    }

    public PotionCollideEvent(Potion potion, EntityPotion thrownPotion) {
        super(potion);
        this.thrownPotion = thrownPotion;
    }

    public EntityPotion getThrownPotion() {
        return this.thrownPotion;
    }
}

