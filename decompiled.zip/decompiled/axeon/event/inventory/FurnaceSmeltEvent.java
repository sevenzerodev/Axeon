/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.event.inventory;

import cn.axeon.blockentity.BlockEntityFurnace;
import cn.axeon.event.Cancellable;
import cn.axeon.event.HandlerList;
import cn.axeon.event.block.BlockEvent;
import cn.axeon.item.Item;

public class FurnaceSmeltEvent
extends BlockEvent
implements Cancellable {
    private static final HandlerList handlers = new HandlerList();
    private BlockEntityFurnace furnace;
    private Item source;
    private Item result;

    public static HandlerList getHandlers() {
        return handlers;
    }

    public FurnaceSmeltEvent(BlockEntityFurnace furnace, Item source, Item result) {
        super(furnace.getBlock());
        this.source = source.clone();
        this.source.setCount(1);
        this.result = result;
        this.furnace = furnace;
    }

    public BlockEntityFurnace getFurnace() {
        return this.furnace;
    }

    public Item getSource() {
        return this.source;
    }

    public Item getResult() {
        return this.result;
    }

    public void setResult(Item result) {
        this.result = result;
    }
}

