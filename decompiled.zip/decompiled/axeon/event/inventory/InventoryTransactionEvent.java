/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.event.inventory;

import cn.axeon.event.Cancellable;
import cn.axeon.event.Event;
import cn.axeon.event.HandlerList;
import cn.axeon.inventory.TransactionGroup;

public class InventoryTransactionEvent
extends Event
implements Cancellable {
    private static final HandlerList handlers = new HandlerList();
    private TransactionGroup transaction;

    public static HandlerList getHandlers() {
        return handlers;
    }

    public InventoryTransactionEvent(TransactionGroup transaction) {
        this.transaction = transaction;
    }

    public TransactionGroup getTransaction() {
        return this.transaction;
    }
}

