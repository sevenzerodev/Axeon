/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.event.inventory;

import cn.axeon.blockentity.BlockEntityFurnace;
import cn.axeon.event.Cancellable;
import cn.axeon.event.HandlerList;
import cn.axeon.event.block.BlockEvent;
import cn.axeon.item.Item;

public class FurnaceBurnEvent
extends BlockEvent
implements Cancellable {
    private static final HandlerList handlers = new HandlerList();
    private BlockEntityFurnace furnace;
    private Item fuel;
    private short burnTime;
    private boolean burning = true;

    public static HandlerList getHandlers() {
        return handlers;
    }

    public FurnaceBurnEvent(BlockEntityFurnace furnace, Item fuel, short burnTime) {
        super(furnace.getBlock());
        this.fuel = fuel;
        this.burnTime = burnTime;
        this.furnace = furnace;
    }

    public BlockEntityFurnace getFurnace() {
        return this.furnace;
    }

    public Item getFuel() {
        return this.fuel;
    }

    public short getBurnTime() {
        return this.burnTime;
    }

    public void setBurnTime(short burnTime) {
        this.burnTime = burnTime;
    }

    public boolean isBurning() {
        return this.burning;
    }

    public void setBurning(boolean burning) {
        this.burning = burning;
    }
}

