/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.event.inventory;

import cn.axeon.Player;
import cn.axeon.event.Cancellable;
import cn.axeon.event.HandlerList;
import cn.axeon.event.inventory.InventoryEvent;
import cn.axeon.inventory.Inventory;

public class InventoryOpenEvent
extends InventoryEvent
implements Cancellable {
    private static final HandlerList handlers = new HandlerList();
    private Player who;

    public static HandlerList getHandlers() {
        return handlers;
    }

    public InventoryOpenEvent(Inventory inventory, Player who) {
        super(inventory);
        this.who = who;
    }

    public Player getPlayer() {
        return this.who;
    }
}

