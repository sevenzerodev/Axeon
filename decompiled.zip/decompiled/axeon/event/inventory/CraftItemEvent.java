/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.event.inventory;

import cn.axeon.Player;
import cn.axeon.event.Cancellable;
import cn.axeon.event.Event;
import cn.axeon.event.HandlerList;
import cn.axeon.inventory.Recipe;
import cn.axeon.item.Item;

public class CraftItemEvent
extends Event
implements Cancellable {
    private static final HandlerList handlers = new HandlerList();
    private Item[] input = new Item[0];
    private Recipe recipe;
    private Player player;

    public static HandlerList getHandlers() {
        return handlers;
    }

    public CraftItemEvent(Player player, Item[] input, Recipe recipe) {
        this.player = player;
        this.input = input;
        this.recipe = recipe;
    }

    public Item[] getInput() {
        Item[] items = new Item[this.input.length];
        for (int i = 0; i < this.input.length; ++i) {
            items[i] = this.input[i].clone();
        }
        return items;
    }

    public Recipe getRecipe() {
        return this.recipe;
    }

    public Player getPlayer() {
        return this.player;
    }
}

