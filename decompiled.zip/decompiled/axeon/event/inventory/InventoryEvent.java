/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.event.inventory;

import cn.axeon.Player;
import cn.axeon.event.Event;
import cn.axeon.inventory.Inventory;

public abstract class InventoryEvent
extends Event {
    protected Inventory inventory;

    public InventoryEvent(Inventory inventory) {
        this.inventory = inventory;
    }

    public Inventory getInventory() {
        return this.inventory;
    }

    public Player[] getViewers() {
        return (Player[])this.inventory.getViewers().stream().toArray(Player[]::new);
    }
}

