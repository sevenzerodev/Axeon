/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.event.inventory;

import cn.axeon.entity.item.EntityItem;
import cn.axeon.event.Cancellable;
import cn.axeon.event.HandlerList;
import cn.axeon.event.inventory.InventoryEvent;
import cn.axeon.inventory.Inventory;

public class InventoryPickupItemEvent
extends InventoryEvent
implements Cancellable {
    private static final HandlerList handlers = new HandlerList();
    private EntityItem item;

    public static HandlerList getHandlers() {
        return handlers;
    }

    public InventoryPickupItemEvent(Inventory inventory, EntityItem item) {
        super(inventory);
        this.item = item;
    }

    public EntityItem getItem() {
        return this.item;
    }
}

