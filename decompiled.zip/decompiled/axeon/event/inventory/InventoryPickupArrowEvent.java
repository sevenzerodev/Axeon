/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.event.inventory;

import cn.axeon.entity.projectile.EntityArrow;
import cn.axeon.event.Cancellable;
import cn.axeon.event.HandlerList;
import cn.axeon.event.inventory.InventoryEvent;
import cn.axeon.inventory.Inventory;

public class InventoryPickupArrowEvent
extends InventoryEvent
implements Cancellable {
    private static final HandlerList handlers = new HandlerList();
    private EntityArrow arrow;

    public static HandlerList getHandlers() {
        return handlers;
    }

    public InventoryPickupArrowEvent(Inventory inventory, EntityArrow arrow) {
        super(inventory);
        this.arrow = arrow;
    }

    public EntityArrow getArrow() {
        return this.arrow;
    }
}

