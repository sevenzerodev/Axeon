/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.event.block;

import cn.axeon.block.Block;
import cn.axeon.event.Cancellable;
import cn.axeon.event.HandlerList;
import cn.axeon.event.block.BlockEvent;

public class BlockGrowEvent
extends BlockEvent
implements Cancellable {
    private static final HandlerList handlers = new HandlerList();
    private Block newState;

    public static HandlerList getHandlers() {
        return handlers;
    }

    public BlockGrowEvent(Block block, Block newState) {
        super(block);
        this.newState = newState;
    }

    public Block getNewState() {
        return this.newState;
    }
}

