/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.event.block;

import cn.axeon.block.Block;
import cn.axeon.event.Cancellable;
import cn.axeon.event.HandlerList;
import cn.axeon.event.block.BlockFormEvent;

public class BlockSpreadEvent
extends BlockFormEvent
implements Cancellable {
    private static final HandlerList handlers = new HandlerList();
    private Block source;

    public static HandlerList getHandlers() {
        return handlers;
    }

    public BlockSpreadEvent(Block block, Block source, Block newState) {
        super(block, newState);
        this.source = source;
    }

    public Block getSource() {
        return this.source;
    }
}

