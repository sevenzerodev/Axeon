/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.event.block;

import cn.axeon.block.Block;
import cn.axeon.event.Cancellable;
import cn.axeon.event.HandlerList;
import cn.axeon.event.block.BlockGrowEvent;

public class BlockFormEvent
extends BlockGrowEvent
implements Cancellable {
    private static final HandlerList handlers = new HandlerList();

    public static HandlerList getHandlers() {
        return handlers;
    }

    public BlockFormEvent(Block block, Block newState) {
        super(block, newState);
    }
}

