/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.event.block;

import cn.axeon.Player;
import cn.axeon.block.Block;
import cn.axeon.event.Cancellable;
import cn.axeon.event.HandlerList;
import cn.axeon.event.block.BlockEvent;
import cn.axeon.item.Item;

public class BlockPlaceEvent
extends BlockEvent
implements Cancellable {
    private static final HandlerList handlers = new HandlerList();
    protected Player player;
    protected Item item;
    protected Block blockReplace;
    protected Block blockAgainst;

    public static HandlerList getHandlers() {
        return handlers;
    }

    public BlockPlaceEvent(Player player, Block blockPlace, Block blockReplace, Block blockAgainst, Item item) {
        super(blockPlace);
        this.blockReplace = blockReplace;
        this.blockAgainst = blockAgainst;
        this.item = item;
        this.player = player;
    }

    public Player getPlayer() {
        return this.player;
    }

    public Item getItem() {
        return this.item;
    }

    public Block getBlockReplace() {
        return this.blockReplace;
    }

    public Block getBlockAgainst() {
        return this.blockAgainst;
    }
}

