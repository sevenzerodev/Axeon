/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.event.block;

import cn.axeon.Player;
import cn.axeon.block.Block;
import cn.axeon.event.Cancellable;
import cn.axeon.event.HandlerList;
import cn.axeon.event.block.BlockUpdateEvent;

public class DoorToggleEvent
extends BlockUpdateEvent
implements Cancellable {
    private static final HandlerList handlers = new HandlerList();
    private Player player;

    public static HandlerList getHandlers() {
        return handlers;
    }

    public DoorToggleEvent(Block block, Player player) {
        super(block);
        this.player = player;
    }

    public void setPlayer(Player player) {
        this.player = player;
    }

    public Player getPlayer() {
        return this.player;
    }
}

