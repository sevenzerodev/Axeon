/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.event.block;

import cn.axeon.block.Block;
import cn.axeon.event.Event;

public abstract class BlockEvent
extends Event {
    protected Block block;

    public BlockEvent(Block block) {
        this.block = block;
    }

    public Block getBlock() {
        return this.block;
    }
}

