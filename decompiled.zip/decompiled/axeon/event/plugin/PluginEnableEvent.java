/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.event.plugin;

import cn.axeon.event.plugin.PluginEvent;
import cn.axeon.plugin.Plugin;

public class PluginEnableEvent
extends PluginEvent {
    public PluginEnableEvent(Plugin plugin) {
        super(plugin);
    }
}

