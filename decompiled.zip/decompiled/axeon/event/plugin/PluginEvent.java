/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.event.plugin;

import cn.axeon.event.Event;
import cn.axeon.event.HandlerList;
import cn.axeon.plugin.Plugin;

public class PluginEvent
extends Event {
    private static final HandlerList handlers = new HandlerList();
    private Plugin plugin;

    public PluginEvent(Plugin plugin) {
        this.plugin = plugin;
    }

    public static HandlerList getHandlers() {
        return handlers;
    }

    public Plugin getPlugin() {
        return this.plugin;
    }
}

