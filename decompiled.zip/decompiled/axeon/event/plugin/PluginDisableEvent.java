/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.event.plugin;

import cn.axeon.event.plugin.PluginEvent;
import cn.axeon.plugin.Plugin;

public class PluginDisableEvent
extends PluginEvent {
    public PluginDisableEvent(Plugin plugin) {
        super(plugin);
    }
}

