/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.event.entity;

import cn.axeon.entity.Entity;
import cn.axeon.entity.projectile.EntityProjectile;
import cn.axeon.event.HandlerList;
import cn.axeon.event.entity.EntityEvent;

public class ProjectileHitEvent
extends EntityEvent {
    private static final HandlerList handlers = new HandlerList();

    public static HandlerList getHandlers() {
        return handlers;
    }

    public ProjectileHitEvent(EntityProjectile entity) {
        this.entity = entity;
    }

    @Override
    public Entity getEntity() {
        return super.getEntity();
    }
}

