/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.event.entity;

import cn.axeon.entity.Entity;
import cn.axeon.event.Cancellable;
import cn.axeon.event.HandlerList;
import cn.axeon.event.entity.EntityEvent;
import cn.axeon.level.Location;

public class EntityTeleportEvent
extends EntityEvent
implements Cancellable {
    private static final HandlerList handlers = new HandlerList();
    private Location from;
    private Location to;

    public static HandlerList getHandlers() {
        return handlers;
    }

    public EntityTeleportEvent(Entity entity, Location from, Location to) {
        this.entity = entity;
        this.from = from;
        this.to = to;
    }

    public Location getFrom() {
        return this.from;
    }

    public void setFrom(Location from) {
        this.from = from;
    }

    public Location getTo() {
        return this.to;
    }

    public void setTo(Location to) {
        this.to = to;
    }
}

