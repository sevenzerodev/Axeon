/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.event.entity;

import cn.axeon.entity.item.EntityItem;
import cn.axeon.event.HandlerList;
import cn.axeon.event.entity.EntityEvent;

public class ItemSpawnEvent
extends EntityEvent {
    private static final HandlerList handlers = new HandlerList();

    public static HandlerList getHandlers() {
        return handlers;
    }

    public ItemSpawnEvent(EntityItem item) {
        this.entity = item;
    }

    @Override
    public EntityItem getEntity() {
        return (EntityItem)this.entity;
    }
}

