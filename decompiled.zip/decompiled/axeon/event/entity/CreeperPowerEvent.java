/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.event.entity;

import cn.axeon.entity.mob.EntityCreeper;
import cn.axeon.entity.weather.EntityLightningStrike;
import cn.axeon.event.Cancellable;
import cn.axeon.event.HandlerList;
import cn.axeon.event.entity.EntityEvent;

public class CreeperPowerEvent
extends EntityEvent
implements Cancellable {
    private static final HandlerList handlers = new HandlerList();
    private final PowerCause cause;
    private EntityLightningStrike bolt;

    public static HandlerList getHandlers() {
        return handlers;
    }

    public CreeperPowerEvent(EntityCreeper creeper, EntityLightningStrike bolt, PowerCause cause) {
        this(creeper, cause);
        this.bolt = bolt;
    }

    public CreeperPowerEvent(EntityCreeper creeper, PowerCause cause) {
        this.entity = creeper;
        this.cause = cause;
    }

    @Override
    public EntityCreeper getEntity() {
        return (EntityCreeper)super.getEntity();
    }

    public EntityLightningStrike getLightning() {
        return this.bolt;
    }

    public PowerCause getCause() {
        return this.cause;
    }

    public static enum PowerCause {
        LIGHTNING,
        SET_ON,
        SET_OFF;

    }
}

