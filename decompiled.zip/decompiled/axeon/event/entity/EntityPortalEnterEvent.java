/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.event.entity;

import cn.axeon.entity.Entity;
import cn.axeon.event.Cancellable;
import cn.axeon.event.HandlerList;
import cn.axeon.event.entity.EntityEvent;

public class EntityPortalEnterEvent
extends EntityEvent
implements Cancellable {
    private static final HandlerList handlers = new HandlerList();
    public static final int TYPE_NETHER = 0;
    public static final int TYPE_END = 1;
    private int type;

    public static HandlerList getHandlers() {
        return handlers;
    }

    public EntityPortalEnterEvent(Entity entity, int type) {
        this.entity = entity;
        this.type = type;
    }

    public int getPortalType() {
        return this.type;
    }
}

