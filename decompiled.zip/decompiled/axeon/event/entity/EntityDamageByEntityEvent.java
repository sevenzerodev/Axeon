/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.event.entity;

import cn.axeon.entity.Entity;
import cn.axeon.event.entity.EntityDamageEvent;
import java.util.Map;

public class EntityDamageByEntityEvent
extends EntityDamageEvent {
    private Entity damager;
    private float knockBack;

    public EntityDamageByEntityEvent(Entity damager, Entity entity, int cause, float damage) {
        this(damager, entity, cause, damage, 0.4f);
    }

    public EntityDamageByEntityEvent(Entity damager, Entity entity, int cause, Map<Integer, Float> damage) {
        this(damager, entity, cause, damage, 0.4f);
    }

    public EntityDamageByEntityEvent(Entity damager, Entity entity, int cause, float damage, float knockBack) {
        super(entity, cause, damage);
        this.damager = damager;
        this.knockBack = knockBack;
        this.addAttackerModifiers(damager);
    }

    public EntityDamageByEntityEvent(Entity damager, Entity entity, int cause, Map<Integer, Float> damage, float knockBack) {
        super(entity, cause, damage);
        this.damager = damager;
        this.knockBack = knockBack;
        this.addAttackerModifiers(damager);
    }

    protected void addAttackerModifiers(Entity damager) {
        if (damager.hasEffect(5)) {
            this.setDamage((float)((double)this.getDamage(0) * 0.3 * (double)(damager.getEffect(5).getAmplifier() + 1)), 2);
        }
        if (damager.hasEffect(18)) {
            this.setDamage(-((float)((double)this.getDamage(0) * 0.2 * (double)(damager.getEffect(18).getAmplifier() + 1))), 3);
        }
    }

    public Entity getDamager() {
        return this.damager;
    }

    public float getKnockBack() {
        return this.knockBack;
    }

    public void setKnockBack(float knockBack) {
        this.knockBack = knockBack;
    }
}

