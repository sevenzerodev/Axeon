/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.event.entity;

import cn.axeon.entity.Entity;
import cn.axeon.event.Cancellable;
import cn.axeon.event.HandlerList;
import cn.axeon.event.entity.EntityEvent;

public class EntityCombustEvent
extends EntityEvent
implements Cancellable {
    private static final HandlerList handlers = new HandlerList();
    protected int duration;

    public static HandlerList getHandlers() {
        return handlers;
    }

    public EntityCombustEvent(Entity combustee, int duration) {
        this.entity = combustee;
        this.duration = duration;
    }

    public int getDuration() {
        return this.duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }
}

