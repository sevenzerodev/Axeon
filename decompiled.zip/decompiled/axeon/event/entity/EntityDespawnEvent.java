/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.event.entity;

import cn.axeon.entity.Entity;
import cn.axeon.entity.EntityCreature;
import cn.axeon.entity.EntityHuman;
import cn.axeon.entity.item.EntityItem;
import cn.axeon.entity.item.EntityVehicle;
import cn.axeon.entity.projectile.EntityProjectile;
import cn.axeon.event.HandlerList;
import cn.axeon.event.entity.EntityEvent;
import cn.axeon.level.Position;

public class EntityDespawnEvent
extends EntityEvent {
    private static final HandlerList handlers = new HandlerList();
    private int entityType;

    public static HandlerList getHandlers() {
        return handlers;
    }

    public EntityDespawnEvent(Entity entity) {
        this.entity = entity;
        this.entityType = entity.getNetworkId();
    }

    public Position getPosition() {
        return this.entity.getPosition();
    }

    public int getType() {
        return this.entityType;
    }

    public boolean isCreature() {
        return this.entity instanceof EntityCreature;
    }

    public boolean isHuman() {
        return this.entity instanceof EntityHuman;
    }

    public boolean isProjectile() {
        return this.entity instanceof EntityProjectile;
    }

    public boolean isVehicle() {
        return this.entity instanceof EntityVehicle;
    }

    public boolean isItem() {
        return this.entity instanceof EntityItem;
    }
}

