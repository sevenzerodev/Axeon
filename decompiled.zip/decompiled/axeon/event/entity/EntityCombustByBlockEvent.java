/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.event.entity;

import cn.axeon.block.Block;
import cn.axeon.entity.Entity;
import cn.axeon.event.entity.EntityCombustEvent;

public class EntityCombustByBlockEvent
extends EntityCombustEvent {
    protected Block combuster;

    public EntityCombustByBlockEvent(Block combuster, Entity combustee, int duration) {
        super(combustee, duration);
        this.combuster = combuster;
    }

    public Block getCombuster() {
        return this.combuster;
    }
}

