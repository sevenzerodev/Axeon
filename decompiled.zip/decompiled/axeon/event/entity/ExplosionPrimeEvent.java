/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.event.entity;

import cn.axeon.entity.Entity;
import cn.axeon.event.Cancellable;
import cn.axeon.event.HandlerList;
import cn.axeon.event.entity.EntityEvent;

public class ExplosionPrimeEvent
extends EntityEvent
implements Cancellable {
    private static final HandlerList handlers = new HandlerList();
    protected double force;
    private boolean blockBreaking;

    public static HandlerList getHandlers() {
        return handlers;
    }

    public ExplosionPrimeEvent(Entity entity, double force) {
        this.entity = entity;
        this.force = force;
        this.blockBreaking = true;
    }

    public double getForce() {
        return this.force;
    }

    public void setForce(double force) {
        this.force = force;
    }

    public boolean isBlockBreaking() {
        return this.blockBreaking;
    }

    public void setBlockBreaking(boolean affectsBlocks) {
        this.blockBreaking = affectsBlocks;
    }
}

