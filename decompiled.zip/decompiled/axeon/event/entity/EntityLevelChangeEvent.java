/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.event.entity;

import cn.axeon.entity.Entity;
import cn.axeon.event.Cancellable;
import cn.axeon.event.HandlerList;
import cn.axeon.event.entity.EntityEvent;
import cn.axeon.level.Level;

public class EntityLevelChangeEvent
extends EntityEvent
implements Cancellable {
    private static final HandlerList handlers = new HandlerList();
    private Level originLevel;
    private Level targetLevel;

    public static HandlerList getHandlers() {
        return handlers;
    }

    public EntityLevelChangeEvent(Entity entity, Level originLevel, Level targetLevel) {
        this.entity = entity;
        this.originLevel = originLevel;
        this.targetLevel = targetLevel;
    }

    public Level getOrigin() {
        return this.originLevel;
    }

    public Level getTarget() {
        return this.targetLevel;
    }
}

