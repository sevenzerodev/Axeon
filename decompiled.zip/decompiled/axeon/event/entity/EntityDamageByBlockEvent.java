/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.event.entity;

import cn.axeon.block.Block;
import cn.axeon.entity.Entity;
import cn.axeon.event.entity.EntityDamageEvent;

public class EntityDamageByBlockEvent
extends EntityDamageEvent {
    private Block damager;

    public EntityDamageByBlockEvent(Block damager, Entity entity, int cause, float damage) {
        super(entity, cause, damage);
        this.damager = damager;
    }

    public Block getDamager() {
        return this.damager;
    }
}

