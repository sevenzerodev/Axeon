/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.event.entity;

import cn.axeon.entity.Entity;
import cn.axeon.event.Event;

public abstract class EntityEvent
extends Event {
    protected Entity entity;

    public Entity getEntity() {
        return this.entity;
    }
}

