/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.event.entity;

import cn.axeon.entity.Entity;
import cn.axeon.event.Cancellable;
import cn.axeon.event.HandlerList;
import cn.axeon.event.entity.EntityEvent;
import cn.axeon.utils.EventException;
import java.util.HashMap;
import java.util.Map;

public class EntityDamageEvent
extends EntityEvent
implements Cancellable {
    private static final HandlerList handlers = new HandlerList();
    public static final int MODIFIER_BASE = 0;
    public static final int MODIFIER_ARMOR = 1;
    public static final int MODIFIER_STRENGTH = 2;
    public static final int MODIFIER_WEAKNESS = 3;
    public static final int MODIFIER_RESISTANCE = 4;
    public static final int CAUSE_CONTACT = 0;
    public static final int CAUSE_ENTITY_ATTACK = 1;
    public static final int CAUSE_PROJECTILE = 2;
    public static final int CAUSE_SUFFOCATION = 3;
    public static final int CAUSE_FALL = 4;
    public static final int CAUSE_FIRE = 5;
    public static final int CAUSE_FIRE_TICK = 6;
    public static final int CAUSE_LAVA = 7;
    public static final int CAUSE_DROWNING = 8;
    public static final int CAUSE_BLOCK_EXPLOSION = 9;
    public static final int CAUSE_ENTITY_EXPLOSION = 10;
    public static final int CAUSE_VOID = 11;
    public static final int CAUSE_SUICIDE = 12;
    public static final int CAUSE_MAGIC = 13;
    public static final int CAUSE_CUSTOM = 14;
    public static final int CAUSE_LIGHTNING = 15;
    private int cause;
    private Map<Integer, Float> modifiers;
    private Map<Integer, Float> originals;

    public static HandlerList getHandlers() {
        return handlers;
    }

    public EntityDamageEvent(Entity entity, int cause, final float damage) {
        this(entity, cause, (Map<Integer, Float>)new HashMap<Integer, Float>(){
            {
                this.put(0, Float.valueOf(damage));
            }
        });
    }

    public EntityDamageEvent(Entity entity, int cause, Map<Integer, Float> modifiers) {
        this.entity = entity;
        this.cause = cause;
        this.modifiers = modifiers;
        this.originals = this.modifiers;
        if (!this.modifiers.containsKey(0)) {
            throw new EventException("BASE Damage modifier missing");
        }
        if (entity.hasEffect(11)) {
            this.setDamage((float)(-((double)this.getDamage(0) * 0.2 * (double)(entity.getEffect(11).getAmplifier() + 1))), 4);
        }
    }

    public int getCause() {
        return this.cause;
    }

    public float getOriginalDamage() {
        return this.getOriginalDamage(0);
    }

    public float getOriginalDamage(int type) {
        if (this.originals.containsKey(type)) {
            return this.originals.get(type).floatValue();
        }
        return 0.0f;
    }

    public float getDamage() {
        return this.getDamage(0);
    }

    public float getDamage(int type) {
        if (this.modifiers.containsKey(type)) {
            return this.modifiers.get(type).floatValue();
        }
        return 0.0f;
    }

    public void setDamage(float damage) {
        this.setDamage(damage, 0);
    }

    public void setDamage(float damage, int type) {
        this.modifiers.put(type, Float.valueOf(damage));
    }

    public boolean isApplicable(int type) {
        return this.modifiers.containsKey(type);
    }

    public float getFinalDamage() {
        float damage = 0.0f;
        for (Float d : this.modifiers.values()) {
            if (d == null) continue;
            damage += d.floatValue();
        }
        return damage;
    }
}

