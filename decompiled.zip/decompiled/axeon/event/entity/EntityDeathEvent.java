/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.event.entity;

import cn.axeon.entity.Entity;
import cn.axeon.entity.EntityLiving;
import cn.axeon.event.HandlerList;
import cn.axeon.event.entity.EntityEvent;
import cn.axeon.item.Item;

public class EntityDeathEvent
extends EntityEvent {
    private static final HandlerList handlers = new HandlerList();
    private Item[] drops = new Item[0];

    public static HandlerList getHandlers() {
        return handlers;
    }

    public EntityDeathEvent(EntityLiving entity) {
        this(entity, new Item[0]);
    }

    public EntityDeathEvent(EntityLiving entity, Item[] drops) {
        this.entity = entity;
        this.drops = drops;
    }

    @Override
    public Entity getEntity() {
        return super.getEntity();
    }

    public Item[] getDrops() {
        return this.drops;
    }

    public void setDrops(Item[] drops) {
        this.drops = drops;
    }
}

