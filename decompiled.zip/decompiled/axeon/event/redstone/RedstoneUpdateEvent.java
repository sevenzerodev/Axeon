/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.event.redstone;

import cn.axeon.block.Block;
import cn.axeon.event.block.BlockUpdateEvent;

public class RedstoneUpdateEvent
extends BlockUpdateEvent {
    public RedstoneUpdateEvent(Block source) {
        super(source);
    }
}

