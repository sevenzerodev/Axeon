/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.event;

import cn.axeon.Server;

public class TextContainer
implements Cloneable {
    protected String text;

    public TextContainer(String text) {
        this.text = text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getText() {
        return this.text;
    }

    public String toString() {
        return this.getText();
    }

    public TextContainer clone() {
        try {
            return (TextContainer)super.clone();
        }
        catch (CloneNotSupportedException e) {
            Server.getInstance().getLogger().logException(e);
            return null;
        }
    }
}

