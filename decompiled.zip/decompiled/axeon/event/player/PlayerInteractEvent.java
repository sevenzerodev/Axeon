/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.event.player;

import cn.axeon.Player;
import cn.axeon.block.Block;
import cn.axeon.event.Cancellable;
import cn.axeon.event.HandlerList;
import cn.axeon.event.player.PlayerEvent;
import cn.axeon.item.Item;
import cn.axeon.level.Position;
import cn.axeon.math.Vector3;

public class PlayerInteractEvent
extends PlayerEvent
implements Cancellable {
    private static final HandlerList handlers = new HandlerList();
    public static final int LEFT_CLICK_BLOCK = 0;
    public static final int RIGHT_CLICK_BLOCK = 1;
    public static final int LEFT_CLICK_AIR = 2;
    public static final int RIGHT_CLICK_AIR = 3;
    public static final int PHYSICAL = 4;
    protected Block blockTouched;
    protected Vector3 touchVector;
    protected int blockFace;
    protected Item item;
    protected int action;

    public static HandlerList getHandlers() {
        return handlers;
    }

    public PlayerInteractEvent(Player player, Item item, Vector3 block, int face) {
        this(player, item, block, face, 1);
    }

    public PlayerInteractEvent(Player player, Item item, Vector3 block, int face, int action) {
        if (block instanceof Block) {
            this.blockTouched = (Block)block;
            this.touchVector = new Vector3(0.0, 0.0, 0.0);
        } else {
            this.touchVector = block;
            this.blockTouched = Block.get(0, 0, new Position(0.0, 0.0, 0.0, player.level));
        }
        this.player = player;
        this.item = item;
        this.blockFace = face;
        this.action = action;
    }

    public int getAction() {
        return this.action;
    }

    public Item getItem() {
        return this.item;
    }

    public Block getBlock() {
        return this.blockTouched;
    }

    public Vector3 getTouchVector() {
        return this.touchVector;
    }

    public int getFace() {
        return this.blockFace;
    }
}

