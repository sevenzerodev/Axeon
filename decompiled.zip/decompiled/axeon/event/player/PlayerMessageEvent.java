/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.event.player;

import cn.axeon.event.player.PlayerEvent;

public abstract class PlayerMessageEvent
extends PlayerEvent {
    protected String message;

    public String getMessage() {
        return this.message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}

