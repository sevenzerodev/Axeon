/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.event.player;

import cn.axeon.Player;
import cn.axeon.event.Event;

public abstract class PlayerEvent
extends Event {
    protected Player player;

    public Player getPlayer() {
        return this.player;
    }
}

