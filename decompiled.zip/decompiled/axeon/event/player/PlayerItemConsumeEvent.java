/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.event.player;

import cn.axeon.Player;
import cn.axeon.event.Cancellable;
import cn.axeon.event.HandlerList;
import cn.axeon.event.player.PlayerEvent;
import cn.axeon.item.Item;

public class PlayerItemConsumeEvent
extends PlayerEvent
implements Cancellable {
    private static final HandlerList handlers = new HandlerList();
    private Item item;

    public static HandlerList getHandlers() {
        return handlers;
    }

    public PlayerItemConsumeEvent(Player player, Item item) {
        this.player = player;
        this.item = item;
    }

    public Item getItem() {
        return this.item.clone();
    }
}

