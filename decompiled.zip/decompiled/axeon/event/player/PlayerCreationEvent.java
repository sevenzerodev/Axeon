/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.event.player;

import cn.axeon.Player;
import cn.axeon.event.Event;
import cn.axeon.event.HandlerList;
import cn.axeon.network.SourceInterface;

public class PlayerCreationEvent
extends Event {
    private static final HandlerList handlers = new HandlerList();
    private SourceInterface interfaz;
    private Long clientId;
    private String address;
    private int port;
    private Class<? extends Player> baseClass;
    private Class<? extends Player> playerClass;

    public static HandlerList getHandlers() {
        return handlers;
    }

    public PlayerCreationEvent(SourceInterface interfaz, Class<? extends Player> baseClass, Class<? extends Player> playerClass, Long clientId, String address, int port) {
        this.interfaz = interfaz;
        this.clientId = clientId;
        this.address = address;
        this.port = port;
        this.baseClass = baseClass;
        this.playerClass = playerClass;
    }

    public SourceInterface getInterface() {
        return this.interfaz;
    }

    public String getAddress() {
        return this.address;
    }

    public int getPort() {
        return this.port;
    }

    public Long getClientId() {
        return this.clientId;
    }

    public Class<? extends Player> getBaseClass() {
        return this.baseClass;
    }

    public void setBaseClass(Class<? extends Player> baseClass) {
        this.baseClass = baseClass;
    }

    public Class<? extends Player> getPlayerClass() {
        return this.playerClass;
    }

    public void setPlayerClass(Class<? extends Player> playerClass) {
        this.playerClass = playerClass;
    }
}

