/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.event.player;

import cn.axeon.Player;
import cn.axeon.event.Cancellable;
import cn.axeon.event.HandlerList;
import cn.axeon.event.player.PlayerEvent;
import cn.axeon.level.Level;
import cn.axeon.level.Location;
import cn.axeon.level.Position;
import cn.axeon.math.Vector3;

public class PlayerTeleportEvent
extends PlayerEvent
implements Cancellable {
    private static final HandlerList handlers = new HandlerList();
    private TeleportCause cause;
    private Location from;
    private Location to;

    public static HandlerList getHandlers() {
        return handlers;
    }

    private PlayerTeleportEvent(Player player) {
        this.player = player;
    }

    public PlayerTeleportEvent(Player player, Location from, Location to, TeleportCause cause) {
        this(player);
        this.from = from;
        this.to = to;
        this.cause = cause;
    }

    public PlayerTeleportEvent(Player player, Vector3 from, Vector3 to, TeleportCause cause) {
        this(player);
        this.from = this.vectorToLocation(player.getLevel(), from);
        this.from = this.vectorToLocation(player.getLevel(), to);
        this.cause = cause;
    }

    public Location getFrom() {
        return this.from;
    }

    public Location getTo() {
        return this.to;
    }

    public TeleportCause getCause() {
        return this.cause;
    }

    private Location vectorToLocation(Level baseLevel, Vector3 vector) {
        if (vector instanceof Location) {
            return (Location)vector;
        }
        if (vector instanceof Position) {
            return ((Position)vector).getLocation();
        }
        return new Location(vector.getX(), vector.getY(), vector.getZ(), 0.0, 0.0, baseLevel);
    }

    public static enum TeleportCause {
        COMMAND,
        PLUGIN,
        NETHER_PORTAL,
        UNKNOWN;

    }
}

