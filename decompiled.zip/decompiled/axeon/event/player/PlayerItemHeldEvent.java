/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.event.player;

import cn.axeon.Player;
import cn.axeon.event.Cancellable;
import cn.axeon.event.HandlerList;
import cn.axeon.event.player.PlayerEvent;
import cn.axeon.item.Item;

public class PlayerItemHeldEvent
extends PlayerEvent
implements Cancellable {
    private static final HandlerList handlers = new HandlerList();
    private Item item;
    private int slot;
    private int inventorySlot;

    public static HandlerList getHandlers() {
        return handlers;
    }

    public PlayerItemHeldEvent(Player player, Item item, int inventorySlot, int slot) {
        this.player = player;
        this.item = item;
        this.inventorySlot = inventorySlot;
        this.slot = slot;
    }

    public int getSlot() {
        return this.slot;
    }

    public int getInventorySlot() {
        return this.inventorySlot;
    }

    public Item getItem() {
        return this.item;
    }
}

