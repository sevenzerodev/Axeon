/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.event.player;

import cn.axeon.Player;
import cn.axeon.event.Cancellable;
import cn.axeon.event.HandlerList;
import cn.axeon.event.player.PlayerEvent;

public class PlayerGameModeChangeEvent
extends PlayerEvent
implements Cancellable {
    private static final HandlerList handlers = new HandlerList();
    protected int gamemode;

    public static HandlerList getHandlers() {
        return handlers;
    }

    public PlayerGameModeChangeEvent(Player player, int newGameMode) {
        this.player = player;
        this.gamemode = newGameMode;
    }

    public int getNewGamemode() {
        return this.gamemode;
    }
}

