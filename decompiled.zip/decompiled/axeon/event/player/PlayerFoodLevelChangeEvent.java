/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.event.player;

import cn.axeon.Player;
import cn.axeon.event.Cancellable;
import cn.axeon.event.HandlerList;
import cn.axeon.event.player.PlayerEvent;

public class PlayerFoodLevelChangeEvent
extends PlayerEvent
implements Cancellable {
    private static final HandlerList handlers = new HandlerList();
    protected int foodLevel;
    protected float foodSaturationLevel;

    public static HandlerList getHandlers() {
        return handlers;
    }

    public PlayerFoodLevelChangeEvent(Player player, int foodLevel, float foodSaturationLevel) {
        this.player = player;
        this.foodLevel = foodLevel;
        this.foodSaturationLevel = foodSaturationLevel;
    }

    public int getFoodLevel() {
        return this.foodLevel;
    }

    public void setFoodLevel(int foodLevel) {
        this.foodLevel = foodLevel;
    }

    public float getFoodSaturationLevel() {
        return this.foodSaturationLevel;
    }

    public void setFoodSaturationLevel(float foodSaturationLevel) {
        this.foodSaturationLevel = foodSaturationLevel;
    }
}

