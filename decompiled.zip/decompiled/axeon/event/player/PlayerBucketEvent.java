/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.event.player;

import cn.axeon.Player;
import cn.axeon.block.Block;
import cn.axeon.event.Cancellable;
import cn.axeon.event.player.PlayerEvent;
import cn.axeon.item.Item;

abstract class PlayerBucketEvent
extends PlayerEvent
implements Cancellable {
    private Block blockClicked;
    private Integer blockFace;
    private Item bucket;
    private Item item;

    public PlayerBucketEvent(Player who, Block blockClicked, Integer blockFace, Item bucket, Item itemInHand) {
        this.player = who;
        this.blockClicked = blockClicked;
        this.blockFace = blockFace;
        this.item = itemInHand;
        this.bucket = bucket;
    }

    public Item getBucket() {
        return this.bucket;
    }

    public Item getItem() {
        return this.item;
    }

    public void setItem(Item item) {
        this.item = item;
    }

    public Block getBlockClicked() {
        return this.blockClicked;
    }

    public int getBlockFace() {
        return this.blockFace;
    }
}

