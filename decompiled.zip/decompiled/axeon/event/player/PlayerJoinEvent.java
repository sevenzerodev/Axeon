/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.event.player;

import cn.axeon.Player;
import cn.axeon.event.HandlerList;
import cn.axeon.event.TextContainer;
import cn.axeon.event.player.PlayerEvent;

public class PlayerJoinEvent
extends PlayerEvent {
    private static final HandlerList handlers = new HandlerList();
    protected TextContainer joinMessage;

    public static HandlerList getHandlers() {
        return handlers;
    }

    public PlayerJoinEvent(Player player, TextContainer joinMessage) {
        this.player = player;
        this.joinMessage = joinMessage;
    }

    public PlayerJoinEvent(Player player, String joinMessage) {
        this.player = player;
        this.joinMessage = new TextContainer(joinMessage);
    }

    public TextContainer getJoinMessage() {
        return this.joinMessage;
    }

    public void setJoinMessage(TextContainer joinMessage) {
        this.joinMessage = joinMessage;
    }

    public void setJoinMessage(String joinMessage) {
        this.setJoinMessage(new TextContainer(joinMessage));
    }
}

