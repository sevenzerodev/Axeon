/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.event.player;

import cn.axeon.Player;
import cn.axeon.event.HandlerList;
import cn.axeon.event.player.PlayerEvent;
import cn.axeon.level.Position;

public class PlayerRespawnEvent
extends PlayerEvent {
    private static final HandlerList handlers = new HandlerList();
    private Position position;

    public static HandlerList getHandlers() {
        return handlers;
    }

    public PlayerRespawnEvent(Player player, Position position) {
        this.player = player;
        this.position = position;
    }

    public Position getRespawnPosition() {
        return this.position;
    }

    public void setRespawnPosition(Position position) {
        this.position = position;
    }
}

