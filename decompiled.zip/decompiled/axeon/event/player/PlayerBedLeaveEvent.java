/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.event.player;

import cn.axeon.Player;
import cn.axeon.block.Block;
import cn.axeon.event.HandlerList;
import cn.axeon.event.player.PlayerEvent;

public class PlayerBedLeaveEvent
extends PlayerEvent {
    private static final HandlerList handlers = new HandlerList();
    private Block bed;

    public static HandlerList getHandlers() {
        return handlers;
    }

    public PlayerBedLeaveEvent(Player player, Block bed) {
        this.player = player;
        this.bed = bed;
    }

    public Block getBed() {
        return this.bed;
    }
}

