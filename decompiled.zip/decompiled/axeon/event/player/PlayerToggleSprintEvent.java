/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.event.player;

import cn.axeon.Player;
import cn.axeon.event.Cancellable;
import cn.axeon.event.HandlerList;
import cn.axeon.event.player.PlayerEvent;

public class PlayerToggleSprintEvent
extends PlayerEvent
implements Cancellable {
    private static final HandlerList handlers = new HandlerList();
    protected boolean isSprinting;

    public static HandlerList getHandlers() {
        return handlers;
    }

    public PlayerToggleSprintEvent(Player player, boolean isSprinting) {
        this.player = player;
        this.isSprinting = isSprinting;
    }

    public boolean isSprinting() {
        return this.isSprinting;
    }
}

