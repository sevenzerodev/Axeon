/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.event;

public interface Cancellable {
    public boolean isCancelled();

    public void setCancelled();

    public void setCancelled(boolean var1);
}

