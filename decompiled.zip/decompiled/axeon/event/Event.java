/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.event;

import cn.axeon.event.Cancellable;
import cn.axeon.utils.EventException;

public abstract class Event {
    protected String eventName = null;
    private boolean isCancelled = false;

    public final String getEventName() {
        return this.eventName == null ? this.getClass().getName() : this.eventName;
    }

    public boolean isCancelled() {
        if (!(this instanceof Cancellable)) {
            throw new EventException("Event is not Cancellable");
        }
        return this.isCancelled;
    }

    public void setCancelled() {
        this.setCancelled(true);
    }

    public void setCancelled(boolean value) {
        if (!(this instanceof Cancellable)) {
            throw new EventException("Event is not Cancellable");
        }
        this.isCancelled = value;
    }
}

