/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.event;

public interface Listener {
}

