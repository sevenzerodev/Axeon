/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.event.level;

import cn.axeon.event.Event;
import cn.axeon.level.Level;

public abstract class LevelEvent
extends Event {
    private Level level;

    public LevelEvent(Level level) {
        this.level = level;
    }

    public Level getLevel() {
        return this.level;
    }
}

