/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.event.level;

import cn.axeon.event.Cancellable;
import cn.axeon.event.HandlerList;
import cn.axeon.event.level.ChunkEvent;
import cn.axeon.level.format.FullChunk;

public class ChunkUnloadEvent
extends ChunkEvent
implements Cancellable {
    private static final HandlerList handlers = new HandlerList();

    public static HandlerList getHandlers() {
        return handlers;
    }

    public ChunkUnloadEvent(FullChunk chunk) {
        super(chunk);
    }
}

