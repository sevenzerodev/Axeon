/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.event.level;

import cn.axeon.event.HandlerList;
import cn.axeon.event.level.LevelEvent;
import cn.axeon.level.Level;
import cn.axeon.level.Position;

public class SpawnChangeEvent
extends LevelEvent {
    private static final HandlerList handlers = new HandlerList();
    private Position previousSpawn;

    public static HandlerList getHandlers() {
        return handlers;
    }

    public SpawnChangeEvent(Level level, Position previousSpawn) {
        super(level);
        this.previousSpawn = previousSpawn;
    }

    public Position getPreviousSpawn() {
        return this.previousSpawn;
    }
}

