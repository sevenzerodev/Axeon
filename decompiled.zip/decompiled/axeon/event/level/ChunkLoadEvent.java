/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.event.level;

import cn.axeon.event.HandlerList;
import cn.axeon.event.level.ChunkEvent;
import cn.axeon.level.format.FullChunk;

public class ChunkLoadEvent
extends ChunkEvent {
    private static final HandlerList handlers = new HandlerList();
    private boolean newChunk;

    public static HandlerList getHandlers() {
        return handlers;
    }

    public ChunkLoadEvent(FullChunk chunk, boolean newChunk) {
        super(chunk);
        this.newChunk = newChunk;
    }

    public boolean isNewChunk() {
        return this.newChunk;
    }
}

