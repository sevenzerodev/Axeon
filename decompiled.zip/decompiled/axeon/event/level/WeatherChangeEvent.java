/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.event.level;

import cn.axeon.event.Cancellable;
import cn.axeon.event.HandlerList;
import cn.axeon.event.level.WeatherEvent;
import cn.axeon.level.Level;

public class WeatherChangeEvent
extends WeatherEvent
implements Cancellable {
    private static final HandlerList handlers = new HandlerList();
    private boolean to;

    public static HandlerList getHandlers() {
        return handlers;
    }

    public WeatherChangeEvent(Level level, boolean to) {
        super(level);
        this.to = to;
    }

    public boolean toWeatherState() {
        return this.to;
    }
}

