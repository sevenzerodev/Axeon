/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.event.level;

import cn.axeon.event.level.LevelEvent;
import cn.axeon.level.format.FullChunk;

public abstract class ChunkEvent
extends LevelEvent {
    private FullChunk chunk;

    public ChunkEvent(FullChunk chunk) {
        super(chunk.getProvider().getLevel());
        this.chunk = chunk;
    }

    public FullChunk getChunk() {
        return this.chunk;
    }
}

