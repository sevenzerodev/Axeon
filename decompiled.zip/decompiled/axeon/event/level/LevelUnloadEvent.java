/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.event.level;

import cn.axeon.event.Cancellable;
import cn.axeon.event.HandlerList;
import cn.axeon.event.level.LevelEvent;
import cn.axeon.level.Level;

public class LevelUnloadEvent
extends LevelEvent
implements Cancellable {
    private static final HandlerList handlers = new HandlerList();

    public static HandlerList getHandlers() {
        return handlers;
    }

    public LevelUnloadEvent(Level level) {
        super(level);
    }
}

