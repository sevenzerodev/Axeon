/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.event.level;

import cn.axeon.event.HandlerList;
import cn.axeon.event.level.LevelEvent;
import cn.axeon.level.Level;

public class LevelInitEvent
extends LevelEvent {
    private static final HandlerList handlers = new HandlerList();

    public static HandlerList getHandlers() {
        return handlers;
    }

    public LevelInitEvent(Level level) {
        super(level);
    }
}

