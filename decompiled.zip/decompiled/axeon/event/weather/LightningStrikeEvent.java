/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.event.weather;

import cn.axeon.entity.weather.EntityLightningStrike;
import cn.axeon.event.Cancellable;
import cn.axeon.event.HandlerList;
import cn.axeon.event.weather.WeatherEvent;
import cn.axeon.level.Level;

public class LightningStrikeEvent
extends WeatherEvent
implements Cancellable {
    private static final HandlerList handlers = new HandlerList();
    private final EntityLightningStrike bolt;

    public static HandlerList getHandlers() {
        return handlers;
    }

    public LightningStrikeEvent(Level level, EntityLightningStrike bolt) {
        super(level);
        this.bolt = bolt;
    }

    public EntityLightningStrike getLightning() {
        return this.bolt;
    }
}

