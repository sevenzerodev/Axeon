/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.event.server;

import cn.axeon.Player;
import cn.axeon.event.Cancellable;
import cn.axeon.event.HandlerList;
import cn.axeon.event.server.ServerEvent;
import cn.axeon.network.protocol.DataPacket;

public class DataPacketSendEvent
extends ServerEvent
implements Cancellable {
    private static final HandlerList handlers = new HandlerList();
    private DataPacket packet;
    private Player player;

    public static HandlerList getHandlers() {
        return handlers;
    }

    public DataPacketSendEvent(Player player, DataPacket packet) {
        this.packet = packet;
        this.player = player;
    }

    public Player getPlayer() {
        return this.player;
    }

    public DataPacket getPacket() {
        return this.packet;
    }
}

