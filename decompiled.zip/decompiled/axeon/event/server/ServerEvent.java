/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.event.server;

import cn.axeon.event.Event;

public abstract class ServerEvent
extends Event {
}

