/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.event.server;

import cn.axeon.command.CommandSender;
import cn.axeon.event.Cancellable;
import cn.axeon.event.HandlerList;
import cn.axeon.event.server.ServerEvent;

public class ServerCommandEvent
extends ServerEvent
implements Cancellable {
    private static final HandlerList handlers = new HandlerList();
    protected String command;
    protected CommandSender sender;

    public ServerCommandEvent(CommandSender sender, String command) {
        this.sender = sender;
        this.command = command;
    }

    public CommandSender getSender() {
        return this.sender;
    }

    public String getCommand() {
        return this.command;
    }

    public void setCommand(String command) {
        this.command = command;
    }

    public static HandlerList getHandlers() {
        return handlers;
    }
}

