/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.entity.mob;

import cn.axeon.entity.EntityCreature;
import cn.axeon.level.format.FullChunk;
import cn.axeon.nbt.tag.CompoundTag;

public abstract class EntityMob
extends EntityCreature {
    public EntityMob(FullChunk chunk, CompoundTag nbt) {
        super(chunk, nbt);
    }
}

