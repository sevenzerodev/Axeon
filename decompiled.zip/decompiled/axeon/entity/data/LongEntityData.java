/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.entity.data;

import cn.axeon.entity.data.EntityData;

public class LongEntityData
extends EntityData<Long> {
    public long data;

    public LongEntityData(int id, long data) {
        super(id);
        this.data = data;
    }

    @Override
    public Long getData() {
        return this.data;
    }

    @Override
    public void setData(Long data) {
        this.data = data;
    }

    @Override
    public int getType() {
        return 7;
    }
}

