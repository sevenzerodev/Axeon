/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.entity.data;

import cn.axeon.entity.data.EntityData;

public class ByteEntityData
extends EntityData<Integer> {
    public int data;

    public ByteEntityData(int id, int data) {
        super(id);
        this.data = data;
    }

    @Override
    public Integer getData() {
        return this.data;
    }

    @Override
    public void setData(Integer data) {
        this.data = data == null ? 0 : data;
    }

    @Override
    public int getType() {
        return 0;
    }
}

