/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.entity.data;

import cn.axeon.entity.data.EntityData;

public class FloatEntityData
extends EntityData<Float> {
    public float data;

    public FloatEntityData(int id, float data) {
        super(id);
        this.data = data;
    }

    @Override
    public Float getData() {
        return Float.valueOf(this.data);
    }

    @Override
    public void setData(Float data) {
        this.data = data == null ? 0.0f : data.floatValue();
    }

    @Override
    public int getType() {
        return 3;
    }
}

