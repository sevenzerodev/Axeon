/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.entity.data;

import java.util.Objects;

public abstract class EntityData<T> {
    private int id;

    protected EntityData(int id) {
        this.id = id;
    }

    public abstract int getType();

    public abstract T getData();

    public abstract void setData(T var1);

    public int getId() {
        return this.id;
    }

    public EntityData setId(int id) {
        this.id = id;
        return this;
    }

    public boolean equals(Object obj) {
        return obj instanceof EntityData && ((EntityData)obj).getId() == this.getId() && Objects.equals(((EntityData)obj).getData(), this.getData());
    }
}

