/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.entity;

import cn.axeon.Server;
import cn.axeon.block.Block;
import cn.axeon.entity.Entity;
import cn.axeon.entity.EntityDamageable;
import cn.axeon.entity.data.ShortEntityData;
import cn.axeon.entity.passive.EntityWaterAnimal;
import cn.axeon.event.entity.EntityDamageByChildEntityEvent;
import cn.axeon.event.entity.EntityDamageByEntityEvent;
import cn.axeon.event.entity.EntityDamageEvent;
import cn.axeon.event.entity.EntityDeathEvent;
import cn.axeon.event.entity.EntityRegainHealthEvent;
import cn.axeon.item.Item;
import cn.axeon.level.format.FullChunk;
import cn.axeon.math.Vector3;
import cn.axeon.nbt.tag.CompoundTag;
import cn.axeon.nbt.tag.ShortTag;
import cn.axeon.network.protocol.DataPacket;
import cn.axeon.network.protocol.EntityEventPacket;
import cn.axeon.utils.BlockIterator;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public abstract class EntityLiving
extends Entity
implements EntityDamageable {
    protected int attackTime = 0;
    protected boolean invisible = false;
    protected float movementSpeed = 0.1f;

    public EntityLiving(FullChunk chunk, CompoundTag nbt) {
        super(chunk, nbt);
    }

    @Override
    protected float getGravity() {
        return 0.08f;
    }

    @Override
    protected float getDrag() {
        return 0.02f;
    }

    @Override
    protected void initEntity() {
        super.initEntity();
        if (this.namedTag.contains("HealF")) {
            this.namedTag.putShort("Health", this.namedTag.getShort("HealF"));
            this.namedTag.remove("HealF");
        }
        if (!this.namedTag.contains("Health") || !(this.namedTag.get("Health") instanceof ShortTag)) {
            this.namedTag.putShort("Health", this.getMaxHealth());
        }
        this.setHealth(this.namedTag.getShort("Health"));
    }

    @Override
    public void setHealth(float health) {
        boolean wasAlive = this.isAlive();
        super.setHealth(health);
        if (this.isAlive() && !wasAlive) {
            EntityEventPacket pk = new EntityEventPacket();
            pk.eid = this.getId();
            pk.eid = 17L;
            Server.broadcastPacket(this.hasSpawned.values(), (DataPacket)pk);
        }
    }

    @Override
    public void saveNBT() {
        super.saveNBT();
        this.namedTag.putShort("Health", this.getHealth());
    }

    public boolean hasLineOfSight(Entity entity) {
        return true;
    }

    @Override
    public void heal(EntityRegainHealthEvent source) {
        super.heal(source);
        if (source.isCancelled()) {
            return;
        }
        this.attackTime = 0;
    }

    @Override
    public void attack(EntityDamageEvent source) {
        EntityDamageEvent lastCause;
        if ((this.attackTime > 0 || this.noDamageTicks > 0) && (lastCause = this.getLastDamageCause()) != null && lastCause.getDamage() >= source.getDamage()) {
            source.setCancelled();
        }
        super.attack(source);
        if (source.isCancelled()) {
            return;
        }
        if (source instanceof EntityDamageByEntityEvent) {
            Entity e = ((EntityDamageByEntityEvent)source).getDamager();
            if (source instanceof EntityDamageByChildEntityEvent) {
                e = ((EntityDamageByChildEntityEvent)source).getChild();
            }
            if (e.isOnFire()) {
                this.setOnFire(2 * this.server.getDifficulty());
            }
            double deltaX = this.x - e.x;
            double deltaZ = this.z - e.z;
            this.knockBack(e, source.getDamage(), deltaX, deltaZ, ((EntityDamageByEntityEvent)source).getKnockBack());
        }
        EntityEventPacket pk = new EntityEventPacket();
        pk.eid = this.getId();
        pk.event = (byte)(this.getHealth() <= 0 ? 3 : 2);
        Server.broadcastPacket(this.hasSpawned.values(), (DataPacket)pk);
        this.attackTime = 10;
    }

    public void knockBack(Entity attacker, double damage, double x, double z) {
        this.knockBack(attacker, damage, x, z, 0.4);
    }

    public void knockBack(Entity attacker, double damage, double x, double z, double base) {
        double f = Math.sqrt(x * x + z * z);
        if (f <= 0.0) {
            return;
        }
        f = 1.0 / f;
        Vector3 motion = new Vector3(this.motionX, this.motionY, this.motionZ);
        motion.x /= 2.0;
        motion.y /= 2.0;
        motion.z /= 2.0;
        motion.x += x * f * base;
        motion.y += base;
        motion.z += z * f * base;
        if (motion.y > base) {
            motion.y = base;
        }
        this.setMotion(motion);
    }

    @Override
    public void kill() {
        if (!this.isAlive()) {
            return;
        }
        super.kill();
        EntityDeathEvent ev = new EntityDeathEvent(this, this.getDrops());
        this.server.getPluginManager().callEvent(ev);
        for (Item item : ev.getDrops()) {
            this.getLevel().dropItem(this, item);
        }
    }

    @Override
    public boolean entityBaseTick() {
        return this.entityBaseTick(1);
    }

    @Override
    public boolean entityBaseTick(int tickDiff) {
        boolean hasUpdate = super.entityBaseTick(tickDiff);
        if (this.isAlive()) {
            if (this.isInsideOfSolid()) {
                hasUpdate = true;
                EntityDamageEvent ev = new EntityDamageEvent((Entity)this, 3, 1.0f);
                this.attack(ev);
            }
            if (!this.hasEffect(13) && this.isInsideOfWater()) {
                if (this instanceof EntityWaterAnimal) {
                    this.setDataProperty(new ShortEntityData(1, 300));
                } else {
                    hasUpdate = true;
                    int airTicks = this.getDataPropertyShort(1) - tickDiff;
                    if (airTicks <= -20) {
                        airTicks = 0;
                        EntityDamageEvent ev = new EntityDamageEvent((Entity)this, 8, 2.0f);
                        this.attack(ev);
                    }
                    this.setDataProperty(new ShortEntityData(1, airTicks));
                }
            } else if (this instanceof EntityWaterAnimal) {
                hasUpdate = true;
                int airTicks = this.getDataPropertyInt(1) - tickDiff;
                if (airTicks <= -20) {
                    airTicks = 0;
                    EntityDamageEvent ev = new EntityDamageEvent((Entity)this, 3, 2.0f);
                    this.attack(ev);
                }
                this.setDataProperty(new ShortEntityData(1, airTicks));
            } else {
                this.setDataProperty(new ShortEntityData(1, 300));
            }
        }
        if (this.attackTime > 0) {
            this.attackTime -= tickDiff;
        }
        return hasUpdate;
    }

    public Item[] getDrops() {
        return new Item[0];
    }

    public Block[] getLineOfSight(int maxDistance) {
        return this.getLineOfSight(maxDistance, 0);
    }

    public Block[] getLineOfSight(int maxDistance, int maxLength) {
        return this.getLineOfSight(maxDistance, maxLength, new HashMap<Integer, Object>());
    }

    public Block[] getLineOfSight(int maxDistance, int maxLength, Map<Integer, Object> transparent) {
        if (maxDistance > 120) {
            maxDistance = 120;
        }
        if (transparent != null && transparent.isEmpty()) {
            transparent = null;
        }
        ArrayList<Block> blocks = new ArrayList<Block>();
        BlockIterator itr = new BlockIterator(this.level, this.getPosition(), this.getDirectionVector(), this.getEyeHeight(), maxDistance);
        while (itr.hasNext()) {
            Block block = itr.next();
            blocks.add(block);
            if (maxLength != 0 && blocks.size() > maxLength) {
                blocks.remove(0);
            }
            int id = block.getId();
            if (!(transparent == null ? id != 0 : !transparent.containsKey(id))) continue;
            break;
        }
        return (Block[])blocks.stream().toArray(Block[]::new);
    }

    public Block getTargetBlock(int maxDistance) {
        return this.getTargetBlock(maxDistance, new HashMap<Integer, Object>());
    }

    public Block getTargetBlock(int maxDistance, Map<Integer, Object> transparent) {
        try {
            Block[] blocks = this.getLineOfSight(maxDistance, 1, transparent);
            Block block = blocks[0];
            if (block instanceof Block) {
                return block;
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        return null;
    }

    public void setMovementSpeed(float speed) {
        this.movementSpeed = speed;
    }

    public float getMovementSpeed() {
        return this.movementSpeed;
    }
}

