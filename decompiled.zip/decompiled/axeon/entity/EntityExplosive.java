/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.entity;

public interface EntityExplosive {
    public void explode();
}

