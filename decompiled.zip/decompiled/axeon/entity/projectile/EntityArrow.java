/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.entity.projectile;

import cn.axeon.Player;
import cn.axeon.entity.Entity;
import cn.axeon.entity.projectile.EntityProjectile;
import cn.axeon.level.format.FullChunk;
import cn.axeon.level.particle.CriticalParticle;
import cn.axeon.math.NukkitMath;
import cn.axeon.math.NukkitRandom;
import cn.axeon.nbt.tag.CompoundTag;
import cn.axeon.network.protocol.AddEntityPacket;

public class EntityArrow
extends EntityProjectile {
    public static final int NETWORK_ID = 80;
    public static final int DATA_SOURCE_ID = 17;
    protected float gravity = 0.05f;
    protected float drag = 0.01f;
    protected double damage = 2.0;
    protected boolean isCritical;

    @Override
    public int getNetworkId() {
        return 80;
    }

    @Override
    public float getWidth() {
        return 0.5f;
    }

    @Override
    public float getLength() {
        return 0.5f;
    }

    @Override
    public float getHeight() {
        return 0.5f;
    }

    @Override
    public float getGravity() {
        return 0.05f;
    }

    @Override
    public float getDrag() {
        return 0.01f;
    }

    @Override
    protected double getDamage() {
        return 2.0;
    }

    public EntityArrow(FullChunk chunk, CompoundTag nbt) {
        this(chunk, nbt, null);
    }

    public EntityArrow(FullChunk chunk, CompoundTag nbt, Entity shootingEntity) {
        this(chunk, nbt, shootingEntity, false);
    }

    public EntityArrow(FullChunk chunk, CompoundTag nbt, Entity shootingEntity, boolean critical) {
        super(chunk, nbt, shootingEntity);
        this.isCritical = critical;
    }

    @Override
    public boolean onUpdate(int currentTick) {
        if (this.closed) {
            return false;
        }
        boolean hasUpdate = super.onUpdate(currentTick);
        if (!this.hadCollision && this.isCritical) {
            NukkitRandom random = new NukkitRandom();
            this.level.addParticle(new CriticalParticle(this.add((double)(this.getWidth() / 2.0f) + (double)NukkitMath.randomRange(random, -100, 100) / 500.0, (double)(this.getHeight() / 2.0f) + (double)NukkitMath.randomRange(random, -100, 100) / 500.0, (double)(this.getWidth() / 2.0f) + (double)NukkitMath.randomRange(random, -100, 100) / 500.0)));
        } else if (this.onGround) {
            this.isCritical = false;
        }
        if (this.age > 1200) {
            this.kill();
            hasUpdate = true;
        }
        return hasUpdate;
    }

    @Override
    public void spawnTo(Player player) {
        AddEntityPacket pk = new AddEntityPacket();
        pk.type = 80;
        pk.eid = this.getId();
        pk.x = (float)this.x;
        pk.y = (float)this.y;
        pk.z = (float)this.z;
        pk.speedX = (float)this.motionX;
        pk.speedY = (float)this.motionY;
        pk.speedZ = (float)this.motionZ;
        pk.metadata = this.dataProperties;
        player.dataPacket(pk);
        super.spawnTo(player);
    }
}

