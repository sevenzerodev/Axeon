/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.entity.projectile;

import cn.axeon.Player;
import cn.axeon.entity.Entity;
import cn.axeon.entity.projectile.EntityProjectile;
import cn.axeon.level.format.FullChunk;
import cn.axeon.nbt.tag.CompoundTag;
import cn.axeon.network.protocol.AddEntityPacket;

public class EntityEgg
extends EntityProjectile {
    public static final int NETWORK_ID = 82;

    @Override
    public int getNetworkId() {
        return 82;
    }

    @Override
    public float getWidth() {
        return 0.25f;
    }

    @Override
    public float getLength() {
        return 0.25f;
    }

    @Override
    public float getHeight() {
        return 0.25f;
    }

    @Override
    protected float getGravity() {
        return 0.03f;
    }

    @Override
    protected float getDrag() {
        return 0.01f;
    }

    public EntityEgg(FullChunk chunk, CompoundTag nbt) {
        this(chunk, nbt, null);
    }

    public EntityEgg(FullChunk chunk, CompoundTag nbt, Entity shootingEntity) {
        super(chunk, nbt, shootingEntity);
    }

    @Override
    public boolean onUpdate(int currentTick) {
        if (this.closed) {
            return false;
        }
        boolean hasUpdate = super.onUpdate(currentTick);
        if (this.age > 1200 || this.isCollided) {
            this.kill();
            hasUpdate = true;
        }
        return hasUpdate;
    }

    @Override
    public void spawnTo(Player player) {
        AddEntityPacket pk = new AddEntityPacket();
        pk.type = 82;
        pk.eid = this.getId();
        pk.x = (float)this.x;
        pk.y = (float)this.y;
        pk.z = (float)this.z;
        pk.speedX = (float)this.motionX;
        pk.speedY = (float)this.motionY;
        pk.speedZ = (float)this.motionZ;
        pk.metadata = this.dataProperties;
        player.dataPacket(pk);
        super.spawnTo(player);
    }
}

