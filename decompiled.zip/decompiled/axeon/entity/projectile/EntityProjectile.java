/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.entity.projectile;

import cn.axeon.entity.Entity;
import cn.axeon.entity.EntityLiving;
import cn.axeon.entity.data.LongEntityData;
import cn.axeon.entity.projectile.EntityArrow;
import cn.axeon.event.entity.EntityCombustByEntityEvent;
import cn.axeon.event.entity.EntityDamageByChildEntityEvent;
import cn.axeon.event.entity.EntityDamageByEntityEvent;
import cn.axeon.event.entity.EntityDamageEvent;
import cn.axeon.event.entity.ProjectileHitEvent;
import cn.axeon.level.MovingObjectPosition;
import cn.axeon.level.format.FullChunk;
import cn.axeon.math.AxisAlignedBB;
import cn.axeon.math.Vector3;
import cn.axeon.nbt.tag.CompoundTag;
import java.util.Random;

public abstract class EntityProjectile
extends Entity {
    public static final int DATA_SHOOTER_ID = 17;
    public Entity shootingEntity = null;
    public boolean hadCollision = false;

    protected double getDamage() {
        return 0.0;
    }

    public EntityProjectile(FullChunk chunk, CompoundTag nbt) {
        this(chunk, nbt, null);
    }

    public EntityProjectile(FullChunk chunk, CompoundTag nbt, Entity shootingEntity) {
        super(chunk, nbt);
        this.shootingEntity = shootingEntity;
        if (shootingEntity != null) {
            this.setDataProperty(new LongEntityData(17, shootingEntity.getId()));
        }
    }

    @Override
    public void attack(EntityDamageEvent source) {
        if (source.getCause() == 11) {
            super.attack(source);
        }
    }

    @Override
    protected void initEntity() {
        super.initEntity();
        this.setMaxHealth(1);
        this.setHealth(1.0f);
        if (this.namedTag.contains("Age")) {
            this.age = this.namedTag.getShort("Age");
        }
    }

    @Override
    public boolean canCollideWith(Entity entity) {
        return entity instanceof EntityLiving && !this.onGround;
    }

    @Override
    public void saveNBT() {
        super.saveNBT();
        this.namedTag.putShort("Age", this.age);
    }

    @Override
    public boolean onUpdate(int currentTick) {
        if (this.closed) {
            return false;
        }
        int tickDiff = currentTick - this.lastUpdate;
        if (tickDiff <= 0 && !this.justCreated) {
            return true;
        }
        this.lastUpdate = currentTick;
        boolean hasUpdate = this.entityBaseTick(tickDiff);
        if (this.isAlive()) {
            MovingObjectPosition movingObjectPosition = null;
            if (!this.isCollided) {
                this.motionY -= (double)this.getGravity();
            }
            Vector3 moveVector = new Vector3(this.x + this.motionX, this.y + this.motionY, this.z + this.motionZ);
            Entity[] list = this.getLevel().getCollidingEntities(this.boundingBox.addCoord(this.motionX, this.motionY, this.motionZ).expand(1.0, 1.0, 1.0), this);
            double nearDistance = 2.147483647E9;
            Entity nearEntity = null;
            for (Entity entity : list) {
                double distance;
                AxisAlignedBB axisalignedbb;
                MovingObjectPosition ob;
                if (entity == this.shootingEntity && this.ticksLived < 5 || (ob = (axisalignedbb = entity.boundingBox.grow(0.3, 0.3, 0.3)).calculateIntercept(this, moveVector)) == null || !((distance = this.distanceSquared(ob.hitVector)) < nearDistance)) continue;
                nearDistance = distance;
                nearEntity = entity;
            }
            if (nearEntity != null) {
                movingObjectPosition = MovingObjectPosition.fromEntity(nearEntity);
            }
            if (movingObjectPosition != null && movingObjectPosition.entityHit != null) {
                this.server.getPluginManager().callEvent(new ProjectileHitEvent(this));
                double motion = Math.sqrt(this.motionX * this.motionX + this.motionY * this.motionY + this.motionZ * this.motionZ);
                double damage = Math.ceil(motion * this.getDamage());
                if (this instanceof EntityArrow && ((EntityArrow)this).isCritical) {
                    damage += (double)new Random().nextInt((int)(damage / 2.0) + 1);
                }
                EntityDamageByEntityEvent ev = this.shootingEntity == null ? new EntityDamageByEntityEvent((Entity)this, movingObjectPosition.entityHit, 2, (float)damage) : new EntityDamageByChildEntityEvent(this.shootingEntity, (Entity)this, movingObjectPosition.entityHit, 2, (float)damage);
                movingObjectPosition.entityHit.attack(ev);
                this.hadCollision = true;
                if (this.fireTicks > 0) {
                    EntityCombustByEntityEvent ev2 = new EntityCombustByEntityEvent(this, movingObjectPosition.entityHit, 5);
                    this.server.getPluginManager().callEvent(ev2);
                    if (!ev2.isCancelled()) {
                        movingObjectPosition.entityHit.setOnFire(ev2.getDuration());
                    }
                }
                this.kill();
                return true;
            }
            this.move(this.motionX, this.motionY, this.motionZ);
            if (this.isCollided && !this.hadCollision) {
                this.hadCollision = true;
                this.motionX = 0.0;
                this.motionY = 0.0;
                this.motionZ = 0.0;
                this.server.getPluginManager().callEvent(new ProjectileHitEvent(this));
            } else if (!this.isCollided && this.hadCollision) {
                this.hadCollision = false;
            }
            if (!this.onGround || Math.abs(this.motionX) > 1.0E-5 || Math.abs(this.motionY) > 1.0E-5 || Math.abs(this.motionZ) > 1.0E-5) {
                double f = Math.sqrt(this.motionX * this.motionX + this.motionZ * this.motionZ);
                this.yaw = Math.atan2(this.motionX, this.motionZ) * 180.0 / Math.PI;
                this.pitch = Math.atan2(this.motionY, f) * 180.0 / Math.PI;
                hasUpdate = true;
            }
            this.updateMovement();
        }
        return hasUpdate;
    }
}

