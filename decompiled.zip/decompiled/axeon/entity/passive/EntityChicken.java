/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.entity.passive;

import cn.axeon.entity.passive.EntityAnimal;
import cn.axeon.item.Item;
import cn.axeon.level.format.FullChunk;
import cn.axeon.nbt.tag.CompoundTag;

public class EntityChicken
extends EntityAnimal {
    public static final int NETWORK_ID = 10;

    public EntityChicken(FullChunk chunk, CompoundTag nbt) {
        super(chunk, nbt);
    }

    @Override
    public float getWidth() {
        return 0.4f;
    }

    @Override
    public float getHeight() {
        if (this.isBaby()) {
            return 0.51f;
        }
        return 0.7f;
    }

    @Override
    public float getEyeHeight() {
        if (this.isBaby()) {
            return 0.51f;
        }
        return 0.7f;
    }

    @Override
    public String getName() {
        return this.getNameTag();
    }

    @Override
    public Item[] getDrops() {
        return new Item[]{Item.get(365), Item.get(288)};
    }

    @Override
    public int getNetworkId() {
        return 10;
    }

    @Override
    protected void initEntity() {
        super.initEntity();
        this.setMaxHealth(4);
    }
}

