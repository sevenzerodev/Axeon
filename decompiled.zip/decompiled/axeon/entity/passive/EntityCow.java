/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.entity.passive;

import cn.axeon.entity.passive.EntityAnimal;
import cn.axeon.item.Item;
import cn.axeon.level.format.FullChunk;
import cn.axeon.nbt.tag.CompoundTag;

public class EntityCow
extends EntityAnimal {
    public static final int NETWORK_ID = 11;

    public EntityCow(FullChunk chunk, CompoundTag nbt) {
        super(chunk, nbt);
    }

    @Override
    public float getWidth() {
        return 0.9f;
    }

    @Override
    public float getHeight() {
        if (this.isBaby()) {
            return 0.65f;
        }
        return 1.3f;
    }

    @Override
    public float getEyeHeight() {
        if (this.isBaby()) {
            return 0.65f;
        }
        return 1.2f;
    }

    @Override
    public String getName() {
        return this.getNameTag();
    }

    @Override
    public Item[] getDrops() {
        return new Item[]{Item.get(334), Item.get(363)};
    }

    @Override
    public int getNetworkId() {
        return 11;
    }

    @Override
    protected void initEntity() {
        super.initEntity();
        this.setMaxHealth(10);
    }
}

