/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.entity.passive;

import cn.axeon.entity.passive.EntityTameable;
import cn.axeon.item.Item;
import cn.axeon.level.format.FullChunk;
import cn.axeon.nbt.tag.CompoundTag;

public class EntityOcelot
extends EntityTameable {
    public static final int NETWORK_ID = 22;

    public EntityOcelot(FullChunk chunk, CompoundTag nbt) {
        super(chunk, nbt);
    }

    @Override
    public float getWidth() {
        return 0.6f;
    }

    @Override
    public float getLength() {
        return 0.6f;
    }

    @Override
    public float getHeight() {
        if (this.isBaby()) {
            return 0.8f;
        }
        return 0.8f;
    }

    @Override
    public float getEyeHeight() {
        if (this.isBaby()) {
            return 0.8f * this.getHeight();
        }
        return 0.8f * this.getHeight();
    }

    @Override
    public String getName() {
        return this.getNameTag();
    }

    @Override
    public Item[] getDrops() {
        return new Item[0];
    }

    @Override
    public int getNetworkId() {
        return 22;
    }

    @Override
    public void initEntity() {
        super.initEntity();
        if (this.isTamed()) {
            this.setMaxHealth(20);
        } else {
            this.setMaxHealth(8);
        }
    }
}

