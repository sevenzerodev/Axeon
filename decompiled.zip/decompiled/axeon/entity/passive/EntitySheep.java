/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.entity.passive;

import cn.axeon.entity.passive.EntityAnimal;
import cn.axeon.item.Item;
import cn.axeon.level.format.FullChunk;
import cn.axeon.nbt.tag.CompoundTag;

public class EntitySheep
extends EntityAnimal {
    public static final int NETWORK_ID = 13;

    public EntitySheep(FullChunk chunk, CompoundTag nbt) {
        super(chunk, nbt);
    }

    @Override
    public float getWidth() {
        return 0.9f;
    }

    @Override
    public float getHeight() {
        if (this.isBaby()) {
            return 0.9f;
        }
        return 1.3f;
    }

    @Override
    public float getEyeHeight() {
        if (this.isBaby()) {
            return 0.85499996f;
        }
        return 0.95f * this.getHeight();
    }

    @Override
    public String getName() {
        return this.getNameTag();
    }

    @Override
    public Item[] getDrops() {
        return new Item[]{Item.get(35)};
    }

    @Override
    public int getNetworkId() {
        return 13;
    }

    @Override
    public void initEntity() {
        this.setMaxHealth(8);
    }
}

