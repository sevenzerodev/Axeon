/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.entity.passive;

import cn.axeon.entity.passive.EntityAnimal;
import cn.axeon.item.Item;
import cn.axeon.level.format.FullChunk;
import cn.axeon.nbt.tag.CompoundTag;

public class EntityPig
extends EntityAnimal {
    public static final int NETWORK_ID = 12;

    public EntityPig(FullChunk chunk, CompoundTag nbt) {
        super(chunk, nbt);
    }

    @Override
    public float getWidth() {
        return 0.9f;
    }

    @Override
    public float getHeight() {
        if (this.isBaby()) {
            return 0.9f;
        }
        return 0.9f;
    }

    @Override
    public float getEyeHeight() {
        if (this.isBaby()) {
            return 0.9f;
        }
        return 0.9f;
    }

    @Override
    public String getName() {
        return this.getNameTag();
    }

    @Override
    public Item[] getDrops() {
        return new Item[]{Item.get(319)};
    }

    @Override
    public int getNetworkId() {
        return 12;
    }

    @Override
    protected void initEntity() {
        super.initEntity();
        this.setMaxHealth(10);
    }
}

