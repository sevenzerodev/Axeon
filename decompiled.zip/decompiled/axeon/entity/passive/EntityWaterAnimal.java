/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.entity.passive;

import cn.axeon.entity.EntityAgeable;
import cn.axeon.entity.EntityCreature;
import cn.axeon.entity.data.ByteEntityData;
import cn.axeon.level.format.FullChunk;
import cn.axeon.nbt.tag.CompoundTag;

public abstract class EntityWaterAnimal
extends EntityCreature
implements EntityAgeable {
    public EntityWaterAnimal(FullChunk chunk, CompoundTag nbt) {
        super(chunk, nbt);
    }

    @Override
    protected void initEntity() {
        super.initEntity();
        if (this.getDataProperty(14) == null) {
            this.setDataProperty(new ByteEntityData(14, 0));
        }
    }

    @Override
    public boolean isBaby() {
        return this.getDataFlag(14, 0);
    }
}

