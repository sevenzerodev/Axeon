/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.entity.weather;

import cn.axeon.entity.weather.EntityWeather;

public interface EntityLightningStrike
extends EntityWeather {
    public boolean isEffect();

    public void setEffect(boolean var1);
}

