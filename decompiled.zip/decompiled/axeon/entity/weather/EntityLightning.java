/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.entity.weather;

import cn.axeon.Player;
import cn.axeon.Server;
import cn.axeon.block.Block;
import cn.axeon.block.BlockFire;
import cn.axeon.entity.Entity;
import cn.axeon.entity.EntityLiving;
import cn.axeon.entity.item.EntityItem;
import cn.axeon.entity.mob.EntityCreeper;
import cn.axeon.entity.weather.EntityLightningStrike;
import cn.axeon.event.entity.EntityDamageByEntityEvent;
import cn.axeon.event.entity.EntityDamageEvent;
import cn.axeon.level.format.FullChunk;
import cn.axeon.nbt.tag.CompoundTag;
import cn.axeon.network.protocol.AddEntityPacket;

public class EntityLightning
extends Entity
implements EntityLightningStrike {
    public static final int NETWORK_ID = 93;
    protected boolean isEffect = true;

    @Override
    public int getNetworkId() {
        return 93;
    }

    public EntityLightning(FullChunk chunk, CompoundTag nbt) {
        super(chunk, nbt);
    }

    @Override
    protected void initEntity() {
        super.initEntity();
        this.setHealth(4.0f);
        this.setMaxHealth(4);
    }

    @Override
    public boolean isEffect() {
        return this.isEffect;
    }

    @Override
    public void setEffect(boolean e) {
        this.isEffect = e;
    }

    @Override
    public void spawnTo(Player player) {
        AddEntityPacket pk = new AddEntityPacket();
        pk.eid = this.getId();
        pk.type = 93;
        pk.x = (float)this.x;
        pk.y = (float)this.y;
        pk.z = (float)this.z;
        pk.speedX = 0.0f;
        pk.speedY = 0.0f;
        pk.speedZ = 0.0f;
        pk.yaw = (float)this.yaw;
        pk.pitch = (float)this.pitch;
        pk.metadata = this.dataProperties;
        player.dataPacket(pk);
        super.spawnTo(player);
    }

    @Override
    public void attack(EntityDamageEvent source) {
        source.setDamage(0.0f);
        super.attack(source);
        if (source.isCancelled()) {
            return;
        }
    }

    @Override
    public boolean onUpdate(int currentTick) {
        int tickDiff;
        if (this.closed) {
            return false;
        }
        if (this.justCreated && this.isEffect()) {
            Block block;
            for (Entity e : this.level.getNearbyEntities(this.boundingBox.grow(6.0, 12.0, 6.0), this)) {
                if (e instanceof EntityLiving) {
                    e.attack(new EntityDamageByEntityEvent((Entity)this, e, 15, 5.0f));
                    e.setOnFire(5);
                    if (!(e instanceof EntityCreeper) || ((EntityCreeper)e).isPowered()) continue;
                    ((EntityCreeper)e).setPowered(this);
                    continue;
                }
                if (!(e instanceof EntityItem)) continue;
                e.kill();
            }
            if (Server.getInstance().getDifficulty() >= 2 && ((block = this.getLevelBlock()).getId() == 0 || block.getId() == 31)) {
                BlockFire fire = new BlockFire();
                fire.x = block.x;
                fire.y = block.y;
                fire.z = block.z;
                fire.level = this.level;
                this.getLevel().setBlock(fire, fire, true);
                if (fire.isBlockTopFacingSurfaceSolid(fire.getSide(0)) || fire.canNeighborBurn()) {
                    this.level.setBlock(fire, fire, true);
                    this.level.scheduleUpdate(fire, fire.tickRate() + this.level.rand.nextInt(10));
                }
            }
        }
        if ((tickDiff = currentTick - this.lastUpdate) <= 0 && !this.justCreated) {
            return true;
        }
        this.lastUpdate = currentTick;
        boolean hasUpdate = true;
        this.entityBaseTick(tickDiff);
        if (this.isAlive() && this.age >= 1) {
            this.close();
            hasUpdate = false;
        }
        return hasUpdate;
    }
}

