/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.entity;

public interface EntityAgeable {
    public static final int DATA_AGEABLE_FLAGS = 14;
    public static final int DATA_FLAG_BABY = 0;

    public boolean isBaby();
}

