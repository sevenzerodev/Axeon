/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.entity;

public interface EntitySmite {
}

