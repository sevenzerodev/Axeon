/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.entity;

import cn.axeon.entity.EntityLiving;
import cn.axeon.level.format.FullChunk;
import cn.axeon.nbt.tag.CompoundTag;

public abstract class EntityCreature
extends EntityLiving {
    public EntityCreature(FullChunk chunk, CompoundTag nbt) {
        super(chunk, nbt);
    }
}

