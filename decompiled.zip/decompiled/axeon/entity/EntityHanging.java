/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.entity;

import cn.axeon.entity.Entity;
import cn.axeon.level.format.FullChunk;
import cn.axeon.nbt.tag.CompoundTag;

public abstract class EntityHanging
extends Entity {
    protected int direction;

    public EntityHanging(FullChunk chunk, CompoundTag nbt) {
        super(chunk, nbt);
    }

    @Override
    protected void initEntity() {
        super.initEntity();
        this.setMaxHealth(1);
        this.setHealth(1.0f);
        if (this.namedTag.contains("Direction")) {
            this.direction = this.namedTag.getByte("Direction");
        } else if (this.namedTag.contains("Dir")) {
            int d = this.namedTag.getByte("Dir");
            if (d == 2) {
                this.direction = 0;
            } else if (d == 0) {
                this.direction = 2;
            }
        }
    }

    @Override
    public void saveNBT() {
        super.saveNBT();
        this.namedTag.putByte("Direction", this.getDirection());
        this.namedTag.putInt("TileX", (int)this.x);
        this.namedTag.putInt("TileY", (int)this.y);
        this.namedTag.putInt("TileZ", (int)this.z);
    }

    @Override
    public Integer getDirection() {
        return this.direction;
    }

    @Override
    public boolean onUpdate(int currentTick) {
        if (this.closed) {
            return false;
        }
        if (!this.isAlive()) {
            this.despawnFromAll();
            if (!this.isPlayer) {
                this.close();
            }
            return true;
        }
        if (this.lastYaw != this.yaw || this.lastX != this.x || this.lastY != this.y || this.lastZ != this.z) {
            this.despawnFromAll();
            this.direction = (int)(this.yaw / 90.0);
            this.lastYaw = this.yaw;
            this.lastX = this.x;
            this.lastY = this.y;
            this.lastZ = this.z;
            this.spawnToAll();
            return true;
        }
        return false;
    }

    protected boolean isSurfaceValid() {
        return true;
    }
}

