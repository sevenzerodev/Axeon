/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.entity;

import cn.axeon.Player;
import cn.axeon.entity.EntityCreature;
import cn.axeon.entity.data.PositionEntityData;
import cn.axeon.entity.data.Skin;
import cn.axeon.inventory.InventoryHolder;
import cn.axeon.inventory.PlayerInventory;
import cn.axeon.item.Item;
import cn.axeon.level.format.FullChunk;
import cn.axeon.nbt.NBTIO;
import cn.axeon.nbt.tag.CompoundTag;
import cn.axeon.nbt.tag.ListTag;
import cn.axeon.network.protocol.AddPlayerPacket;
import cn.axeon.network.protocol.RemovePlayerPacket;
import cn.axeon.utils.Utils;
import java.nio.charset.StandardCharsets;
import java.util.UUID;

public class EntityHuman
extends EntityCreature
implements InventoryHolder {
    public static final int DATA_PLAYER_FLAG_SLEEP = 1;
    public static final int DATA_PLAYER_FLAG_DEAD = 2;
    public static final int DATA_PLAYER_FLAGS = 16;
    public static final int DATA_PLAYER_BED_POSITION = 17;
    protected PlayerInventory inventory;
    protected UUID uuid;
    protected byte[] rawUUID;
    protected Skin skin;

    @Override
    public float getWidth() {
        return 0.6f;
    }

    @Override
    public float getLength() {
        return 0.6f;
    }

    @Override
    public float getHeight() {
        return 1.8f;
    }

    @Override
    public float getEyeHeight() {
        return 1.62f;
    }

    @Override
    public int getNetworkId() {
        return -1;
    }

    public EntityHuman(FullChunk chunk, CompoundTag nbt) {
        super(chunk, nbt);
    }

    public Skin getSkin() {
        return this.skin;
    }

    public UUID getUniqueId() {
        return this.uuid;
    }

    public byte[] getRawUniqueId() {
        return this.rawUUID;
    }

    public void setSkin(Skin skin) {
        this.skin = skin;
    }

    @Override
    public PlayerInventory getInventory() {
        return this.inventory;
    }

    @Override
    protected void initEntity() {
        this.setDataFlag(16, 1, false);
        this.setDataProperty(new PositionEntityData(17, 0, 0, 0));
        this.inventory = new PlayerInventory(this);
        if (this instanceof Player) {
            ((Player)this).addWindow(this.inventory, 0);
        }
        if (!(this instanceof Player)) {
            if (this.namedTag.contains("NameTag")) {
                this.setNameTag(this.namedTag.getString("NameTag"));
            }
            if (this.namedTag.contains("Skin") && this.namedTag.get("Skin") instanceof CompoundTag) {
                if (!this.namedTag.getCompound("Skin").contains("Transparent")) {
                    this.namedTag.getCompound("Skin").putBoolean("Transparent", false);
                }
                this.setSkin(new Skin(this.namedTag.getCompound("Skin").getByteArray("Data"), this.namedTag.getCompound("Skin").getString("ModelId")));
            }
            this.uuid = Utils.dataToUUID(String.valueOf(this.getId()).getBytes(StandardCharsets.UTF_8), this.getSkin().getData(), this.getNameTag().getBytes(StandardCharsets.UTF_8));
        }
        if (this.namedTag.contains("Inventory") && this.namedTag.get("Inventory") instanceof ListTag) {
            ListTag<CompoundTag> inventoryList = this.namedTag.getList("Inventory", CompoundTag.class);
            for (CompoundTag item : inventoryList.getAll()) {
                int slot = item.getByte("Slot");
                if (slot >= 0 && slot < 9) {
                    this.inventory.setHotbarSlotIndex(slot, item.contains("TrueSlot") ? item.getByte("TrueSlot") : -1);
                    continue;
                }
                if (slot >= 100 && slot < 104) {
                    this.inventory.setItem(this.inventory.getSize() + slot - 100, NBTIO.getItemHelper(item));
                    continue;
                }
                this.inventory.setItem(slot - 9, NBTIO.getItemHelper(item));
            }
        }
        super.initEntity();
    }

    @Override
    public String getName() {
        return this.getNameTag();
    }

    @Override
    public Item[] getDrops() {
        if (this.inventory != null) {
            return (Item[])this.inventory.getContents().values().stream().toArray(Item[]::new);
        }
        return new Item[0];
    }

    @Override
    public void saveNBT() {
        super.saveNBT();
        this.namedTag.putList(new ListTag("Inventory"));
        if (this.inventory != null) {
            int slot;
            Item item;
            for (int slot2 = 0; slot2 < 9; ++slot2) {
                int hotbarSlot = this.inventory.getHotbarSlotIndex(slot2);
                if (hotbarSlot != -1 && (item = this.inventory.getItem(hotbarSlot)).getId() != 0 && item.getCount() > 0) {
                    this.namedTag.getList("Inventory", CompoundTag.class).add(NBTIO.putItemHelper(item, slot2).putByte("TrueSlot", hotbarSlot));
                    continue;
                }
                this.namedTag.getList("Inventory", CompoundTag.class).add(new CompoundTag().putByte("Count", 0).putShort("Damage", 0).putByte("Slot", slot2).putByte("TrueSlot", -1).putShort("id", 0));
            }
            int slotCount = 45;
            for (slot = 9; slot < slotCount; ++slot) {
                item = this.inventory.getItem(slot - 9);
                this.namedTag.getList("Inventory", CompoundTag.class).add(NBTIO.putItemHelper(item, slot));
            }
            for (slot = 100; slot < 104; ++slot) {
                item = this.inventory.getItem(this.inventory.getSize() + slot - 100);
                if (item == null || item.getId() == 0) continue;
                this.namedTag.getList("Inventory", CompoundTag.class).add(NBTIO.putItemHelper(item, slot));
            }
        }
        if (this.getSkin().getData().length > 0) {
            this.namedTag.putCompound("Skin", new CompoundTag().putByteArray("Data", this.getSkin().getData()).putString("ModelId", this.getSkin().getModel()));
        }
    }

    @Override
    public void spawnTo(Player player) {
        if (this != player && !this.hasSpawned.containsKey(player.getLoaderId())) {
            this.hasSpawned.put(player.getLoaderId(), player);
            if (this.skin.getData().length < 8192) {
                throw new IllegalStateException(this.getClass().getSimpleName() + " must have a valid skin set");
            }
            if (!(this instanceof Player)) {
                this.server.updatePlayerListData(this.getUniqueId(), this.getId(), this.getName(), this.skin, new Player[]{player});
            }
            AddPlayerPacket pk = new AddPlayerPacket();
            pk.uuid = this.getUniqueId();
            pk.username = this.getName();
            pk.eid = this.getId();
            pk.x = (float)this.x;
            pk.y = (float)this.y;
            pk.z = (float)this.z;
            pk.speedX = (float)this.motionX;
            pk.speedY = (float)this.motionY;
            pk.speedZ = (float)this.motionZ;
            pk.yaw = (float)this.yaw;
            pk.pitch = (float)this.pitch;
            pk.item = this.getInventory().getItemInHand();
            pk.metadata = this.dataProperties;
            player.dataPacket(pk);
            this.inventory.sendArmorContents(player);
            if (!(this instanceof Player)) {
                this.server.removePlayerListData(this.getUniqueId(), new Player[]{player});
            }
        }
    }

    @Override
    public void despawnFrom(Player player) {
        if (this.hasSpawned.containsKey(player.getLoaderId())) {
            RemovePlayerPacket pk = new RemovePlayerPacket();
            pk.eid = this.getId();
            pk.uuid = this.getUniqueId();
            player.dataPacket(pk);
            this.hasSpawned.remove(player.getLoaderId());
        }
    }

    @Override
    public void close() {
        if (!this.closed) {
            if (!(this instanceof Player) || ((Player)this).loggedIn) {
                for (Player viewer : this.inventory.getViewers()) {
                    viewer.removeWindow(this.inventory);
                }
            }
            super.close();
        }
    }
}

