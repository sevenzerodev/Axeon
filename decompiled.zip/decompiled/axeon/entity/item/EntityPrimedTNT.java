/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.entity.item;

import cn.axeon.Player;
import cn.axeon.entity.Entity;
import cn.axeon.entity.EntityExplosive;
import cn.axeon.event.entity.EntityDamageEvent;
import cn.axeon.event.entity.EntityExplosionPrimeEvent;
import cn.axeon.level.Explosion;
import cn.axeon.level.format.FullChunk;
import cn.axeon.nbt.tag.CompoundTag;
import cn.axeon.network.protocol.AddEntityPacket;

public class EntityPrimedTNT
extends Entity
implements EntityExplosive {
    public static final int NETWORK_ID = 65;
    protected int fuse;

    @Override
    public float getWidth() {
        return 0.98f;
    }

    @Override
    public float getLength() {
        return 0.98f;
    }

    @Override
    public float getHeight() {
        return 0.98f;
    }

    @Override
    protected float getGravity() {
        return 0.04f;
    }

    @Override
    protected float getDrag() {
        return 0.02f;
    }

    @Override
    public boolean canCollide() {
        return false;
    }

    public EntityPrimedTNT(FullChunk chunk, CompoundTag nbt) {
        super(chunk, nbt);
    }

    @Override
    public int getNetworkId() {
        return 65;
    }

    @Override
    public void attack(EntityDamageEvent source) {
        if (source.getCause() == 11) {
            super.attack(source);
        }
    }

    @Override
    protected void initEntity() {
        super.initEntity();
        this.fuse = this.namedTag.contains("Fuse") ? this.namedTag.getByte("Fuse") : 80;
    }

    @Override
    public boolean canCollideWith(Entity entity) {
        return false;
    }

    @Override
    public void saveNBT() {
        super.saveNBT();
        this.namedTag.putByte("Fuse", this.fuse);
    }

    @Override
    public boolean onUpdate(int currentTick) {
        if (this.closed) {
            return false;
        }
        int tickDiff = currentTick - this.lastUpdate;
        if (tickDiff <= 0 && !this.justCreated) {
            return true;
        }
        this.lastUpdate = currentTick;
        boolean hasUpdate = this.entityBaseTick(tickDiff);
        if (this.isAlive()) {
            this.motionY -= (double)this.getGravity();
            this.move(this.motionX, this.motionY, this.motionZ);
            float friction = 1.0f - this.getDrag();
            this.motionX *= (double)friction;
            this.motionY *= (double)friction;
            this.motionZ *= (double)friction;
            this.updateMovement();
            if (this.onGround) {
                this.motionY *= -0.5;
                this.motionX *= 0.7;
                this.motionZ *= 0.7;
            }
            this.fuse -= tickDiff;
            if (this.fuse <= 0) {
                this.explode();
                this.kill();
            }
        }
        return hasUpdate || this.fuse >= 0 || Math.abs(this.motionX) > 1.0E-5 || Math.abs(this.motionY) > 1.0E-5 || Math.abs(this.motionZ) > 1.0E-5;
    }

    @Override
    public void explode() {
        EntityExplosionPrimeEvent event = new EntityExplosionPrimeEvent(this, 4.0);
        this.server.getPluginManager().callEvent(event);
        if (event.isCancelled()) {
            return;
        }
        Explosion explosion = new Explosion(this, event.getForce(), this);
        if (event.isBlockBreaking()) {
            explosion.explodeA();
        }
        explosion.explodeB();
    }

    @Override
    public void spawnTo(Player player) {
        AddEntityPacket packet = new AddEntityPacket();
        packet.type = 65;
        packet.eid = this.getId();
        packet.x = (float)this.x;
        packet.y = (float)this.y;
        packet.z = (float)this.z;
        packet.speedX = (float)this.motionX;
        packet.speedY = (float)this.motionY;
        packet.speedZ = (float)this.motionZ;
        packet.metadata = this.dataProperties;
        player.dataPacket(packet);
        super.spawnTo(player);
    }
}

