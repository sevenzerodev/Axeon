/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.entity.item;

import cn.axeon.Player;
import cn.axeon.Server;
import cn.axeon.entity.Entity;
import cn.axeon.entity.item.EntityVehicle;
import cn.axeon.event.entity.EntityDamageByEntityEvent;
import cn.axeon.event.entity.EntityDamageEvent;
import cn.axeon.item.ItemBoat;
import cn.axeon.level.format.FullChunk;
import cn.axeon.level.particle.SmokeParticle;
import cn.axeon.math.Vector3;
import cn.axeon.nbt.tag.CompoundTag;
import cn.axeon.network.protocol.AddEntityPacket;
import cn.axeon.network.protocol.DataPacket;
import cn.axeon.network.protocol.EntityEventPacket;

public class EntityBoat
extends EntityVehicle {
    public static final int NETWORK_ID = 90;
    public static final int DATA_WOOD_ID = 20;

    public EntityBoat(FullChunk chunk, CompoundTag nbt) {
        super(chunk, nbt);
    }

    @Override
    protected void initEntity() {
        super.initEntity();
        this.dataProperties.putByte(20, this.namedTag.getByte("woodID"));
        this.setHealth(4.0f);
        this.setMaxHealth(4);
    }

    @Override
    public float getHeight() {
        return 0.7f;
    }

    @Override
    public float getWidth() {
        return 1.6f;
    }

    @Override
    protected float getDrag() {
        return 0.1f;
    }

    @Override
    protected float getGravity() {
        return 0.1f;
    }

    @Override
    public int getNetworkId() {
        return 90;
    }

    @Override
    public void spawnTo(Player player) {
        AddEntityPacket pk = new AddEntityPacket();
        pk.eid = this.getId();
        pk.type = 90;
        pk.x = (float)this.x;
        pk.y = (float)this.y;
        pk.z = (float)this.z;
        pk.speedX = 0.0f;
        pk.speedY = 0.0f;
        pk.speedZ = 0.0f;
        pk.yaw = (float)this.yaw;
        pk.pitch = (float)this.pitch;
        pk.metadata = this.dataProperties;
        player.dataPacket(pk);
        super.spawnTo(player);
    }

    @Override
    public void attack(EntityDamageEvent source) {
        Entity damager;
        super.attack(source);
        if (source.isCancelled()) {
            return;
        }
        if (source instanceof EntityDamageByEntityEvent && (damager = ((EntityDamageByEntityEvent)source).getDamager()) instanceof Player) {
            if (((Player)damager).isCreative()) {
                this.kill();
            }
            if (this.getHealth() <= 0) {
                if (((Player)damager).isSurvival()) {
                    this.level.dropItem(this, new ItemBoat());
                }
                this.close();
            }
        }
        EntityEventPacket pk = new EntityEventPacket();
        pk.eid = this.getId();
        pk.event = (byte)(this.getHealth() <= 0 ? 3 : 2);
        Server.broadcastPacket(this.hasSpawned.values(), (DataPacket)pk);
    }

    @Override
    public void close() {
        super.close();
        if (this.linkedEntity instanceof Player) {
            this.linkedEntity.riding = null;
        }
        SmokeParticle particle = new SmokeParticle(this);
        this.level.addParticle(particle);
    }

    @Override
    public boolean onUpdate(int currentTick) {
        if (this.closed) {
            return false;
        }
        int tickDiff = currentTick - this.lastUpdate;
        if (tickDiff <= 0 && !this.justCreated) {
            return true;
        }
        this.lastUpdate = currentTick;
        boolean hasUpdate = this.entityBaseTick(tickDiff);
        if (this.isAlive()) {
            double d = this.motionY = this.level.getBlock(new Vector3(this.x, this.y, this.z)).getBoundingBox() != null || this.isInsideOfWater() ? (double)this.getGravity() : -0.08;
            if (this.checkObstruction(this.x, this.y, this.z)) {
                hasUpdate = true;
            }
            this.move(this.motionX, this.motionY, this.motionZ);
            double friction = 1.0f - this.getDrag();
            if (this.onGround && (Math.abs(this.motionX) > 1.0E-5 || Math.abs(this.motionZ) > 1.0E-5)) {
                friction *= this.getLevel().getBlock(this.temporalVector.setComponents((int)Math.floor(this.x), (int)Math.floor(this.y - 1.0), (int)Math.floor(this.z) - 1)).getFrictionFactor();
            }
            this.motionX *= friction;
            this.motionY *= (double)(1.0f - this.getDrag());
            this.motionZ *= friction;
            if (this.onGround) {
                this.motionY *= -0.5;
            }
            this.updateMovement();
        }
        return hasUpdate || !this.onGround || Math.abs(this.motionX) > 1.0E-5 || Math.abs(this.motionY) > 1.0E-5 || Math.abs(this.motionZ) > 1.0E-5;
    }
}

