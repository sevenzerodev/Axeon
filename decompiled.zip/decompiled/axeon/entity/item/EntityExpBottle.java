/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.entity.item;

import cn.axeon.Player;
import cn.axeon.entity.Entity;
import cn.axeon.entity.projectile.EntityProjectile;
import cn.axeon.level.format.FullChunk;
import cn.axeon.level.particle.EnchantParticle;
import cn.axeon.level.particle.SpellParticle;
import cn.axeon.math.NukkitRandom;
import cn.axeon.math.Vector3;
import cn.axeon.nbt.tag.CompoundTag;
import cn.axeon.network.protocol.AddEntityPacket;

public class EntityExpBottle
extends EntityProjectile {
    public static final int NETWORK_ID = 68;

    @Override
    public int getNetworkId() {
        return 68;
    }

    @Override
    public float getWidth() {
        return 0.25f;
    }

    @Override
    public float getLength() {
        return 0.25f;
    }

    @Override
    public float getHeight() {
        return 0.25f;
    }

    @Override
    protected float getGravity() {
        return 0.1f;
    }

    @Override
    protected float getDrag() {
        return 0.01f;
    }

    public EntityExpBottle(FullChunk chunk, CompoundTag nbt) {
        this(chunk, nbt, null);
    }

    public EntityExpBottle(FullChunk chunk, CompoundTag nbt, Entity shootingEntity) {
        super(chunk, nbt, shootingEntity);
    }

    @Override
    public boolean onUpdate(int currentTick) {
        if (this.closed) {
            return false;
        }
        int tickDiff = currentTick - this.lastUpdate;
        boolean hasUpdate = super.onUpdate(currentTick);
        if (this.age > 1200) {
            this.kill();
            hasUpdate = true;
        }
        if (this.isCollided) {
            this.kill();
            EnchantParticle particle1 = new EnchantParticle(this);
            this.getLevel().addParticle(particle1);
            SpellParticle particle2 = new SpellParticle((Vector3)this, 3694022);
            this.getLevel().addParticle(particle2);
            hasUpdate = true;
            NukkitRandom random = new NukkitRandom();
            int add = 1;
            for (int ii = 1; ii <= random.nextRange(3, 11); ii += add) {
                this.getLevel().dropExpOrb(this, add);
                add = random.nextRange(1, 3);
            }
        }
        return hasUpdate;
    }

    @Override
    public void spawnTo(Player player) {
        AddEntityPacket pk = new AddEntityPacket();
        pk.type = 68;
        pk.eid = this.getId();
        pk.x = (float)this.x;
        pk.y = (float)this.y;
        pk.z = (float)this.z;
        pk.speedX = (float)this.motionX;
        pk.speedY = (float)this.motionY;
        pk.speedZ = (float)this.motionZ;
        pk.metadata = this.dataProperties;
        player.dataPacket(pk);
        super.spawnTo(player);
    }
}

