/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.entity.item;

import cn.axeon.Player;
import cn.axeon.block.Block;
import cn.axeon.block.BlockAir;
import cn.axeon.block.BlockLiquid;
import cn.axeon.entity.Entity;
import cn.axeon.entity.data.IntEntityData;
import cn.axeon.event.entity.EntityBlockChangeEvent;
import cn.axeon.event.entity.EntityDamageEvent;
import cn.axeon.item.Item;
import cn.axeon.level.format.FullChunk;
import cn.axeon.math.Vector3;
import cn.axeon.nbt.tag.CompoundTag;
import cn.axeon.network.protocol.AddEntityPacket;

public class EntityFallingBlock
extends Entity {
    public static final int NETWORK_ID = 66;
    public static final int DATA_BLOCK_INFO = 20;
    protected int blockId;
    protected int damage;

    @Override
    public float getWidth() {
        return 0.98f;
    }

    @Override
    public float getLength() {
        return 0.98f;
    }

    @Override
    public float getHeight() {
        return 0.98f;
    }

    @Override
    protected float getGravity() {
        return 0.04f;
    }

    @Override
    protected float getDrag() {
        return 0.02f;
    }

    @Override
    public boolean canCollide() {
        return false;
    }

    public EntityFallingBlock(FullChunk chunk, CompoundTag nbt) {
        super(chunk, nbt);
    }

    @Override
    protected void initEntity() {
        super.initEntity();
        if (this.namedTag != null) {
            if (this.namedTag.contains("TileID")) {
                this.blockId = this.namedTag.getInt("TileID");
            } else if (this.namedTag.contains("Tile")) {
                this.blockId = this.namedTag.getInt("Tile");
                this.namedTag.putInt("TileID", this.blockId);
            }
            if (this.namedTag.contains("Data")) {
                this.damage = this.namedTag.getByte("Data");
            }
        }
        if (this.blockId == 0) {
            this.close();
            return;
        }
        this.setDataProperty(new IntEntityData(20, this.getBlock() | this.getDamage() << 8));
    }

    @Override
    public boolean canCollideWith(Entity entity) {
        return false;
    }

    @Override
    public void attack(EntityDamageEvent source) {
        if (source.getCause() == 11) {
            super.attack(source);
        }
    }

    @Override
    public boolean onUpdate(int currentTick) {
        if (this.closed) {
            return false;
        }
        int tickDiff = currentTick - this.lastUpdate;
        if (tickDiff <= 0 && !this.justCreated) {
            return true;
        }
        this.lastUpdate = currentTick;
        boolean hasUpdate = this.entityBaseTick(tickDiff);
        if (this.isAlive()) {
            Vector3 pos = new Vector3(this.x - 0.5, this.y, this.z - 0.5).round();
            if (this.ticksLived == 1) {
                Block block = this.level.getBlock(pos);
                if (block.getId() != this.blockId) {
                    this.kill();
                    return true;
                }
                this.level.setBlock(pos, new BlockAir(), true);
            }
            this.motionY -= (double)this.getGravity();
            this.move(this.motionX, this.motionY, this.motionZ);
            float friction = 1.0f - this.getDrag();
            this.motionX *= (double)friction;
            this.motionY *= (double)(1.0f - this.getDrag());
            this.motionZ *= (double)friction;
            pos = new Vector3(this.x - 0.5, this.y, this.z - 0.5).round();
            if (this.onGround) {
                this.kill();
                Block block = this.level.getBlock(pos);
                if (block.getId() > 0 && !block.isSolid() && !(block instanceof BlockLiquid)) {
                    this.getLevel().dropItem(this, Item.get(this.getBlock(), this.getDamage(), 1));
                } else {
                    EntityBlockChangeEvent event = new EntityBlockChangeEvent(this, block, Block.get(this.getBlock(), this.getDamage()));
                    this.server.getPluginManager().callEvent(event);
                    if (!event.isCancelled()) {
                        this.getLevel().setBlock(pos, event.getTo(), true);
                    }
                }
                hasUpdate = true;
            }
            this.updateMovement();
        }
        return hasUpdate || !this.onGround || Math.abs(this.motionX) > 1.0E-5 || Math.abs(this.motionY) > 1.0E-5 || Math.abs(this.motionZ) > 1.0E-5;
    }

    public int getBlock() {
        return this.blockId;
    }

    public int getDamage() {
        return this.damage;
    }

    @Override
    public int getNetworkId() {
        return 66;
    }

    @Override
    public void saveNBT() {
        this.namedTag.putInt("TileID", this.blockId);
        this.namedTag.putByte("Data", this.damage);
    }

    @Override
    public void spawnTo(Player player) {
        AddEntityPacket packet = new AddEntityPacket();
        packet.type = 66;
        packet.eid = this.getId();
        packet.x = (float)this.x;
        packet.y = (float)this.y;
        packet.z = (float)this.z;
        packet.speedX = (float)this.motionX;
        packet.speedY = (float)this.motionY;
        packet.speedZ = (float)this.motionZ;
        packet.yaw = (float)this.yaw;
        packet.pitch = (float)this.pitch;
        packet.metadata = this.dataProperties;
        player.dataPacket(packet);
        super.spawnTo(player);
    }
}

