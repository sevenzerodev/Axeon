/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.entity.item;

import cn.axeon.Player;
import cn.axeon.entity.Entity;
import cn.axeon.entity.data.EntityMetadata;
import cn.axeon.event.entity.EntityDamageEvent;
import cn.axeon.level.format.FullChunk;
import cn.axeon.nbt.tag.CompoundTag;
import cn.axeon.network.protocol.AddEntityPacket;

public class EntityXPOrb
extends Entity {
    public static final int NETWORK_ID = 69;
    private int age = 0;
    private int pickupDelay = 0;
    private int exp = 0;

    @Override
    public int getNetworkId() {
        return 69;
    }

    @Override
    public float getWidth() {
        return 0.25f;
    }

    @Override
    public float getLength() {
        return 0.25f;
    }

    @Override
    public float getHeight() {
        return 0.25f;
    }

    @Override
    protected float getGravity() {
        return 0.04f;
    }

    @Override
    protected float getDrag() {
        return 0.02f;
    }

    @Override
    public boolean canCollide() {
        return false;
    }

    public EntityXPOrb(FullChunk chunk, CompoundTag nbt) {
        super(chunk, nbt);
    }

    @Override
    protected void initEntity() {
        super.initEntity();
        this.setMaxHealth(5);
        this.setHealth(5.0f);
        if (this.namedTag.contains("Age")) {
            this.age = this.namedTag.getInt("Age");
        }
        if (this.namedTag.contains("PickupDelay")) {
            this.pickupDelay = this.namedTag.getInt("PickupDelay");
        }
    }

    @Override
    public void attack(EntityDamageEvent source) {
        switch (source.getCause()) {
            case 6: 
            case 9: 
            case 10: 
            case 11: {
                super.attack(source);
            }
        }
    }

    @Override
    public boolean onUpdate(int currentTick) {
        if (this.closed) {
            return false;
        }
        int tickDiff = currentTick - this.lastUpdate;
        if (tickDiff <= 0 && !this.justCreated) {
            return true;
        }
        this.lastUpdate = currentTick;
        boolean hasUpdate = this.entityBaseTick(tickDiff);
        if (this.isAlive()) {
            if (this.pickupDelay > 0 && this.pickupDelay < Short.MAX_VALUE) {
                this.pickupDelay -= tickDiff;
                if (this.pickupDelay < 0) {
                    this.pickupDelay = 0;
                }
            }
            this.motionY -= (double)this.getGravity();
            if (this.checkObstruction(this.x, this.y, this.z)) {
                hasUpdate = true;
            }
            this.move(this.motionX, this.motionY, this.motionZ);
            double friction = 1.0 - (double)this.getDrag();
            if (this.onGround && (Math.abs(this.motionX) > 1.0E-5 || Math.abs(this.motionZ) > 1.0E-5)) {
                friction = this.getLevel().getBlock(this.temporalVector.setComponents((int)Math.floor(this.x), (int)Math.floor(this.y - 1.0), (int)Math.floor(this.z) - 1)).getFrictionFactor() * friction;
            }
            this.motionX *= friction;
            this.motionY *= (double)(1.0f - this.getDrag());
            this.motionZ *= friction;
            if (this.onGround) {
                this.motionY *= -0.5;
            }
            this.updateMovement();
            if (this.age > 6000) {
                this.kill();
                hasUpdate = true;
            }
        }
        return hasUpdate || !this.onGround || Math.abs(this.motionX) > 1.0E-5 || Math.abs(this.motionY) > 1.0E-5 || Math.abs(this.motionZ) > 1.0E-5;
    }

    @Override
    public void saveNBT() {
        super.saveNBT();
        this.namedTag.putShort("Health", this.getHealth());
        this.namedTag.putShort("Age", this.age);
        this.namedTag.putShort("PickupDelay", this.pickupDelay);
    }

    public int getExp() {
        return this.exp;
    }

    public void setExp(int exp) {
        this.exp = exp;
    }

    @Override
    public boolean canCollideWith(Entity entity) {
        return false;
    }

    public int getPickupDelay() {
        return this.pickupDelay;
    }

    public void setPickupDelay(int pickupDelay) {
        this.pickupDelay = pickupDelay;
    }

    @Override
    public void spawnTo(Player player) {
        AddEntityPacket packet = new AddEntityPacket();
        packet.type = this.getNetworkId();
        packet.eid = this.getId();
        packet.x = (float)this.x;
        packet.y = (float)this.y;
        packet.z = (float)this.z;
        packet.speedX = (float)this.motionX;
        packet.speedY = (float)this.motionY;
        packet.speedZ = (float)this.motionZ;
        packet.metadata = new EntityMetadata();
        player.dataPacket(packet);
        super.spawnTo(player);
    }
}

