/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.entity.item;

import cn.axeon.entity.Entity;
import cn.axeon.entity.EntityRideable;
import cn.axeon.entity.data.FloatEntityData;
import cn.axeon.entity.data.IntEntityData;
import cn.axeon.level.format.FullChunk;
import cn.axeon.nbt.tag.CompoundTag;

public abstract class EntityVehicle
extends Entity
implements EntityRideable {
    public static final int DATA_HURT_TIME = 17;
    public static final int DATA_HURT_DIRECTION = 18;
    public static final int DATA_DAMAGE_TAKEN = 19;
    public Entity linkedEntity = null;

    public EntityVehicle(FullChunk chunk, CompoundTag nbt) {
        super(chunk, nbt);
    }

    public int getHurtTime() {
        return this.getDataPropertyInt(17);
    }

    public void setHurtTime(int time) {
        this.setDataProperty(new IntEntityData(17, time));
    }

    public int getHurtDirection() {
        return this.getDataPropertyInt(18);
    }

    public void setHurtDirection(int direction) {
        this.setDataProperty(new IntEntityData(18, direction));
    }

    public float getDamageTaken() {
        return this.getDataPropertyFloat(19);
    }

    public void setDamageTaken(float damage) {
        this.setDataProperty(new FloatEntityData(19, damage));
    }

    public Entity getLinkedEntity() {
        return this.linkedEntity;
    }

    public void setLinkedEntity(Entity entity) {
        this.linkedEntity = entity;
    }
}

