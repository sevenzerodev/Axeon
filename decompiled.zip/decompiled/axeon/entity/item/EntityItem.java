/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.entity.item;

import cn.axeon.Player;
import cn.axeon.entity.Entity;
import cn.axeon.event.entity.EntityDamageEvent;
import cn.axeon.event.entity.ItemDespawnEvent;
import cn.axeon.event.entity.ItemSpawnEvent;
import cn.axeon.item.Item;
import cn.axeon.level.format.FullChunk;
import cn.axeon.nbt.NBTIO;
import cn.axeon.nbt.tag.CompoundTag;
import cn.axeon.network.protocol.AddItemEntityPacket;

public class EntityItem
extends Entity {
    public static final int NETWORK_ID = 64;
    public static final int DATA_SOURCE_ID = 17;
    protected String owner = null;
    protected String thrower = null;
    protected Item item;
    protected int pickupDelay = 0;

    public EntityItem(FullChunk chunk, CompoundTag nbt) {
        super(chunk, nbt);
    }

    @Override
    public int getNetworkId() {
        return 64;
    }

    @Override
    public float getWidth() {
        return 0.25f;
    }

    @Override
    public float getLength() {
        return 0.25f;
    }

    @Override
    public float getHeight() {
        return 0.25f;
    }

    @Override
    public float getGravity() {
        return 0.04f;
    }

    @Override
    public float getDrag() {
        return 0.02f;
    }

    @Override
    public boolean canCollide() {
        return false;
    }

    @Override
    protected void initEntity() {
        super.initEntity();
        this.setMaxHealth(5);
        this.setHealth(this.namedTag.getShort("Health"));
        if (this.namedTag.contains("Age")) {
            this.age = this.namedTag.getShort("Age");
        }
        if (this.namedTag.contains("PickupDelay")) {
            this.pickupDelay = this.namedTag.getShort("PickupDelay");
        }
        if (this.namedTag.contains("Owner")) {
            this.owner = this.namedTag.getString("Owner");
        }
        if (this.namedTag.contains("Thrower")) {
            this.thrower = this.namedTag.getString("Thrower");
        }
        if (!this.namedTag.contains("Item")) {
            this.close();
            return;
        }
        this.item = NBTIO.getItemHelper(this.namedTag.getCompound("Item"));
        this.server.getPluginManager().callEvent(new ItemSpawnEvent(this));
    }

    @Override
    public void attack(EntityDamageEvent source) {
        if (source.getCause() == 11 || source.getCause() == 6 || source.getCause() == 10 || source.getCause() == 9) {
            super.attack(source);
        }
    }

    @Override
    public boolean onUpdate(int currentTick) {
        if (this.closed) {
            return false;
        }
        int tickDiff = currentTick - this.lastUpdate;
        if (tickDiff <= 0 && !this.justCreated) {
            return true;
        }
        this.lastUpdate = currentTick;
        boolean hasUpdate = this.entityBaseTick(tickDiff);
        if (this.isAlive()) {
            if (this.pickupDelay > 0 && this.pickupDelay < Short.MAX_VALUE) {
                this.pickupDelay -= tickDiff;
                if (this.pickupDelay < 0) {
                    this.pickupDelay = 0;
                }
            }
            this.motionY -= (double)this.getGravity();
            if (this.checkObstruction(this.x, this.y, this.z)) {
                hasUpdate = true;
            }
            this.move(this.motionX, this.motionY, this.motionZ);
            double friction = 1.0f - this.getDrag();
            if (this.onGround && (Math.abs(this.motionX) > 1.0E-5 || Math.abs(this.motionZ) > 1.0E-5)) {
                friction *= this.getLevel().getBlock(this.temporalVector.setComponents((int)Math.floor(this.x), (int)Math.floor(this.y - 1.0), (int)Math.floor(this.z) - 1)).getFrictionFactor();
            }
            this.motionX *= friction;
            this.motionY *= (double)(1.0f - this.getDrag());
            this.motionZ *= friction;
            if (this.onGround) {
                this.motionY *= -0.5;
            }
            this.updateMovement();
            if (this.age > 6000) {
                ItemDespawnEvent ev = new ItemDespawnEvent(this);
                this.server.getPluginManager().callEvent(ev);
                if (ev.isCancelled()) {
                    this.age = 0;
                } else {
                    this.kill();
                    hasUpdate = true;
                }
            }
        }
        return hasUpdate || !this.onGround || Math.abs(this.motionX) > 1.0E-5 || Math.abs(this.motionY) > 1.0E-5 || Math.abs(this.motionZ) > 1.0E-5;
    }

    @Override
    public void saveNBT() {
        if (this.item == null) {
            return;
        }
        super.saveNBT();
        this.namedTag.putCompound("Item", new CompoundTag().putShort("id", this.item.getId()).putShort("Damage", this.item.getDamage()).putByte("Count", this.item.getCount()));
        this.namedTag.putShort("Health", this.getHealth());
        this.namedTag.putShort("Age", this.age);
        this.namedTag.putShort("PickupDelay", this.pickupDelay);
        if (this.owner != null) {
            this.namedTag.putString("Owner", this.owner);
        }
        if (this.thrower != null) {
            this.namedTag.putString("Thrower", this.thrower);
        }
    }

    @Override
    public String getName() {
        return this.hasCustomName() ? this.getNameTag() : (this.item.hasCustomName() ? this.item.getCustomName() : this.item.getName());
    }

    public Item getItem() {
        return this.item;
    }

    @Override
    public boolean canCollideWith(Entity entity) {
        return false;
    }

    public int getPickupDelay() {
        return this.pickupDelay;
    }

    public void setPickupDelay(int pickupDelay) {
        this.pickupDelay = pickupDelay;
    }

    public String getOwner() {
        return this.owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    public String getThrower() {
        return this.thrower;
    }

    public void setThrower(String thrower) {
        this.thrower = thrower;
    }

    @Override
    public void spawnTo(Player player) {
        AddItemEntityPacket pk = new AddItemEntityPacket();
        pk.eid = this.getId();
        pk.x = (float)this.x;
        pk.y = (float)this.y;
        pk.z = (float)this.z;
        pk.speedX = (float)this.motionX;
        pk.speedY = (float)this.motionY;
        pk.speedZ = (float)this.motionZ;
        pk.item = this.getItem();
        player.dataPacket(pk);
        this.sendData(player);
        super.spawnTo(player);
    }
}

