/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.entity.item;

import cn.axeon.Player;
import cn.axeon.entity.Entity;
import cn.axeon.entity.projectile.EntityProjectile;
import cn.axeon.event.potion.PotionCollideEvent;
import cn.axeon.level.format.FullChunk;
import cn.axeon.level.particle.InstantSpellParticle;
import cn.axeon.level.particle.SpellParticle;
import cn.axeon.nbt.tag.CompoundTag;
import cn.axeon.network.protocol.AddEntityPacket;
import cn.axeon.potion.Effect;
import cn.axeon.potion.Potion;

public class EntityPotion
extends EntityProjectile {
    public static final int NETWORK_ID = 86;
    public static final int DATA_POTION_ID = 16;
    public int potionId;

    public EntityPotion(FullChunk chunk, CompoundTag nbt) {
        super(chunk, nbt);
    }

    public EntityPotion(FullChunk chunk, CompoundTag nbt, Entity shootingEntity) {
        super(chunk, nbt, shootingEntity);
    }

    @Override
    protected void initEntity() {
        super.initEntity();
        this.potionId = this.namedTag.getShort("PotionId");
        this.dataProperties.putShort(16, this.potionId);
    }

    @Override
    public int getNetworkId() {
        return 86;
    }

    @Override
    public float getWidth() {
        return 0.25f;
    }

    @Override
    public float getLength() {
        return 0.25f;
    }

    @Override
    public float getHeight() {
        return 0.25f;
    }

    @Override
    protected float getGravity() {
        return 0.1f;
    }

    @Override
    protected float getDrag() {
        return 0.01f;
    }

    @Override
    public boolean onUpdate(int currentTick) {
        if (this.closed) {
            return false;
        }
        int tickDiff = currentTick - this.lastUpdate;
        boolean hasUpdate = super.onUpdate(currentTick);
        if (this.age > 1200) {
            this.kill();
            hasUpdate = true;
        }
        if (this.isCollided) {
            Entity[] entities;
            int b;
            int g;
            int r;
            this.kill();
            Potion potion = Potion.getPotion(this.potionId);
            PotionCollideEvent event = new PotionCollideEvent(potion, this);
            this.server.getPluginManager().callEvent(event);
            if (event.isCancelled()) {
                return false;
            }
            potion = event.getPotion();
            if (potion == null) {
                return false;
            }
            potion.setSplash(true);
            Effect effect = Potion.getEffect(potion.getId(), true);
            if (effect == null) {
                r = 40;
                g = 40;
                b = 255;
            } else {
                int[] colors = effect.getColor();
                r = colors[0];
                g = colors[1];
                b = colors[2];
            }
            SpellParticle particle = Potion.isInstant(potion.getId()) ? new InstantSpellParticle(this, r, g, b) : new SpellParticle(this, r, g, b);
            this.getLevel().addParticle(particle);
            hasUpdate = true;
            for (Entity anEntity : entities = this.getLevel().getNearbyEntities(this.getBoundingBox().grow(8.25, 4.24, 8.25))) {
                potion.applyPotion(anEntity);
            }
        }
        return hasUpdate;
    }

    @Override
    public void spawnTo(Player player) {
        AddEntityPacket pk = new AddEntityPacket();
        pk.type = 86;
        pk.eid = this.getId();
        pk.x = (float)this.x;
        pk.y = (float)this.y;
        pk.z = (float)this.z;
        pk.speedX = (float)this.motionX;
        pk.speedY = (float)this.motionY;
        pk.speedZ = (float)this.motionZ;
        pk.metadata = this.dataProperties;
        player.dataPacket(pk);
        super.spawnTo(player);
    }
}

