/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.command;

import cn.axeon.plugin.Plugin;

public interface PluginIdentifiableCommand {
    public Plugin getPlugin();
}

