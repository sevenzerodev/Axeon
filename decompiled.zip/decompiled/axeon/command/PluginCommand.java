/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.command;

import cn.axeon.command.Command;
import cn.axeon.command.CommandExecutor;
import cn.axeon.command.CommandSender;
import cn.axeon.command.PluginIdentifiableCommand;
import cn.axeon.event.TranslationContainer;
import cn.axeon.plugin.Plugin;

public class PluginCommand<T extends Plugin>
extends Command
implements PluginIdentifiableCommand {
    private T owningPlugin;
    private CommandExecutor executor;

    public PluginCommand(String name, T owner) {
        super(name);
        this.owningPlugin = owner;
        this.executor = owner;
        this.usageMessage = "";
    }

    @Override
    public boolean execute(CommandSender sender, String commandLabel, String[] args) {
        if (!this.owningPlugin.isEnabled()) {
            return false;
        }
        if (!this.testPermission(sender)) {
            return false;
        }
        boolean success = this.executor.onCommand(sender, this, commandLabel, args);
        if (!success && !this.usageMessage.equals("")) {
            sender.sendMessage(new TranslationContainer("commands.generic.usage", this.usageMessage));
        }
        return success;
    }

    public CommandExecutor getExecutor() {
        return this.executor;
    }

    public void setExecutor(CommandExecutor executor) {
        this.executor = executor != null ? executor : this.owningPlugin;
    }

    public T getPlugin() {
        return this.owningPlugin;
    }
}

