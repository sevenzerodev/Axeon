/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.command;

import cn.axeon.Server;
import cn.axeon.command.Command;
import cn.axeon.command.CommandMap;
import cn.axeon.command.CommandSender;
import cn.axeon.command.FormattedCommandAlias;
import cn.axeon.command.defaults.BanCommand;
import cn.axeon.command.defaults.BanIpCommand;
import cn.axeon.command.defaults.BanListCommand;
import cn.axeon.command.defaults.DefaultGamemodeCommand;
import cn.axeon.command.defaults.DeopCommand;
import cn.axeon.command.defaults.DifficultyCommand;
import cn.axeon.command.defaults.EffectCommand;
import cn.axeon.command.defaults.EnchantCommand;
import cn.axeon.command.defaults.GamemodeCommand;
import cn.axeon.command.defaults.GarbageCollectorCommand;
import cn.axeon.command.defaults.GiveCommand;
import cn.axeon.command.defaults.HelpCommand;
import cn.axeon.command.defaults.KickCommand;
import cn.axeon.command.defaults.KillCommand;
import cn.axeon.command.defaults.ListCommand;
import cn.axeon.command.defaults.MeCommand;
import cn.axeon.command.defaults.OpCommand;
import cn.axeon.command.defaults.PardonCommand;
import cn.axeon.command.defaults.PardonIpCommand;
import cn.axeon.command.defaults.ParticleCommand;
import cn.axeon.command.defaults.PluginsCommand;
import cn.axeon.command.defaults.ReloadCommand;
import cn.axeon.command.defaults.SaveCommand;
import cn.axeon.command.defaults.SaveOffCommand;
import cn.axeon.command.defaults.SaveOnCommand;
import cn.axeon.command.defaults.SayCommand;
import cn.axeon.command.defaults.SeedCommand;
import cn.axeon.command.defaults.SetWorldSpawnCommand;
import cn.axeon.command.defaults.SpawnpointCommand;
import cn.axeon.command.defaults.StatusCommand;
import cn.axeon.command.defaults.StopCommand;
import cn.axeon.command.defaults.TeleportCommand;
import cn.axeon.command.defaults.TellCommand;
import cn.axeon.command.defaults.TimeCommand;
import cn.axeon.command.defaults.VanillaCommand;
import cn.axeon.command.defaults.VersionCommand;
import cn.axeon.command.defaults.WeatherCommand;
import cn.axeon.command.defaults.WhitelistCommand;
import cn.axeon.command.defaults.XpCommand;
import cn.axeon.event.TranslationContainer;
import cn.axeon.utils.MainLogger;
import cn.axeon.utils.Utils;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class SimpleCommandMap
implements CommandMap {
    protected Map<String, Command> knownCommands = new HashMap<String, Command>();
    private Server server;

    public SimpleCommandMap(Server server) {
        this.server = server;
        this.setDefaultCommands();
    }

    private void setDefaultCommands() {
        this.register("nukkit", new VersionCommand("version"));
        this.register("nukkit", new PluginsCommand("plugins"));
        this.register("nukkit", new SeedCommand("seed"));
        this.register("nukkit", new HelpCommand("help"));
        this.register("nukkit", new StopCommand("stop"));
        this.register("nukkit", new TellCommand("tell"));
        this.register("nukkit", new DefaultGamemodeCommand("defaultgamemode"));
        this.register("nukkit", new BanCommand("ban"));
        this.register("nukkit", new BanIpCommand("ban-ip"));
        this.register("nukkit", new BanListCommand("banlist"));
        this.register("nukkit", new PardonCommand("pardon"));
        this.register("nukkit", new PardonIpCommand("pardon-ip"));
        this.register("nukkit", new SayCommand("say"));
        this.register("nukkit", new MeCommand("me"));
        this.register("nukkit", new ListCommand("list"));
        this.register("nukkit", new DifficultyCommand("difficulty"));
        this.register("nukkit", new KickCommand("kick"));
        this.register("nukkit", new OpCommand("op"));
        this.register("nukkit", new DeopCommand("deop"));
        this.register("nukkit", new WhitelistCommand("whitelist"));
        this.register("nukkit", new SaveOnCommand("save-on"));
        this.register("nukkit", new SaveOffCommand("save-off"));
        this.register("nukkit", new SaveCommand("save-all"));
        this.register("nukkit", new GiveCommand("give"));
        this.register("nukkit", new EffectCommand("effect"));
        this.register("nukkit", new EnchantCommand("enchant"));
        this.register("nukkit", new ParticleCommand("particle"));
        this.register("nukkit", new GamemodeCommand("gamemode"));
        this.register("nukkit", new KillCommand("kill"));
        this.register("nukkit", new SpawnpointCommand("spawnpoint"));
        this.register("nukkit", new SetWorldSpawnCommand("setworldspawn"));
        this.register("nukkit", new TeleportCommand("tp"));
        this.register("nukkit", new TimeCommand("time"));
        this.register("nukkit", new ReloadCommand("reload"));
        this.register("nukkit", new WeatherCommand("weather"));
        this.register("nukkit", new XpCommand("xp"));
        if (((Boolean)this.server.getConfig("debug.commands", false)).booleanValue()) {
            this.register("nukkit", new StatusCommand("status"));
            this.register("nukkit", new GarbageCollectorCommand("gc"));
        }
    }

    @Override
    public void registerAll(String fallbackPrefix, List<? extends Command> commands) {
        for (Command command : commands) {
            this.register(fallbackPrefix, command);
        }
    }

    @Override
    public boolean register(String fallbackPrefix, Command command) {
        return this.register(fallbackPrefix, command, null);
    }

    @Override
    public boolean register(String fallbackPrefix, Command command, String label) {
        if (label == null) {
            label = command.getName();
        }
        label = label.trim().toLowerCase();
        fallbackPrefix = fallbackPrefix.trim().toLowerCase();
        boolean registered = this.registerAlias(command, false, fallbackPrefix, label);
        ArrayList<String> aliases = new ArrayList<String>(Arrays.asList(command.getAliases()));
        Iterator iterator = aliases.iterator();
        while (iterator.hasNext()) {
            String alias = (String)iterator.next();
            if (this.registerAlias(command, true, fallbackPrefix, alias)) continue;
            iterator.remove();
        }
        command.setAliases((String[])aliases.stream().toArray(String[]::new));
        if (!registered) {
            command.setLabel(fallbackPrefix + ":" + label);
        }
        command.register(this);
        return registered;
    }

    private boolean registerAlias(Command command, boolean isAlias, String fallbackPrefix, String label) {
        boolean existingCommandIsNotVanilla;
        this.knownCommands.put(fallbackPrefix + ":" + label, command);
        boolean alreadyRegistered = this.knownCommands.containsKey(label);
        Command existingCommand = this.knownCommands.get(label);
        boolean bl = existingCommandIsNotVanilla = alreadyRegistered && !(existingCommand instanceof VanillaCommand);
        if ((command instanceof VanillaCommand || isAlias) && alreadyRegistered && existingCommandIsNotVanilla) {
            return false;
        }
        if (alreadyRegistered && existingCommand.getLabel() != null && existingCommand.getLabel().equals(label) && existingCommandIsNotVanilla) {
            return false;
        }
        if (!isAlias) {
            command.setLabel(label);
        }
        this.knownCommands.put(label, command);
        return true;
    }

    @Override
    public boolean dispatch(CommandSender sender, String cmdLine) {
        block4: {
            String[] args = cmdLine.split(" ");
            if (args.length == 0) {
                return false;
            }
            String sentCommandLabel = args[0].toLowerCase();
            String[] newargs = new String[args.length - 1];
            System.arraycopy(args, 1, newargs, 0, newargs.length);
            args = newargs;
            Command target = this.getCommand(sentCommandLabel);
            if (target == null) {
                return false;
            }
            try {
                target.execute(sender, sentCommandLabel, args);
            }
            catch (Exception e) {
                sender.sendMessage(new TranslationContainer("\u00a7c%commands.generic.exception"));
                this.server.getLogger().critical(this.server.getLanguage().translateString("nukkit.command.exception", new String[]{cmdLine, target.toString(), Utils.getExceptionMessage(e)}));
                MainLogger logger = sender.getServer().getLogger();
                if (logger == null) break block4;
                logger.logException(e);
            }
        }
        return true;
    }

    @Override
    public void clearCommands() {
        for (Command command : this.knownCommands.values()) {
            command.unregister(this);
        }
        this.knownCommands.clear();
        this.setDefaultCommands();
    }

    @Override
    public Command getCommand(String name) {
        if (this.knownCommands.containsKey(name)) {
            return this.knownCommands.get(name);
        }
        return null;
    }

    public Map<String, Command> getCommands() {
        return this.knownCommands;
    }

    public void registerServerAliases() {
        Map<String, List<String>> values = this.server.getCommandAliases();
        for (Map.Entry<String, List<String>> entry : values.entrySet()) {
            String alias = entry.getKey();
            List<String> commandStrings = entry.getValue();
            if (alias.contains(" ") || alias.contains(":")) {
                this.server.getLogger().warning(this.server.getLanguage().translateString("nukkit.command.alias.illegal", alias));
                continue;
            }
            ArrayList<String> targets = new ArrayList<String>();
            String bad = "";
            for (String commandString : commandStrings) {
                String[] args = commandString.split(" ");
                Command command = this.getCommand(args[0]);
                if (command == null) {
                    if (bad.length() > 0) {
                        bad = bad + ", ";
                    }
                    bad = bad + commandString;
                    continue;
                }
                targets.add(commandString);
            }
            if (bad.length() > 0) {
                this.server.getLogger().warning(this.server.getLanguage().translateString("nukkit.command.alias.notFound", new String[]{alias, bad}));
                continue;
            }
            if (!targets.isEmpty()) {
                this.knownCommands.put(alias.toLowerCase(), new FormattedCommandAlias(alias.toLowerCase(), targets));
                continue;
            }
            this.knownCommands.remove(alias.toLowerCase());
        }
    }
}

