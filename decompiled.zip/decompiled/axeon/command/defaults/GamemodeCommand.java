/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.command.defaults;

import cn.axeon.Player;
import cn.axeon.Server;
import cn.axeon.command.Command;
import cn.axeon.command.CommandSender;
import cn.axeon.command.defaults.VanillaCommand;
import cn.axeon.event.TranslationContainer;

public class GamemodeCommand
extends VanillaCommand {
    public GamemodeCommand(String name) {
        super(name, "%nukkit.command.gamemode.description", "%commands.gamemode.usage");
        this.setPermission("nukkit.command.gamemode");
    }

    @Override
    public boolean execute(CommandSender sender, String commandLabel, String[] args) {
        if (!this.testPermission(sender)) {
            return true;
        }
        if (args.length == 0) {
            sender.sendMessage(new TranslationContainer("commands.generic.usage", this.usageMessage));
            return false;
        }
        int gameMode = Server.getGamemodeFromString(args[0]);
        if (gameMode == -1) {
            sender.sendMessage("Unknown game mode");
            return true;
        }
        CommandSender target = sender;
        if (args.length > 1) {
            target = sender.getServer().getPlayer(args[1]);
            if (target == null) {
                sender.sendMessage(new TranslationContainer("\u00a7c%commands.generic.player.notFound"));
                return true;
            }
        } else if (!(sender instanceof Player)) {
            sender.sendMessage(new TranslationContainer("commands.generic.usage", this.usageMessage));
            return true;
        }
        ((Player)target).setGamemode(gameMode);
        if (gameMode != ((Player)target).getGamemode()) {
            sender.sendMessage("Game mode update for " + target.getName() + " failed");
        } else if (target.equals(sender)) {
            Command.broadcastCommandMessage(sender, new TranslationContainer("commands.gamemode.success.self", Server.getGamemodeString(gameMode)));
        } else {
            target.sendMessage(new TranslationContainer("gameMode.changed"));
            Command.broadcastCommandMessage(sender, new TranslationContainer("commands.gamemode.success.other", new String[]{target.getName(), Server.getGamemodeString(gameMode)}));
        }
        return true;
    }
}

