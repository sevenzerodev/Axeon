/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.command.defaults;

import cn.axeon.command.Command;
import cn.axeon.command.CommandSender;
import cn.axeon.command.defaults.VanillaCommand;
import cn.axeon.event.TranslationContainer;

public class StopCommand
extends VanillaCommand {
    public StopCommand(String name) {
        super(name, "%nukkit.command.stop.description", "%commands.stop.usage");
        this.setPermission("nukkit.command.stop");
    }

    @Override
    public boolean execute(CommandSender sender, String commandLabel, String[] args) {
        if (!this.testPermission(sender)) {
            return true;
        }
        Command.broadcastCommandMessage(sender, new TranslationContainer("commands.stop.start"));
        sender.getServer().shutdown();
        return true;
    }
}

