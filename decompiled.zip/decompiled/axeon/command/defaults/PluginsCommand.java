/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.command.defaults;

import cn.axeon.command.CommandSender;
import cn.axeon.command.defaults.VanillaCommand;
import cn.axeon.event.TranslationContainer;
import cn.axeon.plugin.Plugin;
import java.util.Map;

public class PluginsCommand
extends VanillaCommand {
    public PluginsCommand(String name) {
        super(name, "%nukkit.command.plugins.description", "%nukkit.command.plugins.usage", new String[]{"pl"});
        this.setPermission("nukkit.command.plugins");
    }

    @Override
    public boolean execute(CommandSender sender, String commandLabel, String[] args) {
        if (!this.testPermission(sender)) {
            return true;
        }
        this.sendPluginList(sender);
        return true;
    }

    private void sendPluginList(CommandSender sender) {
        String list = "";
        Map<String, Plugin> plugins = sender.getServer().getPluginManager().getPlugins();
        for (Plugin plugin : plugins.values()) {
            if (list.length() > 0) {
                list = list + "\u00a7f, ";
            }
            list = list + (plugin.isEnabled() ? "\u00a7a" : "\u00a7c");
            list = list + plugin.getDescription().getFullName();
        }
        sender.sendMessage(new TranslationContainer("nukkit.command.plugins.success", new String[]{String.valueOf(plugins.size()), list}));
    }
}

