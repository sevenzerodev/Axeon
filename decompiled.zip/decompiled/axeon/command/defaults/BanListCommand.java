/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.command.defaults;

import cn.axeon.command.CommandSender;
import cn.axeon.command.defaults.VanillaCommand;
import cn.axeon.event.TranslationContainer;
import cn.axeon.permission.BanEntry;
import cn.axeon.permission.BanList;
import java.util.LinkedHashMap;

public class BanListCommand
extends VanillaCommand {
    public BanListCommand(String name) {
        super(name, "%nukkit.command.banlist.description", "%commands.banlist.usage");
        this.setPermission("nukkit.command.ban.list");
    }

    /*
     * Enabled aggressive block sorting
     */
    @Override
    public boolean execute(CommandSender sender, String commandLabel, String[] args) {
        BanList list;
        String arg;
        if (!this.testPermission(sender)) {
            return true;
        }
        if (args.length > 0) {
            arg = args[0].toLowerCase();
            if ("ips".equals(arg)) {
                list = sender.getServer().getIPBans();
            } else {
                if (!"players".equals(arg)) {
                    sender.sendMessage(new TranslationContainer("commands.generic.usage", this.usageMessage));
                    return false;
                }
                list = sender.getServer().getNameBans();
            }
        } else {
            list = sender.getServer().getNameBans();
            arg = "players";
        }
        String message = "";
        LinkedHashMap<String, BanEntry> entries = list.getEntires();
        for (BanEntry entry : entries.values()) {
            message = message + entry.getName() + ", ";
        }
        if ("ips".equals(arg)) {
            sender.sendMessage(new TranslationContainer("commands.banlist.ips", String.valueOf(entries.size())));
        } else {
            sender.sendMessage(new TranslationContainer("commands.banlist.players", String.valueOf(entries.size())));
        }
        if (message.length() > 0) {
            message = message.substring(0, message.length() - 2);
        }
        sender.sendMessage(message);
        return true;
    }
}

