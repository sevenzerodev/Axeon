/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.command.defaults;

import cn.axeon.Player;
import cn.axeon.command.Command;
import cn.axeon.command.CommandSender;
import cn.axeon.command.defaults.VanillaCommand;
import cn.axeon.event.TranslationContainer;

public class KickCommand
extends VanillaCommand {
    public KickCommand(String name) {
        super(name, "%nukkit.command.kick.description", "%commands.kick.usage");
        this.setPermission("nukkit.command.kick");
    }

    @Override
    public boolean execute(CommandSender sender, String commandLabel, String[] args) {
        Player player;
        if (!this.testPermission(sender)) {
            return true;
        }
        if (args.length == 0) {
            sender.sendMessage(new TranslationContainer("commands.generic.usage", this.usageMessage));
            return false;
        }
        String name = args[0];
        String reason = "";
        for (int i = 1; i < args.length; ++i) {
            reason = reason + args[i] + " ";
        }
        if (reason.length() > 0) {
            reason = reason.substring(0, reason.length() - 1);
        }
        if ((player = sender.getServer().getPlayer(name)) != null) {
            player.kick(reason);
            if (reason.length() >= 1) {
                Command.broadcastCommandMessage(sender, new TranslationContainer("commands.kick.success.reason", new String[]{player.getName(), reason}));
            } else {
                Command.broadcastCommandMessage(sender, new TranslationContainer("commands.kick.success", player.getName()));
            }
        } else {
            sender.sendMessage(new TranslationContainer("\u00a7c%commands.generic.player.notFound"));
        }
        return true;
    }
}

