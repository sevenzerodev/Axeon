/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.command.defaults;

import cn.axeon.Player;
import cn.axeon.command.Command;
import cn.axeon.command.CommandSender;
import cn.axeon.command.defaults.VanillaCommand;
import cn.axeon.event.TranslationContainer;
import cn.axeon.item.Item;

public class GiveCommand
extends VanillaCommand {
    public GiveCommand(String name) {
        super(name, "%nukkit.command.give.description", "%nukkit.command.give.usage");
        this.setPermission("nukkit.command.give");
    }

    @Override
    public boolean execute(CommandSender sender, String commandLabel, String[] args) {
        Item item;
        if (!this.testPermission(sender)) {
            return true;
        }
        if (args.length < 2) {
            sender.sendMessage(new TranslationContainer("commands.generic.usage", this.usageMessage));
            return true;
        }
        Player player = sender.getServer().getPlayer(args[0]);
        try {
            item = Item.fromString(args[1]);
        }
        catch (Exception e) {
            sender.sendMessage(new TranslationContainer("commands.generic.usage", this.usageMessage));
            return true;
        }
        try {
            item.setCount(Integer.parseInt(args[2]));
        }
        catch (Exception e) {
            item.setCount(item.getMaxStackSize());
        }
        if (player != null) {
            if (item.getId() == 0) {
                sender.sendMessage(new TranslationContainer("\u00a7c%commands.give.item.notFound", args[1]));
                return true;
            }
        } else {
            sender.sendMessage(new TranslationContainer("\u00a7c%commands.generic.player.notFound"));
            return true;
        }
        player.getInventory().addItem(item.clone());
        Command.broadcastCommandMessage(sender, new TranslationContainer("%commands.give.success", new String[]{item.getName() + " (" + item.getId() + ":" + item.getDamage() + ")", String.valueOf(item.getCount()), player.getName()}));
        return true;
    }
}

