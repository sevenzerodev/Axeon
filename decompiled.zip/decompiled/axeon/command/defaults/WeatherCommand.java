/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.command.defaults;

import cn.axeon.Player;
import cn.axeon.command.Command;
import cn.axeon.command.CommandSender;
import cn.axeon.command.defaults.VanillaCommand;
import cn.axeon.event.TranslationContainer;
import cn.axeon.level.Level;
import java.util.Random;

public class WeatherCommand
extends VanillaCommand {
    private Random rand = new Random();

    public WeatherCommand(String name) {
        super(name, "%nukkit.command.weather.description", "%commands.weather.usage");
        this.setPermission("nukkit.command.weather");
    }

    @Override
    public boolean execute(CommandSender sender, String commandLabel, String[] args) {
        int seconds;
        if (!this.testPermission(sender)) {
            return true;
        }
        if (args.length == 0 || args.length > 2) {
            sender.sendMessage(new TranslationContainer("commands.weather.usage", this.usageMessage));
            return false;
        }
        String weather = args[0];
        if (args.length > 1) {
            try {
                seconds = Integer.parseInt(args[1]);
            }
            catch (Exception e) {
                sender.sendMessage(new TranslationContainer("commands.generic.usage", this.usageMessage));
                return true;
            }
        } else {
            seconds = 12000;
        }
        Level level = sender instanceof Player ? ((Player)sender).getLevel() : sender.getServer().getDefaultLevel();
        switch (weather) {
            case "clear": {
                level.setRaining(false);
                level.setThundering(false);
                level.setRainTime(seconds * 20);
                level.setThunderTime(seconds * 20);
                Command.broadcastCommandMessage(sender, new TranslationContainer("commands.weather.clear"));
                return true;
            }
            case "rain": {
                level.setRaining(true);
                level.setRainTime(seconds * 20);
                Command.broadcastCommandMessage(sender, new TranslationContainer("commands.weather.rain"));
                return true;
            }
            case "thunder": {
                level.setThundering(true);
                level.setRainTime(seconds * 20);
                level.setThunderTime(seconds * 20);
                Command.broadcastCommandMessage(sender, new TranslationContainer("commands.weather.thunder"));
                return true;
            }
        }
        sender.sendMessage(new TranslationContainer("commands.weather.usage", this.usageMessage));
        return false;
    }
}

