/*
 * Axeon API - A Nukkit Fork
 * Originally based on Nukkit, rebranded as Axeon API.
 * Maintained by CloudBurst & SevenZero.
 */
package cn.axeon.command.defaults;

import cn.axeon.command.CommandSender;
import cn.axeon.command.defaults.VanillaCommand;
import cn.axeon.plugin.Plugin;
import cn.axeon.plugin.PluginDescription;
import java.util.List;

public class VersionCommand
extends VanillaCommand {
    public VersionCommand(String name) {
        super(name, "%nukkit.command.version.description", "%nukkit.command.version.usage", new String[]{"ver", "about"});
        this.setPermission("nukkit.command.version");
    }

    @Override
    public boolean execute(CommandSender sender, String commandLabel, String[] args) {
        if (!this.testPermission(sender)) {
            return true;
        }
        if (args.length == 0) {
            sender.sendMessage("\u00a7l\u00a79Axeon\u00a7fAPI\u00a7r\u00a78 \u00bb");
            sender.sendMessage("  \u00a7fSoftware By: \u00a7bCloud\u00a7fBurst & \u00a7eSevenZero");
            sender.sendMessage("  \u00a7fSupported Protocol:\u00a7b 70");
            sender.sendMessage("  \u00a7fVersions: \u00a7e0.14.3");
            sender.sendMessage("  \u00a7fAPI: 1.0.0");
            sender.sendMessage(" ");
            sender.sendMessage("  \u00a7b\u00a7lBlue\u00a7fGames:");
            sender.sendMessage("    \u00a7bAddress: \u00a7fplay.bluegs.xyz");
            sender.sendMessage("    \u00a7bPort: \u00a7f19132");
        } else {
            StringBuilder pluginNameBuilder = new StringBuilder();
            for (String arg : args) {
                pluginNameBuilder.append(arg).append(" ");
            }
            String pluginName = pluginNameBuilder.toString().trim();
            boolean[] found = new boolean[]{false};
            Plugin[] exactPlugin = new Plugin[]{sender.getServer().getPluginManager().getPlugin(pluginName)};
            if (exactPlugin[0] == null) {
                String finalPluginName = pluginName.toLowerCase();
                sender.getServer().getPluginManager().getPlugins().forEach((s, p) -> {
                    if (s.toLowerCase().contains(finalPluginName)) {
                        exactPlugin[0] = p;
                        found[0] = true;
                    }
                });
            } else {
                found[0] = true;
            }
            if (found[0]) {
                PluginDescription desc = exactPlugin[0].getDescription();
                sender.sendMessage("\u00a72" + desc.getName() + "\u00a7f version \u00a72" + desc.getVersion());
                if (desc.getDescription() != null) {
                    sender.sendMessage(desc.getDescription());
                }
                if (desc.getWebsite() != null) {
                    sender.sendMessage("Website: " + desc.getWebsite());
                }
                List<String> authors = desc.getAuthors();
                if (!authors.isEmpty()) {
                    StringBuilder sb = new StringBuilder();
                    for (int i = 0; i < authors.size(); i++) {
                        if (i > 0) sb.append(", ");
                        sb.append(authors.get(i));
                    }
                    if (authors.size() == 1) {
                        sender.sendMessage("Author: " + sb.toString());
                    } else {
                        sender.sendMessage("Authors: " + sb.toString());
                    }
                }
            } else {
                sender.sendMessage("This server is not running any plugin by that name. Use /plugins to get a list of plugins.");
            }
        }
        return true;
    }
}
