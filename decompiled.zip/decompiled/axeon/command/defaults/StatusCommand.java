/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.command.defaults;

import cn.axeon.Nukkit;
import cn.axeon.Server;
import cn.axeon.command.CommandSender;
import cn.axeon.command.defaults.VanillaCommand;
import cn.axeon.level.Level;
import cn.axeon.math.NukkitMath;
import java.util.Objects;

public class StatusCommand
extends VanillaCommand {
    public StatusCommand(String name) {
        super(name, "%nukkit.command.status.description", "%nukkit.command.status.usage");
        this.setPermission("nukkit.command.status");
    }

    @Override
    public boolean execute(CommandSender sender, String commandLabel, String[] args) {
        if (!this.testPermission(sender)) {
            return true;
        }
        Server server = sender.getServer();
        sender.sendMessage("\u00a7a---- \u00a7fServer status\u00a7a ----");
        long time = (System.currentTimeMillis() - Nukkit.START_TIME) / 1000L;
        int seconds = NukkitMath.floorDouble(time % 60L);
        int minutes = NukkitMath.floorDouble(time % 3600L / 60L);
        int hours = NukkitMath.floorDouble(time % 86400L / 3600L);
        int days = NukkitMath.floorDouble(time / 86400L);
        String upTimeString = "\u00a7c" + days + "\u00a76" + " days " + "\u00a7c" + hours + "\u00a76" + " hours " + "\u00a7c" + minutes + "\u00a76" + " minutes " + "\u00a7c" + seconds + "\u00a76" + " seconds";
        sender.sendMessage("\u00a76Uptime: " + upTimeString);
        String tpsColor = "\u00a7a";
        float tps = server.getTicksPerSecond();
        if (tps < 17.0f) {
            tpsColor = "\u00a76";
        } else if (tps < 12.0f) {
            tpsColor = "\u00a7c";
        }
        sender.sendMessage("\u00a76Current TPS: " + tpsColor + NukkitMath.round(tps, 2));
        sender.sendMessage("\u00a76Load: " + tpsColor + server.getTickUsage() + "%");
        sender.sendMessage("\u00a76Network upload: \u00a7a" + NukkitMath.round(server.getNetwork().getUpload() / 1024.0 * 1000.0, 2) + " kB/s");
        sender.sendMessage("\u00a76Network download: \u00a7a" + NukkitMath.round(server.getNetwork().getDownload() / 1024.0 * 1000.0, 2) + " kB/s");
        sender.sendMessage("\u00a76Thread count: \u00a7a" + Thread.getAllStackTraces().size());
        Runtime runtime = Runtime.getRuntime();
        double totalMB = NukkitMath.round((double)runtime.totalMemory() / 1024.0 / 1024.0, 2);
        double usedMB = NukkitMath.round((double)(runtime.totalMemory() - runtime.freeMemory()) / 1024.0 / 1024.0, 2);
        double maxMB = NukkitMath.round((double)runtime.maxMemory() / 1024.0 / 1024.0, 2);
        double usage = usedMB / maxMB * 100.0;
        String usageColor = "\u00a7a";
        if (usage > 85.0) {
            usageColor = "\u00a76";
        }
        sender.sendMessage("\u00a76Used memory: " + usageColor + usedMB + " MB. (" + NukkitMath.round(usage, 2) + "%)");
        sender.sendMessage("\u00a76Total memory: \u00a7c" + totalMB + " MB.");
        sender.sendMessage("\u00a76Maximum VM memory: \u00a7c" + maxMB + " MB.");
        sender.sendMessage("\u00a76Available processors: \u00a7a" + runtime.availableProcessors());
        String playerColor = "\u00a7a";
        if ((double)((float)server.getOnlinePlayers().size() / (float)server.getMaxPlayers()) > 0.85) {
            playerColor = "\u00a76";
        }
        sender.sendMessage("\u00a76Players: " + playerColor + server.getOnlinePlayers().size() + "\u00a7a" + " online, " + "\u00a7c" + server.getMaxPlayers() + "\u00a7a" + " max. ");
        for (Level level : server.getLevels().values()) {
            sender.sendMessage("\u00a76World \"" + level.getFolderName() + "\"" + (!Objects.equals(level.getFolderName(), level.getName()) ? " (" + level.getName() + ")" : "") + ": " + "\u00a7c" + level.getChunks().size() + "\u00a7a" + " chunks, " + "\u00a7c" + level.getEntities().length + "\u00a7a" + " entities, " + "\u00a7c" + level.getBlockEntities().size() + "\u00a7a" + " blockEntities." + " Time " + (level.getTickRate() > 1 || level.getTickRateTime() > 40 ? "\u00a7c" : "\u00a7e") + NukkitMath.round(level.getTickRateTime(), 2) + "ms" + (level.getTickRate() > 1 ? " (tick rate " + level.getTickRate() + ")" : ""));
        }
        return true;
    }
}

