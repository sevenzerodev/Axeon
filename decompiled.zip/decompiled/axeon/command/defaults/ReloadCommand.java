/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.command.defaults;

import cn.axeon.command.Command;
import cn.axeon.command.CommandSender;
import cn.axeon.command.defaults.VanillaCommand;
import cn.axeon.event.TranslationContainer;

public class ReloadCommand
extends VanillaCommand {
    public ReloadCommand(String name) {
        super(name, "%nukkit.command.reload.description", "%commands.reload.usage");
        this.setPermission("nukkit.command.reload");
    }

    @Override
    public boolean execute(CommandSender sender, String commandLabel, String[] args) {
        if (!this.testPermission(sender)) {
            return true;
        }
        Command.broadcastCommandMessage(sender, new TranslationContainer("\u00a7e%nukkit.command.reload.reloading\u00a7f"));
        sender.getServer().reload();
        Command.broadcastCommandMessage(sender, new TranslationContainer("\u00a7e%nukkit.command.reload.reloaded\u00a7f"));
        return true;
    }
}

