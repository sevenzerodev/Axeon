/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.command.defaults;

import cn.axeon.Player;
import cn.axeon.Server;
import cn.axeon.command.Command;
import cn.axeon.command.CommandSender;
import cn.axeon.command.defaults.VanillaCommand;
import cn.axeon.event.TranslationContainer;
import cn.axeon.network.protocol.DataPacket;
import cn.axeon.network.protocol.SetDifficultyPacket;
import java.util.ArrayList;

public class DifficultyCommand
extends VanillaCommand {
    public DifficultyCommand(String name) {
        super(name, "%nukkit.command.difficulty.description", "%commands.difficulty.usage");
        this.setPermission("nukkit.command.difficulty");
    }

    @Override
    public boolean execute(CommandSender sender, String commandLabel, String[] args) {
        if (!this.testPermission(sender)) {
            return true;
        }
        if (args.length != 1) {
            sender.sendMessage(new TranslationContainer("commands.generic.usage", this.usageMessage));
            return false;
        }
        int difficulty = Server.getDifficultyFromString(args[0]);
        if (sender.getServer().isHardcore()) {
            difficulty = 3;
        }
        if (difficulty == -1) {
            sender.sendMessage(new TranslationContainer("commands.generic.usage", this.usageMessage));
            return false;
        }
        sender.getServer().setPropertyInt("difficulty", difficulty);
        SetDifficultyPacket pk = new SetDifficultyPacket();
        pk.difficulty = sender.getServer().getDifficulty();
        Server.broadcastPacket(new ArrayList<Player>(sender.getServer().getOnlinePlayers().values()), (DataPacket)pk);
        Command.broadcastCommandMessage(sender, new TranslationContainer("commands.difficulty.success", String.valueOf(difficulty)));
        return true;
    }
}

