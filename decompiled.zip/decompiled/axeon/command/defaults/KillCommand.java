/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.command.defaults;

import cn.axeon.Player;
import cn.axeon.command.Command;
import cn.axeon.command.CommandSender;
import cn.axeon.command.defaults.VanillaCommand;
import cn.axeon.entity.Entity;
import cn.axeon.event.TranslationContainer;
import cn.axeon.event.entity.EntityDamageEvent;

public class KillCommand
extends VanillaCommand {
    public KillCommand(String name) {
        super(name, "%nukkit.command.kill.description", "%nukkit.command.kill.usage", new String[]{"suicide"});
        this.setPermission("nukkit.command.kill.self;nukkit.command.kill.other");
    }

    @Override
    public boolean execute(CommandSender sender, String commandLabel, String[] args) {
        EntityDamageEvent ev;
        if (!this.testPermission(sender)) {
            return true;
        }
        if (args.length >= 2) {
            sender.sendMessage(new TranslationContainer("commands.generic.usage", this.usageMessage));
            return false;
        }
        if (args.length == 1) {
            if (!sender.hasPermission("nukkit.command.kill.other")) {
                sender.sendMessage(new TranslationContainer("\u00a7c%commands.generic.permission"));
                return true;
            }
            Player player = sender.getServer().getPlayer(args[0]);
            if (player != null) {
                EntityDamageEvent ev2 = new EntityDamageEvent((Entity)player, 12, 1000.0f);
                sender.getServer().getPluginManager().callEvent(ev2);
                if (ev2.isCancelled()) {
                    return true;
                }
                player.setLastDamageCause(ev2);
                player.setHealth(0.0f);
                Command.broadcastCommandMessage(sender, new TranslationContainer("commands.kill.successful", player.getName()));
            } else {
                sender.sendMessage(new TranslationContainer("\u00a7c%commands.generic.player.notFound"));
            }
            return true;
        }
        if (sender instanceof Player) {
            if (!sender.hasPermission("nukkit.command.kill.self")) {
                sender.sendMessage(new TranslationContainer("\u00a7c%commands.generic.permission"));
                return true;
            }
            ev = new EntityDamageEvent((Entity)((Player)sender), 12, 1000.0f);
            sender.getServer().getPluginManager().callEvent(ev);
            if (ev.isCancelled()) {
                return true;
            }
        } else {
            sender.sendMessage(new TranslationContainer("commands.generic.usage", this.usageMessage));
            return false;
        }
        ((Player)sender).setLastDamageCause(ev);
        ((Player)sender).setHealth(0.0f);
        sender.sendMessage(new TranslationContainer("commands.kill.successful", sender.getName()));
        return true;
    }
}

