/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.command.defaults;

import cn.axeon.command.Command;
import cn.axeon.command.CommandSender;
import cn.axeon.command.ConsoleCommandSender;
import cn.axeon.command.defaults.VanillaCommand;
import cn.axeon.event.TranslationContainer;
import java.util.TreeMap;

public class HelpCommand
extends VanillaCommand {
    public HelpCommand(String name) {
        super(name, "%nukkit.command.help.description", "%commands.help.usage", new String[]{"?"});
        this.setPermission("nukkit.command.help");
    }

    @Override
    public boolean execute(CommandSender sender, String commandLabel, String[] args) {
        if (!this.testPermission(sender)) {
            return true;
        }
        String command = "";
        int pageNumber = 1;
        int pageHeight = 5;
        if (args.length != 0) {
            try {
                pageNumber = Integer.valueOf(args[args.length - 1]);
                if (pageNumber <= 0) {
                    pageNumber = 1;
                }
                String[] newargs = new String[args.length - 1];
                System.arraycopy(args, 0, newargs, 0, newargs.length);
                args = newargs;
                for (String string : args) {
                    if (!command.equals("")) {
                        command = command + " ";
                    }
                    command = command + (String)string;
                }
            }
            catch (NumberFormatException e) {
                pageNumber = 1;
                for (String string : args) {
                    if (!command.equals("")) {
                        command = command + " ";
                    }
                    command = command + string;
                }
            }
        }
        if (sender instanceof ConsoleCommandSender) {
            pageHeight = Integer.MAX_VALUE;
        }
        if (command.equals("")) {
            TreeMap<String, Command> commands = new TreeMap<String, Command>();
            for (Command cmd : sender.getServer().getCommandMap().getCommands().values()) {
                if (!cmd.testPermissionSilent(sender)) continue;
                commands.put(cmd.getName(), cmd);
            }
            int totalPage = commands.size() % pageHeight == 0 ? commands.size() / pageHeight : commands.size() / pageHeight + 1;
            if ((pageNumber = Math.min(pageNumber, totalPage)) < 1) {
                pageNumber = 1;
            }
            sender.sendMessage(new TranslationContainer("commands.help.header", new String[]{String.valueOf(pageNumber), String.valueOf(totalPage)}));
            int i = 1;
            for (Command command2 : commands.values()) {
                if (i >= (pageNumber - 1) * pageHeight + 1 && i <= Math.min(commands.size(), pageNumber * pageHeight)) {
                    sender.sendMessage("\u00a72/" + command2.getName() + ": " + "\u00a7f" + command2.getDescription());
                }
                ++i;
            }
            return true;
        }
        Command cmd = sender.getServer().getCommandMap().getCommand(command.toLowerCase());
        if (cmd != null && cmd.testPermissionSilent(sender)) {
            String[] usages;
            String message = "\u00a7e--------- \u00a7f Help: /" + cmd.getName() + "\u00a7e" + " ---------\n";
            message = message + "\u00a76Description: \u00a7f" + cmd.getDescription() + "\n";
            String usage = "";
            for (String u : usages = cmd.getUsage().split("\n")) {
                if (!usage.equals("")) {
                    usage = usage + "\n\u00a7f";
                }
                usage = usage + u;
            }
            message = message + "\u00a76Usage: \u00a7f" + usage + "\n";
            sender.sendMessage(message);
            return true;
        }
        sender.sendMessage("\u00a7cNo help for " + command.toLowerCase());
        return true;
    }
}

