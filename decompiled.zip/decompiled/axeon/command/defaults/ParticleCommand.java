/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.command.defaults;

import cn.axeon.Player;
import cn.axeon.block.Block;
import cn.axeon.command.CommandSender;
import cn.axeon.command.defaults.VanillaCommand;
import cn.axeon.event.TranslationContainer;
import cn.axeon.item.Item;
import cn.axeon.level.Level;
import cn.axeon.level.particle.AngryVillagerParticle;
import cn.axeon.level.particle.BubbleParticle;
import cn.axeon.level.particle.CriticalParticle;
import cn.axeon.level.particle.DustParticle;
import cn.axeon.level.particle.EnchantParticle;
import cn.axeon.level.particle.EnchantmentTableParticle;
import cn.axeon.level.particle.ExplodeParticle;
import cn.axeon.level.particle.FlameParticle;
import cn.axeon.level.particle.HappyVillagerParticle;
import cn.axeon.level.particle.HeartParticle;
import cn.axeon.level.particle.HugeExplodeParticle;
import cn.axeon.level.particle.InkParticle;
import cn.axeon.level.particle.InstantEnchantParticle;
import cn.axeon.level.particle.ItemBreakParticle;
import cn.axeon.level.particle.LargeExplodeParticle;
import cn.axeon.level.particle.LavaDripParticle;
import cn.axeon.level.particle.LavaParticle;
import cn.axeon.level.particle.Particle;
import cn.axeon.level.particle.PortalParticle;
import cn.axeon.level.particle.RainSplashParticle;
import cn.axeon.level.particle.RedstoneParticle;
import cn.axeon.level.particle.SmokeParticle;
import cn.axeon.level.particle.SplashParticle;
import cn.axeon.level.particle.SporeParticle;
import cn.axeon.level.particle.TerrainParticle;
import cn.axeon.level.particle.WaterDripParticle;
import cn.axeon.level.particle.WaterParticle;
import cn.axeon.math.Vector3;
import java.util.Random;

public class ParticleCommand
extends VanillaCommand {
    public ParticleCommand(String name) {
        super(name, "%nukkit.command.particle.description", "%nukkit.command.particle.usage");
        this.setPermission("nukkit.command.particle");
    }

    @Override
    public boolean execute(CommandSender sender, String commandLabel, String[] args) {
        Particle particle;
        if (!this.testPermission(sender)) {
            return true;
        }
        if (args.length < 7) {
            sender.sendMessage(new TranslationContainer("commands.generic.usage", this.usageMessage));
            return true;
        }
        Level level = sender instanceof Player ? ((Player)sender).getLevel() : sender.getServer().getDefaultLevel();
        String name = args[0].toLowerCase();
        float[] floats = new float[6];
        for (int i = 0; i < floats.length; ++i) {
            try {
                double d = Double.valueOf(args[i + 1]);
                floats[i] = (float)d;
                continue;
            }
            catch (Exception e) {
                return false;
            }
        }
        Vector3 pos = new Vector3(floats[0], floats[1], floats[2]);
        float xd = floats[3];
        float yd = floats[4];
        float zd = floats[5];
        int count = 1;
        if (args.length > 7) {
            try {
                double c = Double.valueOf(args[7]);
                count = (int)c;
            }
            catch (Exception c) {
                // empty catch block
            }
        }
        count = Math.max(1, count);
        Integer data = null;
        if (args.length > 8) {
            try {
                double d = Double.valueOf(args[8]);
                data = (int)d;
            }
            catch (Exception d) {
                // empty catch block
            }
        }
        if ((particle = this.getParticle(name, pos, xd, yd, zd, data)) == null) {
            sender.sendMessage(new TranslationContainer("\u00a7c%commands.particle.notFound", name));
            return true;
        }
        sender.sendMessage(new TranslationContainer("commands.particle.success", new String[]{name, String.valueOf(count)}));
        Random random = new Random(System.currentTimeMillis());
        for (int i = 0; i < count; ++i) {
            particle.setComponents(pos.x + (double)((random.nextFloat() * 2.0f - 1.0f) * xd), pos.y + (double)((random.nextFloat() * 2.0f - 1.0f) * yd), pos.z + (double)((random.nextFloat() * 2.0f - 1.0f) * zd));
            level.addParticle(particle);
        }
        return true;
    }

    private Particle getParticle(String name, Vector3 pos, float xd, float yd, float zd, Integer data) {
        String[] d;
        switch (name) {
            case "explode": {
                return new ExplodeParticle(pos);
            }
            case "largeexplode": {
                return new LargeExplodeParticle(pos);
            }
            case "hugeexplosion": {
                return new HugeExplodeParticle(pos);
            }
            case "bubble": {
                return new BubbleParticle(pos);
            }
            case "splash": {
                return new SplashParticle(pos);
            }
            case "wake": 
            case "water": {
                return new WaterParticle(pos);
            }
            case "crit": {
                return new CriticalParticle(pos);
            }
            case "smoke": {
                return new SmokeParticle(pos, data != null ? data : 0);
            }
            case "spell": {
                return new EnchantParticle(pos);
            }
            case "instantspell": {
                return new InstantEnchantParticle(pos);
            }
            case "dripwater": {
                return new WaterDripParticle(pos);
            }
            case "driplava": {
                return new LavaDripParticle(pos);
            }
            case "townaura": 
            case "spore": {
                return new SporeParticle(pos);
            }
            case "portal": {
                return new PortalParticle(pos);
            }
            case "flame": {
                return new FlameParticle(pos);
            }
            case "lava": {
                return new LavaParticle(pos);
            }
            case "reddust": {
                return new RedstoneParticle(pos, data != null ? data : 1);
            }
            case "snowballpoof": {
                return new ItemBreakParticle(pos, Item.get(332));
            }
            case "slime": {
                return new ItemBreakParticle(pos, Item.get(341));
            }
            case "itembreak": {
                if (data == null || data == 0) break;
                return new ItemBreakParticle(pos, Item.get(data));
            }
            case "terrain": {
                if (data == null || data == 0) break;
                return new TerrainParticle(pos, Block.get(data));
            }
            case "heart": {
                return new HeartParticle(pos, data != null ? data : 0);
            }
            case "ink": {
                return new InkParticle(pos, data != null ? data : 0);
            }
            case "droplet": {
                return new RainSplashParticle(pos);
            }
            case "enchantmenttable": {
                return new EnchantmentTableParticle(pos);
            }
            case "happyvillager": {
                return new HappyVillagerParticle(pos);
            }
            case "angryvillager": {
                return new AngryVillagerParticle(pos);
            }
        }
        if (name.startsWith("iconcrack_")) {
            d = name.split("_");
            if (d.length == 3) {
                return new ItemBreakParticle(pos, Item.get(Integer.valueOf(d[1]), Integer.valueOf(d[2])));
            }
        } else if (name.startsWith("blockcrack_")) {
            d = name.split("_");
            if (d.length == 2) {
                return new TerrainParticle(pos, Block.get(Integer.valueOf(d[1]) & 0xFF, Integer.valueOf(d[1]) >> 12));
            }
        } else if (name.startsWith("blockdust_") && (d = name.split("_")).length >= 4) {
            return new DustParticle(pos, (int)(Integer.valueOf(d[1]) & 0xFF), (int)(Integer.valueOf(d[2]) & 0xFF), (int)(Integer.valueOf(d[3]) & 0xFF), d.length >= 5 ? Integer.valueOf(d[4]) & 0xFF : 255);
        }
        return null;
    }
}

