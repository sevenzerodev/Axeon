/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.command.defaults;

import cn.axeon.command.CommandSender;
import cn.axeon.command.defaults.VanillaCommand;
import cn.axeon.level.Level;
import cn.axeon.math.NukkitMath;

public class GarbageCollectorCommand
extends VanillaCommand {
    public GarbageCollectorCommand(String name) {
        super(name, "%nukkit.command.gc.description", "%nukkit.command.gc.usage");
        this.setPermission("nukkit.command.gc");
    }

    @Override
    public boolean execute(CommandSender sender, String commandLabel, String[] args) {
        if (!this.testPermission(sender)) {
            return true;
        }
        int chunksCollected = 0;
        int entitiesCollected = 0;
        int tilesCollected = 0;
        long memory = Runtime.getRuntime().freeMemory();
        for (Level level : sender.getServer().getLevels().values()) {
            int chunksCount = level.getChunks().size();
            int entitiesCount = level.getEntities().length;
            int tilesCount = level.getBlockEntities().size();
            level.doChunkGarbageCollection();
            level.unloadChunks(true);
            chunksCollected += chunksCount - level.getChunks().size();
            entitiesCollected += entitiesCount - level.getEntities().length;
            tilesCollected += tilesCount - level.getBlockEntities().size();
            level.clearCache(true);
        }
        System.gc();
        long freedMemory = Runtime.getRuntime().freeMemory() - memory;
        sender.sendMessage("\u00a7a---- \u00a7fGarbage collection result\u00a7a ----");
        sender.sendMessage("\u00a76Chunks: \u00a7c" + chunksCollected);
        sender.sendMessage("\u00a76Entities: \u00a7c" + entitiesCollected);
        sender.sendMessage("\u00a76Block Entities: \u00a7c" + tilesCollected);
        sender.sendMessage("\u00a76Memory freed: \u00a7c" + NukkitMath.round((double)freedMemory / 1024.0 / 1024.0, 2) + " MB");
        return true;
    }
}

