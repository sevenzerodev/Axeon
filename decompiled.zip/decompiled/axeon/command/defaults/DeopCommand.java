/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.command.defaults;

import cn.axeon.IPlayer;
import cn.axeon.Player;
import cn.axeon.command.Command;
import cn.axeon.command.CommandSender;
import cn.axeon.command.defaults.VanillaCommand;
import cn.axeon.event.TranslationContainer;

public class DeopCommand
extends VanillaCommand {
    public DeopCommand(String name) {
        super(name, "%nukkit.command.deop.description", "%commands.deop.usage");
        this.setPermission("nukkit.command.op.take");
    }

    @Override
    public boolean execute(CommandSender sender, String commandLabel, String[] args) {
        if (!this.testPermission(sender)) {
            return true;
        }
        if (args.length == 0) {
            sender.sendMessage(new TranslationContainer("commands.generic.usage", this.usageMessage));
            return false;
        }
        String playerName = args[0];
        IPlayer player = sender.getServer().getOfflinePlayer(playerName);
        player.setOp(false);
        if (player instanceof Player) {
            ((Player)player).sendMessage("\u00a77You are no longer op!");
        }
        Command.broadcastCommandMessage(sender, new TranslationContainer("commands.deop.success", new String[]{player.getName()}));
        return true;
    }
}

