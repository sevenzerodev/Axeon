/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.command.defaults;

import cn.axeon.IPlayer;
import cn.axeon.Player;
import cn.axeon.command.Command;
import cn.axeon.command.CommandSender;
import cn.axeon.command.defaults.VanillaCommand;
import cn.axeon.event.TranslationContainer;

public class OpCommand
extends VanillaCommand {
    public OpCommand(String name) {
        super(name, "%nukkit.command.op.description", "%commands.op.usage");
        this.setPermission("nukkit.command.op.give");
    }

    @Override
    public boolean execute(CommandSender sender, String commandLabel, String[] args) {
        if (!this.testPermission(sender)) {
            return true;
        }
        if (args.length == 0) {
            sender.sendMessage(new TranslationContainer("commands.generic.usage", this.usageMessage));
            return false;
        }
        String name = args[0];
        IPlayer player = sender.getServer().getOfflinePlayer(name);
        Command.broadcastCommandMessage(sender, new TranslationContainer("commands.op.success", player.getName()));
        if (player instanceof Player) {
            ((Player)player).sendMessage("\u00a77You are now op!");
        }
        player.setOp(true);
        return true;
    }
}

