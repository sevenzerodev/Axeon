/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.command.defaults;

import cn.axeon.Player;
import cn.axeon.command.CommandSender;
import cn.axeon.command.defaults.VanillaCommand;
import cn.axeon.event.TranslationContainer;

public class SeedCommand
extends VanillaCommand {
    public SeedCommand(String name) {
        super(name, "%nukkit.command.seed.description", "%commands.seed.usage");
        this.setPermission("nukkit.command.seed");
    }

    @Override
    public boolean execute(CommandSender sender, String commandLabel, String[] args) {
        if (!this.testPermission(sender)) {
            return true;
        }
        long seed = sender instanceof Player ? ((Player)sender).getLevel().getSeed() : sender.getServer().getDefaultLevel().getSeed();
        sender.sendMessage(new TranslationContainer("commands.seed.success", String.valueOf(seed)));
        return true;
    }
}

