/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.command.defaults;

import cn.axeon.Player;
import cn.axeon.command.CommandSender;
import cn.axeon.command.ConsoleCommandSender;
import cn.axeon.command.defaults.VanillaCommand;
import cn.axeon.event.TranslationContainer;

public class SayCommand
extends VanillaCommand {
    public SayCommand(String name) {
        super(name, "%nukkit.command.say.description", "%commands.say.usage");
        this.setPermission("nukkit.command.say");
    }

    @Override
    public boolean execute(CommandSender sender, String commandLabel, String[] args) {
        if (!this.testPermission(sender)) {
            return true;
        }
        if (args.length == 0) {
            sender.sendMessage(new TranslationContainer("commands.generic.usage", this.usageMessage));
            return false;
        }
        String senderString = sender instanceof Player ? ((Player)sender).getDisplayName() : (sender instanceof ConsoleCommandSender ? "Server" : sender.getName());
        String msg = "";
        for (String arg : args) {
            msg = msg + arg + " ";
        }
        if (msg.length() > 0) {
            msg = msg.substring(0, msg.length() - 1);
        }
        sender.getServer().broadcastMessage(new TranslationContainer("\u00a7d%chat.type.announcement", new String[]{senderString, "\u00a7d" + msg}));
        return true;
    }
}

