/*
 * Axeon API - A Nukkit Fork
 */
package cn.axeon.command.defaults;

import cn.axeon.Player;
import cn.axeon.command.Command;
import cn.axeon.command.CommandSender;
import cn.axeon.command.defaults.VanillaCommand;
import cn.axeon.event.TranslationContainer;
import cn.axeon.level.Level;
import cn.axeon.level.Location;
import cn.axeon.math.Vector3;
import java.text.DecimalFormat;

public class SetWorldSpawnCommand
extends VanillaCommand {
    public SetWorldSpawnCommand(String name) {
        super(name, "%nukkit.command.setworldspawn.description", "%commands.setworldspawn.usage");
        this.setPermission("nukkit.command.setworldspawn");
    }

    @Override
    public boolean execute(CommandSender sender, String commandLabel, String[] args) {
        if (!this.testPermission(sender)) {
            return true;
        }
        Level level;
        Vector3 spawnPos;
        if (args.length == 0) {
            if (!(sender instanceof Player)) {
                sender.sendMessage(new TranslationContainer("commands.generic.ingame"));
                return true;
            }
            level = ((Player)sender).getLevel();
            spawnPos = ((Player)sender).round();
        } else {
            if (args.length != 3) {
                sender.sendMessage(new TranslationContainer("commands.generic.usage", this.usageMessage));
                return true;
            }
            level = sender.getServer().getDefaultLevel();
            try {
                spawnPos = new Vector3(Integer.parseInt(args[0]), Integer.parseInt(args[1]), Integer.parseInt(args[2]));
            }
            catch (NumberFormatException e1) {
                sender.sendMessage(new TranslationContainer("commands.generic.usage", this.usageMessage));
                return true;
            }
        }
        level.setSpawnLocation(spawnPos);
        DecimalFormat round2 = new DecimalFormat("##0.00");
        Command.broadcastCommandMessage(sender, new TranslationContainer("commands.setworldspawn.success", new String[]{round2.format(spawnPos.x), round2.format(spawnPos.y), round2.format(spawnPos.z)}));
        return true;
    }
}
