/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.command;

import cn.axeon.InterruptibleThread;
import cn.axeon.Server;
import cn.axeon.event.server.ServerCommandEvent;
import java.io.IOException;
import jline.console.ConsoleReader;
import jline.console.CursorBuffer;

public class CommandReader
extends Thread
implements InterruptibleThread {
    private ConsoleReader reader;
    public static CommandReader instance;
    private CursorBuffer stashed;
    private boolean running = true;

    public static CommandReader getInstance() {
        return instance;
    }

    public CommandReader() {
        if (instance != null) {
            throw new RuntimeException("Command Reader is already exist");
        }
        try {
            this.reader = new ConsoleReader();
            this.reader.setPrompt("> ");
            instance = this;
        }
        catch (IOException e) {
            Server.getInstance().getLogger().error("Unable to start Console Reader", e);
        }
        this.setName("Console");
    }

    public String readLine() {
        try {
            this.reader.resetPromptLine("", "", 0);
            return this.reader.readLine("> ");
        }
        catch (IOException e) {
            Server.getInstance().getLogger().logException(e);
            return "";
        }
    }

    @Override
    public void run() {
        Long lastLine = System.currentTimeMillis();
        while (this.running) {
            if (Server.getInstance().getConsoleSender() == null || Server.getInstance().getPluginManager() == null) continue;
            String line = this.readLine();
            if (line != null && !line.trim().equals("")) {
                try {
                    ServerCommandEvent event = new ServerCommandEvent(Server.getInstance().getConsoleSender(), line);
                    Server.getInstance().getPluginManager().callEvent(event);
                    if (!event.isCancelled()) {
                        Server.getInstance().dispatchCommand(event.getSender(), event.getCommand());
                    }
                }
                catch (Exception e) {
                    Server.getInstance().getLogger().logException(e);
                }
            } else if (System.currentTimeMillis() - lastLine <= 1L) {
                try {
                    CommandReader.sleep(40L);
                }
                catch (InterruptedException e) {
                    Server.getInstance().getLogger().logException(e);
                }
            }
            lastLine = System.currentTimeMillis();
        }
    }

    public void shutdown() {
        this.running = false;
    }

    public void stashLine() {
        this.stashed = this.reader.getCursorBuffer().copy();
        try {
            this.reader.getOutput().write("\u001b[1G\u001b[K");
            this.reader.flush();
        }
        catch (IOException iOException) {
            // empty catch block
        }
    }

    public void unstashLine() {
        try {
            this.reader.resetPromptLine("> ", this.stashed.toString(), this.stashed.cursor);
        }
        catch (IOException iOException) {
            // empty catch block
        }
    }

    public void removePromptLine() {
        try {
            this.reader.resetPromptLine("", "", 0);
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
}

