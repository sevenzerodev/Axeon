/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.command;

import cn.axeon.command.CommandMap;
import cn.axeon.command.CommandSender;
import cn.axeon.command.ConsoleCommandSender;
import cn.axeon.event.TextContainer;
import cn.axeon.event.TranslationContainer;
import cn.axeon.permission.Permissible;
import java.util.Set;

public abstract class Command {
    private String name;
    private String nextLabel;
    private String label;
    private String[] aliases = new String[0];
    private String[] activeAliases = new String[0];
    private CommandMap commandMap = null;
    protected String description = "";
    protected String usageMessage = "";
    private String permission = null;
    private String permissionMessage = null;

    public Command(String name) {
        this(name, "", null, new String[0]);
    }

    public Command(String name, String description) {
        this(name, description, null, new String[0]);
    }

    public Command(String name, String description, String usageMessage) {
        this(name, description, usageMessage, new String[0]);
    }

    public Command(String name, String description, String usageMessage, String[] aliases) {
        this.name = name;
        this.nextLabel = name;
        this.label = name;
        this.description = description;
        this.usageMessage = usageMessage == null ? "/" + name : usageMessage;
        this.aliases = aliases;
        this.activeAliases = aliases;
    }

    public abstract boolean execute(CommandSender var1, String var2, String[] var3);

    public String getName() {
        return this.name;
    }

    public String getPermission() {
        return this.permission;
    }

    public void setPermission(String permission) {
        this.permission = permission;
    }

    public boolean testPermission(CommandSender target) {
        if (this.testPermissionSilent(target)) {
            return true;
        }
        if (this.permissionMessage == null) {
            target.sendMessage(new TranslationContainer("\u00a7c%commands.generic.permission"));
        } else if (!this.permissionMessage.equals("")) {
            target.sendMessage(this.permissionMessage.replace("<permission>", this.permission));
        }
        return false;
    }

    public boolean testPermissionSilent(CommandSender target) {
        String[] permissions;
        if (this.permission == null || this.permission.equals("")) {
            return true;
        }
        for (String permission : permissions = this.permission.split(";")) {
            if (!target.hasPermission(permission)) continue;
            return true;
        }
        return false;
    }

    public String getLabel() {
        return this.label;
    }

    public boolean setLabel(String name) {
        this.nextLabel = name;
        if (!this.isRegistered()) {
            this.label = name;
            return true;
        }
        return false;
    }

    public boolean register(CommandMap commandMap) {
        if (this.allowChangesFrom(commandMap)) {
            this.commandMap = commandMap;
            return true;
        }
        return false;
    }

    public boolean unregister(CommandMap commandMap) {
        if (this.allowChangesFrom(commandMap)) {
            this.commandMap = null;
            this.activeAliases = this.aliases;
            this.label = this.nextLabel;
            return true;
        }
        return false;
    }

    public boolean allowChangesFrom(CommandMap commandMap) {
        return commandMap == null || commandMap.equals(this.commandMap);
    }

    public boolean isRegistered() {
        return this.commandMap != null;
    }

    public String[] getAliases() {
        return this.activeAliases;
    }

    public String getPermissionMessage() {
        return this.permissionMessage;
    }

    public String getDescription() {
        return this.description;
    }

    public String getUsage() {
        return this.usageMessage;
    }

    public void setAliases(String[] aliases) {
        this.aliases = aliases;
        if (!this.isRegistered()) {
            this.activeAliases = aliases;
        }
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setPermissionMessage(String permissionMessage) {
        this.permissionMessage = permissionMessage;
    }

    public void setUsage(String usageMessage) {
        this.usageMessage = usageMessage;
    }

    public static void broadcastCommandMessage(CommandSender source, String message) {
        Command.broadcastCommandMessage(source, message, true);
    }

    public static void broadcastCommandMessage(CommandSender source, String message, boolean sendToSource) {
        Set<Permissible> users = source.getServer().getPluginManager().getPermissionSubscriptions("nukkit.broadcast.admin");
        TranslationContainer result = new TranslationContainer("chat.type.admin", new String[]{source.getName(), message});
        TranslationContainer colored = new TranslationContainer("\u00a77\u00a7o%chat.type.admin", new String[]{source.getName(), message});
        if (sendToSource && !(source instanceof ConsoleCommandSender)) {
            source.sendMessage(message);
        }
        for (Permissible user : users) {
            if (!(user instanceof CommandSender)) continue;
            if (user instanceof ConsoleCommandSender) {
                ((ConsoleCommandSender)user).sendMessage(result);
                continue;
            }
            if (user.equals(source)) continue;
            ((CommandSender)user).sendMessage(colored);
        }
    }

    public static void broadcastCommandMessage(CommandSender source, TextContainer message) {
        Command.broadcastCommandMessage(source, message, true);
    }

    public static void broadcastCommandMessage(CommandSender source, TextContainer message, boolean sendToSource) {
        TextContainer m = message.clone();
        String resultStr = "[" + source.getName() + ": " + (!m.getText().equals(source.getServer().getLanguage().get(m.getText())) ? "%" : "") + m.getText() + "]";
        Set<Permissible> users = source.getServer().getPluginManager().getPermissionSubscriptions("nukkit.broadcast.admin");
        String coloredStr = "\u00a77\u00a7o" + resultStr;
        m.setText(resultStr);
        TextContainer result = m.clone();
        m.setText(coloredStr);
        TextContainer colored = m.clone();
        if (sendToSource && !(source instanceof ConsoleCommandSender)) {
            source.sendMessage(message);
        }
        for (Permissible user : users) {
            if (!(user instanceof CommandSender)) continue;
            if (user instanceof ConsoleCommandSender) {
                ((ConsoleCommandSender)user).sendMessage(result);
                continue;
            }
            if (user.equals(source)) continue;
            ((CommandSender)user).sendMessage(colored);
        }
    }

    public String toString() {
        return this.name;
    }
}

