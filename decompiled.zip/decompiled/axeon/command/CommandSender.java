/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.command;

import cn.axeon.Server;
import cn.axeon.event.TextContainer;
import cn.axeon.permission.Permissible;

public interface CommandSender
extends Permissible {
    public void sendMessage(String var1);

    public void sendMessage(TextContainer var1);

    public Server getServer();

    public String getName();

    public boolean isPlayer();
}

