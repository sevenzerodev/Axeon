/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.blockentity;

import cn.axeon.blockentity.BlockEntitySpawnable;
import cn.axeon.level.format.FullChunk;
import cn.axeon.nbt.tag.CompoundTag;

public class BlockEntityFlowerPot
extends BlockEntitySpawnable {
    public BlockEntityFlowerPot(FullChunk chunk, CompoundTag nbt) {
        super(chunk, nbt);
        if (!nbt.contains("item")) {
            nbt.putShort("item", 0);
        }
        if (!nbt.contains("data")) {
            if (nbt.contains("mData")) {
                nbt.putInt("data", nbt.getInt("mData"));
                nbt.remove("mData");
            } else {
                nbt.putInt("data", 0);
            }
        }
        this.namedTag = nbt;
    }

    @Override
    public boolean isBlockEntityValid() {
        int blockID = this.getBlock().getId();
        return blockID == 140;
    }

    @Override
    public CompoundTag getSpawnCompound() {
        return new CompoundTag().putString("id", "FlowerPot").putInt("x", (int)this.x).putInt("y", (int)this.y).putInt("z", (int)this.z).putShort("item", this.namedTag.getShort("item")).putInt("mData", this.namedTag.getInt("data"));
    }
}

