/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.blockentity;

import cn.axeon.Player;
import cn.axeon.blockentity.BlockEntity;
import cn.axeon.level.format.FullChunk;
import cn.axeon.nbt.NBTIO;
import cn.axeon.nbt.tag.CompoundTag;
import cn.axeon.network.protocol.BlockEntityDataPacket;
import java.io.IOException;
import java.nio.ByteOrder;

public abstract class BlockEntitySpawnable
extends BlockEntity {
    public BlockEntitySpawnable(FullChunk chunk, CompoundTag nbt) {
        super(chunk, nbt);
        this.spawnToAll();
    }

    public abstract CompoundTag getSpawnCompound();

    public void spawnTo(Player player) {
        if (this.closed) {
            return;
        }
        CompoundTag tag = this.getSpawnCompound();
        BlockEntityDataPacket pk = new BlockEntityDataPacket();
        pk.x = (int)this.x;
        pk.y = (int)this.y;
        pk.z = (int)this.z;
        try {
            pk.namedTag = NBTIO.write(tag, ByteOrder.LITTLE_ENDIAN);
        }
        catch (IOException e) {
            throw new RuntimeException(e);
        }
        player.dataPacket(pk);
    }

    public void spawnToAll() {
        if (this.closed) {
            return;
        }
        for (Player player : this.getLevel().getChunkPlayers(this.chunk.getX(), this.chunk.getZ()).values()) {
            if (!player.spawned) continue;
            this.spawnTo(player);
        }
    }
}

