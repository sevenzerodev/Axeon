/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.blockentity;

import cn.axeon.blockentity.BlockEntitySpawnable;
import cn.axeon.level.format.FullChunk;
import cn.axeon.nbt.tag.CompoundTag;

public class BlockEntitySkull
extends BlockEntitySpawnable {
    public BlockEntitySkull(FullChunk chunk, CompoundTag nbt) {
        super(chunk, nbt);
        if (!nbt.contains("SkullType")) {
            nbt.putByte("SkullType", 0);
        }
        if (!nbt.contains("Rot")) {
            nbt.putByte("Rot", 0);
        }
        this.namedTag = nbt;
    }

    @Override
    public void saveNBT() {
        super.saveNBT();
        this.namedTag.remove("Creator");
    }

    @Override
    public boolean isBlockEntityValid() {
        return this.getBlock().getId() == 144;
    }

    @Override
    public CompoundTag getSpawnCompound() {
        return new CompoundTag().putString("id", "Skull").put("SkullType", this.namedTag.get("SkullType")).putInt("x", (int)this.x).putInt("y", (int)this.y).putInt("z", (int)this.z).put("Rot", this.namedTag.get("Rot"));
    }
}

