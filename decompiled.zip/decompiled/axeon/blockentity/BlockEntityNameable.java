/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.blockentity;

public interface BlockEntityNameable {
    public String getName();

    public void setName(String var1);

    public boolean hasName();
}

