/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.blockentity;

import cn.axeon.Player;
import cn.axeon.Server;
import cn.axeon.block.BlockAir;
import cn.axeon.blockentity.BlockEntityContainer;
import cn.axeon.blockentity.BlockEntityNameable;
import cn.axeon.blockentity.BlockEntitySpawnable;
import cn.axeon.inventory.BrewingInventory;
import cn.axeon.inventory.BrewingRecipe;
import cn.axeon.inventory.InventoryHolder;
import cn.axeon.item.Item;
import cn.axeon.item.ItemBlock;
import cn.axeon.level.format.FullChunk;
import cn.axeon.nbt.tag.CompoundTag;
import cn.axeon.nbt.tag.ListTag;
import cn.axeon.network.protocol.ContainerSetDataPacket;
import java.util.ArrayList;
import java.util.List;

public class BlockEntityBrewingStand
extends BlockEntitySpawnable
implements InventoryHolder,
BlockEntityContainer,
BlockEntityNameable {
    protected BrewingInventory inventory = new BrewingInventory(this);
    public static final int MAX_BREW_TIME = 400;
    public static List<Integer> ingredients = new ArrayList<Integer>();

    public BlockEntityBrewingStand(FullChunk chunk, CompoundTag nbt) {
        super(chunk, nbt);
        if (!this.namedTag.contains("Items") || !(this.namedTag.get("Items") instanceof ListTag)) {
            this.namedTag.putList(new ListTag("Items"));
        }
        for (int i = 0; i < this.getSize(); ++i) {
            this.inventory.setItem(i, this.getItem(i));
        }
        if (!this.namedTag.contains("CookTime") || this.namedTag.getShort("CookTime") > 400) {
            this.namedTag.putShort("CookTime", 400);
        }
        if (this.namedTag.getShort("CookTime") < 400) {
            this.scheduleUpdate();
        }
    }

    @Override
    public String getName() {
        return this.hasName() ? this.namedTag.getString("CustomName") : "Brewing Stand";
    }

    @Override
    public boolean hasName() {
        return this.namedTag.contains("CustomName");
    }

    @Override
    public void setName(String name) {
        if (name == null || name.equals("")) {
            this.namedTag.remove("CustomName");
            return;
        }
        this.namedTag.putString("CustomName", name);
    }

    @Override
    public void close() {
        if (!this.closed) {
            for (Player player : this.getInventory().getViewers()) {
                player.removeWindow(this.getInventory());
            }
            super.close();
        }
    }

    @Override
    public void saveNBT() {
        this.namedTag.putList(new ListTag("Items"));
        for (int index = 0; index < this.getSize(); ++index) {
            this.setItem(index, this.inventory.getItem(index));
        }
    }

    @Override
    public boolean isBlockEntityValid() {
        return this.getBlock().getId() == 117;
    }

    @Override
    public int getSize() {
        return 4;
    }

    protected int getSlotIndex(int index) {
        ListTag<CompoundTag> list = this.namedTag.getList("Items", CompoundTag.class);
        for (int i = 0; i < list.size(); ++i) {
            if (list.get(i).getByte("Slot") != index) continue;
            return i;
        }
        return -1;
    }

    @Override
    public Item getItem(int index) {
        int i = this.getSlotIndex(index);
        if (i < 0) {
            return new ItemBlock(new BlockAir(), (Integer)0, 0);
        }
        CompoundTag data = (CompoundTag)this.namedTag.getList("Items").get(i);
        return Item.get(data.getShort("id"), data.getShort("Damage"), data.getByte("Count"));
    }

    @Override
    public void setItem(int index, Item item) {
        int i = this.getSlotIndex(index);
        CompoundTag d = new CompoundTag().putByte("Count", item.getCount()).putByte("Slot", index).putShort("id", item.getId()).putShort("Damage", item.getDamage());
        if (item.getId() == 0 || item.getCount() <= 0) {
            if (i >= 0) {
                this.namedTag.getList("Items").getAll().remove(i);
            }
        } else if (i < 0) {
            this.namedTag.getList("Items", CompoundTag.class).add(d);
        } else {
            this.namedTag.getList("Items", CompoundTag.class).add(i, d);
        }
    }

    @Override
    public BrewingInventory getInventory() {
        return this.inventory;
    }

    protected boolean checkIngredient(Item ingredient) {
        return ingredients.contains(ingredient.getId());
    }

    @Override
    public boolean onUpdate() {
        int i;
        if (this.closed) {
            return false;
        }
        boolean ret = false;
        Item ingredient = this.inventory.getIngredient();
        boolean canBrew = false;
        for (i = 1; i <= 3; ++i) {
            if (this.inventory.getItem(i).getId() != 373) continue;
            canBrew = true;
        }
        if (this.namedTag.getShort("CookTime") <= 400 && canBrew && ingredient.getCount() > 0) {
            if (!this.checkIngredient(ingredient)) {
                canBrew = false;
            }
        } else {
            canBrew = false;
        }
        if (canBrew) {
            this.namedTag.putShort("CookTime", this.namedTag.getShort("CookTime"));
            if (this.namedTag.getShort("CookTime") <= 0) {
                for (i = 1; i <= 3; ++i) {
                    Item potion = this.inventory.getItem(i);
                    BrewingRecipe recipe = Server.getInstance().getCraftingManager().matchBrewingRecipe(ingredient, potion);
                    if (recipe == null) continue;
                    this.inventory.setItem(i, recipe.getResult());
                }
                --ingredient.count;
                this.inventory.setIngredient(ingredient);
                this.namedTag.putShort("CookTime", this.namedTag.getShort("CookTime"));
            }
            for (Player player : this.getInventory().getViewers()) {
                int windowId = player.getWindowId(this.getInventory());
                if (windowId <= 0) continue;
                ContainerSetDataPacket pk = new ContainerSetDataPacket();
                pk.windowid = (byte)windowId;
                pk.property = 0;
                pk.value = this.namedTag.getShort("CookTime");
                player.dataPacket(pk);
            }
            ret = true;
        } else {
            this.namedTag.putShort("CookTime", 400);
        }
        this.lastUpdate = System.currentTimeMillis();
        return ret;
    }

    @Override
    public CompoundTag getSpawnCompound() {
        CompoundTag nbt = new CompoundTag().putString("id", "BrewingStand").putInt("x", (int)this.x).putInt("y", (int)this.y).putInt("z", (int)this.z).putShort("CookTime", 400);
        if (this.hasName()) {
            nbt.put("CustomName", this.namedTag.get("CustomName"));
        }
        return nbt;
    }
}

