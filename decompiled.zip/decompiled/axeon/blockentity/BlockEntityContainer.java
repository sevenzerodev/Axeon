/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.blockentity;

import cn.axeon.item.Item;

public interface BlockEntityContainer {
    public Item getItem(int var1);

    public void setItem(int var1, Item var2);

    public int getSize();
}

