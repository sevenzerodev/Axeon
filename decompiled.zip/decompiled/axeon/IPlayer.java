/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon;

import cn.axeon.Player;
import cn.axeon.Server;
import cn.axeon.metadata.Metadatable;
import cn.axeon.permission.ServerOperator;

public interface IPlayer
extends ServerOperator,
Metadatable {
    public boolean isOnline();

    public String getName();

    public boolean isBanned();

    public void setBanned(boolean var1);

    public boolean isWhitelisted();

    public void setWhitelisted(boolean var1);

    public Player getPlayer();

    public Server getServer();

    public Long getFirstPlayed();

    public Long getLastPlayed();

    public boolean hasPlayedBefore();
}

