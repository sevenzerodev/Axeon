/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.Player;
import cn.axeon.block.Block;
import cn.axeon.block.BlockFlowable;
import cn.axeon.item.Item;
import cn.axeon.level.generator.object.tree.ObjectTree;
import cn.axeon.math.NukkitRandom;
import cn.axeon.utils.BlockColor;

public class BlockSapling
extends BlockFlowable {
    public static final int OAK = 0;
    public static final int SPRUCE = 1;
    public static final int BIRCH = 2;
    public static final int JUNGLE = 3;
    public static final int ACACIA = 4;
    public static final int DARK_OAK = 5;

    public BlockSapling() {
        this(0);
    }

    public BlockSapling(int meta) {
        super(meta);
    }

    @Override
    public int getId() {
        return 6;
    }

    @Override
    public String getName() {
        String[] names = new String[]{"Oak Sapling", "Spruce Sapling", "Birch Sapling", "Jungle Sapling", "Acacia Sapling", "Dark Oak Sapling", "", ""};
        return names[this.meta & 7];
    }

    @Override
    public boolean place(Item item, Block block, Block target, int face, double fx, double fy, double fz, Player player) {
        Block down = this.getSide(0);
        if (down.getId() == 2 || down.getId() == 3 || down.getId() == 60 || down.getId() == 243) {
            this.getLevel().setBlock(block, this, true, true);
            return true;
        }
        return false;
    }

    @Override
    public boolean canBeActivated() {
        return true;
    }

    @Override
    public boolean onActivate(Item item, Player player) {
        if (item.getId() == 351 && item.getDamage() == 15) {
            ObjectTree.growTree(this.getLevel(), (int)this.x, (int)this.y, (int)this.z, new NukkitRandom(), this.meta & 7);
            if ((player.gamemode & 1) == 0) {
                --item.count;
            }
            return true;
        }
        this.getLevel().loadChunk((int)this.x >> 4, (int)this.z >> 4);
        return false;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public int onUpdate(int type) {
        if (type == 1) {
            if (!this.getSide(0).isTransparent()) return 1;
            this.getLevel().useBreakOn(this);
            return 1;
        }
        if (type != 2) return 1;
        if (new NukkitRandom().nextRange(1, 7) != 1) return 2;
        if ((this.meta & 8) == 8) {
            ObjectTree.growTree(this.getLevel(), (int)this.x, (int)this.y, (int)this.z, new NukkitRandom(), this.meta & 7);
            return 1;
        } else {
            this.meta |= 8;
            this.getLevel().setBlock(this, this, true);
            return 2;
        }
    }

    @Override
    public int[][] getDrops(Item item) {
        return new int[][]{{6, this.getDamage(), 1}};
    }

    @Override
    public BlockColor getColor() {
        return BlockColor.FOLIAGE_BLOCK_COLOR;
    }
}

