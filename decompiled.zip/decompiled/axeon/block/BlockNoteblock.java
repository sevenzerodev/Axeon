/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.Player;
import cn.axeon.block.Block;
import cn.axeon.block.BlockSolid;
import cn.axeon.item.Item;
import cn.axeon.level.sound.NoteBoxSound;
import cn.axeon.math.Vector3;

public class BlockNoteblock
extends BlockSolid {
    public BlockNoteblock() {
        this(0);
    }

    public BlockNoteblock(int meta) {
        super(meta);
    }

    @Override
    public String getName() {
        return "Note Block";
    }

    @Override
    public int getId() {
        return 25;
    }

    @Override
    public int getToolType() {
        return 4;
    }

    @Override
    public double getHardness() {
        return 0.8;
    }

    @Override
    public double getResistance() {
        return 4.0;
    }

    @Override
    public boolean canBeActivated() {
        return true;
    }

    public int getStrength() {
        this.meta = this.meta < 24 ? ++this.meta : 0;
        this.getLevel().setBlock(this, this);
        return this.meta;
    }

    public int getInstrument() {
        Block below = this.getSide(0);
        switch (below.getId()) {
            case 5: 
            case 25: 
            case 58: {
                return NoteBoxSound.INSTRUMENT_BASS;
            }
            case 12: 
            case 24: 
            case 88: {
                return NoteBoxSound.INSTRUMENT_TABOUR;
            }
            case 20: 
            case 89: 
            case 102: {
                return NoteBoxSound.INSTRUMENT_CLICK;
            }
            case 14: 
            case 15: 
            case 16: 
            case 21: 
            case 56: 
            case 73: 
            case 74: 
            case 129: {
                return NoteBoxSound.INSTRUMENT_BASS_DRUM;
            }
        }
        return NoteBoxSound.INSTRUMENT_PIANO;
    }

    @Override
    public boolean onActivate(Item item) {
        return this.onActivate(item, null);
    }

    @Override
    public boolean onActivate(Item item, Player player) {
        Block up = this.getSide(1);
        if (up.getId() == 0) {
            this.getLevel().addSound(new NoteBoxSound((Vector3)this, this.getInstrument(), this.getStrength()));
            return true;
        }
        return false;
    }
}

