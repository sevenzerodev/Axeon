/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.block.BlockFlowable;
import cn.axeon.entity.Entity;
import cn.axeon.item.Item;
import cn.axeon.utils.BlockColor;

public class BlockCobweb
extends BlockFlowable {
    public BlockCobweb() {
        this(0);
    }

    public BlockCobweb(int meta) {
        super(0);
    }

    @Override
    public String getName() {
        return "Cobweb";
    }

    @Override
    public int getId() {
        return 30;
    }

    @Override
    public double getHardness() {
        return 4.0;
    }

    @Override
    public double getResistance() {
        return 20.0;
    }

    @Override
    public int getToolType() {
        return 1;
    }

    @Override
    public void onEntityCollide(Entity entity) {
        entity.resetFallDistance();
    }

    @Override
    public int[][] getDrops(Item item) {
        if (item.isShears() || item.isSword()) {
            return new int[][]{{287, 0, 1}};
        }
        return new int[0][];
    }

    @Override
    public BlockColor getColor() {
        return BlockColor.CLOTH_BLOCK_COLOR;
    }
}

