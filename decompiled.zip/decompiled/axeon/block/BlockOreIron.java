/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.block.BlockSolid;
import cn.axeon.item.Item;

public class BlockOreIron
extends BlockSolid {
    public BlockOreIron() {
        this(0);
    }

    public BlockOreIron(int meta) {
        super(0);
    }

    @Override
    public int getId() {
        return 15;
    }

    @Override
    public double getHardness() {
        return 3.0;
    }

    @Override
    public double getResistance() {
        return 5.0;
    }

    @Override
    public int getToolType() {
        return 3;
    }

    @Override
    public String getName() {
        return "Iron Ore";
    }

    @Override
    public int[][] getDrops(Item item) {
        if (item.isPickaxe() && item.getTier() >= 3) {
            return new int[][]{{15, 0, 1}};
        }
        return new int[0][];
    }
}

