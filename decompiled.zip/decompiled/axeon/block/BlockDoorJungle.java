/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.block.BlockDoorWood;
import cn.axeon.item.Item;

public class BlockDoorJungle
extends BlockDoorWood {
    public BlockDoorJungle() {
        this(0);
    }

    public BlockDoorJungle(int meta) {
        super(meta);
    }

    @Override
    public String getName() {
        return "Jungle Door Block";
    }

    @Override
    public int getId() {
        return 195;
    }

    @Override
    public int[][] getDrops(Item item) {
        return new int[][]{{429, 0, 1}};
    }
}

