/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.Player;
import cn.axeon.block.Block;
import cn.axeon.block.BlockFlowable;
import cn.axeon.item.Item;
import cn.axeon.level.sound.LeverSound;
import cn.axeon.math.Vector3;
import cn.axeon.redstone.Redstone;

public class BlockLever
extends BlockFlowable {
    public BlockLever(int meta) {
        super(meta);
        this.setPowerSource(true);
        this.setPowerLevel(16);
    }

    public BlockLever() {
        this(0);
    }

    @Override
    public String getName() {
        return "Lever";
    }

    @Override
    public int getId() {
        return 69;
    }

    @Override
    public boolean canBeActivated() {
        return true;
    }

    @Override
    public double getHardness() {
        return 0.5;
    }

    @Override
    public double getResistance() {
        return 2.5;
    }

    @Override
    public int[][] getDrops(Item item) {
        return new int[][]{{69, 0, 1}};
    }

    public boolean isPowerOn() {
        return this.meta >= 8;
    }

    @Override
    public boolean onActivate(Item item, Player player) {
        this.meta ^= 8;
        this.getLevel().setBlock(this, this, true, false);
        this.getLevel().addSound(new LeverSound((Vector3)this, this.isPowerOn()));
        if (this.isPowerOn()) {
            this.setPowerSource(true);
            Redstone.active(this);
        } else {
            Redstone.deactive(this, this.getPowerLevel());
        }
        return true;
    }

    @Override
    public boolean place(Item item, Block block, Block target, int face, double fx, double fy, double fz, Player player) {
        if (!target.isTransparent()) {
            int[] faces = new int[]{0, 5, 4, 3, 2, 1};
            if (face == 0) {
                int to;
                this.meta = to = player != null ? player.getDirection() : 0;
            } else if (face == 1) {
                int to = player != null ? player.getDirection() : 0;
                this.meta = to ^ 6;
            } else {
                this.meta = faces[face];
            }
            this.getLevel().setBlock(block, this, true, true);
            return true;
        }
        return false;
    }

    @Override
    public boolean onBreak(Item item) {
        super.onBreak(item);
        int level = this.getPowerLevel();
        Redstone.deactive(this, level);
        return true;
    }
}

