/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.Player;
import cn.axeon.block.Block;
import cn.axeon.block.BlockTransparent;
import cn.axeon.event.block.DoorToggleEvent;
import cn.axeon.item.Item;
import cn.axeon.level.sound.DoorSound;
import cn.axeon.math.AxisAlignedBB;
import cn.axeon.utils.BlockColor;

public class BlockTrapdoor
extends BlockTransparent {
    public BlockTrapdoor() {
        this(0);
    }

    public BlockTrapdoor(int meta) {
        super(meta);
    }

    @Override
    public int getId() {
        return 96;
    }

    @Override
    public String getName() {
        return "Wooden Trapdoor";
    }

    @Override
    public double getHardness() {
        return 3.0;
    }

    @Override
    public double getResistance() {
        return 15.0;
    }

    @Override
    public boolean canBeActivated() {
        return true;
    }

    @Override
    public int getToolType() {
        return 4;
    }

    @Override
    protected AxisAlignedBB recalculateBoundingBox() {
        int damage = this.getDamage();
        double f = 0.1875;
        AxisAlignedBB bb = (damage & 8) > 0 ? new AxisAlignedBB(this.x, this.y + 1.0 - f, this.z, this.x + 1.0, this.y + 1.0, this.z + 1.0) : new AxisAlignedBB(this.x, this.y, this.z, this.x + 1.0, this.y + f, this.z + 1.0);
        if ((damage & 4) > 0) {
            if ((damage & 3) == 0) {
                bb.setBounds(this.x, this.y, this.z + 1.0 - f, this.x + 1.0, this.y + 1.0, this.z + 1.0);
            } else if ((damage & 3) == 1) {
                bb.setBounds(this.x, this.y, this.z, this.x + 1.0, this.y + 1.0, this.z + f);
            }
            if ((damage & 3) == 2) {
                bb.setBounds(this.x + 1.0 - f, this.y, this.z, this.x + 1.0, this.y + 1.0, this.z + 1.0);
            }
            if ((damage & 3) == 3) {
                bb.setBounds(this.x, this.y, this.z, this.x + f, this.y + 1.0, this.z + 1.0);
            }
        }
        return bb;
    }

    @Override
    public boolean place(Item item, Block block, Block target, int face, double fx, double fy, double fz, Player player) {
        if (!(target.isTransparent() && target.getId() != 44 || face == 0 || face == 1)) {
            int faceBit = 0;
            int upDownBit = 0;
            if (fy > 0.5) {
                upDownBit = 4;
            }
            switch (face) {
                case 2: {
                    faceBit = 3;
                    break;
                }
                case 3: {
                    faceBit = 2;
                    break;
                }
                case 4: {
                    faceBit = 1;
                    break;
                }
                case 5: {
                    faceBit = 0;
                }
            }
            this.meta |= upDownBit;
            this.meta |= faceBit;
            this.getLevel().setBlock(block, this, true, true);
            return true;
        }
        return false;
    }

    @Override
    public int[][] getDrops(Item item) {
        return new int[][]{{this.getId(), 0, 1}};
    }

    @Override
    public boolean onActivate(Item item, Player player) {
        if (!this.toggle(player)) {
            return false;
        }
        this.getLevel().setBlock(this, this, true);
        this.level.addSound(new DoorSound(this));
        return true;
    }

    @Override
    public BlockColor getColor() {
        return BlockColor.WOOD_BLOCK_COLOR;
    }

    public boolean toggle(Player player) {
        DoorToggleEvent event = new DoorToggleEvent(this, player);
        this.getLevel().getServer().getPluginManager().callEvent(event);
        if (event.isCancelled()) {
            return false;
        }
        int sideBit = this.meta & 7;
        int openBit = this.meta & 8;
        openBit = ~openBit & 8;
        this.meta = sideBit | openBit;
        return true;
    }

    public boolean isOpen() {
        return (this.meta & 8) > 0;
    }
}

