/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.block.BlockSignPost;

public class BlockWallSign
extends BlockSignPost {
    public BlockWallSign() {
        this(0);
    }

    public BlockWallSign(int meta) {
        super(meta);
    }

    @Override
    public int getId() {
        return 68;
    }

    @Override
    public String getName() {
        return "Wall Sign";
    }

    @Override
    public int onUpdate(int type) {
        int[] faces = new int[]{3, 2, 5, 4};
        if (type == 1 && this.meta >= 2 && this.meta <= 5) {
            if (this.getSide(faces[this.meta - 2]).getId() == 0) {
                this.getLevel().useBreakOn(this);
            }
            return 1;
        }
        return 0;
    }
}

