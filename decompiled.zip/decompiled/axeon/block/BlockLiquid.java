/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.block.Block;
import cn.axeon.block.BlockAir;
import cn.axeon.block.BlockCobblestone;
import cn.axeon.block.BlockLava;
import cn.axeon.block.BlockObsidian;
import cn.axeon.block.BlockStone;
import cn.axeon.block.BlockTransparent;
import cn.axeon.block.BlockWater;
import cn.axeon.entity.Entity;
import cn.axeon.item.Item;
import cn.axeon.level.particle.SmokeParticle;
import cn.axeon.level.sound.FizzSound;
import cn.axeon.math.AxisAlignedBB;
import cn.axeon.math.Vector3;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

public abstract class BlockLiquid
extends BlockTransparent {
    public int adjacentSources = 0;
    public boolean[] isOptimalFlowDirection = new boolean[]{false, false, false, false};
    public int[] flowinCost = new int[]{0, 0, 0, 0};
    private Vector3 temporalVector = null;

    protected BlockLiquid(int meta) {
        super(meta);
    }

    @Override
    public boolean hasEntityCollision() {
        return true;
    }

    @Override
    public boolean isBreakable(Item item) {
        return false;
    }

    @Override
    public boolean canBeReplaced() {
        return true;
    }

    @Override
    public boolean isSolid() {
        return false;
    }

    @Override
    public AxisAlignedBB getBoundingBox() {
        return null;
    }

    @Override
    public int[][] getDrops(Item item) {
        return new int[0][];
    }

    public float getFluidHeightPercent() {
        float d = this.meta;
        if (d >= 8.0f) {
            d = 0.0f;
        }
        return (d + 1.0f) / 9.0f;
    }

    protected int getFlowDecay(Vector3 pos) {
        if (!(pos instanceof Block)) {
            pos = this.getLevel().getBlock(pos);
        }
        if (((Block)pos).getId() != this.getId()) {
            return -1;
        }
        return ((Block)pos).getDamage();
    }

    protected int getEffectiveFlowDecay(Vector3 pos) {
        if (!(pos instanceof Block)) {
            pos = this.getLevel().getBlock(pos);
        }
        if (((Block)pos).getId() != this.getId()) {
            return -1;
        }
        int decay = ((Block)pos).getDamage();
        if (decay >= 8) {
            decay = 0;
        }
        return decay;
    }

    public Vector3 getFlowVector() {
        Vector3 vector = new Vector3(0.0, 0.0, 0.0);
        if (this.temporalVector == null) {
            this.temporalVector = new Vector3(0.0, 0.0, 0.0);
        }
        int decay = this.getEffectiveFlowDecay(this);
        for (int j = 0; j < 4; ++j) {
            int realDecay;
            double x = this.x;
            double y = this.y;
            double z = this.z;
            if (j == 0) {
                x -= 1.0;
            } else if (j == 1) {
                x += 1.0;
            } else if (j == 2) {
                z -= 1.0;
            } else if (j == 3) {
                z += 1.0;
            }
            Block sideBlock = this.getLevel().getBlock(this.temporalVector.setComponents(x, y, z));
            int blockDecay = this.getEffectiveFlowDecay(sideBlock);
            if (blockDecay < 0) {
                if (!sideBlock.canBeFlowedInto() || (blockDecay = this.getEffectiveFlowDecay(this.getLevel().getBlock(this.temporalVector.setComponents(x, y - 1.0, z)))) < 0) continue;
                realDecay = blockDecay - (decay - 8);
                vector.x += (sideBlock.x - this.x) * (double)realDecay;
                vector.y += (sideBlock.y - this.y) * (double)realDecay;
                vector.z += (sideBlock.z - this.z) * (double)realDecay;
                continue;
            }
            realDecay = blockDecay - decay;
            vector.x += (sideBlock.x - this.x) * (double)realDecay;
            vector.y += (sideBlock.y - this.y) * (double)realDecay;
            vector.z += (sideBlock.z - this.z) * (double)realDecay;
        }
        if (this.getDamage() >= 8) {
            boolean falling = false;
            if (!this.getLevel().getBlock(this.temporalVector.setComponents(this.x, this.y, this.z - 1.0)).canBeFlowedInto()) {
                falling = true;
            } else if (!this.getLevel().getBlock(this.temporalVector.setComponents(this.x, this.y, this.z + 1.0)).canBeFlowedInto()) {
                falling = true;
            } else if (!this.getLevel().getBlock(this.temporalVector.setComponents(this.x - 1.0, this.y, this.z)).canBeFlowedInto()) {
                falling = true;
            } else if (!this.getLevel().getBlock(this.temporalVector.setComponents(this.x + 1.0, this.y, this.z)).canBeFlowedInto()) {
                falling = true;
            } else if (!this.getLevel().getBlock(this.temporalVector.setComponents(this.x, this.y + 1.0, this.z - 1.0)).canBeFlowedInto()) {
                falling = true;
            } else if (!this.getLevel().getBlock(this.temporalVector.setComponents(this.x, this.y + 1.0, this.z + 1.0)).canBeFlowedInto()) {
                falling = true;
            } else if (!this.getLevel().getBlock(this.temporalVector.setComponents(this.x - 1.0, this.y + 1.0, this.z)).canBeFlowedInto()) {
                falling = true;
            } else if (!this.getLevel().getBlock(this.temporalVector.setComponents(this.x + 1.0, this.y + 1.0, this.z)).canBeFlowedInto()) {
                falling = true;
            }
            if (falling) {
                vector = vector.normalize().add(0.0, -6.0, 0.0);
            }
        }
        return vector.normalize();
    }

    @Override
    public void addVelocityToEntity(Entity entity, Vector3 vector) {
        Vector3 flow = this.getFlowVector();
        vector.x += flow.x;
        vector.y += flow.y;
        vector.z += flow.z;
    }

    @Override
    public int tickRate() {
        if (this instanceof BlockWater) {
            return 5;
        }
        if (this instanceof BlockLava) {
            if (this.getLevel().getDimension() == 1) {
                return 5;
            }
            return 30;
        }
        return 0;
    }

    @Override
    public int onUpdate(int type) {
        if (type == 1) {
            this.checkForHarden();
            this.getLevel().scheduleUpdate(this, this.tickRate());
        } else if (type == 3) {
            Block bottomBlock;
            if (this.temporalVector == null) {
                this.temporalVector = new Vector3(0.0, 0.0, 0.0);
            }
            int decay = this.getFlowDecay(this);
            int multiplier = this instanceof BlockLava ? 2 : 1;
            boolean flag = true;
            if (decay > 0) {
                int topFlowDecay;
                int smallestFlowDecay = -100;
                this.adjacentSources = 0;
                smallestFlowDecay = this.getSmallestFlowDecay(this.level.getBlock(this.temporalVector.setComponents(this.x, this.y, this.z - 1.0)), smallestFlowDecay);
                smallestFlowDecay = this.getSmallestFlowDecay(this.level.getBlock(this.temporalVector.setComponents(this.x, this.y, this.z + 1.0)), smallestFlowDecay);
                smallestFlowDecay = this.getSmallestFlowDecay(this.level.getBlock(this.temporalVector.setComponents(this.x - 1.0, this.y, this.z)), smallestFlowDecay);
                smallestFlowDecay = this.getSmallestFlowDecay(this.level.getBlock(this.temporalVector.setComponents(this.x + 1.0, this.y, this.z)), smallestFlowDecay);
                int k = smallestFlowDecay + multiplier;
                if (k >= 8 || smallestFlowDecay < 0) {
                    k = -1;
                }
                if ((topFlowDecay = this.getFlowDecay(this.level.getBlock(this.level.getBlock(this.temporalVector.setComponents(this.x, this.y + 1.0, this.z))))) >= 0) {
                    k = topFlowDecay >= 8 ? topFlowDecay : topFlowDecay | 8;
                }
                if (this.adjacentSources >= 2 && this instanceof BlockWater) {
                    Block bottomBlock2 = this.level.getBlock(this.level.getBlock(this.temporalVector.setComponents(this.x, this.y - 1.0, this.z)));
                    if (bottomBlock2.isSolid()) {
                        k = 0;
                    } else if (bottomBlock2 instanceof BlockWater && bottomBlock2.getDamage() == 0) {
                        k = 0;
                    }
                }
                if (this instanceof BlockLava && decay < 8 && k < 8 && k > 1 && new Random().nextInt(4) != 0) {
                    k = decay;
                    flag = false;
                }
                if (k != decay) {
                    decay = k;
                    if (decay < 0) {
                        this.getLevel().setBlock(this, new BlockAir(), true);
                    } else {
                        this.getLevel().setBlock(this, this.getBlock(decay), true);
                        this.getLevel().scheduleUpdate(this, this.tickRate());
                    }
                } else if (flag) {
                    // empty if block
                }
            }
            if ((bottomBlock = this.level.getBlock(this.temporalVector.setComponents(this.x, this.y - 1.0, this.z))).canBeFlowedInto() || bottomBlock instanceof BlockLiquid) {
                if (this instanceof BlockLava && bottomBlock instanceof BlockWater) {
                    this.getLevel().setBlock(bottomBlock, new BlockStone(), true);
                    this.triggerLavaMixEffects(bottomBlock);
                    return 0;
                }
                if (decay >= 8) {
                    this.flowIntoBlock(bottomBlock, decay);
                } else {
                    this.flowIntoBlock(bottomBlock, decay | 8);
                }
            } else if (!(decay < 0 || decay != 0 && bottomBlock.canBeFlowedInto())) {
                boolean[] flags = this.getOptimalFlowDirections();
                int l = decay + multiplier;
                if (decay >= 8) {
                    l = 1;
                }
                if (l >= 8) {
                    this.checkForHarden();
                    return 0;
                }
                if (flags[0]) {
                    this.flowIntoBlock(this.level.getBlock(this.temporalVector.setComponents(this.x - 1.0, this.y, this.z)), l);
                }
                if (flags[1]) {
                    this.flowIntoBlock(this.level.getBlock(this.temporalVector.setComponents(this.x + 1.0, this.y, this.z)), l);
                }
                if (flags[2]) {
                    this.flowIntoBlock(this.level.getBlock(this.temporalVector.setComponents(this.x, this.y, this.z - 1.0)), l);
                }
                if (flags[3]) {
                    this.flowIntoBlock(this.level.getBlock(this.temporalVector.setComponents(this.x, this.y, this.z + 1.0)), l);
                }
            }
            this.checkForHarden();
        }
        return 0;
    }

    private void flowIntoBlock(Block block, int newFlowDecay) {
        if (block.canBeFlowedInto()) {
            if (block.getId() > 0) {
                if (this instanceof BlockLava) {
                    this.triggerLavaMixEffects(block);
                } else {
                    this.getLevel().useBreakOn(block);
                }
            }
            this.getLevel().setBlock(block, this.getBlock(newFlowDecay), true);
        }
    }

    private int calculateFlowCost(Block block, int accumulatedCost, int previousDirection) {
        int cost = 1000;
        for (int j = 0; j < 4; ++j) {
            int realCost;
            if (!(j == 0 && previousDirection == 1 || j == 1 && previousDirection == 0 || j == 2 && previousDirection == 3) && (j != 3 || previousDirection != 2)) continue;
            double x = block.x;
            double y = block.y;
            double z = block.z;
            if (j == 0) {
                x -= 1.0;
            } else if (j == 1) {
                x += 1.0;
            } else if (j == 2) {
                z -= 1.0;
            } else if (j == 3) {
                z += 1.0;
            }
            Block blockSide = this.getLevel().getBlock(this.temporalVector.setComponents(x, y, z));
            if (!blockSide.canBeFlowedInto() && !(blockSide instanceof BlockLiquid) || blockSide instanceof BlockLiquid && blockSide.getDamage() == 0) continue;
            if (this.getLevel().getBlock(this.temporalVector.setComponents(x, y - 1.0, z)).canBeFlowedInto()) {
                return accumulatedCost;
            }
            if (accumulatedCost >= 4 || (realCost = this.calculateFlowCost(blockSide, accumulatedCost + 1, j)) >= cost) continue;
            cost = realCost;
        }
        return cost;
    }

    @Override
    public double getHardness() {
        return 100.0;
    }

    @Override
    public double getResistance() {
        return 500.0;
    }

    private boolean[] getOptimalFlowDirections() {
        int i;
        if (this.temporalVector == null) {
            this.temporalVector = new Vector3(0.0, 0.0, 0.0);
        }
        for (int j = 0; j < 4; ++j) {
            this.flowinCost[j] = 1000;
            double x = this.x;
            double y = this.y;
            double z = this.z;
            if (j == 0) {
                x -= 1.0;
            } else if (j == 1) {
                x += 1.0;
            } else if (j == 2) {
                z -= 1.0;
            } else if (j == 3) {
                z += 1.0;
            }
            Block block = this.getLevel().getBlock(this.temporalVector.setComponents(x, y, z));
            if (!block.canBeFlowedInto() && !(block instanceof BlockLiquid) || block instanceof BlockLiquid && block.getDamage() == 0) continue;
            this.flowinCost[j] = this.getLevel().getBlock(this.temporalVector.setComponents(x, y - 1.0, z)).canBeFlowedInto() ? 0 : this.calculateFlowCost(block, 1, j);
        }
        int minCost = this.flowinCost[0];
        for (i = 1; i < 4; ++i) {
            if (this.flowinCost[i] >= minCost) continue;
            minCost = this.flowinCost[i];
        }
        for (i = 0; i < 4; ++i) {
            this.isOptimalFlowDirection[i] = this.flowinCost[i] == minCost;
        }
        return this.isOptimalFlowDirection;
    }

    private int getSmallestFlowDecay(Vector3 pos, int decay) {
        int blockDecay = this.getFlowDecay(pos);
        if (blockDecay < 0) {
            return decay;
        }
        if (blockDecay == 0) {
            ++this.adjacentSources;
        } else if (blockDecay >= 8) {
            blockDecay = 0;
        }
        return decay >= 0 && blockDecay >= decay ? decay : blockDecay;
    }

    private void checkForHarden() {
        if (this instanceof BlockLava) {
            boolean colliding = false;
            for (int side = 0; side <= 5 && !colliding; ++side) {
                colliding = this.getSide(side) instanceof BlockWater;
            }
            if (colliding) {
                if (this.getDamage() == 0) {
                    this.getLevel().setBlock(this, new BlockObsidian(), true);
                } else if (this.getDamage() <= 4) {
                    this.getLevel().setBlock(this, new BlockCobblestone(), true);
                }
                this.triggerLavaMixEffects(this);
            }
        }
    }

    protected void triggerLavaMixEffects(Vector3 pos) {
        this.getLevel().addSound(new FizzSound(pos.add(0.5, 0.5, 0.5), 2.6f + (ThreadLocalRandom.current().nextFloat() - ThreadLocalRandom.current().nextFloat()) * 0.8f));
        for (int i = 0; i < 8; ++i) {
            this.getLevel().addParticle(new SmokeParticle(pos.add(Math.random(), 1.2, Math.random())));
        }
    }

    public abstract BlockLiquid getBlock(int var1);

    @Override
    public boolean canPassThrough() {
        return true;
    }

    @Override
    public void onEntityCollide(Entity entity) {
        entity.resetFallDistance();
    }
}

