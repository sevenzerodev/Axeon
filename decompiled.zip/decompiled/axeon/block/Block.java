/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.Player;
import cn.axeon.Server;
import cn.axeon.block.BlockAir;
import cn.axeon.block.BlockAnvil;
import cn.axeon.block.BlockBed;
import cn.axeon.block.BlockBedrock;
import cn.axeon.block.BlockBedrockInvisible;
import cn.axeon.block.BlockBeetroot;
import cn.axeon.block.BlockBookshelf;
import cn.axeon.block.BlockBrewingStand;
import cn.axeon.block.BlockBricks;
import cn.axeon.block.BlockBricksStone;
import cn.axeon.block.BlockCactus;
import cn.axeon.block.BlockCake;
import cn.axeon.block.BlockCarpet;
import cn.axeon.block.BlockCarrot;
import cn.axeon.block.BlockChest;
import cn.axeon.block.BlockClay;
import cn.axeon.block.BlockClayHardened;
import cn.axeon.block.BlockClayStained;
import cn.axeon.block.BlockCoal;
import cn.axeon.block.BlockCobblestone;
import cn.axeon.block.BlockCobweb;
import cn.axeon.block.BlockDandelion;
import cn.axeon.block.BlockDaylightDetector;
import cn.axeon.block.BlockDaylightDetectorInverted;
import cn.axeon.block.BlockDeadBush;
import cn.axeon.block.BlockDiamond;
import cn.axeon.block.BlockDirt;
import cn.axeon.block.BlockDoorAcacia;
import cn.axeon.block.BlockDoorBirch;
import cn.axeon.block.BlockDoorDarkOak;
import cn.axeon.block.BlockDoorIron;
import cn.axeon.block.BlockDoorJungle;
import cn.axeon.block.BlockDoorSpruce;
import cn.axeon.block.BlockDoorWood;
import cn.axeon.block.BlockDoublePlant;
import cn.axeon.block.BlockDoubleSlab;
import cn.axeon.block.BlockDoubleSlabWood;
import cn.axeon.block.BlockEmerald;
import cn.axeon.block.BlockEnchantingTable;
import cn.axeon.block.BlockEndPortalFrame;
import cn.axeon.block.BlockEndStone;
import cn.axeon.block.BlockFarmland;
import cn.axeon.block.BlockFence;
import cn.axeon.block.BlockFenceGate;
import cn.axeon.block.BlockFenceGateAcacia;
import cn.axeon.block.BlockFenceGateBirch;
import cn.axeon.block.BlockFenceGateDarkOak;
import cn.axeon.block.BlockFenceGateJungle;
import cn.axeon.block.BlockFenceGateSpruce;
import cn.axeon.block.BlockFenceNetherBrick;
import cn.axeon.block.BlockFire;
import cn.axeon.block.BlockFlower;
import cn.axeon.block.BlockFlowerPot;
import cn.axeon.block.BlockFurnace;
import cn.axeon.block.BlockFurnaceBurning;
import cn.axeon.block.BlockGlass;
import cn.axeon.block.BlockGlassPane;
import cn.axeon.block.BlockGlowstone;
import cn.axeon.block.BlockGold;
import cn.axeon.block.BlockGrass;
import cn.axeon.block.BlockGrassPath;
import cn.axeon.block.BlockGravel;
import cn.axeon.block.BlockHayBale;
import cn.axeon.block.BlockHugeMushroomBrown;
import cn.axeon.block.BlockHugeMushroomRed;
import cn.axeon.block.BlockIce;
import cn.axeon.block.BlockIron;
import cn.axeon.block.BlockIronBars;
import cn.axeon.block.BlockLadder;
import cn.axeon.block.BlockLapis;
import cn.axeon.block.BlockLava;
import cn.axeon.block.BlockLavaStill;
import cn.axeon.block.BlockLeaves;
import cn.axeon.block.BlockLeaves2;
import cn.axeon.block.BlockLever;
import cn.axeon.block.BlockLiquid;
import cn.axeon.block.BlockLitRedstoneLamp;
import cn.axeon.block.BlockMelon;
import cn.axeon.block.BlockMobSpawner;
import cn.axeon.block.BlockMossStone;
import cn.axeon.block.BlockMushroomBrown;
import cn.axeon.block.BlockMushroomRed;
import cn.axeon.block.BlockMycelium;
import cn.axeon.block.BlockNetherBrick;
import cn.axeon.block.BlockNetherPortal;
import cn.axeon.block.BlockNetherrack;
import cn.axeon.block.BlockNoteblock;
import cn.axeon.block.BlockObsidian;
import cn.axeon.block.BlockObsidianGlowing;
import cn.axeon.block.BlockOreCoal;
import cn.axeon.block.BlockOreDiamond;
import cn.axeon.block.BlockOreEmerald;
import cn.axeon.block.BlockOreGold;
import cn.axeon.block.BlockOreIron;
import cn.axeon.block.BlockOreLapis;
import cn.axeon.block.BlockOreQuartz;
import cn.axeon.block.BlockOreRedstone;
import cn.axeon.block.BlockOreRedstoneGlowing;
import cn.axeon.block.BlockPackedIce;
import cn.axeon.block.BlockPlanks;
import cn.axeon.block.BlockPodzol;
import cn.axeon.block.BlockPotato;
import cn.axeon.block.BlockPressurePlateStone;
import cn.axeon.block.BlockPressurePlateWood;
import cn.axeon.block.BlockPumpkin;
import cn.axeon.block.BlockPumpkinLit;
import cn.axeon.block.BlockQuartz;
import cn.axeon.block.BlockRail;
import cn.axeon.block.BlockRailActivator;
import cn.axeon.block.BlockRailDetector;
import cn.axeon.block.BlockRailPowered;
import cn.axeon.block.BlockRedstone;
import cn.axeon.block.BlockRedstoneLamp;
import cn.axeon.block.BlockRedstoneTorch;
import cn.axeon.block.BlockRedstoneWire;
import cn.axeon.block.BlockSand;
import cn.axeon.block.BlockSandstone;
import cn.axeon.block.BlockSapling;
import cn.axeon.block.BlockSignPost;
import cn.axeon.block.BlockSkull;
import cn.axeon.block.BlockSlab;
import cn.axeon.block.BlockSlabWood;
import cn.axeon.block.BlockSlime;
import cn.axeon.block.BlockSnow;
import cn.axeon.block.BlockSnowLayer;
import cn.axeon.block.BlockSoulSand;
import cn.axeon.block.BlockSponge;
import cn.axeon.block.BlockStairsAcacia;
import cn.axeon.block.BlockStairsBirch;
import cn.axeon.block.BlockStairsBrick;
import cn.axeon.block.BlockStairsCobblestone;
import cn.axeon.block.BlockStairsDarkOak;
import cn.axeon.block.BlockStairsJungle;
import cn.axeon.block.BlockStairsNetherBrick;
import cn.axeon.block.BlockStairsQuartz;
import cn.axeon.block.BlockStairsSandstone;
import cn.axeon.block.BlockStairsSpruce;
import cn.axeon.block.BlockStairsStoneBrick;
import cn.axeon.block.BlockStairsWood;
import cn.axeon.block.BlockStemMelon;
import cn.axeon.block.BlockStemPumpkin;
import cn.axeon.block.BlockStone;
import cn.axeon.block.BlockStonecutter;
import cn.axeon.block.BlockSugarcane;
import cn.axeon.block.BlockTNT;
import cn.axeon.block.BlockTallGrass;
import cn.axeon.block.BlockTorch;
import cn.axeon.block.BlockTrapdoor;
import cn.axeon.block.BlockTrapdoorIron;
import cn.axeon.block.BlockUnknown;
import cn.axeon.block.BlockVine;
import cn.axeon.block.BlockWall;
import cn.axeon.block.BlockWallSign;
import cn.axeon.block.BlockWater;
import cn.axeon.block.BlockWaterLily;
import cn.axeon.block.BlockWaterStill;
import cn.axeon.block.BlockWeightedPressurePlateHeavy;
import cn.axeon.block.BlockWeightedPressurePlateLight;
import cn.axeon.block.BlockWheat;
import cn.axeon.block.BlockWood;
import cn.axeon.block.BlockWood2;
import cn.axeon.block.BlockWool;
import cn.axeon.block.BlockWorkbench;
import cn.axeon.entity.Entity;
import cn.axeon.item.Item;
import cn.axeon.level.MovingObjectPosition;
import cn.axeon.level.Position;
import cn.axeon.math.AxisAlignedBB;
import cn.axeon.math.Vector3;
import cn.axeon.metadata.MetadataValue;
import cn.axeon.metadata.Metadatable;
import cn.axeon.plugin.Plugin;
import cn.axeon.utils.BlockColor;
import java.lang.reflect.Constructor;
import java.util.List;

public abstract class Block
extends Position
implements Metadatable,
Cloneable {
    public static final int AIR = 0;
    public static final int STONE = 1;
    public static final int GRASS = 2;
    public static final int DIRT = 3;
    public static final int COBBLESTONE = 4;
    public static final int COBBLE = 4;
    public static final int PLANK = 5;
    public static final int PLANKS = 5;
    public static final int WOODEN_PLANK = 5;
    public static final int WOODEN_PLANKS = 5;
    public static final int SAPLING = 6;
    public static final int SAPLINGS = 6;
    public static final int BEDROCK = 7;
    public static final int WATER = 8;
    public static final int STILL_WATER = 9;
    public static final int LAVA = 10;
    public static final int STILL_LAVA = 11;
    public static final int SAND = 12;
    public static final int GRAVEL = 13;
    public static final int GOLD_ORE = 14;
    public static final int IRON_ORE = 15;
    public static final int COAL_ORE = 16;
    public static final int LOG = 17;
    public static final int WOOD = 17;
    public static final int TRUNK = 17;
    public static final int LEAVES = 18;
    public static final int LEAVE = 18;
    public static final int SPONGE = 19;
    public static final int GLASS = 20;
    public static final int LAPIS_ORE = 21;
    public static final int LAPIS_BLOCK = 22;
    public static final int DISPENSER = 23;
    public static final int SANDSTONE = 24;
    public static final int NOTEBLOCK = 25;
    public static final int BED_BLOCK = 26;
    public static final int POWERED_RAIL = 27;
    public static final int DETECTOR_RAIL = 28;
    public static final int COBWEB = 30;
    public static final int TALL_GRASS = 31;
    public static final int BUSH = 32;
    public static final int DEAD_BUSH = 32;
    public static final int WOOL = 35;
    public static final int DANDELION = 37;
    public static final int POPPY = 38;
    public static final int ROSE = 38;
    public static final int FLOWER = 38;
    public static final int RED_FLOWER = 38;
    public static final int BROWN_MUSHROOM = 39;
    public static final int RED_MUSHROOM = 40;
    public static final int GOLD_BLOCK = 41;
    public static final int IRON_BLOCK = 42;
    public static final int DOUBLE_SLAB = 43;
    public static final int DOUBLE_SLABS = 43;
    public static final int SLAB = 44;
    public static final int SLABS = 44;
    public static final int BRICKS = 45;
    public static final int BRICKS_BLOCK = 45;
    public static final int TNT = 46;
    public static final int BOOKSHELF = 47;
    public static final int MOSS_STONE = 48;
    public static final int MOSSY_STONE = 48;
    public static final int OBSIDIAN = 49;
    public static final int TORCH = 50;
    public static final int FIRE = 51;
    public static final int MONSTER_SPAWNER = 52;
    public static final int WOOD_STAIRS = 53;
    public static final int WOODEN_STAIRS = 53;
    public static final int OAK_WOOD_STAIRS = 53;
    public static final int OAK_WOODEN_STAIRS = 53;
    public static final int CHEST = 54;
    public static final int REDSTONE_WIRE = 55;
    public static final int DIAMOND_ORE = 56;
    public static final int DIAMOND_BLOCK = 57;
    public static final int CRAFTING_TABLE = 58;
    public static final int WORKBENCH = 58;
    public static final int WHEAT_BLOCK = 59;
    public static final int FARMLAND = 60;
    public static final int FURNACE = 61;
    public static final int BURNING_FURNACE = 62;
    public static final int LIT_FURNACE = 62;
    public static final int SIGN_POST = 63;
    public static final int DOOR_BLOCK = 64;
    public static final int WOODEN_DOOR_BLOCK = 64;
    public static final int WOOD_DOOR_BLOCK = 64;
    public static final int LADDER = 65;
    public static final int RAIL = 66;
    public static final int COBBLE_STAIRS = 67;
    public static final int COBBLESTONE_STAIRS = 67;
    public static final int WALL_SIGN = 68;
    public static final int LEVER = 69;
    public static final int STONE_PRESSURE_PLATE = 70;
    public static final int IRON_DOOR_BLOCK = 71;
    public static final int WOODEN_PRESSURE_PLATE = 72;
    public static final int REDSTONE_ORE = 73;
    public static final int GLOWING_REDSTONE_ORE = 74;
    public static final int LIT_REDSTONE_ORE = 74;
    public static final int REDSTONE_TORCH = 76;
    public static final int SNOW = 78;
    public static final int SNOW_LAYER = 78;
    public static final int ICE = 79;
    public static final int SNOW_BLOCK = 80;
    public static final int CACTUS = 81;
    public static final int CLAY_BLOCK = 82;
    public static final int REEDS = 83;
    public static final int SUGARCANE_BLOCK = 83;
    public static final int FENCE = 85;
    public static final int PUMPKIN = 86;
    public static final int NETHERRACK = 87;
    public static final int SOUL_SAND = 88;
    public static final int GLOWSTONE = 89;
    public static final int GLOWSTONE_BLOCK = 89;
    public static final int NETHER_PORTAL = 90;
    public static final int LIT_PUMPKIN = 91;
    public static final int JACK_O_LANTERN = 91;
    public static final int CAKE_BLOCK = 92;
    public static final int INVISIBLE_BEDROCK = 95;
    public static final int TRAPDOOR = 96;
    public static final int STONE_BRICKS = 98;
    public static final int STONE_BRICK = 98;
    public static final int BROWN_MUSHROOM_BLOCK = 99;
    public static final int RED_MUSHROOM_BLOCK = 100;
    public static final int IRON_BAR = 101;
    public static final int IRON_BARS = 101;
    public static final int GLASS_PANE = 102;
    public static final int GLASS_PANEL = 102;
    public static final int MELON_BLOCK = 103;
    public static final int PUMPKIN_STEM = 104;
    public static final int MELON_STEM = 105;
    public static final int VINE = 106;
    public static final int VINES = 106;
    public static final int FENCE_GATE = 107;
    public static final int FENCE_GATE_OAK = 107;
    public static final int BRICK_STAIRS = 108;
    public static final int STONE_BRICK_STAIRS = 109;
    public static final int MYCELIUM = 110;
    public static final int WATER_LILY = 111;
    public static final int LILY_PAD = 111;
    public static final int NETHER_BRICKS = 112;
    public static final int NETHER_BRICK_BLOCK = 112;
    public static final int NETHER_BRICK_FENCE = 113;
    public static final int NETHER_BRICKS_STAIRS = 114;
    public static final int ENCHANTING_TABLE = 116;
    public static final int ENCHANT_TABLE = 116;
    public static final int ENCHANTMENT_TABLE = 116;
    public static final int BREWING_STAND_BLOCK = 117;
    public static final int BREWING_BLOCK = 117;
    public static final int CAULDRON_BLOCK = 118;
    public static final int END_PORTAL = 119;
    public static final int END_PORTAL_FRAME = 120;
    public static final int END_STONE = 121;
    public static final int REDSTONE_LAMP = 123;
    public static final int LIT_REDSTONE_LAMP = 124;
    public static final int ACTIVATOR_RAIL = 126;
    public static final int SANDSTONE_STAIRS = 128;
    public static final int EMERALD_ORE = 129;
    public static final int EMERALD_BLOCK = 133;
    public static final int SPRUCE_WOOD_STAIRS = 134;
    public static final int SPRUCE_WOODEN_STAIRS = 134;
    public static final int BIRCH_WOOD_STAIRS = 135;
    public static final int BIRCH_WOODEN_STAIRS = 135;
    public static final int JUNGLE_WOOD_STAIRS = 136;
    public static final int JUNGLE_WOODEN_STAIRS = 136;
    public static final int COBBLE_WALL = 139;
    public static final int STONE_WALL = 139;
    public static final int COBBLESTONE_WALL = 139;
    public static final int FLOWER_POT_BLOCK = 140;
    public static final int CARROT_BLOCK = 141;
    public static final int POTATO_BLOCK = 142;
    public static final int SKULL_BLOCK = 144;
    public static final int ANVIL = 145;
    public static final int TRAPPED_CHEST = 146;
    public static final int LIGHT_WEIGHTED_PRESSURE_PLATE = 147;
    public static final int HEAVY_WEIGHTED_PRESSURE_PLATE = 148;
    public static final int UNPOWERED_COMPARATOR = 149;
    public static final int POWERED_COMPARATOR = 150;
    public static final int DAYLIGHT_DETECTOR = 151;
    public static final int REDSTONE_BLOCK = 152;
    public static final int QUARTZ_ORE = 153;
    public static final int HOPPER_BLOCK = 154;
    public static final int QUARTZ_BLOCK = 155;
    public static final int QUARTZ_STAIRS = 156;
    public static final int DOUBLE_WOOD_SLAB = 157;
    public static final int DOUBLE_WOODEN_SLAB = 157;
    public static final int DOUBLE_WOOD_SLABS = 157;
    public static final int DOUBLE_WOODEN_SLABS = 157;
    public static final int WOOD_SLAB = 158;
    public static final int WOODEN_SLAB = 158;
    public static final int WOOD_SLABS = 158;
    public static final int WOODEN_SLABS = 158;
    public static final int STAINED_CLAY = 159;
    public static final int STAINED_HARDENED_CLAY = 159;
    public static final int LEAVES2 = 161;
    public static final int LEAVE2 = 161;
    public static final int WOOD2 = 162;
    public static final int TRUNK2 = 162;
    public static final int LOG2 = 162;
    public static final int ACACIA_WOOD_STAIRS = 163;
    public static final int ACACIA_WOODEN_STAIRS = 163;
    public static final int DARK_OAK_WOOD_STAIRS = 164;
    public static final int DARK_OAK_WOODEN_STAIRS = 164;
    public static final int SLIME_BLOCK = 165;
    public static final int IRON_TRAPDOOR = 167;
    public static final int HAY_BALE = 170;
    public static final int CARPET = 171;
    public static final int HARDENED_CLAY = 172;
    public static final int COAL_BLOCK = 173;
    public static final int PACKED_ICE = 174;
    public static final int DOUBLE_PLANT = 175;
    public static final int DAYLIGHT_DETECTOR_INVERTED = 178;
    public static final int FENCE_GATE_SPRUCE = 183;
    public static final int FENCE_GATE_BIRCH = 184;
    public static final int FENCE_GATE_JUNGLE = 185;
    public static final int FENCE_GATE_DARK_OAK = 186;
    public static final int FENCE_GATE_ACACIA = 187;
    public static final int SPRUCE_DOOR_BLOCK = 193;
    public static final int BIRCH_DOOR_BLOCK = 194;
    public static final int JUNGLE_DOOR_BLOCK = 195;
    public static final int ACACIA_DOOR_BLOCK = 196;
    public static final int DARK_OAK_DOOR_BLOCK = 197;
    public static final int GRASS_PATH = 198;
    public static final int PODZOL = 243;
    public static final int BEETROOT_BLOCK = 244;
    public static final int STONECUTTER = 245;
    public static final int GLOWING_OBSIDIAN = 246;
    public static Class[] list = null;
    public static Block[] fullList = null;
    public static int[] light = null;
    public static int[] lightFilter = null;
    public static boolean[] solid = null;
    public static double[] hardness = null;
    public static boolean[] transparent = null;
    public AxisAlignedBB boundingBox = null;
    protected int meta = 0;
    protected int powerLevel = 0;
    protected boolean powerSource = false;

    protected Block(Integer meta) {
        this.meta = meta != null ? meta : 0;
    }

    public static void init() {
        if (list == null) {
            list = new Class[256];
            fullList = new Block[4096];
            light = new int[256];
            lightFilter = new int[256];
            solid = new boolean[256];
            hardness = new double[256];
            transparent = new boolean[256];
            Block.list[0] = BlockAir.class;
            Block.list[1] = BlockStone.class;
            Block.list[2] = BlockGrass.class;
            Block.list[3] = BlockDirt.class;
            Block.list[4] = BlockCobblestone.class;
            Block.list[5] = BlockPlanks.class;
            Block.list[6] = BlockSapling.class;
            Block.list[7] = BlockBedrock.class;
            Block.list[8] = BlockWater.class;
            Block.list[9] = BlockWaterStill.class;
            Block.list[10] = BlockLava.class;
            Block.list[11] = BlockLavaStill.class;
            Block.list[12] = BlockSand.class;
            Block.list[13] = BlockGravel.class;
            Block.list[14] = BlockOreGold.class;
            Block.list[15] = BlockOreIron.class;
            Block.list[16] = BlockOreCoal.class;
            Block.list[17] = BlockWood.class;
            Block.list[18] = BlockLeaves.class;
            Block.list[19] = BlockSponge.class;
            Block.list[20] = BlockGlass.class;
            Block.list[21] = BlockOreLapis.class;
            Block.list[22] = BlockLapis.class;
            Block.list[24] = BlockSandstone.class;
            Block.list[25] = BlockNoteblock.class;
            Block.list[26] = BlockBed.class;
            Block.list[30] = BlockCobweb.class;
            Block.list[31] = BlockTallGrass.class;
            Block.list[32] = BlockDeadBush.class;
            Block.list[35] = BlockWool.class;
            Block.list[37] = BlockDandelion.class;
            Block.list[38] = BlockFlower.class;
            Block.list[39] = BlockMushroomBrown.class;
            Block.list[40] = BlockMushroomRed.class;
            Block.list[41] = BlockGold.class;
            Block.list[42] = BlockIron.class;
            Block.list[43] = BlockDoubleSlab.class;
            Block.list[44] = BlockSlab.class;
            Block.list[45] = BlockBricks.class;
            Block.list[46] = BlockTNT.class;
            Block.list[47] = BlockBookshelf.class;
            Block.list[48] = BlockMossStone.class;
            Block.list[49] = BlockObsidian.class;
            Block.list[50] = BlockTorch.class;
            Block.list[51] = BlockFire.class;
            Block.list[52] = BlockMobSpawner.class;
            Block.list[53] = BlockStairsWood.class;
            Block.list[54] = BlockChest.class;
            Block.list[55] = BlockRedstoneWire.class;
            Block.list[56] = BlockOreDiamond.class;
            Block.list[57] = BlockDiamond.class;
            Block.list[58] = BlockWorkbench.class;
            Block.list[59] = BlockWheat.class;
            Block.list[60] = BlockFarmland.class;
            Block.list[61] = BlockFurnace.class;
            Block.list[62] = BlockFurnaceBurning.class;
            Block.list[63] = BlockSignPost.class;
            Block.list[64] = BlockDoorWood.class;
            Block.list[65] = BlockLadder.class;
            Block.list[67] = BlockStairsCobblestone.class;
            Block.list[68] = BlockWallSign.class;
            Block.list[71] = BlockDoorIron.class;
            Block.list[73] = BlockOreRedstone.class;
            Block.list[74] = BlockOreRedstoneGlowing.class;
            Block.list[76] = BlockRedstoneTorch.class;
            Block.list[78] = BlockSnowLayer.class;
            Block.list[79] = BlockIce.class;
            Block.list[80] = BlockSnow.class;
            Block.list[81] = BlockCactus.class;
            Block.list[82] = BlockClay.class;
            Block.list[83] = BlockSugarcane.class;
            Block.list[85] = BlockFence.class;
            Block.list[86] = BlockPumpkin.class;
            Block.list[87] = BlockNetherrack.class;
            Block.list[88] = BlockSoulSand.class;
            Block.list[89] = BlockGlowstone.class;
            Block.list[90] = BlockNetherPortal.class;
            Block.list[91] = BlockPumpkinLit.class;
            Block.list[92] = BlockCake.class;
            Block.list[95] = BlockBedrockInvisible.class;
            Block.list[96] = BlockTrapdoor.class;
            Block.list[98] = BlockBricksStone.class;
            Block.list[100] = BlockHugeMushroomRed.class;
            Block.list[99] = BlockHugeMushroomBrown.class;
            Block.list[101] = BlockIronBars.class;
            Block.list[102] = BlockGlassPane.class;
            Block.list[103] = BlockMelon.class;
            Block.list[124] = BlockLitRedstoneLamp.class;
            Block.list[104] = BlockStemPumpkin.class;
            Block.list[105] = BlockStemMelon.class;
            Block.list[106] = BlockVine.class;
            Block.list[107] = BlockFenceGate.class;
            Block.list[108] = BlockStairsBrick.class;
            Block.list[109] = BlockStairsStoneBrick.class;
            Block.list[110] = BlockMycelium.class;
            Block.list[111] = BlockWaterLily.class;
            Block.list[112] = BlockNetherBrick.class;
            Block.list[113] = BlockFenceNetherBrick.class;
            Block.list[114] = BlockStairsNetherBrick.class;
            Block.list[116] = BlockEnchantingTable.class;
            Block.list[120] = BlockEndPortalFrame.class;
            Block.list[121] = BlockEndStone.class;
            Block.list[128] = BlockStairsSandstone.class;
            Block.list[129] = BlockOreEmerald.class;
            Block.list[133] = BlockEmerald.class;
            Block.list[134] = BlockStairsSpruce.class;
            Block.list[135] = BlockStairsBirch.class;
            Block.list[136] = BlockStairsJungle.class;
            Block.list[139] = BlockWall.class;
            Block.list[141] = BlockCarrot.class;
            Block.list[142] = BlockPotato.class;
            Block.list[145] = BlockAnvil.class;
            Block.list[152] = BlockRedstone.class;
            Block.list[153] = BlockOreQuartz.class;
            Block.list[155] = BlockQuartz.class;
            Block.list[156] = BlockStairsQuartz.class;
            Block.list[157] = BlockDoubleSlabWood.class;
            Block.list[158] = BlockSlabWood.class;
            Block.list[159] = BlockClayStained.class;
            Block.list[161] = BlockLeaves2.class;
            Block.list[162] = BlockWood2.class;
            Block.list[163] = BlockStairsAcacia.class;
            Block.list[164] = BlockStairsDarkOak.class;
            Block.list[165] = BlockSlime.class;
            Block.list[167] = BlockTrapdoorIron.class;
            Block.list[170] = BlockHayBale.class;
            Block.list[171] = BlockCarpet.class;
            Block.list[172] = BlockClayHardened.class;
            Block.list[173] = BlockCoal.class;
            Block.list[174] = BlockPackedIce.class;
            Block.list[175] = BlockDoublePlant.class;
            Block.list[183] = BlockFenceGateSpruce.class;
            Block.list[184] = BlockFenceGateBirch.class;
            Block.list[185] = BlockFenceGateJungle.class;
            Block.list[186] = BlockFenceGateDarkOak.class;
            Block.list[187] = BlockFenceGateAcacia.class;
            Block.list[198] = BlockGrassPath.class;
            Block.list[243] = BlockPodzol.class;
            Block.list[244] = BlockBeetroot.class;
            Block.list[245] = BlockStonecutter.class;
            Block.list[246] = BlockObsidianGlowing.class;
            Block.list[117] = BlockBrewingStand.class;
            Block.list[196] = BlockDoorAcacia.class;
            Block.list[193] = BlockDoorSpruce.class;
            Block.list[197] = BlockDoorDarkOak.class;
            Block.list[194] = BlockDoorBirch.class;
            Block.list[195] = BlockDoorJungle.class;
            Block.list[151] = BlockDaylightDetector.class;
            Block.list[178] = BlockDaylightDetectorInverted.class;
            Block.list[66] = BlockRail.class;
            Block.list[126] = BlockRailActivator.class;
            Block.list[28] = BlockRailDetector.class;
            Block.list[27] = BlockRailPowered.class;
            Block.list[140] = BlockFlowerPot.class;
            Block.list[69] = BlockLever.class;
            Block.list[148] = BlockWeightedPressurePlateHeavy.class;
            Block.list[147] = BlockWeightedPressurePlateLight.class;
            Block.list[123] = BlockRedstoneLamp.class;
            Block.list[70] = BlockPressurePlateStone.class;
            Block.list[72] = BlockPressurePlateWood.class;
            Block.list[144] = BlockSkull.class;
            for (int id = 0; id < 256; ++id) {
                Class c = list[id];
                if (c != null) {
                    Block block;
                    try {
                        block = (Block)c.newInstance();
                        Constructor constructor = c.getDeclaredConstructor(Integer.TYPE);
                        constructor.setAccessible(true);
                        for (int data = 0; data < 16; ++data) {
                            Block.fullList[id << 4 | data] = (Block)constructor.newInstance(data);
                        }
                    }
                    catch (Exception e) {
                        Server.getInstance().getLogger().error("Error while registering " + c.getName(), e);
                        return;
                    }
                    Block.solid[id] = block.isSolid();
                    Block.transparent[id] = block.isTransparent();
                    Block.hardness[id] = block.getHardness();
                    Block.light[id] = block.getLightLevel();
                    if (block.isSolid()) {
                        if (block.isTransparent()) {
                            if (block instanceof BlockLiquid || block instanceof BlockIce) {
                                Block.lightFilter[id] = 2;
                                continue;
                            }
                            Block.lightFilter[id] = 1;
                            continue;
                        }
                        Block.lightFilter[id] = 15;
                        continue;
                    }
                    Block.lightFilter[id] = 1;
                    continue;
                }
                Block.lightFilter[id] = 1;
                for (int data = 0; data < 16; ++data) {
                    Block.fullList[id << 4 | data] = new BlockUnknown(id, (Integer)data);
                }
            }
        }
    }

    public static Block get(int id) {
        return Block.get(id, 0);
    }

    public static Block get(int id, Integer meta) {
        return Block.get(id, meta, null);
    }

    public static Block get(int id, Integer meta, Position pos) {
        Block block;
        try {
            Class c = list[id];
            if (c != null) {
                Constructor constructor = c.getDeclaredConstructor(Integer.TYPE);
                constructor.setAccessible(true);
                block = (Block)constructor.newInstance(meta);
            } else {
                block = new BlockUnknown(id, meta);
            }
        }
        catch (Exception e) {
            block = new BlockUnknown(id, meta);
        }
        if (pos != null) {
            block.x = pos.x;
            block.y = pos.y;
            block.z = pos.z;
            block.level = pos.level;
        }
        return block;
    }

    public boolean place(Item item, Block block, Block target, int face, double fx, double fy, double fz) {
        return this.place(item, block, target, face, fx, fy, fz, null);
    }

    public boolean place(Item item, Block block, Block target, int face, double fx, double fy, double fz, Player player) {
        return this.getLevel().setBlock(this, this, true, true);
    }

    public boolean isBreakable(Item item) {
        return true;
    }

    public int tickRate() {
        return 10;
    }

    public boolean onBreak(Item item) {
        return this.getLevel().setBlock(this, new BlockAir(), true, true);
    }

    public int onUpdate(int type) {
        return 0;
    }

    public boolean onActivate(Item item) {
        return this.onActivate(item, null);
    }

    public boolean onActivate(Item item, Player player) {
        return false;
    }

    public double getHardness() {
        return 10.0;
    }

    public double getResistance() {
        return 1.0;
    }

    public int getBurnChance() {
        return 0;
    }

    public int getBurnAbility() {
        return 0;
    }

    public int getToolType() {
        return 0;
    }

    public double getFrictionFactor() {
        return 0.6;
    }

    public int getLightLevel() {
        return 0;
    }

    public boolean canBePlaced() {
        return true;
    }

    public boolean canBeReplaced() {
        return false;
    }

    public boolean isTransparent() {
        return false;
    }

    public boolean isSolid() {
        return true;
    }

    public boolean canBeFlowedInto() {
        return false;
    }

    public boolean canBeActivated() {
        return false;
    }

    public boolean hasEntityCollision() {
        return false;
    }

    public boolean canPassThrough() {
        return false;
    }

    public BlockColor getColor() {
        return BlockColor.VOID_BLOCK_COLOR;
    }

    public abstract String getName();

    public abstract int getId();

    public void addVelocityToEntity(Entity entity, Vector3 vector) {
    }

    public final int getDamage() {
        return this.meta;
    }

    public final void setDamage(Integer meta) {
        this.meta = meta == null ? 0 : meta & 0xF;
    }

    public final void position(Position v) {
        this.x = (int)v.x;
        this.y = (int)v.y;
        this.z = (int)v.z;
        this.level = v.level;
        this.boundingBox = null;
    }

    public int[][] getDrops(Item item) {
        if (this.getId() < 0 || this.getId() > list.length) {
            return new int[0][0];
        }
        return new int[][]{{this.getId(), this.getDamage(), 1}};
    }

    public double getBreakTime(Item item) {
        double base = this.getHardness() * 1.5;
        if (this.canBeBrokenWith(item)) {
            if (this.getToolType() == 5 && item.isShears()) {
                base /= 15.0;
            } else if (this.getToolType() == 3 && item.isPickaxe() || this.getToolType() == 4 && item.isAxe() || this.getToolType() == 2 && item.isShovel()) {
                int tier = item.getTier();
                switch (tier) {
                    case 1: {
                        base /= 2.0;
                        break;
                    }
                    case 3: {
                        base /= 4.0;
                        break;
                    }
                    case 4: {
                        base /= 6.0;
                        break;
                    }
                    case 5: {
                        base /= 8.0;
                        break;
                    }
                    case 2: {
                        base /= 12.0;
                    }
                }
            }
        } else {
            base *= 3.33;
        }
        if (item.isSword()) {
            base *= 0.5;
        }
        return base;
    }

    public boolean canBeBrokenWith(Item item) {
        return this.getHardness() != -1.0;
    }

    @Override
    public Block getSide(int side) {
        return this.getSide(side, 1);
    }

    @Override
    public Block getSide(int side, int step) {
        if (this.isValid()) {
            return this.getLevel().getBlock(super.getSide(side, step));
        }
        return Block.get(0, 0, Position.fromObject(new Vector3(this.x, this.y, this.z).getSide(side, step)));
    }

    @Override
    public String toString() {
        return "Block[" + this.getName() + "] (" + this.getId() + ":" + this.getDamage() + ")";
    }

    public boolean collidesWithBB(AxisAlignedBB bb) {
        AxisAlignedBB bb1 = this.getBoundingBox();
        return bb1 != null && bb.intersectsWith(bb1);
    }

    public void onEntityCollide(Entity entity) {
    }

    public AxisAlignedBB getBoundingBox() {
        if (this.boundingBox == null) {
            this.boundingBox = this.recalculateBoundingBox();
        }
        return this.boundingBox;
    }

    protected AxisAlignedBB recalculateBoundingBox() {
        return new AxisAlignedBB(this.x, this.y, this.z, this.x + 1.0, this.y + 1.0, this.z + 1.0);
    }

    public MovingObjectPosition calculateIntercept(Vector3 pos1, Vector3 pos2) {
        AxisAlignedBB bb = this.getBoundingBox();
        if (bb == null) {
            return null;
        }
        Vector3 v1 = pos1.getIntermediateWithXValue(pos2, bb.minX);
        Vector3 v2 = pos1.getIntermediateWithXValue(pos2, bb.maxX);
        Vector3 v3 = pos1.getIntermediateWithYValue(pos2, bb.minY);
        Vector3 v4 = pos1.getIntermediateWithYValue(pos2, bb.maxY);
        Vector3 v5 = pos1.getIntermediateWithZValue(pos2, bb.minZ);
        Vector3 v6 = pos1.getIntermediateWithZValue(pos2, bb.maxZ);
        if (v1 != null && !bb.isVectorInYZ(v1)) {
            v1 = null;
        }
        if (v2 != null && !bb.isVectorInYZ(v2)) {
            v2 = null;
        }
        if (v3 != null && !bb.isVectorInXZ(v3)) {
            v3 = null;
        }
        if (v4 != null && !bb.isVectorInXZ(v4)) {
            v4 = null;
        }
        if (v5 != null && !bb.isVectorInXY(v5)) {
            v5 = null;
        }
        if (v6 != null && !bb.isVectorInXY(v6)) {
            v6 = null;
        }
        Vector3 vector = v1;
        if (v2 != null && (vector == null || pos1.distanceSquared(v2) < pos1.distanceSquared(vector))) {
            vector = v2;
        }
        if (v3 != null && (vector == null || pos1.distanceSquared(v3) < pos1.distanceSquared(vector))) {
            vector = v3;
        }
        if (v4 != null && (vector == null || pos1.distanceSquared(v4) < pos1.distanceSquared(vector))) {
            vector = v4;
        }
        if (v5 != null && (vector == null || pos1.distanceSquared(v5) < pos1.distanceSquared(vector))) {
            vector = v5;
        }
        if (v6 != null && (vector == null || pos1.distanceSquared(v6) < pos1.distanceSquared(vector))) {
            vector = v6;
        }
        if (vector == null) {
            return null;
        }
        int f = -1;
        if (vector == v1) {
            f = 4;
        } else if (vector == v2) {
            f = 5;
        } else if (vector == v3) {
            f = 0;
        } else if (vector == v4) {
            f = 1;
        } else if (vector == v5) {
            f = 2;
        } else if (vector == v6) {
            f = 3;
        }
        return MovingObjectPosition.fromBlock((int)this.x, (int)this.y, (int)this.z, f, vector.add(this.x, this.y, this.z));
    }

    @Override
    public void setMetadata(String metadataKey, MetadataValue newMetadataValue) throws Exception {
        if (this.getLevel() != null) {
            this.getLevel().getBlockMetadata().setMetadata(this, metadataKey, newMetadataValue);
        }
    }

    @Override
    public List<MetadataValue> getMetadata(String metadataKey) throws Exception {
        if (this.getLevel() != null) {
            return this.getLevel().getBlockMetadata().getMetadata(this, metadataKey);
        }
        return null;
    }

    @Override
    public boolean hasMetadata(String metadataKey) throws Exception {
        return this.getLevel() != null && this.getLevel().getBlockMetadata().hasMetadata(this, metadataKey);
    }

    @Override
    public void removeMetadata(String metadataKey, Plugin owningPlugin) throws Exception {
        if (this.getLevel() != null) {
            this.getLevel().getBlockMetadata().removeMetadata(this, metadataKey, owningPlugin);
        }
    }

    @Override
    public Block clone() {
        return (Block)super.clone();
    }

    public int getPowerLevel() {
        return this.powerLevel;
    }

    public void setPowerLevel(int powerLevel) {
        this.powerLevel = powerLevel;
    }

    public int getPowerLevel(int side) {
        return this.getSide(side).getPowerLevel();
    }

    public boolean isNeighborPowered() {
        return this.getNeighborPowerLevel() > 0;
    }

    public int getNeighborPowerLevel() {
        int energy = 0;
        int tempLevel = this.getSide(0).getPowerLevel();
        energy = tempLevel > energy ? tempLevel : energy;
        tempLevel = this.getSide(1).getPowerLevel();
        energy = tempLevel > energy ? tempLevel : energy;
        for (int side : new int[]{2, 3, 4, 5}) {
            tempLevel = this.getSide(side).getPowerLevel();
            energy = tempLevel > energy ? tempLevel : energy;
        }
        return energy;
    }

    public boolean isPowered() {
        return this.powerLevel > 0;
    }

    public boolean isPowerSource() {
        return this.powerSource;
    }

    public void setPowerSource(boolean isSource) {
        this.powerSource = isSource;
    }

    public String getLocationHash() {
        String str = "";
        str = String.valueOf((int)this.x);
        str = str + ":";
        str = str + String.valueOf((int)this.y);
        str = str + ":";
        str = str + String.valueOf((int)this.z);
        return str;
    }

    public int getDropExp() {
        return 0;
    }
}

