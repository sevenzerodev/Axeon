/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.block.Block;
import cn.axeon.block.BlockSolid;
import cn.axeon.item.Item;
import cn.axeon.utils.BlockColor;

public class BlockObsidian
extends BlockSolid {
    public BlockObsidian() {
        this(0);
    }

    public BlockObsidian(int meta) {
        super(0);
    }

    @Override
    public String getName() {
        return "Obsidian";
    }

    @Override
    public int getId() {
        return 49;
    }

    @Override
    public int getToolType() {
        return 3;
    }

    @Override
    public double getHardness() {
        return 50.0;
    }

    @Override
    public double getResistance() {
        return 2000.0;
    }

    @Override
    public int[][] getDrops(Item item) {
        if (item.isPickaxe() && item.getTier() >= 5) {
            return new int[][]{{49, 0, 1}};
        }
        return new int[0][];
    }

    @Override
    public boolean onBreak(Item item) {
        Block[] nearby;
        for (Block aNearby : nearby = new Block[]{this.getSide(1), this.getSide(0), this.getSide(2), this.getSide(3), this.getSide(4), this.getSide(5)}) {
            if (aNearby == null || aNearby.getId() != 90) continue;
            aNearby.onBreak(item);
        }
        return super.onBreak(item);
    }

    @Override
    public BlockColor getColor() {
        return BlockColor.OBSIDIAN_BLOCK_COLOR;
    }
}

