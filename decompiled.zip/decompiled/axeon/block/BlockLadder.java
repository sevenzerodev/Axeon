/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.Player;
import cn.axeon.block.Block;
import cn.axeon.block.BlockTransparent;
import cn.axeon.entity.Entity;
import cn.axeon.item.Item;
import cn.axeon.math.AxisAlignedBB;
import cn.axeon.utils.BlockColor;

public class BlockLadder
extends BlockTransparent {
    public BlockLadder() {
        this(0);
    }

    public BlockLadder(int meta) {
        super(meta);
    }

    @Override
    public String getName() {
        return "Ladder";
    }

    @Override
    public int getId() {
        return 65;
    }

    @Override
    public boolean hasEntityCollision() {
        return true;
    }

    @Override
    public boolean isSolid() {
        return false;
    }

    @Override
    public double getHardness() {
        return 0.4;
    }

    @Override
    public double getResistance() {
        return 2.0;
    }

    @Override
    public void onEntityCollide(Entity entity) {
        entity.resetFallDistance();
        entity.onGround = true;
    }

    @Override
    protected AxisAlignedBB recalculateBoundingBox() {
        double f = 0.125;
        if (this.meta == 2) {
            return new AxisAlignedBB(this.x, this.y, this.z + 1.0 - f, this.x + 1.0, this.y + 1.0, this.z + 1.0);
        }
        if (this.meta == 3) {
            return new AxisAlignedBB(this.x, this.y, this.z, this.x + 1.0, this.y + 1.0, this.z + f);
        }
        if (this.meta == 4) {
            return new AxisAlignedBB(this.x + 1.0 - f, this.y, this.z, this.x + 1.0, this.y + 1.0, this.z + 1.0);
        }
        if (this.meta == 5) {
            return new AxisAlignedBB(this.x, this.y, this.z, this.x + f, this.y + 1.0, this.z + 1.0);
        }
        return null;
    }

    @Override
    public boolean place(Item item, Block block, Block target, int face, double fx, double fy, double fz, Player player) {
        if (!target.isTransparent() && face >= 2 && face <= 5) {
            this.meta = face;
            this.getLevel().setBlock(block, this, true, true);
            return true;
        }
        return false;
    }

    @Override
    public int onUpdate(int type) {
        int[] faces;
        if (type == 1 && this.getSide((faces = new int[]{0, 1, 3, 2, 5, 4})[this.meta]).isTransparent()) {
            this.getLevel().useBreakOn(this);
        }
        return 0;
    }

    @Override
    public int getToolType() {
        return 4;
    }

    @Override
    public int[][] getDrops(Item item) {
        return new int[][]{{this.getId(), 0, 1}};
    }

    @Override
    public BlockColor getColor() {
        return BlockColor.AIR_BLOCK_COLOR;
    }
}

