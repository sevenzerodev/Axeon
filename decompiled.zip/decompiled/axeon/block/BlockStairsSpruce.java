/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.block.BlockStairsWood;

public class BlockStairsSpruce
extends BlockStairsWood {
    public BlockStairsSpruce() {
        this(0);
    }

    public BlockStairsSpruce(int meta) {
        super(meta);
    }

    @Override
    public int getId() {
        return 134;
    }

    @Override
    public String getName() {
        return "Spruce Wood Stairs";
    }
}

