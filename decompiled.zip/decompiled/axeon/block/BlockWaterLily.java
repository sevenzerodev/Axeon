/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.Player;
import cn.axeon.block.Block;
import cn.axeon.block.BlockFlowable;
import cn.axeon.block.BlockWater;
import cn.axeon.item.Item;
import cn.axeon.math.AxisAlignedBB;
import cn.axeon.utils.BlockColor;

public class BlockWaterLily
extends BlockFlowable {
    public BlockWaterLily() {
        this(0);
    }

    public BlockWaterLily(int meta) {
        super(meta);
    }

    @Override
    public boolean isSolid() {
        return false;
    }

    @Override
    public String getName() {
        return "Lily Pad";
    }

    @Override
    public int getId() {
        return 111;
    }

    @Override
    public boolean canPassThrough() {
        return true;
    }

    @Override
    protected AxisAlignedBB recalculateBoundingBox() {
        return new AxisAlignedBB(this.x, this.y, this.z, this.x, this.y + 0.0625, this.z);
    }

    @Override
    public boolean place(Item item, Block block, Block target, int face, double fx, double fy, double fz, Player player) {
        Block up;
        if (target instanceof BlockWater && (up = target.getSide(1)).getId() == 0) {
            this.getLevel().setBlock(up, this, true, true);
            return true;
        }
        return false;
    }

    @Override
    public int onUpdate(int type) {
        if (type == 1 && !(this.getSide(0) instanceof BlockWater)) {
            this.getLevel().useBreakOn(this);
            return 1;
        }
        return 0;
    }

    @Override
    public int[][] getDrops(Item item) {
        return new int[][]{{this.getId(), 0, 1}};
    }

    @Override
    public BlockColor getColor() {
        return BlockColor.FOLIAGE_BLOCK_COLOR;
    }
}

