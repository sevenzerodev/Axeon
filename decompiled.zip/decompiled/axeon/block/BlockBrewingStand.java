/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.Player;
import cn.axeon.block.Block;
import cn.axeon.block.BlockAir;
import cn.axeon.block.BlockSolid;
import cn.axeon.blockentity.BlockEntity;
import cn.axeon.blockentity.BlockEntityBrewingStand;
import cn.axeon.item.Item;
import cn.axeon.nbt.tag.CompoundTag;
import cn.axeon.nbt.tag.ListTag;
import cn.axeon.nbt.tag.StringTag;
import cn.axeon.nbt.tag.Tag;
import cn.axeon.utils.BlockColor;
import java.util.Map;

public class BlockBrewingStand
extends BlockSolid {
    protected int id = 117;

    public BlockBrewingStand() {
        this(0);
    }

    public BlockBrewingStand(int meta) {
        super(meta);
    }

    @Override
    public String getName() {
        return "Brewing Stand";
    }

    @Override
    public boolean canBeActivated() {
        return true;
    }

    @Override
    public double getHardness() {
        return 0.5;
    }

    @Override
    public double getResistance() {
        return 2.5;
    }

    @Override
    public int getToolType() {
        return 3;
    }

    @Override
    public int getLightLevel() {
        return 1;
    }

    @Override
    public boolean place(Item item, Block block, Block target, int face, double fx, double fy, double fz, Player player) {
        int[] faces = new int[]{4, 2, 5, 3};
        this.meta = faces[player != null ? player.getDirection() : 0];
        this.getLevel().setBlock(block, this, true, true);
        CompoundTag nbt = new CompoundTag().putList(new ListTag("Items")).putString("id", "BrewingStand").putInt("x", (int)this.x).putInt("y", (int)this.y).putInt("z", (int)this.z);
        if (item.hasCustomName()) {
            nbt.putString("CustomName", item.getCustomName());
        }
        if (item.hasCustomBlockData()) {
            Map<String, Tag> customData = item.getCustomBlockData().getTags();
            for (Map.Entry<String, Tag> tag : customData.entrySet()) {
                nbt.put(tag.getKey(), tag.getValue());
            }
        }
        new BlockEntityBrewingStand(this.getLevel().getChunk((int)this.x >> 4, (int)this.z >> 4), nbt);
        return true;
    }

    @Override
    public boolean onBreak(Item item) {
        this.getLevel().setBlock(this, new BlockAir(), true, true);
        return true;
    }

    @Override
    public int getId() {
        return 117;
    }

    @Override
    public boolean onActivate(Item item, Player player) {
        if (player != null) {
            BlockEntity t = this.getLevel().getBlockEntity(this);
            BlockEntityBrewingStand brewing = null;
            if (t instanceof BlockEntityBrewingStand) {
                brewing = (BlockEntityBrewingStand)t;
            } else {
                CompoundTag nbt = new CompoundTag().putList(new ListTag("Items")).putString("id", "BrewingStand").putInt("x", (int)this.x).putInt("y", (int)this.y).putInt("z", (int)this.z);
                brewing = new BlockEntityBrewingStand(this.getLevel().getChunk((int)this.x >> 4, (int)this.z >> 4), nbt);
            }
            if (brewing.namedTag.contains("Lock") && brewing.namedTag.get("Lock") instanceof StringTag && !brewing.namedTag.getString("Lock").equals(item.getCustomName())) {
                return false;
            }
            player.addWindow(brewing.getInventory());
        }
        return true;
    }

    @Override
    public int[][] getDrops(Item item) {
        if (item.isPickaxe() && item.getTier() >= 1) {
            return new int[][]{{379, 0, 1}};
        }
        return new int[0][];
    }

    @Override
    public BlockColor getColor() {
        return BlockColor.IRON_BLOCK_COLOR;
    }
}

