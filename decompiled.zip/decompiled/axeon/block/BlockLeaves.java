/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.Player;
import cn.axeon.block.Block;
import cn.axeon.block.BlockTransparent;
import cn.axeon.item.Item;
import cn.axeon.utils.BlockColor;

public class BlockLeaves
extends BlockTransparent {
    public static final int OAK = 0;
    public static final int SPRUCE = 1;
    public static final int BRICH = 2;
    public static final int JUNGLE = 3;
    public static final int ACACIA = 4;
    public static final int DARK_OAK = 5;

    public BlockLeaves() {
        this(0);
    }

    public BlockLeaves(int meta) {
        super(meta);
    }

    @Override
    public int getId() {
        return 18;
    }

    @Override
    public double getHardness() {
        return 0.2;
    }

    @Override
    public int getToolType() {
        return 5;
    }

    @Override
    public String getName() {
        String[] names = new String[]{"Oak Leaves", "Spruce Leaves", "Birch Leaves", "Jungle Leaves"};
        return names[this.meta & 3];
    }

    @Override
    public int getBurnChance() {
        return 30;
    }

    @Override
    public int getBurnAbility() {
        return 60;
    }

    @Override
    public boolean place(Item item, Block block, Block target, int face, double fx, double fy, double fz, Player player) {
        this.meta |= 4;
        this.getLevel().setBlock(this, this, true);
        return true;
    }

    @Override
    public int[][] getDrops(Item item) {
        if (item.isShears()) {
            return new int[][]{{18, this.meta & 3, 1}};
        }
        if ((int)(Math.random() * 200.0) == 0 && (this.meta & 3) == 0) {
            return new int[][]{{260, 0, 1}};
        }
        if ((int)(Math.random() * 20.0) == 0) {
            return new int[][]{{6, this.meta & 3, 1}};
        }
        return new int[0][];
    }

    @Override
    public BlockColor getColor() {
        return BlockColor.FOLIAGE_BLOCK_COLOR;
    }
}

