/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.block.BlockLitRedstoneLamp;
import cn.axeon.block.BlockSolid;
import cn.axeon.item.Item;
import cn.axeon.redstone.Redstone;

public class BlockRedstoneLamp
extends BlockSolid {
    public BlockRedstoneLamp(int meta) {
        super(meta);
    }

    public BlockRedstoneLamp() {
        this(0);
    }

    @Override
    public String getName() {
        return "Redstone Lamp";
    }

    @Override
    public int getId() {
        return 123;
    }

    @Override
    public double getHardness() {
        return 0.3;
    }

    @Override
    public double getResistance() {
        return 1.5;
    }

    @Override
    public int getToolType() {
        return 3;
    }

    @Override
    public int onUpdate(int type) {
        if ((type == 1 || type == 3) && this.getNeighborPowerLevel() > 0) {
            int level = this.getPowerLevel();
            Redstone.deactive(this, level);
            this.getLevel().setBlock(this, new BlockLitRedstoneLamp());
        }
        return 0;
    }

    @Override
    public int[][] getDrops(Item item) {
        return new int[][]{{123, 0, 1}};
    }
}

