/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.block.BlockLeaves;
import cn.axeon.item.Item;

public class BlockLeaves2
extends BlockLeaves {
    public BlockLeaves2() {
        this(0);
    }

    public BlockLeaves2(int meta) {
        super(meta);
    }

    @Override
    public String getName() {
        String[] names = new String[]{"Oak Leaves", "Spruce Leaves", "Birch Leaves", "Jungle Leaves"};
        return names[this.meta & 1];
    }

    @Override
    public int getId() {
        return 161;
    }

    @Override
    public int[][] getDrops(Item item) {
        if (item.isShears()) {
            return new int[][]{{161, this.meta & 3, 1}};
        }
        if ((int)(Math.random() * 20.0) == 0) {
            return new int[][]{{6, this.meta & 3, 1}};
        }
        return new int[0][];
    }
}

