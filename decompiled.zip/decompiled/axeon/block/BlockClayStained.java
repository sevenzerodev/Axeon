/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.block.BlockSolid;
import cn.axeon.item.ItemDye;
import cn.axeon.utils.BlockColor;

public class BlockClayStained
extends BlockSolid {
    public BlockClayStained() {
        this(0);
    }

    public BlockClayStained(int meta) {
        super(meta);
    }

    @Override
    public String getName() {
        return ItemDye.getColorName(this.meta) + " Stained Clay";
    }

    @Override
    public int getId() {
        return 159;
    }

    @Override
    public double getHardness() {
        return 1.25;
    }

    @Override
    public double getResistance() {
        return 0.75;
    }

    @Override
    public int getToolType() {
        return 3;
    }

    @Override
    public BlockColor getColor() {
        return BlockColor.getDyeColor(this.meta);
    }
}

