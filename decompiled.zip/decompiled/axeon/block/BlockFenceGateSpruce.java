/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.block.BlockFenceGate;

public class BlockFenceGateSpruce
extends BlockFenceGate {
    public BlockFenceGateSpruce() {
        this(0);
    }

    public BlockFenceGateSpruce(int meta) {
        super(meta);
    }

    @Override
    public int getId() {
        return 183;
    }

    @Override
    public String getName() {
        return "Spruce Fence Gate";
    }
}

