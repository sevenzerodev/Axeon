/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.block.BlockStairsWood;

public class BlockStairsAcacia
extends BlockStairsWood {
    public BlockStairsAcacia() {
        this(0);
    }

    public BlockStairsAcacia(int meta) {
        super(meta);
    }

    @Override
    public int getId() {
        return 163;
    }

    @Override
    public String getName() {
        return "Acacia Wood Stairs";
    }
}

