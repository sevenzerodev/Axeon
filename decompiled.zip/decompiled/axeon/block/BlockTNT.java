/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.Player;
import cn.axeon.block.BlockAir;
import cn.axeon.block.BlockSolid;
import cn.axeon.entity.item.EntityPrimedTNT;
import cn.axeon.item.Item;
import cn.axeon.level.sound.TNTPrimeSound;
import cn.axeon.math.NukkitRandom;
import cn.axeon.nbt.tag.CompoundTag;
import cn.axeon.nbt.tag.DoubleTag;
import cn.axeon.nbt.tag.FloatTag;
import cn.axeon.nbt.tag.ListTag;
import cn.axeon.utils.BlockColor;

public class BlockTNT
extends BlockSolid {
    public BlockTNT() {
        this(0);
    }

    public BlockTNT(int meta) {
        super(0);
    }

    @Override
    public String getName() {
        return "TNT";
    }

    @Override
    public int getId() {
        return 46;
    }

    @Override
    public double getHardness() {
        return 0.0;
    }

    @Override
    public double getResistance() {
        return 0.0;
    }

    @Override
    public boolean canBeActivated() {
        return true;
    }

    @Override
    public int getBurnChance() {
        return 15;
    }

    @Override
    public int getBurnAbility() {
        return 100;
    }

    public void prime() {
        this.getLevel().setBlock(this, new BlockAir(), true);
        double mot = (double)new NukkitRandom().nextSignedFloat() * Math.PI * 2.0;
        CompoundTag nbt = new CompoundTag().putList(new ListTag<DoubleTag>("Pos").add(new DoubleTag("", this.x + 0.5)).add(new DoubleTag("", this.y)).add(new DoubleTag("", this.z + 0.5))).putList(new ListTag<DoubleTag>("Motion").add(new DoubleTag("", -Math.sin(mot) * 0.02)).add(new DoubleTag("", 0.2)).add(new DoubleTag("", -Math.cos(mot) * 0.02))).putList(new ListTag<FloatTag>("Rotation").add(new FloatTag("", 0.0f)).add(new FloatTag("", 0.0f))).putByte("Fuse", 80);
        EntityPrimedTNT tnt = new EntityPrimedTNT(this.getLevel().getChunk(this.getFloorX() >> 4, this.getFloorZ() >> 4), nbt);
        tnt.spawnToAll();
        this.level.addSound(new TNTPrimeSound(this));
    }

    @Override
    public int onUpdate(int type) {
        if (type == 1 && this.getNeighborPowerLevel() > 0) {
            this.prime();
        }
        return 0;
    }

    @Override
    public boolean onActivate(Item item, Player player) {
        if (item.getId() == 259) {
            item.useOn(this);
            this.prime();
            return true;
        }
        return false;
    }

    @Override
    public BlockColor getColor() {
        return BlockColor.TNT_BLOCK_COLOR;
    }
}

