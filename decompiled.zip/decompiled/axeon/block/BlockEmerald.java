/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.block.BlockSolid;
import cn.axeon.item.Item;
import cn.axeon.utils.BlockColor;

public class BlockEmerald
extends BlockSolid {
    public BlockEmerald() {
        this(0);
    }

    public BlockEmerald(int meta) {
        super(0);
    }

    @Override
    public String getName() {
        return "Emerald Block";
    }

    @Override
    public int getId() {
        return 133;
    }

    @Override
    public double getHardness() {
        return 5.0;
    }

    @Override
    public double getResistance() {
        return 30.0;
    }

    @Override
    public int getToolType() {
        return 3;
    }

    @Override
    public int[][] getDrops(Item item) {
        if (item.isPickaxe()) {
            return new int[][]{{133, 0, 1}};
        }
        return new int[0][];
    }

    @Override
    public BlockColor getColor() {
        return BlockColor.EMERALD_BLOCK_COLOR;
    }
}

