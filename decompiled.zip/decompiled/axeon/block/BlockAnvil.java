/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.Player;
import cn.axeon.block.Block;
import cn.axeon.block.BlockFallable;
import cn.axeon.inventory.AnvilInventory;
import cn.axeon.item.Item;
import cn.axeon.utils.BlockColor;

public class BlockAnvil
extends BlockFallable {
    public BlockAnvil() {
        this(0);
    }

    public BlockAnvil(int meta) {
        super(meta);
    }

    @Override
    public int getId() {
        return 145;
    }

    @Override
    public boolean isSolid() {
        return false;
    }

    @Override
    public boolean canBeActivated() {
        return true;
    }

    @Override
    public double getHardness() {
        return 5.0;
    }

    @Override
    public double getResistance() {
        return 6000.0;
    }

    @Override
    public int getToolType() {
        return 3;
    }

    @Override
    public String getName() {
        String[] names = new String[]{"Anvil", "Anvil", "Anvil", "Anvil", "Slighty Damaged Anvil", "Slighty Damaged Anvil", "Slighty Damaged Anvil", "Slighty Damaged Anvil", "Very Damaged Anvil", "Very Damaged Anvil", "Very Damaged Anvil", "Very Damaged Anvil"};
        return names[this.meta];
    }

    @Override
    public boolean place(Item item, Block block, Block target, int face, double fx, double fy, double fz, Player player) {
        if (!target.isTransparent()) {
            int[] faces = new int[]{0, 1, 2, 3};
            int damage = this.getDamage();
            this.meta = faces[player != null ? player.getDirection() : 0] & 4;
            if (damage >= 0 && damage <= 3) {
                this.meta = faces[player != null ? player.getDirection() : 0];
            } else if (damage >= 4 && damage <= 7) {
                this.meta = faces[player != null ? player.getDirection() : 0] | 4;
            } else if (damage >= 8 && damage <= 11) {
                this.meta = faces[player != null ? player.getDirection() : 0] | 8;
            }
            this.getLevel().setBlock(block, this, true);
            return true;
        }
        return false;
    }

    @Override
    public boolean onActivate(Item item, Player player) {
        if (player != null) {
            player.addWindow(new AnvilInventory(this));
        }
        return true;
    }

    @Override
    public int[][] getDrops(Item item) {
        int damage = this.getDamage();
        if (item.isPickaxe() && item.getTier() >= 1) {
            if (damage >= 0 && damage <= 3) {
                return new int[][]{{this.getId(), 0, 1}};
            }
            if (damage >= 4 && damage <= 7) {
                return new int[][]{{this.getId(), this.meta & 4, 1}};
            }
            if (damage >= 8 && damage <= 11) {
                return new int[][]{{this.getId(), this.meta & 8, 1}};
            }
        } else {
            return new int[0][];
        }
        return new int[0][];
    }

    @Override
    public BlockColor getColor() {
        return BlockColor.IRON_BLOCK_COLOR;
    }
}

