/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.block.BlockFenceGate;

public class BlockFenceGateBirch
extends BlockFenceGate {
    public BlockFenceGateBirch() {
        this(0);
    }

    public BlockFenceGateBirch(int meta) {
        super(meta);
    }

    @Override
    public int getId() {
        return 184;
    }

    @Override
    public String getName() {
        return "Birch Fence Gate";
    }
}

