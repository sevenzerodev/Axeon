/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.Player;
import cn.axeon.block.Block;
import cn.axeon.block.BlockAir;
import cn.axeon.block.BlockSolid;
import cn.axeon.item.Item;
import cn.axeon.redstone.Redstone;
import cn.axeon.utils.BlockColor;

public class BlockRedstone
extends BlockSolid {
    public BlockRedstone() {
        this(0);
    }

    public BlockRedstone(int meta) {
        super(0);
        this.setPowerSource(true);
        this.setPowerLevel(16);
    }

    @Override
    public int getId() {
        return 152;
    }

    @Override
    public double getResistance() {
        return 10.0;
    }

    @Override
    public double getHardness() {
        return 5.0;
    }

    @Override
    public int getToolType() {
        return 3;
    }

    @Override
    public String getName() {
        return "Redstone Block";
    }

    @Override
    public boolean place(Item item, Block block, Block target, int face, double fx, double fy, double fz, Player player) {
        this.getLevel().setBlock(block, this, true, false);
        Redstone.active(this);
        this.getLevel().updateAllLight(this);
        this.getLevel().updateAroundRedstone(this);
        this.getLevel().updateAround(block);
        return true;
    }

    @Override
    public boolean onBreak(Item item) {
        int level = this.getPowerLevel();
        this.getLevel().setBlock(this, new BlockAir(), true, true);
        Redstone.deactive(this, level);
        return true;
    }

    @Override
    public int[][] getDrops(Item item) {
        if (item.isPickaxe() && item.getTier() >= 1) {
            return new int[][]{{152, 0, 1}};
        }
        return new int[0][];
    }

    @Override
    public BlockColor getColor() {
        return BlockColor.REDSTONE_BLOCK_COLOR;
    }
}

