/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.block.BlockSolid;
import cn.axeon.item.Item;
import cn.axeon.math.NukkitRandom;
import java.util.Random;

public class BlockOreRedstone
extends BlockSolid {
    public BlockOreRedstone() {
        this(0);
    }

    public BlockOreRedstone(int meta) {
        super(0);
    }

    @Override
    public int getId() {
        return 73;
    }

    @Override
    public double getHardness() {
        return 3.0;
    }

    @Override
    public double getResistance() {
        return 15.0;
    }

    @Override
    public int getToolType() {
        return 3;
    }

    @Override
    public String getName() {
        return "Redstone Ore";
    }

    @Override
    public int[][] getDrops(Item item) {
        if (item.isPickaxe() && item.getTier() >= 4) {
            return new int[][]{{331, 0, new Random().nextInt(1) + 4}};
        }
        return new int[0][];
    }

    @Override
    public int onUpdate(int type) {
        if (type == 5) {
            this.getLevel().setBlock(this, new BlockOreRedstone(this.meta), false, false);
            return 4;
        }
        return 0;
    }

    @Override
    public int getDropExp() {
        return new NukkitRandom().nextRange(1, 5);
    }
}

