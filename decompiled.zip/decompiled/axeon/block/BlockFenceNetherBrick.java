/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.block.Block;
import cn.axeon.block.BlockFence;
import cn.axeon.block.BlockFenceGate;
import cn.axeon.item.Item;
import cn.axeon.utils.BlockColor;

public class BlockFenceNetherBrick
extends BlockFence {
    public BlockFenceNetherBrick() {
        this(0);
    }

    public BlockFenceNetherBrick(int meta) {
        super(meta);
    }

    @Override
    public double getBreakTime(Item item) {
        if (item.getId() == 0) {
            return 10.0;
        }
        return super.getBreakTime(item);
    }

    @Override
    public int getToolType() {
        return 3;
    }

    @Override
    public String getName() {
        return "Nether Brick Fence";
    }

    @Override
    public int getId() {
        return 113;
    }

    @Override
    public double getHardness() {
        return 2.0;
    }

    @Override
    public double getResistance() {
        return 10.0;
    }

    @Override
    public int[][] getDrops(Item item) {
        if (item.isPickaxe() && item.getTier() >= 1) {
            return new int[][]{{this.getId(), 0, 1}};
        }
        return new int[0][];
    }

    @Override
    public boolean canConnect(Block block) {
        return block instanceof BlockFenceNetherBrick || block instanceof BlockFenceGate || block.isSolid() && !block.isTransparent();
    }

    @Override
    public BlockColor getColor() {
        return BlockColor.NETHERRACK_BLOCK_COLOR;
    }
}

