/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.block.BlockDirt;

public class BlockPodzol
extends BlockDirt {
    public BlockPodzol() {
        this(0);
    }

    public BlockPodzol(int meta) {
        super(0);
    }

    @Override
    public int getId() {
        return 243;
    }

    @Override
    public String getName() {
        return "Podzol";
    }
}

