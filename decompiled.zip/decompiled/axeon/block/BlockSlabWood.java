/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.Player;
import cn.axeon.block.Block;
import cn.axeon.block.BlockDoubleSlabWood;
import cn.axeon.block.BlockSlab;
import cn.axeon.item.Item;
import cn.axeon.utils.BlockColor;

public class BlockSlabWood
extends BlockSlab {
    public BlockSlabWood() {
        this(0);
    }

    public BlockSlabWood(int meta) {
        super(meta);
    }

    @Override
    public String getName() {
        String[] names = new String[]{"Oak", "Spruce", "Birch", "Jungle", "Acacia", "Dark Oak", "", ""};
        return ((this.meta & 8) == 8 ? "Upper " : "") + names[this.meta & 7] + " Wooden Slab";
    }

    @Override
    public int getId() {
        return 158;
    }

    @Override
    public int getBurnChance() {
        return 5;
    }

    @Override
    public int getBurnAbility() {
        return 20;
    }

    @Override
    public boolean place(Item item, Block block, Block target, int face, double fx, double fy, double fz) {
        return this.place(item, block, target, face, fx, fy, fz, null);
    }

    @Override
    public boolean place(Item item, Block block, Block target, int face, double fx, double fy, double fz, Player player) {
        this.meta &= 7;
        if (face == 0) {
            if (target.getId() == 158 && (target.getDamage() & 8) == 8 && (target.getDamage() & 7) == (this.meta & 7)) {
                this.getLevel().setBlock(target, new BlockDoubleSlabWood(this.meta), true);
                return true;
            }
            if (block.getId() == 158 && (block.getDamage() & 7) == (this.meta & 7)) {
                this.getLevel().setBlock(block, new BlockDoubleSlabWood(this.meta), true);
                return true;
            }
            this.meta |= 8;
        } else if (face == 1) {
            if (target.getId() == 158 && (target.getDamage() & 8) == 0 && (target.getDamage() & 7) == (this.meta & 7)) {
                this.getLevel().setBlock(target, new BlockDoubleSlabWood(this.meta), true);
                return true;
            }
            if (block.getId() == 158 && (block.getDamage() & 7) == (this.meta & 7)) {
                this.getLevel().setBlock(block, new BlockDoubleSlabWood(this.meta), true);
                return true;
            }
        } else {
            if (block.getId() == 158) {
                if ((block.getDamage() & 7) == (this.meta & 7)) {
                    this.getLevel().setBlock(block, new BlockDoubleSlabWood(this.meta), true);
                    return true;
                }
                return false;
            }
            if (fy > 0.5) {
                this.meta |= 8;
            }
        }
        if (block.getId() == 158 && (target.getDamage() & 7) != (this.meta & 7)) {
            return false;
        }
        this.getLevel().setBlock(block, this, true, true);
        return true;
    }

    @Override
    public int getToolType() {
        return 4;
    }

    @Override
    public double getHardness() {
        return 2.0;
    }

    @Override
    public double getResistance() {
        return 15.0;
    }

    @Override
    public int[][] getDrops(Item item) {
        return new int[][]{{this.getId(), this.meta & 7, 1}};
    }

    @Override
    public BlockColor getColor() {
        return BlockColor.WOOD_BLOCK_COLOR;
    }
}

