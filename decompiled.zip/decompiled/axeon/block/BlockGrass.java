/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.Player;
import cn.axeon.Server;
import cn.axeon.block.Block;
import cn.axeon.block.BlockDirt;
import cn.axeon.block.BlockFarmland;
import cn.axeon.block.BlockGrassPath;
import cn.axeon.event.block.BlockSpreadEvent;
import cn.axeon.item.Item;
import cn.axeon.level.generator.object.ObjectTallGrass;
import cn.axeon.math.NukkitRandom;
import cn.axeon.math.Vector3;
import cn.axeon.utils.BlockColor;

public class BlockGrass
extends BlockDirt {
    public BlockGrass() {
        this(0);
    }

    public BlockGrass(int meta) {
        super(0);
    }

    @Override
    public int getId() {
        return 2;
    }

    @Override
    public boolean canBeActivated() {
        return true;
    }

    @Override
    public double getHardness() {
        return 0.6;
    }

    @Override
    public double getResistance() {
        return 3.0;
    }

    @Override
    public String getName() {
        return "Grass";
    }

    @Override
    public boolean onActivate(Item item) {
        return this.onActivate(item, null);
    }

    @Override
    public boolean onActivate(Item item, Player player) {
        if (item.getId() == 351 && item.getDamage() == 15) {
            --item.count;
            ObjectTallGrass.growGrass(this.getLevel(), this, new NukkitRandom(), 15, 10);
            return true;
        }
        if (item.isHoe()) {
            item.useOn(this);
            this.getLevel().setBlock(this, new BlockFarmland());
            return true;
        }
        if (item.isShovel()) {
            item.useOn(this);
            this.getLevel().setBlock(this, new BlockGrassPath());
            return true;
        }
        return false;
    }

    @Override
    public int onUpdate(int type) {
        if (type == 2) {
            Block block = this.getLevel().getBlock(new Vector3(this.x, this.y, this.z));
            if (block.getSide(1).getLightLevel() < 4) {
                BlockSpreadEvent ev = new BlockSpreadEvent(block, this, new BlockDirt());
                Server.getInstance().getPluginManager().callEvent(ev);
            } else if (block.getSide(1).getLightLevel() >= 9) {
                for (int l = 0; l < 4; ++l) {
                    NukkitRandom random = new NukkitRandom();
                    int x = random.nextRange((int)this.x - 1, (int)this.x + 1);
                    int y = random.nextRange((int)this.y - 2, (int)this.y + 2);
                    int z = random.nextRange((int)this.z - 1, (int)this.z + 1);
                    Block blocks = this.getLevel().getBlock(new Vector3(x, y, z));
                    if (blocks.getId() != 3 || blocks.getDamage() != 15 || blocks.getSide(1).getLightLevel() < 4 || !(blocks.z <= 2.0)) continue;
                    BlockSpreadEvent ev = new BlockSpreadEvent(blocks, this, new BlockGrass());
                    Server.getInstance().getPluginManager().callEvent(ev);
                    if (ev.isCancelled()) continue;
                    this.getLevel().setBlock(blocks, ev.getNewState());
                }
            }
        }
        return 0;
    }

    @Override
    public BlockColor getColor() {
        return BlockColor.GRASS_BLOCK_COLOR;
    }
}

