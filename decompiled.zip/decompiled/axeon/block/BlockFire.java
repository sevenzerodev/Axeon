/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.Player;
import cn.axeon.Server;
import cn.axeon.block.Block;
import cn.axeon.block.BlockAir;
import cn.axeon.block.BlockFlowable;
import cn.axeon.block.BlockSlab;
import cn.axeon.block.BlockSnowLayer;
import cn.axeon.block.BlockStairs;
import cn.axeon.block.BlockTNT;
import cn.axeon.entity.Entity;
import cn.axeon.entity.projectile.EntityArrow;
import cn.axeon.event.block.BlockBurnEvent;
import cn.axeon.event.entity.EntityCombustByBlockEvent;
import cn.axeon.event.entity.EntityCombustEvent;
import cn.axeon.event.entity.EntityDamageByBlockEvent;
import cn.axeon.event.entity.EntityDamageEvent;
import cn.axeon.event.entity.EntityEvent;
import cn.axeon.item.Item;
import cn.axeon.math.Vector3;
import cn.axeon.utils.BlockColor;
import java.util.Random;

public class BlockFire
extends BlockFlowable {
    public BlockFire() {
        this(0);
    }

    public BlockFire(int meta) {
        super(meta);
    }

    @Override
    public int getId() {
        return 51;
    }

    @Override
    public boolean hasEntityCollision() {
        return true;
    }

    @Override
    public String getName() {
        return "Fire Block";
    }

    @Override
    public int getLightLevel() {
        return 15;
    }

    @Override
    public boolean isBreakable(Item item) {
        return false;
    }

    @Override
    public boolean canBeReplaced() {
        return true;
    }

    @Override
    public void onEntityCollide(Entity entity) {
        EntityEvent ev;
        if (!entity.hasEffect(12)) {
            ev = new EntityDamageByBlockEvent(this, entity, 5, 1.0f);
            entity.attack((EntityDamageEvent)ev);
        }
        ev = new EntityCombustByBlockEvent(this, entity, 8);
        if (entity instanceof EntityArrow) {
            ev.setCancelled();
        }
        Server.getInstance().getPluginManager().callEvent(ev);
        if (!ev.isCancelled() && entity instanceof Player && !((Player)entity).isCreative()) {
            entity.setOnFire(((EntityCombustEvent)ev).getDuration());
        }
    }

    @Override
    public int[][] getDrops(Item item) {
        return new int[0][];
    }

    @Override
    public int onUpdate(int type) {
        if (type == 1 || type == 2) {
            if (!this.isBlockTopFacingSurfaceSolid(this.getSide(0)) && !this.canNeighborBurn()) {
                this.getLevel().setBlock(this, new BlockAir(), true);
            }
            return 1;
        }
        if (type == 3) {
            boolean forever = this.getSide(0).getId() == 87;
            Random random = this.getLevel().rand;
            if (!this.isBlockTopFacingSurfaceSolid(this.getSide(0)) && !this.canNeighborBurn()) {
                this.getLevel().setBlock(this, new BlockAir(), true);
            }
            if (!forever && this.getLevel().isRaining() && (this.getLevel().canBlockSeeSky(this) || this.getLevel().canBlockSeeSky(this.getSide(5)) || this.getLevel().canBlockSeeSky(this.getSide(4)) || this.getLevel().canBlockSeeSky(this.getSide(3)) || this.getLevel().canBlockSeeSky(this.getSide(2)))) {
                this.getLevel().setBlock(this, new BlockAir(), true);
            } else {
                int meta = this.getDamage();
                if (meta < 15) {
                    this.meta = meta + random.nextInt(3);
                    this.getLevel().setBlock(this, this, true);
                }
                this.getLevel().scheduleUpdate(this, this.tickRate() + random.nextInt(10));
                if (!forever && !this.canNeighborBurn()) {
                    if (!this.isBlockTopFacingSurfaceSolid(this.getSide(0)) || meta > 3) {
                        this.getLevel().setBlock(this, new BlockAir(), true);
                    }
                } else if (!forever && this.getSide(0).getBurnAbility() <= 0 && meta == 15 && random.nextInt(4) == 0) {
                    this.getLevel().setBlock(this, new BlockAir(), true);
                } else {
                    int o = 0;
                    this.tryToCatchBlockOnFire(this.getSide(5), 300 + o, meta);
                    this.tryToCatchBlockOnFire(this.getSide(4), 300 + o, meta);
                    this.tryToCatchBlockOnFire(this.getSide(0), 250 + o, meta);
                    this.tryToCatchBlockOnFire(this.getSide(1), 250 + o, meta);
                    this.tryToCatchBlockOnFire(this.getSide(3), 300 + o, meta);
                    this.tryToCatchBlockOnFire(this.getSide(2), 300 + o, meta);
                    for (int x = (int)(this.x - 1.0); x <= (int)(this.x + 1.0); ++x) {
                        for (int z = (int)(this.z - 1.0); z <= (int)(this.z + 1.0); ++z) {
                            for (int y = (int)(this.y - 1.0); y <= (int)(this.y + 4.0); ++y) {
                                int t;
                                int chance;
                                if (x == (int)this.x && y == (int)this.y && z == (int)this.z) continue;
                                int k = 100;
                                if ((double)y > this.y + 1.0) {
                                    k = (int)((double)k + ((double)y - (this.y + 1.0)) * 100.0);
                                }
                                if ((chance = this.getChanceOfNeighborsEncouragingFire(this.getLevel().getBlock(new Vector3(x, y, z)))) <= 0 || (t = (chance + 40 + this.getLevel().getServer().getDifficulty() * 7) / (meta + 30)) <= 0 || random.nextInt(k) > t) continue;
                                int damage = meta + random.nextInt(5) / 4;
                                if (damage > 15) {
                                    damage = 15;
                                }
                                this.getLevel().setBlock(new Vector3(x, y, z), new BlockFire(damage), true);
                                this.getLevel().scheduleUpdate(new Vector3(x, y, z), this.tickRate());
                            }
                        }
                    }
                }
            }
        }
        return 0;
    }

    private void tryToCatchBlockOnFire(Block block, int bound, int damage) {
        int burnAbility = block.getBurnAbility();
        Random random = this.getLevel().rand;
        if (random.nextInt(bound) < burnAbility) {
            if (random.nextInt(damage + 10) < 5) {
                int meta = damage + random.nextInt(5) / 4;
                if (meta > 15) {
                    meta = 15;
                }
                this.getLevel().setBlock(block, new BlockFire(meta), true);
                this.getLevel().scheduleUpdate(block, this.tickRate());
            } else {
                BlockBurnEvent ev = new BlockBurnEvent(block);
                this.getLevel().getServer().getPluginManager().callEvent(ev);
                if (!ev.isCancelled()) {
                    this.getLevel().setBlock(block, new BlockAir(), true);
                }
            }
            if (block instanceof BlockTNT) {
                ((BlockTNT)block).prime();
            }
        }
    }

    private int getChanceOfNeighborsEncouragingFire(Block block) {
        if (block.getId() != 0) {
            return 0;
        }
        int chance = 0;
        chance = Math.max(chance, block.getSide(5).getBurnChance());
        chance = Math.max(chance, block.getSide(4).getBurnChance());
        chance = Math.max(chance, block.getSide(0).getBurnChance());
        chance = Math.max(chance, block.getSide(1).getBurnChance());
        chance = Math.max(chance, block.getSide(3).getBurnChance());
        chance = Math.max(chance, block.getSide(2).getBurnChance());
        return chance;
    }

    public boolean canNeighborBurn() {
        for (int face = 0; face <= 5; ++face) {
            if (this.getSide(face).getBurnChance() <= 0) continue;
            return true;
        }
        return false;
    }

    public boolean isBlockTopFacingSurfaceSolid(Block block) {
        if (block != null) {
            if (block.isSolid()) {
                return true;
            }
            if (block instanceof BlockStairs && (block.getDamage() & 4) == 4) {
                return true;
            }
            if (block instanceof BlockSlab && (block.getDamage() & 8) == 8) {
                return true;
            }
            if (block instanceof BlockSnowLayer && (block.getDamage() & 7) == 7) {
                return true;
            }
        }
        return false;
    }

    @Override
    public int tickRate() {
        return 30;
    }

    @Override
    public BlockColor getColor() {
        return BlockColor.AIR_BLOCK_COLOR;
    }
}

