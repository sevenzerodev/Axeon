/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.block.BlockSolid;
import cn.axeon.item.Item;

public class BlockSlime
extends BlockSolid {
    public BlockSlime() {
        this(0);
    }

    public BlockSlime(int meta) {
        super(meta);
    }

    @Override
    public String getName() {
        return "Slime Block";
    }

    @Override
    public int getId() {
        return 165;
    }

    @Override
    public int[][] getDrops(Item item) {
        return new int[][]{{165, 0, 1}};
    }
}

