/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.block.BlockStairsWood;

public class BlockStairsJungle
extends BlockStairsWood {
    public BlockStairsJungle() {
        this(0);
    }

    public BlockStairsJungle(int meta) {
        super(meta);
    }

    @Override
    public int getId() {
        return 136;
    }

    @Override
    public String getName() {
        return "Jungle Wood Stairs";
    }
}

