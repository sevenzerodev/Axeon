/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.block.Block;
import cn.axeon.block.BlockTransparent;
import cn.axeon.math.AxisAlignedBB;

public class BlockWall
extends BlockTransparent {
    public static final int NONE_MOSSY_WALL = 0;
    public static final int MOSSY_WALL = 1;

    public BlockWall() {
        this(0);
    }

    public BlockWall(int meta) {
        super(meta);
    }

    @Override
    public int getId() {
        return 139;
    }

    @Override
    public boolean isSolid() {
        return false;
    }

    @Override
    public double getHardness() {
        return 2.0;
    }

    @Override
    public double getResistance() {
        return 30.0;
    }

    @Override
    public String getName() {
        if (this.meta == 1) {
            return "Mossy Cobblestone Wall";
        }
        return "Cobblestone Wall";
    }

    @Override
    protected AxisAlignedBB recalculateBoundingBox() {
        double e;
        boolean north = this.canConnect(this.getSide(2));
        boolean south = this.canConnect(this.getSide(3));
        boolean west = this.canConnect(this.getSide(4));
        boolean east = this.canConnect(this.getSide(5));
        double n = north ? 0.0 : 0.25;
        double s = south ? 1.0 : 0.75;
        double w = west ? 0.0 : 0.25;
        double d = e = east ? 1.0 : 0.75;
        if (north && south && !west && !east) {
            w = 0.3125;
            e = 0.6875;
        } else if (!north && !south && west && east) {
            n = 0.3125;
            s = 0.6875;
        }
        return new AxisAlignedBB(this.x + w, this.y, this.z + n, this.x + e, this.y + 1.5, this.z + s);
    }

    public boolean canConnect(Block block) {
        return block.getId() == 139 || block.getId() == 107 || block.isSolid() && !block.isTransparent();
    }

    @Override
    public int getToolType() {
        return 3;
    }
}

