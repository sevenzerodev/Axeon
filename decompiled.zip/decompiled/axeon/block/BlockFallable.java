/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.Player;
import cn.axeon.block.Block;
import cn.axeon.block.BlockLiquid;
import cn.axeon.block.BlockSolid;
import cn.axeon.entity.item.EntityFallingBlock;
import cn.axeon.item.Item;
import cn.axeon.nbt.tag.CompoundTag;
import cn.axeon.nbt.tag.DoubleTag;
import cn.axeon.nbt.tag.FloatTag;
import cn.axeon.nbt.tag.ListTag;

public abstract class BlockFallable
extends BlockSolid {
    protected BlockFallable(int meta) {
        super(meta);
    }

    @Override
    public boolean place(Item item, Block block, Block target, int face, double fx, double fy, double fz) {
        return this.place(item, block, target, face, fx, fy, fz, null);
    }

    @Override
    public boolean place(Item item, Block block, Block target, int face, double fx, double fy, double fz, Player player) {
        return this.getLevel().setBlock(this, this, true, true);
    }

    @Override
    public int onUpdate(int type) {
        Block down;
        if (type == 1 && ((down = this.getSide(0)).getId() == 0 || down instanceof BlockLiquid)) {
            CompoundTag nbt = new CompoundTag().putList(new ListTag<DoubleTag>("Pos").add(new DoubleTag("", this.x + 0.5)).add(new DoubleTag("", this.y)).add(new DoubleTag("", this.z + 0.5))).putList(new ListTag<DoubleTag>("Motion").add(new DoubleTag("", 0.0)).add(new DoubleTag("", 0.0)).add(new DoubleTag("", 0.0))).putList(new ListTag<FloatTag>("Rotation").add(new FloatTag("", 0.0f)).add(new FloatTag("", 0.0f))).putInt("TileID", this.getId()).putByte("Data", this.getDamage());
            EntityFallingBlock fall = new EntityFallingBlock(this.getLevel().getChunk((int)this.x >> 4, (int)this.z >> 4), nbt);
            fall.spawnToAll();
        }
        return type;
    }
}

