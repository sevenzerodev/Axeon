/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.block.Block;
import cn.axeon.utils.BlockColor;

public abstract class BlockTransparent
extends Block {
    protected BlockTransparent(int meta) {
        super((Integer)meta);
    }

    @Override
    public boolean isTransparent() {
        return true;
    }

    @Override
    public BlockColor getColor() {
        return BlockColor.TRANSPARENT_BLOCK_COLOR;
    }
}

