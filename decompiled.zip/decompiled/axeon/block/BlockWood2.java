/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.block.BlockWood;

public class BlockWood2
extends BlockWood {
    public static final int ACACIA = 0;
    public static final int DARK_OAK = 1;

    public BlockWood2() {
        this(0);
    }

    public BlockWood2(int meta) {
        super(meta);
    }

    @Override
    public int getId() {
        return 162;
    }

    @Override
    public String getName() {
        String[] names = new String[]{"Acacia Wood", "Dark Oak Wood", ""};
        return names[this.meta & 3];
    }
}

