/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.block.BlockRail;
import cn.axeon.item.Item;

public class BlockRailDetector
extends BlockRail {
    public BlockRailDetector() {
        this(0);
    }

    public BlockRailDetector(int meta) {
        super(meta);
    }

    @Override
    public int getId() {
        return 28;
    }

    @Override
    public String getName() {
        return "Detector Rail";
    }

    @Override
    public int[][] getDrops(Item item) {
        return new int[][]{{28, 0, 1}};
    }
}

