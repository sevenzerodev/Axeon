/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.block.BlockDoorWood;
import cn.axeon.item.Item;

public class BlockDoorBirch
extends BlockDoorWood {
    public BlockDoorBirch() {
        this(0);
    }

    public BlockDoorBirch(int meta) {
        super(meta);
    }

    @Override
    public String getName() {
        return "Birch Door Block";
    }

    @Override
    public int getId() {
        return 194;
    }

    @Override
    public int[][] getDrops(Item item) {
        return new int[][]{{428, 0, 1}};
    }
}

