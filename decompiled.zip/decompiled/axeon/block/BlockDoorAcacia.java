/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.block.BlockDoorWood;
import cn.axeon.item.Item;

public class BlockDoorAcacia
extends BlockDoorWood {
    public BlockDoorAcacia() {
        this(0);
    }

    public BlockDoorAcacia(int meta) {
        super(meta);
    }

    @Override
    public String getName() {
        return "Acacia Door Block";
    }

    @Override
    public int getId() {
        return 196;
    }

    @Override
    public int[][] getDrops(Item item) {
        return new int[][]{{430, 0, 1}};
    }
}

