/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.block.BlockSolid;
import cn.axeon.item.Item;
import cn.axeon.utils.BlockColor;

public class BlockBricks
extends BlockSolid {
    public BlockBricks(int meta) {
        super(meta);
    }

    public BlockBricks() {
        this(0);
    }

    @Override
    public String getName() {
        return "Bricks";
    }

    @Override
    public int getId() {
        return 45;
    }

    @Override
    public double getHardness() {
        return 2.0;
    }

    @Override
    public double getResistance() {
        return 30.0;
    }

    @Override
    public int getToolType() {
        return 3;
    }

    @Override
    public int[][] getDrops(Item item) {
        if (item.isPickaxe()) {
            return new int[][]{{45, 0, 1}};
        }
        return new int[][]{new int[0]};
    }

    @Override
    public BlockColor getColor() {
        return BlockColor.STONE_BLOCK_COLOR;
    }
}

