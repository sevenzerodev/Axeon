/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.block.BlockRail;
import cn.axeon.item.Item;

public class BlockRailActivator
extends BlockRail {
    public BlockRailActivator(int meta) {
        super(meta);
    }

    public BlockRailActivator() {
        this(0);
    }

    @Override
    public String getName() {
        return "Activator Rail";
    }

    @Override
    public int getId() {
        return 126;
    }

    @Override
    public int[][] getDrops(Item item) {
        return new int[][]{{126, 0, 1}};
    }
}

