/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.block.BlockFlowable;
import cn.axeon.item.Item;
import cn.axeon.utils.BlockColor;

public class BlockDoublePlant
extends BlockFlowable {
    public BlockDoublePlant() {
        this(0);
    }

    public BlockDoublePlant(int meta) {
        super(meta);
    }

    @Override
    public int getId() {
        return 175;
    }

    @Override
    public boolean canBeReplaced() {
        return this.meta == 2 || this.meta == 3;
    }

    @Override
    public String getName() {
        String[] names = new String[]{"Sunflower", "Lilac", "Double Tallgrass", "Large Fern", "Rose Bush", "Peony"};
        return names[this.meta & 7];
    }

    @Override
    public int onUpdate(int type) {
        if (type == 1) {
            if ((this.meta & 8) == 8) {
                if (this.getSide(0).getId() != 175) {
                    this.getLevel().useBreakOn(this);
                    return 1;
                }
            } else if (this.getSide(0).isTransparent() || this.getSide(1).getId() != 175) {
                this.getLevel().useBreakOn(this);
                return 1;
            }
        }
        return 0;
    }

    @Override
    public int[][] getDrops(Item item) {
        return new int[0][];
    }

    @Override
    public BlockColor getColor() {
        return BlockColor.FOLIAGE_BLOCK_COLOR;
    }
}

