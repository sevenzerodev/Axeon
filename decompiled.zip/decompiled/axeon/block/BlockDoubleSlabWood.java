/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.block.BlockSolid;
import cn.axeon.item.Item;
import cn.axeon.utils.BlockColor;

public class BlockDoubleSlabWood
extends BlockSolid {
    public BlockDoubleSlabWood() {
        this(0);
    }

    public BlockDoubleSlabWood(int meta) {
        super(meta);
    }

    @Override
    public int getId() {
        return 157;
    }

    @Override
    public double getHardness() {
        return 2.0;
    }

    @Override
    public double getResistance() {
        return 15.0;
    }

    @Override
    public int getToolType() {
        return 4;
    }

    @Override
    public String getName() {
        String[] names = new String[]{"Oak", "Spruce", "Birch", "Jungle", "Acacia", "Dark Oak", "", ""};
        return "Double " + names[this.meta & 7] + " Slab";
    }

    @Override
    public int[][] getDrops(Item item) {
        return new int[][]{{158, this.meta & 7, 2}};
    }

    @Override
    public BlockColor getColor() {
        return BlockColor.WOOD_BLOCK_COLOR;
    }
}

