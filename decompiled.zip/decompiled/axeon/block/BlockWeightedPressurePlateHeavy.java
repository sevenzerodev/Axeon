/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.block.BlockWeightedPressurePlate;
import cn.axeon.item.Item;

public class BlockWeightedPressurePlateHeavy
extends BlockWeightedPressurePlate {
    public BlockWeightedPressurePlateHeavy(int meta) {
        super(meta);
    }

    public BlockWeightedPressurePlateHeavy() {
        this(0);
    }

    @Override
    public String getName() {
        return "Heavy Weighted Pressure Plate";
    }

    @Override
    public int getId() {
        return 148;
    }

    @Override
    public double getHardness() {
        return 0.5;
    }

    @Override
    public double getResistance() {
        return 2.5;
    }

    @Override
    public int getToolType() {
        return 3;
    }

    @Override
    public int[][] getDrops(Item item) {
        if (item.isPickaxe()) {
            return new int[][]{{148, 0, 1}};
        }
        return new int[][]{new int[0]};
    }
}

