/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.Player;
import cn.axeon.Server;
import cn.axeon.block.Block;
import cn.axeon.block.BlockFire;
import cn.axeon.block.BlockLiquid;
import cn.axeon.entity.Entity;
import cn.axeon.event.entity.EntityCombustByBlockEvent;
import cn.axeon.event.entity.EntityCombustEvent;
import cn.axeon.event.entity.EntityDamageByBlockEvent;
import cn.axeon.event.entity.EntityDamageEvent;
import cn.axeon.event.entity.EntityEvent;
import cn.axeon.item.Item;
import cn.axeon.level.Position;
import cn.axeon.utils.BlockColor;
import java.util.Random;

public class BlockLava
extends BlockLiquid {
    public BlockLava() {
        this(0);
    }

    public BlockLava(int meta) {
        super(meta);
    }

    @Override
    public int getId() {
        return 10;
    }

    @Override
    public int getLightLevel() {
        return 15;
    }

    @Override
    public String getName() {
        return "Lava";
    }

    @Override
    public void onEntityCollide(Entity entity) {
        EntityEvent ev;
        entity.highestPosition -= (entity.highestPosition - entity.y) * 0.5;
        if (!entity.hasEffect(12)) {
            ev = new EntityDamageByBlockEvent(this, entity, 7, 4.0f);
            entity.attack((EntityDamageEvent)ev);
        }
        ev = new EntityCombustByBlockEvent(this, entity, 15);
        Server.getInstance().getPluginManager().callEvent(ev);
        if (!ev.isCancelled()) {
            entity.setOnFire(((EntityCombustEvent)ev).getDuration());
        }
        super.onEntityCollide(entity);
    }

    @Override
    public boolean place(Item item, Block block, Block target, int face, double fx, double fy, double fz) {
        return this.place(item, block, target, face, fx, fy, fz, null);
    }

    @Override
    public boolean place(Item item, Block block, Block target, int face, double fx, double fy, double fz, Player player) {
        boolean ret = this.getLevel().setBlock(this, this, true, false);
        this.getLevel().scheduleUpdate(this, this.tickRate());
        return ret;
    }

    @Override
    public int onUpdate(int type) {
        int result;
        block5: {
            result = super.onUpdate(type);
            if (type != 2) break block5;
            Random random = this.getLevel().rand;
            int i = random.nextInt(3);
            if (i > 0) {
                for (int k = 0; k < i; ++k) {
                    Position v = this.add(random.nextInt(3) - 1, 1.0, random.nextInt(3) - 1);
                    Block block = this.getLevel().getBlock(v);
                    if (block.getId() == 0) {
                        if (!this.isSurroundingBlockFlammable(block)) continue;
                        BlockFire fire = new BlockFire();
                        this.getLevel().setBlock(v, fire, true);
                        this.getLevel().scheduleUpdate(v, fire.tickRate());
                        return 2;
                    }
                    if (!block.isSolid()) continue;
                    return 2;
                }
            } else {
                for (int k = 0; k < 3; ++k) {
                    Position v = this.add(random.nextInt(3) - 1, 0.0, random.nextInt(3) - 1);
                    Block block = this.getLevel().getBlock(v);
                    if (block.getSide(1).getId() != 0 || block.getBurnChance() <= 0) continue;
                    BlockFire fire = new BlockFire();
                    this.getLevel().setBlock(v, fire, true);
                    this.getLevel().scheduleUpdate(v, fire.tickRate());
                }
            }
        }
        return result;
    }

    protected boolean isSurroundingBlockFlammable(Block block) {
        for (int side = 0; side <= 5; ++side) {
            if (block.getSide(side).getBurnChance() <= 0) continue;
            return true;
        }
        return false;
    }

    @Override
    public BlockColor getColor() {
        return BlockColor.LAVA_BLOCK_COLOR;
    }

    @Override
    public BlockLiquid getBlock(int meta) {
        return new BlockLava(meta);
    }
}

