/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.block.BlockSolid;
import cn.axeon.item.Item;

public class BlockCobblestone
extends BlockSolid {
    public BlockCobblestone() {
        this(0);
    }

    public BlockCobblestone(int meta) {
        super(meta);
    }

    @Override
    public int getId() {
        return 4;
    }

    @Override
    public double getHardness() {
        return 2.0;
    }

    @Override
    public double getResistance() {
        return 30.0;
    }

    @Override
    public int getToolType() {
        return 3;
    }

    @Override
    public String getName() {
        return "Cobblestone";
    }

    @Override
    public int[][] getDrops(Item item) {
        if (item.isPickaxe() && item.getTier() >= 1) {
            return new int[][]{{4, 0, 1}};
        }
        return new int[0][];
    }
}

