/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.Player;
import cn.axeon.Server;
import cn.axeon.block.Block;
import cn.axeon.block.BlockFlowable;
import cn.axeon.block.BlockWater;
import cn.axeon.event.block.BlockGrowEvent;
import cn.axeon.item.Item;
import cn.axeon.math.Vector3;
import cn.axeon.utils.BlockColor;

public class BlockSugarcane
extends BlockFlowable {
    public BlockSugarcane() {
        this(0);
    }

    public BlockSugarcane(int meta) {
        super(0);
    }

    @Override
    public String getName() {
        return "Sugarcane";
    }

    @Override
    public int getId() {
        return 83;
    }

    @Override
    public int[][] getDrops(Item item) {
        return new int[][]{{338, 0, 1}};
    }

    @Override
    public boolean onActivate(Item item, Player player) {
        if (item.getId() == 351 && item.getDamage() == 15) {
            if (this.getSide(0).getId() != 83) {
                this.y = 1.0;
                while (this.y < 3.0) {
                    Block b = this.getLevel().getBlock(new Vector3(this.x, this.y + this.y, this.z));
                    if (b.getId() == 0) {
                        BlockGrowEvent ev = new BlockGrowEvent(b, new BlockSugarcane());
                        Server.getInstance().getPluginManager().callEvent(ev);
                        if (ev.isCancelled()) break;
                        this.getLevel().setBlock(b, ev.getNewState(), true);
                        break;
                    }
                    this.y += 1.0;
                }
                this.meta = 0;
                this.getLevel().setBlock(this, this, true);
            }
            if ((player.gamemode & 1) == 0) {
                --item.count;
            }
            return true;
        }
        return false;
    }

    @Override
    public int onUpdate(int type) {
        if (type == 1) {
            Block down = this.getSide(0);
            if (down.isTransparent() && down.getId() != 83) {
                this.getLevel().useBreakOn(this);
                return 1;
            }
        } else if (type == 2 && this.getSide(0).getId() != 83) {
            if (this.meta == 15) {
                this.y = 1.0;
                while (this.y < 3.0) {
                    Block b = this.getLevel().getBlock(new Vector3(this.x, this.y + this.y, this.z));
                    if (b.getId() == 0) {
                        this.getLevel().setBlock(b, new BlockSugarcane(), true);
                        break;
                    }
                    this.y += 1.0;
                }
                this.meta = 0;
                this.getLevel().setBlock(this, this, true);
            } else {
                ++this.meta;
                this.getLevel().setBlock(this, this, true);
            }
            return 2;
        }
        return 0;
    }

    @Override
    public boolean place(Item item, Block block, Block target, int face, double fx, double fy, double fz, Player player) {
        Block down = this.getSide(0);
        if (down.getId() == 83) {
            this.getLevel().setBlock(block, new BlockSugarcane(), true);
            return true;
        }
        if (down.getId() == 2 || down.getId() == 3 || down.getId() == 12) {
            Block block0 = down.getSide(2);
            Block block1 = down.getSide(3);
            Block block2 = down.getSide(4);
            Block block3 = down.getSide(5);
            if (block0 instanceof BlockWater || block1 instanceof BlockWater || block2 instanceof BlockWater || block3 instanceof BlockWater) {
                this.getLevel().setBlock(block, new BlockSugarcane(), true);
                return true;
            }
        }
        return false;
    }

    @Override
    public BlockColor getColor() {
        return BlockColor.FOLIAGE_BLOCK_COLOR;
    }
}

