/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.Player;
import cn.axeon.block.Block;
import cn.axeon.block.BlockTransparent;
import cn.axeon.blockentity.BlockEntity;
import cn.axeon.blockentity.BlockEntitySkull;
import cn.axeon.item.Item;
import cn.axeon.item.ItemSkull;
import cn.axeon.nbt.tag.CompoundTag;
import cn.axeon.nbt.tag.Tag;

public class BlockSkull
extends BlockTransparent {
    public BlockSkull() {
        this(0);
    }

    public BlockSkull(int meta) {
        super(meta);
    }

    @Override
    public int getId() {
        return 144;
    }

    @Override
    public double getHardness() {
        return 1.0;
    }

    @Override
    public double getResistance() {
        return 5.0;
    }

    @Override
    public boolean isSolid() {
        return false;
    }

    @Override
    public String getName() {
        BlockEntity blockEntity = this.getLevel().getBlockEntity(this);
        int itemMeta = 0;
        if (blockEntity != null) {
            itemMeta = blockEntity.namedTag.getByte("SkullType");
        }
        return ItemSkull.getItemSkullName(itemMeta);
    }

    @Override
    public boolean place(Item item, Block block, Block target, int face, double fx, double fy, double fz) {
        return this.place(item, block, target, face, fx, fy, fz, null);
    }

    @Override
    public boolean place(Item item, Block block, Block target, int face, double fx, double fy, double fz, Player player) {
        switch (face) {
            case 1: 
            case 2: 
            case 3: 
            case 4: 
            case 5: {
                this.meta = face;
                break;
            }
            default: {
                return false;
            }
        }
        this.getLevel().setBlock(block, this, true, true);
        CompoundTag nbt = new CompoundTag().putString("id", "Skull").putByte("SkullType", item.getDamage()).putInt("x", block.getFloorX()).putInt("y", block.getFloorY()).putInt("z", block.getFloorZ()).putByte("Rot", (int)Math.floor(player.yaw * 16.0 / 360.0 + 0.5) & 0xF);
        if (item.hasCustomBlockData()) {
            for (Tag aTag : item.getCustomBlockData().getAllTags()) {
                nbt.put(aTag.getName(), aTag);
            }
        }
        new BlockEntitySkull(this.getLevel().getChunk((int)block.x >> 4, (int)block.z >> 4), nbt);
        return true;
    }

    @Override
    public int[][] getDrops(Item item) {
        BlockEntity blockEntity = this.getLevel().getBlockEntity(this);
        int dropMeta = 0;
        if (blockEntity != null) {
            dropMeta = blockEntity.namedTag.getByte("SkullType");
        }
        return new int[][]{{397, dropMeta, 1}};
    }

    @Override
    public int getToolType() {
        return 3;
    }
}

