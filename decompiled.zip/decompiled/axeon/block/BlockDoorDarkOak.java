/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.block.BlockDoorWood;
import cn.axeon.item.Item;

public class BlockDoorDarkOak
extends BlockDoorWood {
    public BlockDoorDarkOak() {
        this(0);
    }

    public BlockDoorDarkOak(int meta) {
        super(meta);
    }

    @Override
    public String getName() {
        return "Dark Oak Door Block";
    }

    @Override
    public int getId() {
        return 197;
    }

    @Override
    public int[][] getDrops(Item item) {
        return new int[][]{{431, 0, 1}};
    }
}

