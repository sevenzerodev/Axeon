/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.Player;
import cn.axeon.block.Block;
import cn.axeon.block.BlockAir;
import cn.axeon.block.BlockTransparent;
import cn.axeon.event.block.DoorToggleEvent;
import cn.axeon.item.Item;
import cn.axeon.level.sound.DoorSound;
import cn.axeon.math.AxisAlignedBB;

public abstract class BlockDoor
extends BlockTransparent {
    protected BlockDoor(int meta) {
        super(meta);
    }

    @Override
    public boolean canBeActivated() {
        return true;
    }

    @Override
    public boolean isSolid() {
        return false;
    }

    private int getFullDamage() {
        int up;
        int down;
        boolean isUp;
        int damage = this.getDamage();
        boolean bl = isUp = (damage & 8) > 0;
        if (isUp) {
            down = this.getSide(0).getDamage();
            up = damage;
        } else {
            down = damage;
            up = this.getSide(1).getDamage();
        }
        boolean isRight = (up & 1) > 0;
        return down & 7 | (isUp ? 8 : 0) | (isRight ? 16 : 0);
    }

    @Override
    protected AxisAlignedBB recalculateBoundingBox() {
        boolean isRight;
        double f = 0.1875;
        int damage = this.getFullDamage();
        AxisAlignedBB bb = new AxisAlignedBB(this.x, this.y, this.z, this.x + 1.0, this.y + 2.0, this.z + 1.0);
        int j = damage & 3;
        boolean isOpen = (damage & 4) > 0;
        boolean bl = isRight = (damage & 0x10) > 0;
        if (j == 0) {
            if (isOpen) {
                if (!isRight) {
                    bb.setBounds(this.x, this.y, this.z, this.x + 1.0, this.y + 1.0, this.z + f);
                } else {
                    bb.setBounds(this.x, this.y, this.z + 1.0 - f, this.x + 1.0, this.y + 1.0, this.z + 1.0);
                }
            } else {
                bb.setBounds(this.x, this.y, this.z, this.x + f, this.y + 1.0, this.z + 1.0);
            }
        } else if (j == 1) {
            if (isOpen) {
                if (!isRight) {
                    bb.setBounds(this.x + 1.0 - f, this.y, this.z, this.x + 1.0, this.y + 1.0, this.z + 1.0);
                } else {
                    bb.setBounds(this.x, this.y, this.z, this.x + f, this.y + 1.0, this.z + 1.0);
                }
            } else {
                bb.setBounds(this.x, this.y, this.z, this.x + 1.0, this.y + 1.0, this.z + f);
            }
        } else if (j == 2) {
            if (isOpen) {
                if (!isRight) {
                    bb.setBounds(this.x, this.y, this.z + 1.0 - f, this.x + 1.0, this.y + 1.0, this.z + 1.0);
                } else {
                    bb.setBounds(this.x, this.y, this.z, this.x + 1.0, this.y + 1.0, this.z + f);
                }
            } else {
                bb.setBounds(this.x + 1.0 - f, this.y, this.z, this.x + 1.0, this.y + 1.0, this.z + 1.0);
            }
        } else if (j == 3) {
            if (isOpen) {
                if (!isRight) {
                    bb.setBounds(this.x, this.y, this.z, this.x + f, this.y + 1.0, this.z + 1.0);
                } else {
                    bb.setBounds(this.x + 1.0 - f, this.y, this.z, this.x + 1.0, this.y + 1.0, this.z + 1.0);
                }
            } else {
                bb.setBounds(this.x, this.y, this.z + 1.0 - f, this.x + 1.0, this.y + 1.0, this.z + 1.0);
            }
        }
        return bb;
    }

    @Override
    public int onUpdate(int type) {
        if (type == 1 && this.getSide(0).getId() == 0) {
            if (this.getSide(1) instanceof BlockDoor) {
                this.getLevel().setBlock(this.getSide(1), new BlockAir(), false);
                this.getLevel().useBreakOn(this);
            }
            return 1;
        }
        return 0;
    }

    @Override
    public boolean place(Item item, Block block, Block target, int face, double fx, double fy, double fz) {
        return this.place(item, block, target, face, fx, fy, fz, null);
    }

    @Override
    public boolean place(Item item, Block block, Block target, int face, double fx, double fy, double fz, Player player) {
        if (face == 1) {
            Block blockUp = this.getSide(1);
            Block blockDown = this.getSide(0);
            if (!blockUp.canBeReplaced() || blockDown.isTransparent()) {
                return false;
            }
            int direction = player != null ? player.getDirection() : 0;
            int[] faces = new int[]{3, 4, 2, 5};
            Block next = this.getSide(faces[(direction + 2) % 4]);
            Block next2 = this.getSide(faces[direction]);
            int metaUp = 8;
            if (next.getId() == this.getId() || !next2.isTransparent() && next.isTransparent()) {
                metaUp |= 1;
            }
            this.setDamage(direction & 3);
            this.getLevel().setBlock(block, this, true, true);
            this.getLevel().setBlock(blockUp, Block.get(this.getId(), metaUp), true);
            return true;
        }
        return false;
    }

    @Override
    public boolean onBreak(Item item) {
        if ((this.getDamage() & 8) == 8) {
            Block down = this.getSide(0);
            if (down.getId() == this.getId()) {
                this.getLevel().setBlock(down, new BlockAir(), true);
            }
        } else {
            Block up = this.getSide(1);
            if (up.getId() == this.getId()) {
                this.getLevel().setBlock(up, new BlockAir(), true);
            }
        }
        this.getLevel().setBlock(this, new BlockAir(), true);
        return true;
    }

    @Override
    public boolean onActivate(Item item) {
        return this.onActivate(item, null);
    }

    @Override
    public boolean onActivate(Item item, Player player) {
        if (!this.toggle(player)) {
            return false;
        }
        this.level.addSound(new DoorSound(this));
        return true;
    }

    public boolean toggle(Player player) {
        DoorToggleEvent event = new DoorToggleEvent(this, player);
        this.getLevel().getServer().getPluginManager().callEvent(event);
        if (event.isCancelled()) {
            return false;
        }
        if ((this.meta & 8) == 8) {
            Block down = this.getSide(0);
            if (down.getId() != this.getId()) {
                return false;
            }
            this.getLevel().setBlock(down, Block.get(this.getId(), down.getDamage() ^ 4), true);
        } else {
            this.meta ^= 4;
            this.getLevel().setBlock(this, this, true);
        }
        return true;
    }

    public boolean isOpen() {
        return (this.meta & 4) > 0;
    }
}

