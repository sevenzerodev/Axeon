/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.block.BlockCrops;
import cn.axeon.item.Item;
import java.util.Random;

public class BlockPotato
extends BlockCrops {
    public BlockPotato(int meta) {
        super(meta);
    }

    public BlockPotato() {
        this(0);
    }

    @Override
    public String getName() {
        return "Potato Block";
    }

    @Override
    public int getId() {
        return 142;
    }

    @Override
    public int[][] getDrops(Item item) {
        if (this.meta >= 7) {
            return new int[][]{{392, 0, new Random().nextInt(3) + 1}};
        }
        return new int[][]{{392, 0, 1}};
    }
}

