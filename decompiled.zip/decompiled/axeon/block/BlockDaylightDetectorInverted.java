/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.block.BlockDaylightDetector;
import cn.axeon.item.Item;

public class BlockDaylightDetectorInverted
extends BlockDaylightDetector {
    public BlockDaylightDetectorInverted() {
        this(0);
    }

    public BlockDaylightDetectorInverted(int meta) {
        super(meta);
    }

    @Override
    public int getId() {
        return 178;
    }

    @Override
    public String getName() {
        return "Daylight Detector Inverted";
    }

    @Override
    public int[][] getDrops(Item item) {
        return new int[][]{{178, 0, 1}};
    }

    @Override
    protected boolean invertDetect() {
        return true;
    }
}

