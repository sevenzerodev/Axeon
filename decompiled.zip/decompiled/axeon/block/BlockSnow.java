/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.block.BlockSolid;
import cn.axeon.item.Item;
import cn.axeon.utils.BlockColor;

public class BlockSnow
extends BlockSolid {
    public BlockSnow() {
        this(0);
    }

    public BlockSnow(int meta) {
        super(meta);
    }

    @Override
    public String getName() {
        return "Snow Block";
    }

    @Override
    public int getId() {
        return 80;
    }

    @Override
    public double getHardness() {
        return 0.2;
    }

    @Override
    public double getResistance() {
        return 1.0;
    }

    @Override
    public int getToolType() {
        return 2;
    }

    @Override
    public int[][] getDrops(Item item) {
        if (item.isShovel()) {
            return new int[][]{{332, 0, 4}};
        }
        return new int[0][];
    }

    @Override
    public BlockColor getColor() {
        return BlockColor.SNOW_BLOCK_COLOR;
    }
}

