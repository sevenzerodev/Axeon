/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.block.BlockCrops;
import cn.axeon.item.Item;
import java.util.Random;

public class BlockCarrot
extends BlockCrops {
    public BlockCarrot(int meta) {
        super(meta);
    }

    public BlockCarrot() {
        this(0);
    }

    @Override
    public String getName() {
        return "Carrot Block";
    }

    @Override
    public int getId() {
        return 141;
    }

    @Override
    public int[][] getDrops(Item item) {
        if (this.meta >= 7) {
            return new int[][]{{391, 0, new Random().nextInt(3) + 1}};
        }
        return new int[][]{{391, 0, 1}};
    }
}

