/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.Player;
import cn.axeon.Server;
import cn.axeon.block.Block;
import cn.axeon.block.BlockTransparent;
import cn.axeon.entity.Entity;
import cn.axeon.event.block.BlockGrowEvent;
import cn.axeon.event.entity.EntityDamageByBlockEvent;
import cn.axeon.item.Item;
import cn.axeon.math.AxisAlignedBB;
import cn.axeon.math.Vector3;
import cn.axeon.utils.BlockColor;

public class BlockCactus
extends BlockTransparent {
    public BlockCactus(int meta) {
        super(meta);
    }

    public BlockCactus() {
        this(0);
    }

    @Override
    public int getId() {
        return 81;
    }

    @Override
    public double getHardness() {
        return 0.4;
    }

    @Override
    public double getResistance() {
        return 2.0;
    }

    @Override
    public boolean hasEntityCollision() {
        return true;
    }

    @Override
    protected AxisAlignedBB recalculateBoundingBox() {
        return new AxisAlignedBB(this.x + 0.0625, this.y + 0.0625, this.z + 0.0625, this.x + 0.9375, this.y + 0.9375, this.z + 0.9375);
    }

    @Override
    public void onEntityCollide(Entity entity) {
        entity.attack(new EntityDamageByBlockEvent(this, entity, 0, 1.0f));
    }

    @Override
    public int onUpdate(int type) {
        if (type == 1) {
            Block down = this.getSide(0);
            if (down.getId() != 12 && down.getId() != 81) {
                this.getLevel().useBreakOn(this);
            } else {
                for (int side = 2; side <= 5; ++side) {
                    Block block = this.getSide(side);
                    if (block.canBeFlowedInto()) continue;
                    this.getLevel().useBreakOn(this);
                }
            }
        } else if (type == 2 && this.getSide(0).getId() != 81) {
            if (this.meta == 15) {
                for (int y = 1; y < 3; ++y) {
                    Block b = this.getLevel().getBlock(new Vector3(this.x, this.y + (double)y, this.z));
                    if (b.getId() != 0) continue;
                    BlockGrowEvent event = new BlockGrowEvent(b, new BlockCactus());
                    Server.getInstance().getPluginManager().callEvent(event);
                    if (event.isCancelled()) continue;
                    this.getLevel().setBlock(b, event.getNewState(), true);
                }
                this.meta = 0;
                this.getLevel().setBlock(this, this);
            } else {
                ++this.meta;
                this.getLevel().setBlock(this, this);
            }
        }
        return 0;
    }

    @Override
    public boolean place(Item item, Block block, Block target, int face, double fx, double fy, double fz, Player player) {
        Block down = this.getSide(0);
        if (down.getId() == 12 || down.getId() == 81) {
            Block block0 = this.getSide(2);
            Block block1 = this.getSide(3);
            Block block2 = this.getSide(4);
            Block block3 = this.getSide(5);
            if (block0.isTransparent() && block1.isTransparent() && block2.isTransparent() && block3.isTransparent()) {
                this.getLevel().setBlock(this, this, true);
                return true;
            }
        }
        return false;
    }

    @Override
    public int[][] getDrops(Item item) {
        return new int[][]{{this.getId(), 0, 1}};
    }

    @Override
    public String getName() {
        return "Cactus";
    }

    @Override
    public BlockColor getColor() {
        return BlockColor.FOLIAGE_BLOCK_COLOR;
    }
}

