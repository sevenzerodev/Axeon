/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.Player;
import cn.axeon.block.Block;
import cn.axeon.block.BlockTransparent;
import cn.axeon.event.block.DoorToggleEvent;
import cn.axeon.item.Item;
import cn.axeon.level.sound.DoorSound;
import cn.axeon.math.AxisAlignedBB;
import cn.axeon.utils.BlockColor;

public class BlockFenceGate
extends BlockTransparent {
    public BlockFenceGate() {
        this(0);
    }

    public BlockFenceGate(int meta) {
        super(meta);
    }

    @Override
    public int getId() {
        return 107;
    }

    @Override
    public String getName() {
        return "Oak Fence Gate";
    }

    @Override
    public double getHardness() {
        return 2.0;
    }

    @Override
    public double getResistance() {
        return 15.0;
    }

    @Override
    public boolean canBeActivated() {
        return true;
    }

    @Override
    public int getToolType() {
        return 4;
    }

    @Override
    protected AxisAlignedBB recalculateBoundingBox() {
        if ((this.getDamage() & 4) > 0) {
            return null;
        }
        int i = this.getDamage() & 3;
        if (i == 2 || i == 0) {
            return new AxisAlignedBB(this.x, this.y, this.z + 0.375, this.x + 1.0, this.y + 1.5, this.z + 0.625);
        }
        return new AxisAlignedBB(this.x + 0.375, this.y, this.z, this.x + 0.625, this.y + 1.5, this.z + 1.0);
    }

    @Override
    public boolean place(Item item, Block block, Block target, int face, double fx, double fy, double fz, Player player) {
        int[] faces = new int[]{3, 0, 1, 2};
        this.meta = faces[player != null ? player.getDirection() : 0] & 3;
        this.getLevel().setBlock(block, this, true, true);
        return true;
    }

    @Override
    public int[][] getDrops(Item item) {
        return new int[][]{{this.getId(), 0, 1}};
    }

    @Override
    public boolean onActivate(Item item, Player player) {
        if (player == null) {
            return false;
        }
        if (!this.toggle(player)) {
            return false;
        }
        this.getLevel().setBlock(this, this, true);
        this.getLevel().addSound(new DoorSound(this));
        return true;
    }

    @Override
    public BlockColor getColor() {
        return BlockColor.WOOD_BLOCK_COLOR;
    }

    public boolean toggle(Player player) {
        int originDirection;
        DoorToggleEvent event = new DoorToggleEvent(this, player);
        this.getLevel().getServer().getPluginManager().callEvent(event);
        if (event.isCancelled()) {
            return false;
        }
        player = event.getPlayer();
        if (player == null) {
            return false;
        }
        double yaw = player.yaw;
        double rotation = (yaw - 90.0) % 360.0;
        if (rotation < 0.0) {
            rotation += 360.0;
        }
        int direction = (originDirection = this.getDamage() & 1) == 0 ? (rotation >= 0.0 && rotation < 180.0 ? 2 : 0) : (rotation >= 90.0 && rotation < 270.0 ? 3 : 1);
        this.setDamage(direction | ~this.getDamage() & 4);
        return true;
    }

    public boolean isOpen() {
        return (this.meta & 4) > 0;
    }
}

