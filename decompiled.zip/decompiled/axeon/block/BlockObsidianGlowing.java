/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.block.BlockObsidian;
import cn.axeon.item.Item;

public class BlockObsidianGlowing
extends BlockObsidian {
    public BlockObsidianGlowing() {
        this(0);
    }

    public BlockObsidianGlowing(int meta) {
        super(meta);
    }

    @Override
    public int getId() {
        return 246;
    }

    @Override
    public String getName() {
        return "Glowing Obsidian";
    }

    @Override
    public double getResistance() {
        return 6000.0;
    }

    @Override
    public int getLightLevel() {
        return 12;
    }

    @Override
    public int[][] getDrops(Item item) {
        if (item.isPickaxe() && item.getTier() > 278) {
            return new int[][]{{246, 0, 1}};
        }
        return new int[0][];
    }
}

