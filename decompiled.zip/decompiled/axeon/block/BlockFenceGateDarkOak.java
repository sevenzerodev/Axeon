/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.block.BlockFenceGate;

public class BlockFenceGateDarkOak
extends BlockFenceGate {
    public BlockFenceGateDarkOak() {
        this(0);
    }

    public BlockFenceGateDarkOak(int meta) {
        super(meta);
    }

    @Override
    public int getId() {
        return 186;
    }

    @Override
    public String getName() {
        return "Dark Oak Fence Gate";
    }
}

