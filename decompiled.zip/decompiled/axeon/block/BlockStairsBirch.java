/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.block.BlockStairsWood;

public class BlockStairsBirch
extends BlockStairsWood {
    public BlockStairsBirch() {
        this(0);
    }

    public BlockStairsBirch(int meta) {
        super(meta);
    }

    @Override
    public int getId() {
        return 135;
    }

    @Override
    public String getName() {
        return "Birch Wood Stairs";
    }
}

