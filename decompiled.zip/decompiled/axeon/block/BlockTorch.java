/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.Player;
import cn.axeon.block.Block;
import cn.axeon.block.BlockFence;
import cn.axeon.block.BlockFlowable;
import cn.axeon.item.Item;
import cn.axeon.utils.BlockColor;

public class BlockTorch
extends BlockFlowable {
    public BlockTorch() {
        this(0);
    }

    public BlockTorch(int meta) {
        super(meta);
    }

    @Override
    public String getName() {
        return "Torch";
    }

    @Override
    public int getId() {
        return 50;
    }

    @Override
    public int getLightLevel() {
        return 15;
    }

    @Override
    public int onUpdate(int type) {
        if (type == 1) {
            Block below = this.getSide(0);
            int[] faces = new int[]{0, 4, 5, 2, 3, 0, 0};
            int side = this.getDamage();
            if (this.getSide(faces[side]).isTransparent() && (side != 0 || !(below instanceof BlockFence) && below.getId() != 139)) {
                this.getLevel().useBreakOn(this);
                return 1;
            }
        }
        return 0;
    }

    @Override
    public boolean place(Item item, Block block, Block target, int face, double fx, double fy, double fz, Player player) {
        Block below = this.getSide(0);
        if (!target.isTransparent() && face != 0) {
            int[] faces = new int[]{0, 5, 4, 3, 2, 1};
            this.meta = faces[face];
            this.getLevel().setBlock(block, this, true, true);
            return true;
        }
        if (!below.isTransparent() || below instanceof BlockFence || below.getId() == 139) {
            this.meta = 0;
            this.getLevel().setBlock(block, this, true, true);
            return true;
        }
        return false;
    }

    @Override
    public int[][] getDrops(Item item) {
        return new int[][]{{this.getId(), 0, 1}};
    }

    @Override
    public BlockColor getColor() {
        return BlockColor.AIR_BLOCK_COLOR;
    }
}

