/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.Player;
import cn.axeon.block.Block;
import cn.axeon.block.BlockFlowable;
import cn.axeon.item.Item;
import cn.axeon.utils.BlockColor;
import java.util.Random;

public class BlockTallGrass
extends BlockFlowable {
    public BlockTallGrass() {
        this(1);
    }

    public BlockTallGrass(int meta) {
        super(meta);
    }

    @Override
    public int getId() {
        return 31;
    }

    @Override
    public String getName() {
        String[] names = new String[]{"Dead Shrub", "Tall Grass", "Fern", ""};
        return names[this.meta & 3];
    }

    @Override
    public boolean canBeActivated() {
        return true;
    }

    @Override
    public boolean canBeReplaced() {
        return true;
    }

    @Override
    public int getBurnChance() {
        return 60;
    }

    @Override
    public int getBurnAbility() {
        return 100;
    }

    @Override
    public boolean place(Item item, Block block, Block target, int face, double fx, double fy, double fz, Player player) {
        Block down = this.getSide(0);
        if (down.getId() == 2 || down.getId() == 3 || down.getId() == 243) {
            this.getLevel().setBlock(block, this, true);
            return true;
        }
        return false;
    }

    @Override
    public int onUpdate(int type) {
        if (type == 1 && this.getSide(0).isTransparent()) {
            this.getLevel().useBreakOn(this);
            return 1;
        }
        return 0;
    }

    @Override
    public boolean onActivate(Item item) {
        return this.onActivate(item, null);
    }

    @Override
    public boolean onActivate(Item item, Player player) {
        return false;
    }

    @Override
    public int[][] getDrops(Item item) {
        boolean dropSeeds;
        boolean bl = dropSeeds = new Random().nextInt(10) == 0;
        if (item.isShears()) {
            if (dropSeeds) {
                return new int[][]{{295, 0, 1}, {31, this.meta, 1}};
            }
            return new int[][]{{31, this.meta, 1}};
        }
        if (dropSeeds) {
            return new int[][]{{295, 0, 1}};
        }
        return new int[0][];
    }

    @Override
    public int getToolType() {
        return 5;
    }

    @Override
    public BlockColor getColor() {
        return BlockColor.FOLIAGE_BLOCK_COLOR;
    }
}

