/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.block.Block;
import cn.axeon.block.BlockDirt;
import cn.axeon.block.BlockTransparent;
import cn.axeon.block.BlockWater;
import cn.axeon.item.Item;
import cn.axeon.math.AxisAlignedBB;
import cn.axeon.math.Vector3;
import cn.axeon.utils.BlockColor;

public class BlockFarmland
extends BlockTransparent {
    public BlockFarmland() {
        this(0);
    }

    public BlockFarmland(int meta) {
        super(meta);
    }

    @Override
    public String getName() {
        return "Farmland";
    }

    @Override
    public int getId() {
        return 60;
    }

    @Override
    public double getResistance() {
        return 3.0;
    }

    @Override
    public double getHardness() {
        return 0.6;
    }

    @Override
    public int getToolType() {
        return 2;
    }

    @Override
    protected AxisAlignedBB recalculateBoundingBox() {
        return new AxisAlignedBB(this.x, this.y, this.z, this.x + 1.0, this.y + 0.9375, this.z + 1.0);
    }

    @Override
    public int onUpdate(int type) {
        if (type == 2) {
            boolean found = false;
            Vector3 v = new Vector3();
            int x = (int)this.x - 1;
            while ((double)x <= this.x + 1.0) {
                int z = (int)this.z - 1;
                while ((double)z <= this.z + 1.0) {
                    Block block;
                    if (((double)z != this.z || (double)x != this.x) && (block = this.level.getBlock(v.setComponents(x, this.y, z))) instanceof BlockWater) {
                        found = true;
                        break;
                    }
                    ++z;
                }
                ++x;
            }
            Block block = this.level.getBlock(v.setComponents(this.x, this.y - 1.0, this.z));
            if (found || block instanceof BlockWater) {
                return 2;
            }
            this.level.setBlock(this, new BlockDirt(), true, true);
            return 2;
        }
        return 0;
    }

    @Override
    public int[][] getDrops(Item item) {
        return new int[][]{{3, 0, 1}};
    }

    @Override
    public BlockColor getColor() {
        return BlockColor.DIRT_BLOCK_COLOR;
    }
}

