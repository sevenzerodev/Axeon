/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.Player;
import cn.axeon.block.Block;
import cn.axeon.block.BlockAir;
import cn.axeon.block.BlockFlowable;
import cn.axeon.block.BlockSolid;
import cn.axeon.item.Item;
import cn.axeon.redstone.Redstone;
import cn.axeon.utils.BlockColor;

public class BlockRedstoneWire
extends BlockFlowable {
    public BlockRedstoneWire() {
        this(0);
    }

    public BlockRedstoneWire(int meta) {
        super(meta);
        this.powerLevel = meta;
    }

    @Override
    public String getName() {
        return "Redstone Wire";
    }

    @Override
    public int getId() {
        return 55;
    }

    @Override
    public void setPowerLevel(int redstonePower) {
        if (redstonePower > 15) {
            redstonePower = 15;
        } else if (redstonePower < 0) {
            redstonePower = 0;
        }
        this.powerLevel = redstonePower;
        this.meta = redstonePower;
    }

    @Override
    public int getNeighborPowerLevel() {
        Block block;
        int power = 0;
        int tempLevel = this.getSide(0).getPowerLevel();
        power = tempLevel > power ? tempLevel : power;
        tempLevel = this.getSide(1).getPowerLevel();
        power = tempLevel > power ? tempLevel : power;
        for (int side : new int[]{2, 3, 4, 5}) {
            Block blockDown;
            block = this.getSide(side);
            tempLevel = block.getPowerLevel();
            int n = power = tempLevel > power ? tempLevel : power;
            if (block instanceof BlockSolid || !((blockDown = block.getSide(0)) instanceof BlockRedstoneWire)) continue;
            tempLevel = blockDown.getPowerLevel();
            power = tempLevel > power ? tempLevel : power;
        }
        Block topBlock = this.getSide(1);
        if (!(topBlock instanceof BlockSolid)) {
            for (int side : new int[]{2, 3, 4, 5}) {
                block = topBlock.getSide(side);
                if (!(block instanceof BlockRedstoneWire)) continue;
                tempLevel = block.getPowerLevel();
                power = tempLevel > power ? tempLevel : power;
            }
        }
        return power;
    }

    @Override
    public int onUpdate(int type) {
        if (type == 1 && this.getSide(0).isTransparent()) {
            this.getLevel().useBreakOn(this);
            return 1;
        }
        return 0;
    }

    @Override
    public boolean place(Item item, Block block, Block target, int face, double fx, double fy, double fz, Player player) {
        if (this.getSide(0).isTransparent()) {
            return false;
        }
        this.setPowerLevel(this.getNeighborPowerLevel() - 1);
        block.getLevel().setBlock(block, this, true, true);
        Redstone.active(this);
        return true;
    }

    @Override
    public boolean onBreak(Item item) {
        int level = this.getPowerLevel();
        this.getLevel().setBlock(this, new BlockAir(), true, false);
        Redstone.deactive(this, level);
        return true;
    }

    @Override
    public int[][] getDrops(Item item) {
        return new int[][]{{331, 0, 1}};
    }

    @Override
    public BlockColor getColor() {
        return BlockColor.AIR_BLOCK_COLOR;
    }
}

