/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.Player;
import cn.axeon.block.Block;
import cn.axeon.block.BlockAir;
import cn.axeon.block.BlockSolid;
import cn.axeon.blockentity.BlockEntity;
import cn.axeon.blockentity.BlockEntityFurnace;
import cn.axeon.item.Item;
import cn.axeon.nbt.tag.CompoundTag;
import cn.axeon.nbt.tag.ListTag;
import cn.axeon.nbt.tag.StringTag;
import cn.axeon.nbt.tag.Tag;
import java.util.Map;

public class BlockFurnaceBurning
extends BlockSolid {
    public BlockFurnaceBurning() {
        this(0);
    }

    public BlockFurnaceBurning(int meta) {
        super(meta);
    }

    @Override
    public int getId() {
        return 62;
    }

    @Override
    public String getName() {
        return "Burning Furnace";
    }

    @Override
    public boolean canBeActivated() {
        return true;
    }

    @Override
    public double getHardness() {
        return 3.5;
    }

    @Override
    public double getResistance() {
        return 17.5;
    }

    @Override
    public int getToolType() {
        return 3;
    }

    @Override
    public int getLightLevel() {
        return 13;
    }

    @Override
    public boolean place(Item item, Block block, Block target, int face, double fx, double fy, double fz, Player player) {
        int[] faces = new int[]{4, 2, 5, 3};
        this.meta = faces[player != null ? player.getDirection() : 0];
        this.getLevel().setBlock(block, this, true, true);
        CompoundTag nbt = new CompoundTag().putList(new ListTag("Items")).putString("id", "Furnace").putInt("x", (int)this.x).putInt("y", (int)this.y).putInt("z", (int)this.z);
        if (item.hasCustomName()) {
            nbt.putString("CustomName", item.getCustomName());
        }
        if (item.hasCustomBlockData()) {
            Map<String, Tag> customData = item.getCustomBlockData().getTags();
            for (Map.Entry<String, Tag> tag : customData.entrySet()) {
                nbt.put(tag.getKey(), tag.getValue());
            }
        }
        new BlockEntityFurnace(this.getLevel().getChunk((int)this.x >> 4, (int)this.z >> 4), nbt);
        return true;
    }

    @Override
    public boolean onBreak(Item item) {
        this.getLevel().setBlock(this, new BlockAir(), true, true);
        return true;
    }

    @Override
    public boolean onActivate(Item item, Player player) {
        if (player != null) {
            BlockEntityFurnace furnace;
            BlockEntity t = this.getLevel().getBlockEntity(this);
            if (t instanceof BlockEntityFurnace) {
                furnace = (BlockEntityFurnace)t;
            } else {
                CompoundTag nbt = new CompoundTag().putList(new ListTag("Items")).putString("id", "Furnace").putInt("x", (int)this.x).putInt("y", (int)this.y).putInt("z", (int)this.z);
                furnace = new BlockEntityFurnace(this.getLevel().getChunk((int)this.x >> 4, (int)this.z >> 4), nbt);
            }
            if (furnace.namedTag.contains("Lock") && furnace.namedTag.get("Lock") instanceof StringTag && !furnace.namedTag.getString("Lock").equals(item.getCustomName())) {
                return true;
            }
            player.addWindow(furnace.getInventory());
        }
        return true;
    }

    @Override
    public int[][] getDrops(Item item) {
        if (item.isPickaxe() && item.getTier() >= 1) {
            return new int[][]{{61, 0, 1}};
        }
        return new int[0][];
    }
}

