/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.Player;
import cn.axeon.block.BlockFarmland;
import cn.axeon.block.BlockSolid;
import cn.axeon.item.Item;
import cn.axeon.utils.BlockColor;

public class BlockDirt
extends BlockSolid {
    public BlockDirt() {
        this(0);
    }

    public BlockDirt(int meta) {
        super(0);
    }

    @Override
    public int getId() {
        return 3;
    }

    @Override
    public boolean canBeActivated() {
        return true;
    }

    @Override
    public double getResistance() {
        return 2.5;
    }

    @Override
    public int[][] getDrops(Item item) {
        return new int[][]{{3, 0, 1}};
    }

    @Override
    public double getHardness() {
        return 0.5;
    }

    @Override
    public int getToolType() {
        return 2;
    }

    @Override
    public String getName() {
        return "Dirt";
    }

    @Override
    public boolean onActivate(Item item) {
        return this.onActivate(item, null);
    }

    @Override
    public boolean onActivate(Item item, Player player) {
        if (item.isHoe()) {
            item.useOn(this);
            this.getLevel().setBlock(this, new BlockFarmland(), true);
            return true;
        }
        return false;
    }

    @Override
    public BlockColor getColor() {
        return BlockColor.DIRT_BLOCK_COLOR;
    }
}

