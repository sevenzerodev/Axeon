/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.block.Block;

public class BlockUnknown
extends Block {
    private int id;

    public BlockUnknown(int id) {
        this(id, (Integer)0);
    }

    public BlockUnknown(int id, Integer meta) {
        super(meta);
        this.id = id;
    }

    @Override
    public int getId() {
        return this.id;
    }

    @Override
    public String getName() {
        return "Unknown";
    }
}

