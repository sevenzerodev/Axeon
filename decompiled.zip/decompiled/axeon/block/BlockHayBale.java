/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.Player;
import cn.axeon.block.Block;
import cn.axeon.block.BlockSolid;
import cn.axeon.item.Item;
import cn.axeon.utils.BlockColor;

public class BlockHayBale
extends BlockSolid {
    public BlockHayBale() {
        this(0);
    }

    public BlockHayBale(int meta) {
        super(meta);
    }

    @Override
    public int getId() {
        return 170;
    }

    @Override
    public String getName() {
        return "Hay Bale";
    }

    @Override
    public double getHardness() {
        return 0.5;
    }

    @Override
    public int getBurnChance() {
        return 60;
    }

    @Override
    public int getBurnAbility() {
        return 20;
    }

    @Override
    public boolean place(Item item, Block block, Block target, int face, double fx, double fy, double fz, Player player) {
        int[] faces = new int[]{0, 0, 8, 8, 4, 4};
        this.meta = this.meta & 3 | faces[face];
        this.getLevel().setBlock(block, this, true, true);
        return true;
    }

    @Override
    public int[][] getDrops(Item item) {
        return new int[][]{{this.getId(), 0, 1}};
    }

    @Override
    public BlockColor getColor() {
        return BlockColor.GRASS_BLOCK_COLOR;
    }
}

