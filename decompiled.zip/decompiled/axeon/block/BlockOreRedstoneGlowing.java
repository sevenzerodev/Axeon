/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.block.BlockOreRedstone;

public class BlockOreRedstoneGlowing
extends BlockOreRedstone {
    public BlockOreRedstoneGlowing() {
        this(0);
    }

    public BlockOreRedstoneGlowing(int meta) {
        super(0);
    }

    @Override
    public String getName() {
        return "Glowing Redstone Ore";
    }

    @Override
    public int getId() {
        return 74;
    }

    @Override
    public int getLightLevel() {
        return 9;
    }

    @Override
    public int onUpdate(int type) {
        if (type == 3 || type == 2) {
            this.getLevel().setBlock(this, new BlockOreRedstone(this.meta), false, false);
            return 4;
        }
        return 0;
    }
}

