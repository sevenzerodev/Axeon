/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.block.BlockSolid;
import cn.axeon.item.Item;

public class BlockStonecutter
extends BlockSolid {
    public BlockStonecutter() {
        this(0);
    }

    public BlockStonecutter(int meta) {
        super(meta);
    }

    @Override
    public int getId() {
        return 245;
    }

    @Override
    public String getName() {
        return "Stonecutter";
    }

    @Override
    public int getToolType() {
        return 3;
    }

    @Override
    public double getResistance() {
        return 17.5;
    }

    @Override
    public int[][] getDrops(Item item) {
        return new int[][]{{245, 0, 1}};
    }
}

