/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.block.BlockSolid;
import cn.axeon.item.Item;
import cn.axeon.utils.BlockColor;

public class BlockDoubleSlab
extends BlockSolid {
    public static final int STONE = 0;
    public static final int SANDSTONE = 1;
    public static final int WOODEN = 2;
    public static final int COBBLESTONE = 3;
    public static final int BRICK = 4;
    public static final int STONE_BRICK = 5;
    public static final int QUARTZ = 6;
    public static final int NETHER_BRICK = 7;

    public BlockDoubleSlab() {
        this(0);
    }

    public BlockDoubleSlab(int meta) {
        super(meta);
    }

    @Override
    public int getId() {
        return 43;
    }

    @Override
    public double getHardness() {
        return 2.0;
    }

    @Override
    public int getToolType() {
        return 3;
    }

    @Override
    public String getName() {
        String[] names = new String[]{"Stone", "Sandstone", "Wooden", "Cobblestone", "Brick", "Stone Brick", "Quartz", "Nether Brick"};
        return "Double " + names[this.meta & 7] + " Slab";
    }

    @Override
    public int[][] getDrops(Item item) {
        if (item.isPickaxe() && item.getTier() >= 1) {
            return new int[][]{{44, this.meta & 7, 2}};
        }
        return new int[0][];
    }

    @Override
    public BlockColor getColor() {
        switch (this.meta & 7) {
            case 0: {
                return BlockColor.STONE_BLOCK_COLOR;
            }
            case 1: {
                return BlockColor.SAND_BLOCK_COLOR;
            }
            case 2: {
                return BlockColor.WOOD_BLOCK_COLOR;
            }
            case 3: {
                return BlockColor.STONE_BLOCK_COLOR;
            }
            case 4: {
                return BlockColor.STONE_BLOCK_COLOR;
            }
            case 5: {
                return BlockColor.STONE_BLOCK_COLOR;
            }
            case 6: {
                return BlockColor.QUARTZ_BLOCK_COLOR;
            }
            case 7: {
                return BlockColor.NETHERRACK_BLOCK_COLOR;
            }
        }
        return BlockColor.STONE_BLOCK_COLOR;
    }
}

