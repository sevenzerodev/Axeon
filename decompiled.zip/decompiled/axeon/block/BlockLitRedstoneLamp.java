/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.block.BlockRedstoneLamp;
import cn.axeon.item.Item;

public class BlockLitRedstoneLamp
extends BlockRedstoneLamp {
    public BlockLitRedstoneLamp(int meta) {
        super(meta);
    }

    public BlockLitRedstoneLamp() {
        this(0);
    }

    @Override
    public String getName() {
        return "Lit Redstone Lamp";
    }

    @Override
    public int getId() {
        return 124;
    }

    @Override
    public int getLightLevel() {
        return 15;
    }

    @Override
    public int onUpdate(int type) {
        if ((type == 1 || type == 3) && this.getNeighborPowerLevel() <= 0) {
            this.getLevel().setBlock(this, new BlockRedstoneLamp());
        }
        return 0;
    }

    @Override
    public int[][] getDrops(Item item) {
        return new int[][]{{123, 0, 1}};
    }
}

