/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.block.BlockSolid;
import cn.axeon.utils.BlockColor;

public class BlockClayHardened
extends BlockSolid {
    public BlockClayHardened() {
        this(0);
    }

    public BlockClayHardened(int meta) {
        super(0);
    }

    @Override
    public int getId() {
        return 172;
    }

    @Override
    public String getName() {
        return "Hardened Clay";
    }

    @Override
    public int getToolType() {
        return 3;
    }

    @Override
    public double getHardness() {
        return 1.25;
    }

    @Override
    public double getResistance() {
        return 7.0;
    }

    @Override
    public BlockColor getColor() {
        return BlockColor.ADOBE_BLOCK_COLOR;
    }
}

