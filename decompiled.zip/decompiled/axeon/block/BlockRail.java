/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.Player;
import cn.axeon.block.Block;
import cn.axeon.block.BlockFlowable;
import cn.axeon.item.Item;
import cn.axeon.math.Vector3;
import cn.axeon.utils.BlockColor;
import java.util.ArrayList;

public class BlockRail
extends BlockFlowable {
    public BlockRail() {
        this(0);
    }

    public BlockRail(int meta) {
        super(meta);
    }

    @Override
    public String getName() {
        return "Rail";
    }

    @Override
    public int getId() {
        return 66;
    }

    @Override
    public double getHardness() {
        return 0.7;
    }

    @Override
    public double getResistance() {
        return 3.5;
    }

    @Override
    public int getToolType() {
        return 3;
    }

    @Override
    public int onUpdate(int type) {
        if (type == 1 && this.getSide(0).isTransparent()) {
            this.getLevel().useBreakOn(this);
            return 1;
        }
        return 0;
    }

    @Override
    public int[][] getDrops(Item item) {
        return new int[][]{{66, 0, 1}};
    }

    @Override
    public BlockColor getColor() {
        return BlockColor.AIR_BLOCK_COLOR;
    }

    @Override
    public boolean place(Item item, Block block, Block target, int face, double fx, double fy, double fz, Player player) {
        Block down = this.getSide(0);
        if (down == null) {
            return false;
        }
        if (down.isTransparent()) {
            return false;
        }
        int[][] arrayXZ = new int[][]{{1, 0}, {0, 1}, {-1, 0}, {0, -1}};
        int[] arrayY = new int[]{0, 1, -1};
        ArrayList<Block> connected = new ArrayList<Block>();
        for (int[] xz : arrayXZ) {
            int x = xz[0];
            int z = xz[1];
            for (int y : arrayY) {
                Vector3 v3 = new Vector3(x, y, z).add(this);
                Block v3block = this.getLevel().getBlock(v3);
                if (v3block == null || !BlockRail.isRailBlock(v3block.getId()) || !BlockRail.isValidRailMeta(v3block.getDamage()) || !(v3block instanceof BlockRail)) continue;
                this.connectRail(v3block);
                connected.add(v3block);
            }
            if (connected.size() >= 2) break;
        }
        if (connected.size() == 1) {
            Vector3 v3 = ((Vector3)connected.get(0)).subtract(this);
            this.meta = v3.y != 1.0 ? (v3.x == 0.0 ? 0 : 1) : (int)(v3.z == 0.0 ? v3.x / -2.0 + 2.5 : v3.z / 2.0 + 4.5);
        } else if (connected.size() == 2) {
            Vector3[] subtract = new Vector3[2];
            for (int i = 0; i < connected.size(); ++i) {
                subtract[i] = ((Vector3)connected.get(i)).subtract(this);
            }
            if (Math.abs(subtract[0].x) == Math.abs(subtract[1].z) && Math.abs(subtract[1].x) == Math.abs(subtract[0].z)) {
                Vector3 v3 = ((Vector3)connected.get(0)).subtract(this).add(((Vector3)connected.get(1)).subtract(this));
                this.meta = v3.x == 1.0 ? (v3.z == 1.0 ? 6 : 9) : (v3.z == 1.0 ? 7 : 8);
            } else if (subtract[0].y == 1.0 || subtract[1].y == 1.0) {
                Vector3 v3;
                Vector3 vector3 = v3 = subtract[0].y == 1.0 ? subtract[0] : subtract[1];
                this.meta = v3.x == 0.0 ? (v3.z == -1.0 ? 4 : 5) : (v3.x == 1.0 ? 2 : 3);
            } else {
                this.meta = subtract[0].x == 0.0 ? 0 : 1;
            }
        }
        this.getLevel().setBlock(this, Block.get(this.getId(), this.getDamage()), true, true);
        return true;
    }

    protected Vector3[] canConnectRail(Block block) {
        if (!(block instanceof BlockRail)) {
            return null;
        }
        if (this.distanceSquared(block) > 2.0) {
            return null;
        }
        Vector3[] result = BlockRail.checkRail(this);
        if (result.length == 2) {
            return null;
        }
        return result;
    }

    protected void connectRail(Block rail) {
        Vector3[] connected = this.canConnectRail(rail);
        if (connected == null) {
            return;
        }
        if (connected.length == 1) {
            Vector3 v3 = connected[0].subtract(this);
            this.meta = v3.y != 1.0 ? (v3.x == 0.0 ? 0 : 1) : (int)(v3.z == 0.0 ? v3.x / -2.0 + 2.5 : v3.z / 2.0 + 4.5);
        } else if (connected.length == 2) {
            Vector3[] subtract = new Vector3[2];
            for (int i = 0; i < connected.length; ++i) {
                subtract[i] = connected[i].subtract(this);
            }
            if (Math.abs(subtract[0].x) == Math.abs(subtract[1].z) && Math.abs(subtract[1].x) == Math.abs(subtract[0].z)) {
                Vector3 v3 = connected[0].subtract(this).add(connected[1].subtract(this));
                this.meta = v3.x == 1.0 ? (v3.z == 1.0 ? 6 : 9) : (v3.z == 1.0 ? 7 : 8);
            } else if (subtract[0].y == 1.0 || subtract[1].y == 1.0) {
                Vector3 v3;
                Vector3 vector3 = v3 = subtract[0].y == 1.0 ? subtract[0] : subtract[1];
                this.meta = v3.x == 0.0 ? (v3.z == -1.0 ? 4 : 5) : (v3.x == 1.0 ? 2 : 3);
            } else {
                this.meta = subtract[0].x == 0.0 ? 0 : 1;
            }
        }
        this.getLevel().setBlock(this, Block.get(this.getId(), this.getDamage()), true, true);
    }

    protected static Vector3[] checkRail(Block rail) {
        int zDiff;
        int xDiff;
        int metaToConnect;
        int idToConnect;
        Vector3 v3;
        if (!(rail instanceof BlockRail)) {
            return null;
        }
        int damage = rail.getDamage();
        if (damage < 0 || damage > 10) {
            return null;
        }
        int[][][] delta = new int[][][]{new int[][]{{0, 1}, {0, -1}}, new int[][]{{1, 0}, {-1, 0}}, new int[][]{{1, 0}, {-1, 0}}, new int[][]{{1, 0}, {-1, 0}}, new int[][]{{0, 1}, {0, -1}}, new int[][]{{0, 1}, {0, -1}}, new int[][]{{1, 0}, {0, 1}}, new int[][]{{0, 1}, {-1, 0}}, new int[][]{{-1, 0}, {0, -1}}, new int[][]{{0, -1}, {1, 0}}};
        int[] deltaY = new int[]{0, 1, -1};
        int[][] blocks = delta[damage];
        ArrayList<Vector3> connected = new ArrayList<Vector3>();
        for (int y : deltaY) {
            v3 = new Vector3(rail.getFloorX() + blocks[0][0], rail.getFloorY() + y, rail.getFloorZ() + blocks[0][1]);
            idToConnect = rail.getLevel().getBlockIdAt(v3.getFloorX(), v3.getFloorY(), v3.getFloorZ());
            metaToConnect = rail.getLevel().getBlockDataAt(v3.getFloorX(), v3.getFloorY(), v3.getFloorZ());
            if (!BlockRail.isRailBlock(idToConnect) || !BlockRail.isValidRailMeta(metaToConnect)) continue;
            xDiff = damage - v3.getFloorX();
            zDiff = damage - v3.getFloorZ();
            for (int[] xz : blocks) {
                if (xz[0] != xDiff || xz[1] != zDiff) continue;
                connected.add(v3);
            }
        }
        for (int y : deltaY) {
            v3 = new Vector3(rail.getFloorX() + blocks[1][0], rail.getFloorY() + y, rail.getFloorZ() + blocks[1][1]);
            idToConnect = rail.getLevel().getBlockIdAt(v3.getFloorX(), v3.getFloorY(), v3.getFloorZ());
            metaToConnect = rail.getLevel().getBlockDataAt(v3.getFloorX(), v3.getFloorY(), v3.getFloorZ());
            if (!BlockRail.isRailBlock(idToConnect) || !BlockRail.isValidRailMeta(metaToConnect)) continue;
            xDiff = damage - v3.getFloorX();
            zDiff = damage - v3.getFloorZ();
            for (int[] xz : blocks) {
                if (xz[0] != xDiff || xz[1] != zDiff) continue;
                connected.add(v3);
            }
        }
        return connected.toArray(new Vector3[connected.size()]);
    }

    protected static boolean isRailBlock(int id) {
        switch (id) {
            case 27: 
            case 28: 
            case 66: 
            case 126: {
                return true;
            }
        }
        return false;
    }

    protected static boolean isValidRailMeta(int meta) {
        return meta >= 0 && meta <= 10;
    }
}

