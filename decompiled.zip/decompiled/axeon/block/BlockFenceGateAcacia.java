/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.block.BlockFenceGate;

public class BlockFenceGateAcacia
extends BlockFenceGate {
    public BlockFenceGateAcacia() {
        this(0);
    }

    public BlockFenceGateAcacia(int meta) {
        super(meta);
    }

    @Override
    public int getId() {
        return 187;
    }

    @Override
    public String getName() {
        return "Acacia Fence Gate";
    }
}

