/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.block.BlockSolid;
import cn.axeon.item.Item;
import cn.axeon.math.NukkitRandom;

public class BlockOreEmerald
extends BlockSolid {
    public BlockOreEmerald() {
        this(0);
    }

    public BlockOreEmerald(int meta) {
        super(0);
    }

    @Override
    public String getName() {
        return "Emerald Ore";
    }

    @Override
    public int getId() {
        return 129;
    }

    @Override
    public int getToolType() {
        return 3;
    }

    @Override
    public double getHardness() {
        return 3.0;
    }

    @Override
    public double getResistance() {
        return 15.0;
    }

    @Override
    public int[][] getDrops(Item item) {
        if (item.isPickaxe()) {
            return new int[][]{{388, 0, 1}};
        }
        return new int[0][];
    }

    @Override
    public int getDropExp() {
        return new NukkitRandom().nextRange(3, 7);
    }
}

