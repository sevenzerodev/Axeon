/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.block.BlockSolid;
import cn.axeon.item.Item;
import cn.axeon.math.NukkitRandom;
import java.util.Random;

public class BlockOreLapis
extends BlockSolid {
    public BlockOreLapis() {
        this(0);
    }

    public BlockOreLapis(int meta) {
        super(0);
    }

    @Override
    public int getId() {
        return 21;
    }

    @Override
    public double getHardness() {
        return 3.0;
    }

    @Override
    public double getResistance() {
        return 5.0;
    }

    @Override
    public int getToolType() {
        return 3;
    }

    @Override
    public String getName() {
        return "Lapis Lazuli Ore";
    }

    @Override
    public int[][] getDrops(Item item) {
        if (item.isPickaxe() && item.getTier() >= 3) {
            return new int[][]{{351, 4, new Random().nextInt(4) + 4}};
        }
        return new int[0][];
    }

    @Override
    public int getDropExp() {
        return new NukkitRandom().nextRange(2, 5);
    }
}

