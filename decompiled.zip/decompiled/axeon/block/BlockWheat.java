/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.block.BlockCrops;
import cn.axeon.item.Item;

public class BlockWheat
extends BlockCrops {
    public BlockWheat() {
        this(0);
    }

    public BlockWheat(int meta) {
        super(meta);
    }

    @Override
    public String getName() {
        return "Wheat Block";
    }

    @Override
    public int getId() {
        return 59;
    }

    @Override
    public int[][] getDrops(Item item) {
        if (this.meta >= 7) {
            return new int[][]{{296, 0, 1}, {295, 0, (int)(4.0 * Math.random())}};
        }
        return new int[][]{{295, 0, 1}};
    }
}

