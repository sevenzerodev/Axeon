/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.block.BlockWeightedPressurePlate;
import cn.axeon.item.Item;

public class BlockWeightedPressurePlateLight
extends BlockWeightedPressurePlate {
    public BlockWeightedPressurePlateLight(int meta) {
        super(meta);
    }

    public BlockWeightedPressurePlateLight() {
        this(0);
    }

    @Override
    public String getName() {
        return "Light Weighted Pressure Plate";
    }

    @Override
    public int getId() {
        return 147;
    }

    @Override
    public double getHardness() {
        return 0.5;
    }

    @Override
    public double getResistance() {
        return 2.5;
    }

    @Override
    public int getToolType() {
        return 3;
    }

    @Override
    public int[][] getDrops(Item item) {
        if (item.isPickaxe()) {
            return new int[][]{{147, 0, 1}};
        }
        return new int[][]{new int[0]};
    }
}

