/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.block.BlockSolid;
import cn.axeon.item.ItemDye;
import cn.axeon.utils.BlockColor;

public class BlockWool
extends BlockSolid {
    public BlockWool() {
        this(0);
    }

    public BlockWool(int meta) {
        super(meta);
    }

    @Override
    public String getName() {
        return ItemDye.getColorName(this.meta) + " Wool";
    }

    @Override
    public int getId() {
        return 35;
    }

    @Override
    public int getToolType() {
        return 5;
    }

    @Override
    public double getHardness() {
        return 0.8;
    }

    @Override
    public double getResistance() {
        return 4.0;
    }

    @Override
    public int getBurnChance() {
        return 30;
    }

    @Override
    public int getBurnAbility() {
        return 60;
    }

    @Override
    public BlockColor getColor() {
        return BlockColor.getDyeColor(this.meta);
    }
}

