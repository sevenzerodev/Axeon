/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.Player;
import cn.axeon.block.Block;
import cn.axeon.block.BlockFlowable;
import cn.axeon.blockentity.BlockEntity;
import cn.axeon.blockentity.BlockEntityFlowerPot;
import cn.axeon.item.Item;
import cn.axeon.nbt.tag.CompoundTag;
import cn.axeon.nbt.tag.Tag;

public class BlockFlowerPot
extends BlockFlowable {
    public BlockFlowerPot() {
        this(0);
    }

    public BlockFlowerPot(int meta) {
        super(meta);
    }

    @Override
    public String getName() {
        return "Flower Pot";
    }

    @Override
    public int getId() {
        return 140;
    }

    @Override
    public double getHardness() {
        return 0.0;
    }

    @Override
    public double getResistance() {
        return 0.0;
    }

    @Override
    public boolean place(Item item, Block block, Block target, int face, double fx, double fy, double fz) {
        return super.place(item, block, target, face, fx, fy, fz);
    }

    @Override
    public boolean place(Item item, Block block, Block target, int face, double fx, double fy, double fz, Player player) {
        if (face != 1) {
            return false;
        }
        CompoundTag nbt = new CompoundTag().putString("id", "FlowerPot").putInt("x", (int)this.x).putInt("y", (int)this.y).putInt("z", (int)this.z).putShort("item", 0).putInt("data", 0);
        if (item.hasCustomBlockData()) {
            for (Tag aTag : item.getCustomBlockData().getAllTags()) {
                nbt.put(aTag.getName(), aTag);
            }
        }
        new BlockEntityFlowerPot(this.getLevel().getChunk((int)block.x >> 4, (int)block.z >> 4), nbt);
        this.getLevel().setBlock(block, this, true, true);
        return true;
    }

    @Override
    public boolean canBeActivated() {
        return true;
    }

    @Override
    public boolean onActivate(Item item) {
        return this.onActivate(item, null);
    }

    @Override
    public boolean onActivate(Item item, Player player) {
        int itemMeta;
        int itemID;
        BlockEntity blockEntity = this.getLevel().getBlockEntity(this);
        if (!(blockEntity instanceof BlockEntityFlowerPot)) {
            return false;
        }
        if (blockEntity.namedTag.getShort("item") != 0 || blockEntity.namedTag.getInt("mData") != 0) {
            return false;
        }
        if (!BlockFlowerPot.canPlaceIntoFlowerPot(item.getId())) {
            if (!BlockFlowerPot.canPlaceIntoFlowerPot(item.getBlock().getId())) {
                return false;
            }
            itemID = item.getBlock().getId();
            itemMeta = item.getDamage();
        } else {
            itemID = item.getId();
            itemMeta = item.getDamage();
        }
        blockEntity.namedTag.putShort("item", itemID);
        blockEntity.namedTag.putInt("data", itemMeta);
        this.meta = 1;
        this.getLevel().setBlock(this, this, true);
        ((BlockEntityFlowerPot)blockEntity).spawnToAll();
        if (player.isSurvival()) {
            item.setCount(item.getCount() - 1);
            player.getInventory().setItemInHand(item.getCount() > 0 ? item : Item.get(0));
        }
        return true;
    }

    @Override
    public int[][] getDrops(Item item) {
        boolean dropInside = false;
        int insideID = 0;
        int insideMeta = 0;
        BlockEntity blockEntity = this.getLevel().getBlockEntity(this);
        if (blockEntity instanceof BlockEntityFlowerPot) {
            dropInside = true;
            insideID = blockEntity.namedTag.getShort("item");
            insideMeta = blockEntity.namedTag.getInt("data");
        }
        if (dropInside) {
            return new int[][]{{390, 0, 1}, {insideID, insideMeta, 1}};
        }
        return new int[][]{{390, 0, 1}};
    }

    protected static boolean canPlaceIntoFlowerPot(int id) {
        switch (id) {
            case 6: 
            case 30: 
            case 31: 
            case 32: 
            case 37: 
            case 38: 
            case 39: 
            case 40: 
            case 81: 
            case 83: {
                return true;
            }
        }
        return false;
    }
}

