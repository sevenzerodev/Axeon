/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.block.BlockTransparent;

public abstract class BlockWeightedPressurePlate
extends BlockTransparent {
    public BlockWeightedPressurePlate(int meta) {
        super(meta);
    }

    public BlockWeightedPressurePlate() {
        this(0);
    }

    @Override
    public boolean canPassThrough() {
        return true;
    }
}

