/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.Player;
import cn.axeon.block.Block;
import cn.axeon.block.BlockDoubleSlab;
import cn.axeon.block.BlockTransparent;
import cn.axeon.item.Item;
import cn.axeon.math.AxisAlignedBB;
import cn.axeon.utils.BlockColor;

public class BlockSlab
extends BlockTransparent {
    public static final int STONE = 0;
    public static final int SANDSTONE = 1;
    public static final int WOODEN = 2;
    public static final int COBBLESTONE = 3;
    public static final int BRICK = 4;
    public static final int STONE_BRICK = 5;
    public static final int QUARTZ = 6;
    public static final int NETHER_BRICK = 7;

    public BlockSlab() {
        this(0);
    }

    public BlockSlab(int meta) {
        super(meta);
    }

    @Override
    public int getId() {
        return 44;
    }

    @Override
    public double getHardness() {
        return 2.0;
    }

    @Override
    public String getName() {
        String[] names = new String[]{"Stone", "Sandstone", "Wooden", "Cobblestone", "Brick", "Stone Brick", "Quartz", "Nether Brick"};
        return ((this.meta & 8) > 0 ? "Upper " : "") + names[this.meta & 7] + " Slab";
    }

    @Override
    protected AxisAlignedBB recalculateBoundingBox() {
        if ((this.meta & 8) > 0) {
            return new AxisAlignedBB(this.x, this.y + 0.5, this.z, this.x + 1.0, this.y + 1.0, this.z + 1.0);
        }
        return new AxisAlignedBB(this.x, this.y, this.z, this.x + 1.0, this.y + 0.5, this.z + 1.0);
    }

    @Override
    public boolean place(Item item, Block block, Block target, int face, double fx, double fy, double fz) {
        return this.place(item, block, target, face, fx, fy, fz, null);
    }

    @Override
    public boolean place(Item item, Block block, Block target, int face, double fx, double fy, double fz, Player player) {
        this.meta &= 7;
        if (face == 0) {
            if (target.getId() == 44 && (target.getDamage() & 8) == 8 && (target.getDamage() & 7) == (this.meta & 7)) {
                this.getLevel().setBlock(target, new BlockDoubleSlab(this.meta), true);
                return true;
            }
            if (block.getId() == 44 && (block.getDamage() & 7) == (this.meta & 7)) {
                this.getLevel().setBlock(block, new BlockDoubleSlab(this.meta), true);
                return true;
            }
            this.meta |= 8;
        } else if (face == 1) {
            if (target.getId() == 44 && (target.getDamage() & 8) == 0 && (target.getDamage() & 7) == (this.meta & 7)) {
                this.getLevel().setBlock(target, new BlockDoubleSlab(this.meta), true);
                return true;
            }
            if (block.getId() == 44 && (block.getDamage() & 7) == (this.meta & 7)) {
                this.getLevel().setBlock(block, new BlockDoubleSlab(this.meta), true);
                return true;
            }
        } else {
            if (block.getId() == 44) {
                if ((block.getDamage() & 7) == (this.meta & 7)) {
                    this.getLevel().setBlock(block, new BlockDoubleSlab(this.meta), true);
                    return true;
                }
                return false;
            }
            if (fy > 0.5) {
                this.meta |= 8;
            }
        }
        if (block.getId() == 44 && (target.getDamage() & 7) != (this.meta & 7)) {
            return false;
        }
        this.getLevel().setBlock(block, this, true, true);
        return true;
    }

    @Override
    public int[][] getDrops(Item item) {
        if (item.isPickaxe() && item.getTier() >= 1) {
            return new int[][]{{this.getId(), this.meta & 7, 1}};
        }
        return new int[0][];
    }

    @Override
    public int getToolType() {
        return 3;
    }

    @Override
    public BlockColor getColor() {
        switch (this.meta & 7) {
            case 0: {
                return BlockColor.STONE_BLOCK_COLOR;
            }
            case 1: {
                return BlockColor.SAND_BLOCK_COLOR;
            }
            case 2: {
                return BlockColor.WOOD_BLOCK_COLOR;
            }
            case 3: {
                return BlockColor.STONE_BLOCK_COLOR;
            }
            case 4: {
                return BlockColor.STONE_BLOCK_COLOR;
            }
            case 5: {
                return BlockColor.STONE_BLOCK_COLOR;
            }
            case 6: {
                return BlockColor.QUARTZ_BLOCK_COLOR;
            }
            case 7: {
                return BlockColor.NETHERRACK_BLOCK_COLOR;
            }
        }
        return BlockColor.STONE_BLOCK_COLOR;
    }
}

