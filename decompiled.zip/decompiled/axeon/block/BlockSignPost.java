/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.Player;
import cn.axeon.block.Block;
import cn.axeon.block.BlockTransparent;
import cn.axeon.block.BlockWallSign;
import cn.axeon.blockentity.BlockEntitySign;
import cn.axeon.item.Item;
import cn.axeon.math.AxisAlignedBB;
import cn.axeon.nbt.tag.CompoundTag;
import cn.axeon.nbt.tag.Tag;
import cn.axeon.utils.BlockColor;

public class BlockSignPost
extends BlockTransparent {
    public BlockSignPost() {
        this(0);
    }

    public BlockSignPost(int meta) {
        super(meta);
    }

    @Override
    public int getId() {
        return 63;
    }

    @Override
    public double getHardness() {
        return 1.0;
    }

    @Override
    public double getResistance() {
        return 5.0;
    }

    @Override
    public boolean isSolid() {
        return false;
    }

    @Override
    public String getName() {
        return "Sign Post";
    }

    @Override
    public AxisAlignedBB getBoundingBox() {
        return null;
    }

    @Override
    public boolean place(Item item, Block block, Block target, int face, double fx, double fy, double fz, Player player) {
        if (face != 0) {
            CompoundTag nbt = new CompoundTag().putString("id", "Sign").putInt("x", (int)block.x).putInt("y", (int)block.y).putInt("z", (int)block.z).putString("Text1", "").putString("Text2", "").putString("Text3", "").putString("Text4", "");
            if (face == 1) {
                this.meta = (int)Math.floor((player.yaw + 180.0) * 16.0 / 360.0 + 0.5) & 0xF;
                this.getLevel().setBlock(block, new BlockSignPost(this.meta), true);
            } else {
                this.meta = face;
                this.getLevel().setBlock(block, new BlockWallSign(this.meta), true);
            }
            if (player != null) {
                nbt.putString("Creator", player.getUniqueId().toString());
            }
            if (item.hasCustomBlockData()) {
                for (Tag aTag : item.getCustomBlockData().getAllTags()) {
                    nbt.put(aTag.getName(), aTag);
                }
            }
            new BlockEntitySign(this.getLevel().getChunk((int)block.x >> 4, (int)block.z >> 4), nbt);
            return true;
        }
        return false;
    }

    @Override
    public int onUpdate(int type) {
        if (type == 1 && this.getSide(0).getId() == 0) {
            this.getLevel().useBreakOn(this);
            return 1;
        }
        return 0;
    }

    @Override
    public int[][] getDrops(Item item) {
        return new int[][]{{323, 0, 1}};
    }

    @Override
    public int getToolType() {
        return 4;
    }

    @Override
    public BlockColor getColor() {
        return BlockColor.AIR_BLOCK_COLOR;
    }
}

