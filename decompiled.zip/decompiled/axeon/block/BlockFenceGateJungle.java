/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.block.BlockFenceGate;

public class BlockFenceGateJungle
extends BlockFenceGate {
    public BlockFenceGateJungle() {
        this(0);
    }

    public BlockFenceGateJungle(int meta) {
        super(meta);
    }

    @Override
    public int getId() {
        return 185;
    }

    @Override
    public String getName() {
        return "Jungle Fence Gate";
    }
}

