/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.block.BlockGrass;
import cn.axeon.math.AxisAlignedBB;
import cn.axeon.utils.BlockColor;

public class BlockGrassPath
extends BlockGrass {
    public BlockGrassPath() {
        this(0);
    }

    public BlockGrassPath(int meta) {
        super(0);
    }

    @Override
    public int getId() {
        return 198;
    }

    @Override
    public String getName() {
        return "Grass Path";
    }

    @Override
    public int getToolType() {
        return 2;
    }

    @Override
    protected AxisAlignedBB recalculateBoundingBox() {
        return new AxisAlignedBB(this.x, this.y, this.z, this.x + 1.0, this.y + 0.9375, this.z + 1.0);
    }

    @Override
    public double getResistance() {
        return 3.25;
    }

    @Override
    public BlockColor getColor() {
        return BlockColor.GRASS_BLOCK_COLOR;
    }
}

