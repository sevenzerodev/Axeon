/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.Server;
import cn.axeon.block.Block;
import cn.axeon.block.BlockCrops;
import cn.axeon.block.BlockPumpkin;
import cn.axeon.event.block.BlockGrowEvent;
import cn.axeon.item.Item;
import cn.axeon.math.NukkitRandom;

public class BlockStemPumpkin
extends BlockCrops {
    public BlockStemPumpkin() {
        this(0);
    }

    public BlockStemPumpkin(int meta) {
        super(meta);
    }

    @Override
    public int getId() {
        return 104;
    }

    @Override
    public String getName() {
        return "Pumpkin Stem";
    }

    @Override
    public int onUpdate(int type) {
        if (type == 1) {
            if (this.getSide(0).isTransparent()) {
                this.getLevel().useBreakOn(this);
                return 1;
            }
        } else if (type == 2) {
            NukkitRandom random = new NukkitRandom();
            if (random.nextRange(1, 2) == 1) {
                if (this.meta < 7) {
                    Block block = this.clone();
                    ++block.meta;
                    BlockGrowEvent ev = new BlockGrowEvent(this, block);
                    Server.getInstance().getPluginManager().callEvent(ev);
                    if (!ev.isCancelled()) {
                        this.getLevel().setBlock(this, ev.getNewState(), true);
                    }
                    return 2;
                }
                for (int side = 2; side <= 5; ++side) {
                    Block b = this.getSide(side);
                    if (b.getId() != 86) continue;
                    return 2;
                }
                Block side = this.getSide(random.nextRange(2, 5));
                Block d = side.getSide(0);
                if (side.getId() == 0 && (d.getId() == 60 || d.getId() == 2 || d.getId() == 3)) {
                    BlockGrowEvent ev = new BlockGrowEvent(side, new BlockPumpkin());
                    Server.getInstance().getPluginManager().callEvent(ev);
                    if (!ev.isCancelled()) {
                        this.getLevel().setBlock(side, ev.getNewState(), true);
                    }
                }
            }
            return 2;
        }
        return 0;
    }

    @Override
    public int[][] getDrops(Item item) {
        NukkitRandom random = new NukkitRandom();
        return new int[][]{{361, 0, random.nextRange(0, 2)}};
    }
}

