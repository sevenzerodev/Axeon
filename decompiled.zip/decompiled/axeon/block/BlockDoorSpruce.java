/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.block.BlockDoorWood;
import cn.axeon.item.Item;

public class BlockDoorSpruce
extends BlockDoorWood {
    public BlockDoorSpruce() {
        this(0);
    }

    public BlockDoorSpruce(int meta) {
        super(meta);
    }

    @Override
    public String getName() {
        return "Spruce Door Block";
    }

    @Override
    public int getId() {
        return 193;
    }

    @Override
    public int[][] getDrops(Item item) {
        return new int[][]{{427, 0, 1}};
    }
}

