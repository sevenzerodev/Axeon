/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.Player;
import cn.axeon.block.Block;
import cn.axeon.block.BlockSolid;
import cn.axeon.blockentity.BlockEntity;
import cn.axeon.blockentity.BlockEntityEnchantTable;
import cn.axeon.inventory.EnchantInventory;
import cn.axeon.item.Item;
import cn.axeon.nbt.tag.CompoundTag;
import cn.axeon.nbt.tag.ListTag;
import cn.axeon.nbt.tag.StringTag;
import cn.axeon.nbt.tag.Tag;
import java.util.Map;

public class BlockEnchantingTable
extends BlockSolid {
    public BlockEnchantingTable() {
        this(0);
    }

    public BlockEnchantingTable(int meta) {
        super(meta);
    }

    @Override
    public int getId() {
        return 116;
    }

    @Override
    public String getName() {
        return "Enchanting Table";
    }

    @Override
    public int getToolType() {
        return 3;
    }

    @Override
    public double getHardness() {
        return 5.0;
    }

    @Override
    public double getResistance() {
        return 6000.0;
    }

    @Override
    public boolean canBeActivated() {
        return true;
    }

    @Override
    public int[][] getDrops(Item item) {
        if (item.isPickaxe()) {
            return new int[][]{{116, 0, 1}};
        }
        return new int[][]{new int[0]};
    }

    @Override
    public boolean place(Item item, Block block, Block target, int face, double fx, double fy, double fz, Player player) {
        this.getLevel().setBlock(block, this, true, true);
        CompoundTag nbt = new CompoundTag().putString("id", "EnchantTable").putInt("x", (int)this.x).putInt("y", (int)this.y).putInt("z", (int)this.z);
        if (item.hasCustomName()) {
            nbt.putString("CustomName", item.getCustomName());
        }
        if (item.hasCustomBlockData()) {
            Map<String, Tag> customData = item.getCustomBlockData().getTags();
            for (Map.Entry<String, Tag> tag : customData.entrySet()) {
                nbt.put(tag.getKey(), tag.getValue());
            }
        }
        BlockEntity.createBlockEntity("EnchantTable", this.getLevel().getChunk((int)this.x >> 4, (int)this.z >> 4), nbt, new Object[0]);
        return true;
    }

    @Override
    public boolean onActivate(Item item, Player player) {
        if (player != null) {
            BlockEntityEnchantTable enchantTable;
            BlockEntity t = this.getLevel().getBlockEntity(this);
            if (t instanceof BlockEntityEnchantTable) {
                enchantTable = (BlockEntityEnchantTable)t;
            } else {
                CompoundTag nbt = new CompoundTag().putList(new ListTag("Items")).putString("id", "EnchantTable").putInt("x", (int)this.x).putInt("y", (int)this.y).putInt("z", (int)this.z);
                enchantTable = new BlockEntityEnchantTable(this.getLevel().getChunk((int)this.x >> 4, (int)this.z >> 4), nbt);
            }
            if (enchantTable.namedTag.contains("Lock") && enchantTable.namedTag.get("Lock") instanceof StringTag && !enchantTable.namedTag.getString("Lock").equals(item.getCustomName())) {
                return true;
            }
            player.addWindow(new EnchantInventory(this.getLocation()));
        }
        return true;
    }
}

