/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.block.BlockCrops;
import cn.axeon.item.Item;

public class BlockBeetroot
extends BlockCrops {
    public BlockBeetroot() {
        this(0);
    }

    public BlockBeetroot(int meta) {
        super(meta);
    }

    @Override
    public int getId() {
        return 244;
    }

    @Override
    public String getName() {
        return "Beetroot Block";
    }

    @Override
    public int[][] getDrops(Item item) {
        if (this.meta >= 7) {
            return new int[][]{{457, 0, 1}, {458, 0, (int)(4.0 * Math.random())}};
        }
        return new int[][]{{458, 0, 1}};
    }
}

