/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.block.BlockStairsWood;

public class BlockStairsDarkOak
extends BlockStairsWood {
    public BlockStairsDarkOak() {
        this(0);
    }

    public BlockStairsDarkOak(int meta) {
        super(meta);
    }

    @Override
    public int getId() {
        return 164;
    }

    @Override
    public String getName() {
        return "Dark Oak Wood Stairs";
    }
}

