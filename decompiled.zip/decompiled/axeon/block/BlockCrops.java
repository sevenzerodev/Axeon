/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.Player;
import cn.axeon.Server;
import cn.axeon.block.Block;
import cn.axeon.block.BlockFlowable;
import cn.axeon.event.block.BlockGrowEvent;
import cn.axeon.item.Item;
import cn.axeon.utils.BlockColor;
import java.util.Random;

public abstract class BlockCrops
extends BlockFlowable {
    protected BlockCrops(int meta) {
        super(meta);
    }

    @Override
    public boolean canBeActivated() {
        return true;
    }

    @Override
    public boolean place(Item item, Block block, Block target, int face, double fx, double fy, double fz) {
        return this.place(item, block, target, face, fx, fy, fz, null);
    }

    @Override
    public boolean place(Item item, Block block, Block target, int face, double fx, double fy, double fz, Player player) {
        Block down = this.getSide(0);
        if (down.getId() == 60) {
            this.getLevel().setBlock(block, this, true, true);
            return true;
        }
        return false;
    }

    @Override
    public boolean onActivate(Item item) {
        return this.onActivate(item, null);
    }

    @Override
    public boolean onActivate(Item item, Player player) {
        if (item.getId() == 351 && item.getDamage() == 15) {
            BlockCrops block = (BlockCrops)this.clone();
            block.meta += new Random().nextInt(3) + 2;
            if (block.meta > 7) {
                block.meta = 7;
            }
            BlockGrowEvent ev = new BlockGrowEvent(this, block);
            Server.getInstance().getPluginManager().callEvent(ev);
            if (ev.isCancelled()) {
                return false;
            }
            this.getLevel().setBlock(this, ev.getNewState(), true, true);
            --item.count;
            return true;
        }
        return false;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public int onUpdate(int type) {
        if (type == 1) {
            if (this.getSide(0).getId() == 60) return 0;
            this.getLevel().useBreakOn(this);
            return 1;
        }
        if (type != 2) return 0;
        if (new Random().nextInt(2) != 1) return 2;
        if (this.meta >= 7) return 0;
        BlockCrops block = (BlockCrops)this.clone();
        ++block.meta;
        BlockGrowEvent ev = new BlockGrowEvent(this, block);
        Server.getInstance().getPluginManager().callEvent(ev);
        if (ev.isCancelled()) return 2;
        this.getLevel().setBlock(this, ev.getNewState(), true, true);
        return 0;
    }

    @Override
    public BlockColor getColor() {
        return BlockColor.FOLIAGE_BLOCK_COLOR;
    }
}

