/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.Player;
import cn.axeon.block.Block;
import cn.axeon.block.BlockAir;
import cn.axeon.block.BlockTransparent;
import cn.axeon.item.Item;
import cn.axeon.item.food.Food;
import cn.axeon.math.AxisAlignedBB;
import cn.axeon.utils.BlockColor;

public class BlockCake
extends BlockTransparent {
    public BlockCake(int meta) {
        super(meta);
    }

    public BlockCake() {
        this(0);
    }

    @Override
    public String getName() {
        return "Cake Block";
    }

    @Override
    public int getId() {
        return 92;
    }

    @Override
    public boolean canBeActivated() {
        return true;
    }

    @Override
    public double getHardness() {
        return 0.5;
    }

    @Override
    public double getResistance() {
        return 2.5;
    }

    @Override
    protected AxisAlignedBB recalculateBoundingBox() {
        return new AxisAlignedBB(this.x + (double)((1 + this.getDamage() * 2) / 16), this.y, this.z + 0.0625, this.x - 0.0625 + 1.0, this.y + 0.5, this.z - 0.0625 + 1.0);
    }

    @Override
    public boolean place(Item item, Block block, Block target, int face, double fx, double fy, double fz, Player player) {
        if (this.getSide(0).getId() != 0) {
            this.getLevel().setBlock(block, this, true, true);
            return true;
        }
        return false;
    }

    @Override
    public int onUpdate(int type) {
        if (type == 1 && this.getSide(0).getId() == 0) {
            this.getLevel().setBlock(this, new BlockAir(), true);
            return 1;
        }
        return 0;
    }

    @Override
    public int[][] getDrops(Item item) {
        return new int[0][];
    }

    @Override
    public boolean onActivate(Item item, Player player) {
        if (player != null && player.getFoodData().getLevel() < player.getFoodData().getMaxLevel()) {
            if (this.meta <= 6) {
                ++this.meta;
            }
            if (this.meta >= 6) {
                this.getLevel().setBlock(this, new BlockAir(), true);
            } else {
                Food.getByRelative(this).eatenBy(player);
                this.getLevel().setBlock(this, this, true);
            }
            return true;
        }
        return false;
    }

    @Override
    public BlockColor getColor() {
        return BlockColor.AIR_BLOCK_COLOR;
    }
}

