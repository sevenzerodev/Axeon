/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.block.BlockThin;
import cn.axeon.item.Item;
import cn.axeon.utils.BlockColor;

public class BlockGlassPane
extends BlockThin {
    public BlockGlassPane() {
        this(0);
    }

    public BlockGlassPane(int meta) {
        super(0);
    }

    @Override
    public String getName() {
        return "Glass Pane";
    }

    @Override
    public int getId() {
        return 102;
    }

    @Override
    public double getResistance() {
        return 1.5;
    }

    @Override
    public double getHardness() {
        return 0.3;
    }

    @Override
    public int[][] getDrops(Item item) {
        return new int[0][];
    }

    @Override
    public BlockColor getColor() {
        return BlockColor.AIR_BLOCK_COLOR;
    }
}

