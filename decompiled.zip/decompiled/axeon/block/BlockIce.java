/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.block.BlockTransparent;
import cn.axeon.block.BlockWater;
import cn.axeon.item.Item;
import cn.axeon.utils.BlockColor;

public class BlockIce
extends BlockTransparent {
    public BlockIce() {
        this(0);
    }

    public BlockIce(int meta) {
        super(0);
    }

    @Override
    public int getId() {
        return 79;
    }

    @Override
    public String getName() {
        return "Ice";
    }

    @Override
    public double getResistance() {
        return 2.5;
    }

    @Override
    public double getHardness() {
        return 0.5;
    }

    @Override
    public double getFrictionFactor() {
        return 0.98;
    }

    @Override
    public int getToolType() {
        return 3;
    }

    @Override
    public boolean onBreak(Item item) {
        this.getLevel().setBlock(this, new BlockWater(), true);
        return true;
    }

    @Override
    public int onUpdate(int type) {
        if (type == 2 && this.getLevel().getBlockLightAt((int)this.x, (int)this.y, (int)this.z) >= 12) {
            this.getLevel().setBlock(this, new BlockWater(), true);
            return 1;
        }
        return 0;
    }

    @Override
    public int[][] getDrops(Item item) {
        return new int[0][0];
    }

    @Override
    public BlockColor getColor() {
        return BlockColor.ICE_BLOCK_COLOR;
    }
}

