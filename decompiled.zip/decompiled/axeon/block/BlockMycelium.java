/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.Server;
import cn.axeon.block.Block;
import cn.axeon.block.BlockSolid;
import cn.axeon.block.BlockTransparent;
import cn.axeon.event.block.BlockSpreadEvent;
import cn.axeon.item.Item;
import cn.axeon.math.NukkitRandom;
import cn.axeon.math.Vector3;
import cn.axeon.utils.BlockColor;

public class BlockMycelium
extends BlockSolid {
    public BlockMycelium() {
        this(0);
    }

    public BlockMycelium(int meta) {
        super(0);
    }

    @Override
    public String getName() {
        return "Mycelium";
    }

    @Override
    public int getId() {
        return 110;
    }

    @Override
    public int getToolType() {
        return 2;
    }

    @Override
    public double getHardness() {
        return 0.6;
    }

    @Override
    public int[][] getDrops(Item item) {
        return new int[][]{{3, 0, 1}};
    }

    @Override
    public int onUpdate(int type) {
        if (type == 2) {
            NukkitRandom random = new NukkitRandom();
            this.x = random.nextRange((int)this.x - 1, (int)this.x + 1);
            this.y = random.nextRange((int)this.y - 1, (int)this.y + 1);
            this.z = random.nextRange((int)this.z - 1, (int)this.z + 1);
            Block block = this.getLevel().getBlock(new Vector3(this.x, this.y, this.z));
            if (block.getId() == 3 && block.getSide(1) instanceof BlockTransparent) {
                BlockSpreadEvent ev = new BlockSpreadEvent(block, this, new BlockMycelium());
                Server.getInstance().getPluginManager().callEvent(ev);
                if (!ev.isCancelled()) {
                    this.getLevel().setBlock(block, ev.getNewState());
                }
            }
        }
        return 0;
    }

    @Override
    public BlockColor getColor() {
        return BlockColor.GRASS_BLOCK_COLOR;
    }
}

