/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.Player;
import cn.axeon.block.Block;
import cn.axeon.block.BlockAir;
import cn.axeon.block.BlockTransparent;
import cn.axeon.blockentity.BlockEntity;
import cn.axeon.blockentity.BlockEntityChest;
import cn.axeon.item.Item;
import cn.axeon.math.AxisAlignedBB;
import cn.axeon.nbt.tag.CompoundTag;
import cn.axeon.nbt.tag.ListTag;
import cn.axeon.nbt.tag.StringTag;
import cn.axeon.nbt.tag.Tag;
import cn.axeon.utils.BlockColor;
import java.util.Map;

public class BlockChest
extends BlockTransparent {
    public BlockChest() {
        this(0);
    }

    public BlockChest(int meta) {
        super(meta);
    }

    @Override
    public boolean canBeActivated() {
        return true;
    }

    @Override
    public int getId() {
        return 54;
    }

    @Override
    public String getName() {
        return "Chest";
    }

    @Override
    public double getHardness() {
        return 2.5;
    }

    @Override
    public double getResistance() {
        return 12.5;
    }

    @Override
    public int getToolType() {
        return 4;
    }

    @Override
    public AxisAlignedBB recalculateBoundingBox() {
        return new AxisAlignedBB(this.x + 0.0625, this.y, this.z + 0.0625, this.x + 0.9375, this.y + 0.9475, this.z + 0.9375);
    }

    @Override
    public boolean place(Item item, Block block, Block target, int face, double fx, double fy, double fz, Player player) {
        int[] faces = new int[]{4, 2, 5, 3};
        BlockEntityChest chest = null;
        this.meta = faces[player != null ? player.getDirection() : 0];
        for (int side = 2; side <= 5; ++side) {
            BlockEntity blockEntity;
            Block c;
            if ((this.meta == 4 || this.meta == 5) && (side == 4 || side == 5) || (this.meta == 3 || this.meta == 2) && (side == 2 || side == 3) || !((c = this.getSide(side)) instanceof BlockChest) || c.getDamage() != this.meta || !((blockEntity = this.getLevel().getBlockEntity(c)) instanceof BlockEntityChest) || ((BlockEntityChest)blockEntity).isPaired()) continue;
            chest = (BlockEntityChest)blockEntity;
            break;
        }
        this.getLevel().setBlock(block, this, true, true);
        CompoundTag nbt = new CompoundTag("").putList(new ListTag("Items")).putString("id", "Chest").putInt("x", (int)this.x).putInt("y", (int)this.y).putInt("z", (int)this.z);
        if (item.hasCustomName()) {
            nbt.putString("CustomName", item.getCustomName());
        }
        if (item.hasCustomBlockData()) {
            Map<String, Tag> customData = item.getCustomBlockData().getTags();
            for (Map.Entry<String, Tag> tag : customData.entrySet()) {
                nbt.put(tag.getKey(), tag.getValue());
            }
        }
        BlockEntityChest blockEntity = new BlockEntityChest(this.getLevel().getChunk((int)this.x >> 4, (int)this.z >> 4), nbt);
        if (chest != null) {
            chest.pairWith(blockEntity);
            blockEntity.pairWith(chest);
        }
        return true;
    }

    @Override
    public boolean onBreak(Item item) {
        BlockEntity t = this.getLevel().getBlockEntity(this);
        if (t instanceof BlockEntityChest) {
            ((BlockEntityChest)t).unpair();
        }
        this.getLevel().setBlock(this, new BlockAir(), true, true);
        return true;
    }

    @Override
    public boolean onActivate(Item item, Player player) {
        if (player != null) {
            BlockEntityChest chest;
            Block top = this.getSide(1);
            if (!top.isTransparent()) {
                return true;
            }
            BlockEntity t = this.getLevel().getBlockEntity(this);
            if (t instanceof BlockEntityChest) {
                chest = (BlockEntityChest)t;
            } else {
                CompoundTag nbt = new CompoundTag("").putList(new ListTag("Items")).putString("id", "Chest").putInt("x", (int)this.x).putInt("y", (int)this.y).putInt("z", (int)this.z);
                chest = new BlockEntityChest(this.getLevel().getChunk((int)this.x >> 4, (int)this.z >> 4), nbt);
            }
            if (chest.namedTag.contains("Lock") && chest.namedTag.get("Lock") instanceof StringTag && !chest.namedTag.getString("Lock").equals(item.getCustomName())) {
                return true;
            }
            player.addWindow(chest.getInventory());
        }
        return true;
    }

    @Override
    public int[][] getDrops(Item item) {
        return new int[][]{{this.getId(), 0, 1}};
    }

    @Override
    public BlockColor getColor() {
        return BlockColor.WOOD_BLOCK_COLOR;
    }
}

