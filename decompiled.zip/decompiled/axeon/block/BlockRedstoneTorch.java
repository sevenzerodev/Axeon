/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.Player;
import cn.axeon.block.Block;
import cn.axeon.block.BlockAir;
import cn.axeon.block.BlockFence;
import cn.axeon.block.BlockTorch;
import cn.axeon.item.Item;
import cn.axeon.redstone.Redstone;

public class BlockRedstoneTorch
extends BlockTorch {
    public BlockRedstoneTorch() {
        this(0);
    }

    public BlockRedstoneTorch(int meta) {
        super(meta);
        this.setPowerSource(true);
        this.setPowerLevel(16);
    }

    @Override
    public String getName() {
        return "Redstone Torch";
    }

    @Override
    public int getId() {
        return 76;
    }

    @Override
    public int getLightLevel() {
        return 7;
    }

    @Override
    public boolean place(Item item, Block block, Block target, int face, double fx, double fy, double fz, Player player) {
        Block below = this.getSide(0);
        if (!target.isTransparent() && face != 0) {
            int[] faces = new int[]{0, 5, 4, 3, 2, 1};
            this.meta = faces[face];
            this.getLevel().setBlock(block, this, true, true);
            Redstone.active(this);
            return true;
        }
        if (!below.isTransparent() || below instanceof BlockFence || below.getId() == 139) {
            this.meta = 0;
            this.getLevel().setBlock(block, this, true, true);
            Redstone.active(this);
            return true;
        }
        return false;
    }

    @Override
    public boolean onBreak(Item item) {
        int level = this.getPowerLevel();
        this.getLevel().setBlock(this, new BlockAir(), true, true);
        Redstone.deactive(this, level);
        return true;
    }
}

