/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.Player;
import cn.axeon.block.Block;
import cn.axeon.block.BlockAir;
import cn.axeon.block.BlockTransparent;
import cn.axeon.item.Item;
import cn.axeon.math.AxisAlignedBB;
import cn.axeon.utils.BlockColor;

public class BlockBed
extends BlockTransparent {
    public BlockBed() {
        this(0);
    }

    public BlockBed(int meta) {
        super(meta);
    }

    @Override
    public int getId() {
        return 26;
    }

    @Override
    public boolean canBeActivated() {
        return true;
    }

    @Override
    public double getResistance() {
        return 1.0;
    }

    @Override
    public double getHardness() {
        return 0.2;
    }

    @Override
    public String getName() {
        return "Bed Block";
    }

    @Override
    protected AxisAlignedBB recalculateBoundingBox() {
        return new AxisAlignedBB(this.x, this.y, this.z, this.x + 1.0, this.y + 0.5625, this.z + 1.0);
    }

    @Override
    public boolean onActivate(Item item) {
        return this.onActivate(item, null);
    }

    @Override
    public boolean onActivate(Item item, Player player) {
        Block b;
        boolean isNight;
        int time = this.getLevel().getTime() % 24000;
        boolean bl = isNight = time >= 14000 && time < 23000;
        if (player != null && !isNight) {
            player.sendMessage("\u00a77You can only sleep at night");
            return true;
        }
        Block blockNorth = this.getSide(2);
        Block blockSouth = this.getSide(3);
        Block blockEast = this.getSide(5);
        Block blockWest = this.getSide(4);
        if ((this.meta & 8) == 8) {
            b = this;
        } else if (blockNorth.getId() == this.getId() && (blockNorth.meta & 8) == 8) {
            b = blockNorth;
        } else if (blockSouth.getId() == this.getId() && (blockSouth.meta & 8) == 8) {
            b = blockSouth;
        } else if (blockEast.getId() == this.getId() && (blockEast.meta & 8) == 8) {
            b = blockEast;
        } else if (blockWest.getId() == this.getId() && (blockWest.meta & 8) == 8) {
            b = blockWest;
        } else {
            if (player != null) {
                player.sendMessage("\u00a77This bed is incomplete");
            }
            return true;
        }
        if (player != null && !player.sleepOn(b)) {
            player.sendMessage("\u00a77This bed is occupied");
        }
        return true;
    }

    @Override
    public boolean place(Item item, Block block, Block target, int face, double fx, double fy, double fz) {
        return this.place(item, block, target, face, fx, fy, fz, null);
    }

    @Override
    public boolean place(Item item, Block block, Block target, int face, double fx, double fy, double fz, Player player) {
        Block down = this.getSide(0);
        if (!down.isTransparent()) {
            int[] faces = new int[]{3, 4, 2, 5};
            int d = player != null ? player.getDirection() : 0;
            Block next = this.getSide(faces[(d + 3) % 4]);
            Block downNext = this.getSide(0);
            if (next.canBeReplaced() && !downNext.isTransparent()) {
                int meta = (d + 3) % 4 & 3;
                this.getLevel().setBlock(block, Block.get(this.getId(), meta), true, true);
                this.getLevel().setBlock(next, Block.get(this.getId(), meta | 8), true, true);
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean onBreak(Item item) {
        Block blockNorth = this.getSide(2);
        Block blockSouth = this.getSide(3);
        Block blockEast = this.getSide(5);
        Block blockWest = this.getSide(4);
        if ((this.meta & 8) == 8) {
            if (blockNorth.getId() == this.getId() && blockNorth.meta != 8) {
                this.getLevel().setBlock(blockNorth, new BlockAir(), true, true);
            } else if (blockSouth.getId() == this.getId() && blockSouth.meta != 8) {
                this.getLevel().setBlock(blockSouth, new BlockAir(), true, true);
            } else if (blockEast.getId() == this.getId() && blockEast.meta != 8) {
                this.getLevel().setBlock(blockEast, new BlockAir(), true, true);
            } else if (blockWest.getId() == this.getId() && blockWest.meta != 8) {
                this.getLevel().setBlock(blockWest, new BlockAir(), true, true);
            }
        } else if (blockNorth.getId() == this.getId() && (blockNorth.meta & 8) == 8) {
            this.getLevel().setBlock(blockNorth, new BlockAir(), true, true);
        } else if (blockSouth.getId() == this.getId() && (blockSouth.meta & 8) == 8) {
            this.getLevel().setBlock(blockSouth, new BlockAir(), true, true);
        } else if (blockEast.getId() == this.getId() && (blockEast.meta & 8) == 8) {
            this.getLevel().setBlock(blockEast, new BlockAir(), true, true);
        } else if (blockWest.getId() == this.getId() && (blockWest.meta & 8) == 8) {
            this.getLevel().setBlock(blockWest, new BlockAir(), true, true);
        }
        this.getLevel().setBlock(this, new BlockAir(), true, true);
        return true;
    }

    @Override
    public int[][] getDrops(Item item) {
        return new int[][]{{355, 0, 1}};
    }

    @Override
    public BlockColor getColor() {
        return BlockColor.CLOTH_BLOCK_COLOR;
    }
}

