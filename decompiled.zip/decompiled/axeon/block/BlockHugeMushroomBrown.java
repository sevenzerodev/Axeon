/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.block.BlockSolid;
import cn.axeon.item.Item;
import cn.axeon.math.NukkitRandom;

public class BlockHugeMushroomBrown
extends BlockSolid {
    public BlockHugeMushroomBrown() {
        this(0);
    }

    public BlockHugeMushroomBrown(int meta) {
        super(meta);
    }

    @Override
    public String getName() {
        return "Brown Mushroom Block";
    }

    @Override
    public int getId() {
        return 99;
    }

    @Override
    public int getToolType() {
        return 4;
    }

    @Override
    public double getHardness() {
        return 0.2;
    }

    @Override
    public double getResistance() {
        return 1.0;
    }

    @Override
    public int[][] getDrops(Item item) {
        if (new NukkitRandom().nextRange(1, 20) == 0) {
            return new int[][]{{39, this.meta & 3, 1}};
        }
        return new int[0][];
    }
}

