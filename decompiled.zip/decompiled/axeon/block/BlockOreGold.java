/*
 * Decompiled with CFR 0.152.
 */
package cn.axeon.block;

import cn.axeon.block.BlockSolid;
import cn.axeon.item.Item;

public class BlockOreGold
extends BlockSolid {
    public BlockOreGold() {
        this(0);
    }

    public BlockOreGold(int meta) {
        super(0);
    }

    @Override
    public int getId() {
        return 14;
    }

    @Override
    public double getHardness() {
        return 3.0;
    }

    @Override
    public double getResistance() {
        return 15.0;
    }

    @Override
    public int getToolType() {
        return 3;
    }

    @Override
    public String getName() {
        return "Gold Ore";
    }

    @Override
    public int[][] getDrops(Item item) {
        if (item.isPickaxe() && item.getTier() >= 4) {
            return new int[][]{{14, 0, 1}};
        }
        return new int[0][];
    }
}

